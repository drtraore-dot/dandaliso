import React, { useState, useEffect } from "react";
import { Printer, X } from "lucide-react";
import { db } from "@/db";
import { getPrintSettings, renderPrintHeader, renderPrintFooter } from "@/lib/printSettings";

interface Medicament {
  brandName: string;
  dci: string;
  dosage: string;
  form: string;
  quantity: number;
  frequency: string;
  duration: string;
}

interface Structure {
  nom_clinique: string;
  type_structure: string;
  adresse: string;
  telephone: string;
}

interface OrdonnancePreviewProps {
  patientNom: string;
  age?: number;
  sexe?: "M" | "F";
  medecinNom: string;
  date: string;
  diagnostic?: string;
  conseils?: string;
  medicaments: Medicament[];
  structure: Structure;
  onClose: () => void;
}

const OrdonnancePreview: React.FC<OrdonnancePreviewProps> = ({
  patientNom,
  age,
  sexe,
  medecinNom,
  date,
  diagnostic,
  conseils,
  medicaments,
  structure,
  onClose,
}) => {
  const escapeHtml = (value: any) =>
    String(value ?? "")
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;")
      .replace(/'/g, "&#039;");

  const handlePrint = async () => {
    const printSettings = await getPrintSettings();
    const medecinClean = (medecinNom || "").replace(/^Dr\.?\s*/i, "");
    const medsHtml = medicaments.length
      ? medicaments
          .map(
            (med, idx) => `
              <div class="med">
                <div class="med-title"><span class="num">${idx + 1}</span> ${escapeHtml(med.brandName)} ${med.dosage ? `(${escapeHtml(med.dosage)})` : ""}</div>
                <div class="med-sub">DCI: ${escapeHtml(med.dci || "N/A")} - ${escapeHtml(med.form || "")}</div>
                <div class="med-pos">Qté: ${escapeHtml(med.quantity || 1)} &nbsp; | &nbsp; Posologie: ${escapeHtml(med.frequency || "")} &nbsp; | &nbsp; Durée: ${escapeHtml(med.duration || "")}</div>
              </div>`,
          )
          .join("")
      : '<p class="muted">Aucun médicament prescrit.</p>';

    const printContent = `
      <html>
        <head>
          <title>Ordonnance - ${escapeHtml(patientNom)}</title>
          <style>
            @page { size: A5 portrait; margin: 10mm; }
            body { font-family: Arial, sans-serif; color:#111827; font-size: 10pt; }
            .print-logo-wrap { flex:0 0 auto; }
            .print-logo { width:52px; height:52px; object-fit:contain; display:block; }
            .print-header-main { flex:1; }
            .print-header-block { display:flex; align-items:center; justify-content:center; gap:10px; text-align:center; border-bottom:3px double #0f766e; padding-bottom:8px; margin-bottom:14px; }
            .print-clinic-name { font-size:16pt; color:#0f766e; font-weight:700; text-transform:uppercase; letter-spacing:1px; }
            .print-clinic-sub, .print-custom-header { font-size:8pt; color:#64748b; margin:2px 0; line-height:1.25; }
            .print-doc-title { font-size:8pt; color:#64748b; margin-top:4px; }
            .small { font-size:8pt; color:#64748b; margin:2px 0; }
            h1 { text-align:center; font-size:15pt; letter-spacing:4px; text-transform:uppercase; margin:12px 0 4px; }
            .meta { display:flex; justify-content:space-between; gap:12px; margin:14px 0; line-height:1.45; }
            .box { background:#f8fafc; border-left:3px solid #0f766e; padding:7px 10px; margin:10px 0; }
            .label { font-size:7pt; text-transform:uppercase; letter-spacing:1.5px; color:#0f766e; font-weight:700; margin:0 0 3px; }
            .rx-title { border-bottom:1px solid #e2e8f0; padding-bottom:4px; text-transform:uppercase; font-weight:700; color:#475569; letter-spacing:1.5px; }
            .med { margin:10px 0; padding-bottom:8px; border-bottom:1px dashed #cbd5e1; }
            .med-title { font-size:11pt; font-weight:700; color:#0f766e; }
            .num { display:inline-block; width:18px; height:18px; line-height:18px; text-align:center; background:#0f766e; color:white; border-radius:50%; font-size:8pt; margin-right:5px; }
            .med-sub { margin-left:27px; color:#64748b; font-size:8pt; font-style:italic; }
            .med-pos { margin-left:27px; color:#1f2937; font-size:9pt; margin-top:3px; }
            .advice { background:#fffbeb; border:1px solid #fcd34d; padding:7px 10px; margin-top:12px; }
            .sig { margin-top:35px; text-align:right; }
            .line { display:inline-block; min-width:160px; border-top:1px solid #111; text-align:center; padding-top:5px; font-weight:600; }
            .footer, .print-footer-block { margin-top:20px; text-align:center; font-size:7pt; color:#64748b; border-top:1px solid #cbd5e1; padding-top:5px; }
            .muted { color:#64748b; font-style:italic; }
          </style>
        </head>
        <body>
          ${renderPrintHeader(printSettings, 'Ordonnance médicale')}
          <h1>Ordonnance médicale</h1>
          <p class="small" style="text-align:center">N° ORD-${Date.now().toString(36).toUpperCase().slice(-6)}</p>
          <div class="meta">
            <div><strong>Patient:</strong> <strong>${escapeHtml(patientNom)}</strong><br/>${age !== undefined ? `<strong>Âge:</strong> ${escapeHtml(age)} ans<br/>` : ""}${sexe ? `<strong>Sexe:</strong> ${sexe === "M" ? "Masculin" : "Féminin"}<br/>` : ""}</div>
            <div style="text-align:right"><strong>Médecin:</strong> Dr. ${escapeHtml(medecinClean)}<br/><strong>Date:</strong> ${escapeHtml(date)}</div>
          </div>
          ${diagnostic ? `<div class="box"><p class="label">Diagnostic</p>${escapeHtml(diagnostic)}</div>` : ""}
          <div class="rx-title">Prescription</div>
          ${medsHtml}
          ${conseils ? `<div class="advice"><p class="label" style="color:#b45309">Conseils au patient</p>${escapeHtml(conseils)}</div>` : ""}
          <div class="sig"><p class="small">Signature et cachet du médecin</p><span class="line">Dr. ${escapeHtml(medecinClean)}</span></div>
          ${renderPrintFooter(printSettings)}
          <script>window.onload=function(){setTimeout(function(){window.print();},300);};</script>
        </body>
      </html>`;

    if (window.DANDALI_PRINT?.previewHtml) {
      window.DANDALI_PRINT.previewHtml(printContent);
    } else {
      const win = window.open("", "_blank");
      if (win) { win.document.write(printContent); win.document.close(); }
    }
  };

  const medecinDisplay = (medecinNom || "").replace(/^Dr\.?\s*/i, "");

  return (
    <div className="fixed inset-0 z-50 bg-black/50 flex items-center justify-center p-4">
      <div className="bg-white rounded-xl max-w-2xl w-full max-h-[90vh] overflow-hidden shadow-2xl">
        <div className="flex items-center justify-between p-4 border-b bg-slate-50">
          <h3 className="font-bold text-lg text-slate-800">
            Apercu de l'ordonnance
          </h3>
          <div className="flex items-center gap-2">
            <button
              onClick={handlePrint}
              className="bg-teal-600 hover:bg-teal-700 text-white px-4 py-2 rounded-md flex items-center"
            >
              <Printer className="w-4 h-4 mr-1" /> Imprimer
            </button>
            <button
              onClick={onClose}
              className="p-2 hover:bg-slate-200 rounded-full"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        <div className="overflow-y-auto max-h-[calc(90vh-70px)] p-5 bg-white">
          <div
            style={{
              textAlign: "center",
              borderBottom: "3px double #0f766e",
              paddingBottom: "10px",
              marginBottom: "14px",
            }}
          >
            <h1
              style={{
                fontSize: "16pt",
                color: "#0f766e",
                margin: "0 0 3px 0",
                fontWeight: 700,
                letterSpacing: "2px",
                textTransform: "uppercase",
              }}
            >
              {structure.nom_clinique}
            </h1>
            <p
              style={{
                fontSize: "9pt",
                color: "#555",
                fontStyle: "italic",
                margin: 0,
                lineHeight: 1.2,
              }}
            >
              {structure.type_structure}
            </p>
            {structure.adresse && (
              <p
                style={{
                  fontSize: "7.5pt",
                  color: "#777",
                  margin: "3px 0 0 0",
                }}
              >
                {structure.adresse}
              </p>
            )}
            {structure.telephone && (
              <p style={{ fontSize: "7.5pt", color: "#777", margin: 0 }}>
                Tel: {structure.telephone}
              </p>
            )}
          </div>

          <div style={{ textAlign: "center", margin: "14px 0" }}>
            <h2
              style={{
                fontSize: "14pt",
                color: "#1a1a1a",
                margin: 0,
                fontWeight: 600,
                letterSpacing: "5px",
                textTransform: "uppercase",
              }}
            >
              Ordonnance Medicale
            </h2>
            <p style={{ fontSize: "7.5pt", color: "#888", marginTop: "3px" }}>
              No ORD-{Date.now().toString(36).toUpperCase().slice(-6)}
            </p>
          </div>

          <div
            style={{
              display: "flex",
              justifyContent: "space-between",
              marginBottom: "12px",
              fontSize: "9pt",
              lineHeight: 1.4,
            }}
          >
            <div>
              <strong>Patient:</strong> <strong>{patientNom}</strong>
              <br />
              {age !== undefined && (
                <>
                  <strong>Age:</strong> {age} ans
                  <br />
                </>
              )}
              {sexe && (
                <>
                  <strong>Sexe:</strong> {sexe === "M" ? "Masculin" : "Feminin"}
                  <br />
                </>
              )}
            </div>
            <div style={{ textAlign: "right" }}>
              <strong>Medecin:</strong> <strong>Dr. {medecinDisplay}</strong>
              <br />
              <strong>Date:</strong> {date}
            </div>
          </div>

          <hr
            style={{
              border: "none",
              borderTop: "1px solid #ddd",
              margin: "8px 0",
            }}
          />

          {diagnostic && (
            <div
              style={{
                background: "#f8fafc",
                borderLeft: "3px solid #0f766e",
                padding: "6px 10px",
                marginBottom: "12px",
                borderRadius: "0 4px 4px 0",
              }}
            >
              <p
                style={{
                  fontSize: "7pt",
                  textTransform: "uppercase",
                  letterSpacing: "2px",
                  color: "#0f766e",
                  fontWeight: 700,
                  marginBottom: "2px",
                }}
              >
                Diagnostic
              </p>
              <p
                style={{
                  fontSize: "9pt",
                  color: "#1a1a1a",
                  fontStyle: "italic",
                  margin: 0,
                  lineHeight: 1.3,
                }}
              >
                {diagnostic}
              </p>
            </div>
          )}

          <div>
            <p
              style={{
                fontSize: "8pt",
                textTransform: "uppercase",
                letterSpacing: "2px",
                color: "#555",
                fontWeight: 600,
                marginBottom: "10px",
                borderBottom: "1px solid #e2e8f0",
                paddingBottom: "4px",
              }}
            >
              Prescription
            </p>
            {medicaments.map((med, idx) => (
              <div
                key={idx}
                style={{
                  marginBottom: "10px",
                  paddingBottom: "8px",
                  borderBottom:
                    idx < medicaments.length - 1
                      ? "1px dashed #cbd5e1"
                      : "none",
                }}
              >
                <div>
                  <span
                    style={{
                      display: "inline-flex",
                      alignItems: "center",
                      justifyContent: "center",
                      width: "20px",
                      height: "20px",
                      background: "#0f766e",
                      color: "#fff",
                      borderRadius: "50%",
                      fontSize: "8pt",
                      fontWeight: 700,
                      marginRight: "8px",
                    }}
                  >
                    {idx + 1}
                  </span>
                  <span
                    style={{
                      fontSize: "11pt",
                      fontWeight: 700,
                      color: "#0f766e",
                    }}
                  >
                    {med.brandName}
                  </span>
                </div>
                <p
                  style={{
                    fontSize: "8pt",
                    color: "#666",
                    fontStyle: "italic",
                    margin: "1px 0 0 28px",
                  }}
                >
                  {med.dci} - {med.dosage} - {med.form}
                </p>
                <div
                  style={{
                    fontSize: "9pt",
                    color: "#333",
                    margin: "3px 0 0 28px",
                  }}
                >
                  {med.quantity > 0 && (
                    <span>
                      <strong>Qté:</strong> {med.quantity} {med.form}(s)
                      &nbsp;&nbsp;
                    </span>
                  )}
                  {med.frequency && (
                    <span>
                      <strong>Pos:</strong> {med.frequency} &nbsp;&nbsp;
                    </span>
                  )}
                  {med.duration && (
                    <span>
                      <strong>Durée:</strong> {med.duration}
                    </span>
                  )}
                </div>
              </div>
            ))}
            {medicaments.length === 0 && (
              <p
                style={{ fontSize: "10pt", color: "#888", fontStyle: "italic" }}
              >
                Aucun medicament prescrit.
              </p>
            )}
          </div>

          {conseils && (
            <div
              style={{
                background: "#fffbeb",
                border: "1px solid #fcd34d",
                padding: "6px 10px",
                marginTop: "12px",
                borderRadius: "4px",
              }}
            >
              <p
                style={{
                  fontSize: "7pt",
                  textTransform: "uppercase",
                  letterSpacing: "2px",
                  color: "#b45309",
                  fontWeight: 700,
                  marginBottom: "2px",
                }}
              >
                Conseils au patient
              </p>
              <p
                style={{
                  fontSize: "8.5pt",
                  color: "#444",
                  fontStyle: "italic",
                  margin: 0,
                  lineHeight: 1.3,
                }}
              >
                {conseils}
              </p>
            </div>
          )}

          <div style={{ marginTop: "35px", textAlign: "right" }}>
            <p
              style={{ fontSize: "7.5pt", color: "#888", marginBottom: "30px" }}
            >
              Signature et cachet du medecin
            </p>
            <span
              style={{
                display: "inline-block",
                width: "160px",
                borderTop: "1px solid #333",
                paddingTop: "4px",
                fontSize: "9pt",
                fontWeight: 600,
                color: "#1a1a1a",
                textAlign: "center",
              }}
            >
              Dr. {medecinDisplay}
            </span>
          </div>
        </div>
      </div>
    </div>
  );
};

export default OrdonnancePreview;
