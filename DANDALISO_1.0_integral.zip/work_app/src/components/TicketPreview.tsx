import React, { useState, useEffect } from 'react';
import { Printer, X } from 'lucide-react';
import { db } from '@/db';

interface TicketData {
  id: number;
  date: string;
  patient_nom: string;
  prescripteur_nom?: string;
  prestataire_nom?: string;
  libelle: string;
  quantite: number;
  prix_unitaire: number;
  montant: number;
  mode_paiement: string;
  reference_paiement?: string;
  isCredit?: boolean;
  montant_avance?: number;
  montant_restant?: number;
}

interface ClinicInfo {
  nom_clinique: string;
  type_structure: string;
  adresse: string;
  telephone: string;
}

interface TicketPreviewProps {
  ticket: TicketData;
  clinicInfo: ClinicInfo;
  onClose: () => void;
}

export const TicketPreview: React.FC<TicketPreviewProps> = ({ ticket, clinicInfo, onClose }) => {
  const formattedDate = new Date(ticket.date).toLocaleString('fr-FR');
  const ticketId = `TK-${String(ticket.id || Date.now()).slice(-6)}`;
  const quantity = ticket.quantite || 1;
  const unitPrice = ticket.prix_unitaire || ticket.montant;

  const handlePrint = () => {
    const printContent = `
      <html>
        <head>
          <style>
            body { font-family: sans-serif; padding: 20px; }
            .ftr { margin-top: 20px; text-align: center; color: #94a3b8; font-size: 8pt; border-top: 1px solid #e2e8f0; padding-top: 8px; }
          </style>
        </head>
        <body>
          <div class="content">
            <h1>Recu: ${ticketId}</h1>
            <p>Patient: ${ticket.patient_nom}</p>
            <p>Montant: ${ticket.montant.toLocaleString()} FCFA</p>
          </div>
          <div class="ftr">
            <p>${clinicInfo.nom_clinique} - ${clinicInfo.adresse}</p>
            <p>Ce recu est un justificatif de paiement. Conservez-le.</p>
            <p>Tel: ${clinicInfo.telephone}</p>
          </div>
          <script>window.onload=function(){setTimeout(function(){window.print();},300);};</script>
        </body>
      </html>
    `;
    if (window.DANDALI_PRINT?.previewHtml) {
      window.DANDALI_PRINT.previewHtml(printContent);
    } else {
      const win = window.open("", "_blank");
      if (win) { win.document.write(printContent); win.document.close(); }
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/50 flex items-center justify-center p-4">
      <div className="bg-white rounded-xl max-w-md w-full max-h-[90vh] overflow-hidden shadow-2xl">
        <div className="flex items-center justify-between p-4 border-b bg-slate-50">
          <h3 className="font-bold text-lg">Recu de paiement</h3>
          <div className="flex items-center gap-2">
            <button onClick={handlePrint} className="bg-teal-600 hover:bg-teal-700 text-white px-3 py-1.5 rounded flex items-center text-sm">
              <Printer className="w-4 h-4 mr-1" /> Imprimer
            </button>
            <button onClick={onClose} className="p-1 hover:bg-slate-200 rounded">
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        <div className="overflow-y-auto max-h-[calc(90vh-70px)] p-5 bg-white">
          <div className="text-center" style={{ borderBottom: "3px double #0f766e", paddingBottom: "10px", marginBottom: "14px" }}>
            <h1 style={{ fontSize: "16pt", color: "#0f766e", margin: "0 0 3px 0", fontWeight: 700, letterSpacing: "2px", textTransform: "uppercase" }}>
              {clinicInfo.nom_clinique}
            </h1>
            <p style={{ fontSize: "9pt", color: "#555", fontStyle: "italic", margin: 0 }}>{clinicInfo.type_structure}</p>
            {clinicInfo.adresse && <p style={{ fontSize: "8pt", color: "#777", margin: "2px 0 0 0" }}>{clinicInfo.adresse}</p>}
            {clinicInfo.telephone && <p style={{ fontSize: "8pt", color: "#777", margin: 0 }}>Tel: {clinicInfo.telephone}</p>}
          </div>

          <div style={{ textAlign: "center", margin: "10px 0" }}>
            <h2 style={{ fontSize: "14pt", color: "#1a1a1a", margin: 0, fontWeight: 600, letterSpacing: "5px", textTransform: "uppercase" }}>Recu de paiement</h2>
            <p style={{ fontSize: "8pt", color: "#888", marginTop: "3px" }}>No {ticketId}</p>
          </div>

          <div style={{ display: "flex", justifyContent: "space-between", marginBottom: "12px", fontSize: "9pt", lineHeight: 1.5 }}>
            <div>
              <strong>Patient:</strong> <strong>{ticket.patient_nom || "N/A"}</strong><br />
              {ticket.prescripteur_nom && <><strong>Prescripteur:</strong> {ticket.prescripteur_nom}<br /></>}
              {ticket.prestataire_nom && <><strong>Prestataire:</strong> {ticket.prestataire_nom}<br /></>}
            </div>
            <div style={{ textAlign: "right" }}>
              <strong>Date:</strong> {formattedDate}<br />
              <strong>Mode:</strong> {ticket.mode_paiement}<br />
              {ticket.reference_paiement && <><strong>Ref:</strong> {ticket.reference_paiement}<br /></>}
            </div>
          </div>

          <hr style={{ border: "none", borderTop: "2px solid #333", margin: "8px 0" }} />

          <table style={{ width: "100%", borderCollapse: "collapse", fontSize: "9.5pt", margin: "10px 0" }}>
            <thead>
              <tr style={{ background: "#f1f5f9" }}>
                <th style={{ textAlign: "left", padding: "6px 8px", borderBottom: "2px solid #cbd5e1", fontWeight: 600 }}>Acte</th>
                <th style={{ textAlign: "center", padding: "6px 8px", borderBottom: "2px solid #cbd5e1", fontWeight: 600 }}>Qte</th>
                <th style={{ textAlign: "right", padding: "6px 8px", borderBottom: "2px solid #cbd5e1", fontWeight: 600 }}>Prix unit.</th>
                <th style={{ textAlign: "right", padding: "6px 8px", borderBottom: "2px solid #cbd5e1", fontWeight: 600 }}>Total</th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <td style={{ padding: "6px 8px", borderBottom: "1px solid #e2e8f0" }}>{ticket.libelle}</td>
                <td style={{ padding: "6px 8px", borderBottom: "1px solid #e2e8f0", textAlign: "center" }}>{quantity}</td>
                <td style={{ padding: "6px 8px", borderBottom: "1px solid #e2e8f0", textAlign: "right" }}>{unitPrice.toLocaleString()} FCFA</td>
                <td style={{ padding: "6px 8px", borderBottom: "1px solid #e2e8f0", textAlign: "right", fontWeight: 600 }}>{ticket.montant.toLocaleString()} FCFA</td>
              </tr>
            </tbody>
          </table>

          {ticket.isCredit && (
            <div style={{ background: "#fffbeb", border: "1px solid #fcd34d", padding: "8px 12px", margin: "10px 0", borderRadius: "4px", fontSize: "9pt" }}>
              <strong>Paiement en credit</strong><br />
              Avance: {(ticket.montant_avance || 0).toLocaleString()} FCFA | Restant: {(ticket.montant_restant || 0).toLocaleString()} FCFA
            </div>
          )}

          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", fontSize: "13pt", fontWeight: "bold", padding: "10px 0", margin: "10px 0", borderTop: "2px solid #333", borderBottom: "2px solid #333" }}>
            <span>TOTAL A PAYER</span>
            <span>{ticket.montant.toLocaleString()} FCFA</span>
          </div>

          <div style={{ marginTop: "40px", display: "flex", justifyContent: "space-between" }}>
            <div style={{ textAlign: "center", width: "160px" }}>
              <p style={{ fontSize: "8pt", color: "#888", marginBottom: "30px" }}>Signature du patient</p>
              <span style={{ display: "inline-block", width: "100%", borderTop: "1px solid #333", paddingTop: "4px", fontSize: "9pt", fontWeight: 600 }}>{ticket.patient_nom || ""}</span>
            </div>
            <div style={{ textAlign: "center", width: "160px" }}>
              <p style={{ fontSize: "8pt", color: "#888", marginBottom: "30px" }}>Signature et cachet</p>
              <span style={{ display: "inline-block", width: "100%", borderTop: "1px solid #333", paddingTop: "4px", fontSize: "9pt", fontWeight: 600 }}>{clinicInfo.nom_clinique}</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};