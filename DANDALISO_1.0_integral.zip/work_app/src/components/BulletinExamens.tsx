import React, { useState } from 'react';
import { db } from '@/db';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { toast } from 'sonner';
import {
  FlaskConical,
  Plus,
  X,
  Printer,
  FileText,
  Trash2,
  Stethoscope
} from 'lucide-react';
import { getPrintSettings, renderPrintHeader, renderPrintFooter } from '@/lib/printSettings';

interface ExamenDemande {
  id: string;
  nom: string;
  categorie: string;
  notes: string;
}

interface BulletinExamensProps {
  patientId: number;
  patientNom: string;
  patientNumero?: string;
  medecin: string;
  consultationId?: number;
  onClose: () => void;
  onSaved?: () => void;
}

const CATEGORIES_EXAMEN = [
  'Biochimie',
  'Hematologie',
  'Immunologie',
  'Bacteriologie',
  'Parasitologie',
  'Virologie',
  'Radiologie',
  'Imagerie',
  'Autre'
];

export default function BulletinExamens({
  patientId,
  patientNom,
  patientNumero,
  medecin,
  consultationId,
  onClose,
  onSaved
}: BulletinExamensProps) {
  const [examens, setExamens] = useState<ExamenDemande[]>([]);
  const [diagnostic, setDiagnostic] = useState('');
  const [motif, setMotif] = useState('');
  const [urgente, setUrgente] = useState(false);
  const [showForm, setShowForm] = useState(true);

  // Nouvel examen en cours de saisie
  const [newExamen, setNewExamen] = useState({
    nom: '',
    categorie: CATEGORIES_EXAMEN[0],
    notes: ''
  });

  const addExamen = () => {
    if (!newExamen.nom.trim()) {
      toast.error('Veuillez saisir le nom de l\'examen');
      return;
    }
    setExamens(prev => [...prev, {
      id: `exam-${Date.now()}`,
      nom: newExamen.nom.trim(),
      categorie: newExamen.categorie,
      notes: newExamen.notes.trim()
    }]);
    setNewExamen({ nom: '', categorie: CATEGORIES_EXAMEN[0], notes: '' });
  };

  const removeExamen = (id: string) => {
    setExamens(prev => prev.filter(e => e.id !== id));
  };

  const saveBulletin = async () => {
    if (examens.length === 0) {
      toast.error('Ajoutez au moins un examen au bulletin');
      return;
    }

    try {
      const bulletinId = await db.bulletins_examens.add({
        patient_id: patientId,
        consultation_id: consultationId || null,
        medecin,
        examens_demandes: examens,
        diagnostic,
        motif,
        urgente,
        statut: 'en_attente',
        created_at: new Date(),
        updated_at: new Date()
      });

      // Creer aussi des entrees dans examensLaboratoire pour compatibilite
      for (const exam of examens) {
        await db.examensLaboratoire.add({
          patient_id: patientId,
          consultation_id: consultationId || null,
          bulletin_id: bulletinId,
          type_analyse: exam.nom,
          sous_categorie: exam.categorie,
          status: 'demande',
          notes_demande: exam.notes,
          created_at: new Date()
        });
      }

      toast.success('Bulletin de demande d\'examens enregistre');
      setShowForm(false);
      onSaved?.();
    } catch (err) {
      console.error(err);
      toast.error('Erreur lors de l\'enregistrement du bulletin');
    }
  };

  const printBulletin = async () => {
    if (examens.length === 0) {
      toast.error('Ajoutez au moins un examen pour imprimer');
      return;
    }

    const printSettings = await getPrintSettings();
    const dateStr = new Date().toLocaleString('fr-FR');

    const examensHTML = examens.map((ex, idx) => `
      <tr>
        <td style="border:1px solid #cbd5e1;padding:8px;text-align:center">${idx + 1}</td>
        <td style="border:1px solid #cbd5e1;padding:8px;font-weight:bold">${ex.nom}</td>
        <td style="border:1px solid #cbd5e1;padding:8px">${ex.categorie}</td>
        <td style="border:1px solid #cbd5e1;padding:8px;font-size:9pt">${ex.notes || '-'}</td>
      </tr>
    `).join('');

    const printContent = `
      <!DOCTYPE html>
      <html>
        <head>
          <title>Bulletin de Demande d'Examens - ${patientNom}</title>
          <style>
            @page { size: A5 portrait; margin: 8mm; }
            body { font-family: Arial, sans-serif; padding: 10px; color: #1e293b; background: white; font-size: 9pt; line-height: 1.35; }
            .print-logo-wrap { flex:0 0 auto; }
            .print-logo { width:52px; height:52px; object-fit:contain; display:block; }
            .print-header-main { flex:1; }
            .print-header-block { display: flex; justify-content: space-between; align-items: start; border-bottom: 2px solid #0f766e; padding-bottom: 8px; margin-bottom: 15px; }
            .print-clinic-name { font-size: 14pt; font-weight: 800; color: #0f766e; text-transform: uppercase; }
            .print-clinic-sub, .print-custom-header { font-size: 8pt; color: #64748b; line-height:1.3; }
            .print-doc-title { font-size:9pt; text-align:right; color:#64748b; max-width:200px; }
            .print-footer-block { border-top: 1px solid #cbd5e1; margin-top: 20px; padding-top: 6px; text-align:center; font-size:8pt; color:#64748b; }
            .document-title { text-align: center; margin: 12px 0; font-size: 12pt; font-weight: bold; color: #0f766e; border-bottom: 2px double #0f766e; display: inline-block; padding-bottom: 5px; width: 100%; text-transform: uppercase; letter-spacing: 2px; }
            .info-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 10px; margin-bottom: 20px; padding: 10px; background: #f8fafc; border-radius: 6px; border: 1px solid #cbd5e1; }
            .info-grid h4 { margin: 0 0 8px 0; color: #0f766e; border-bottom: 1px solid #cbd5e1; padding-bottom: 3px; font-weight: bold; text-transform: uppercase; font-size: 10pt; }
            table { width: 100%; border-collapse: collapse; margin: 15px 0; font-size: 10pt; }
            th { background-color: #0f766e; color: white; font-weight: 600; text-align: left; padding: 8px; border: 1px solid #0f766e; }
            td { padding: 8px; border: 1px solid #cbd5e1; }
            .urgence-badge { display: inline-block; padding: 4px 12px; background: #ef4444; color: white; font-weight: bold; border-radius: 4px; text-transform: uppercase; font-size: 9pt; }
            .normal-badge { display: inline-block; padding: 4px 12px; background: #0f766e; color: white; font-weight: bold; border-radius: 4px; text-transform: uppercase; font-size: 9pt; }
            .signatures { display: flex; justify-content: space-between; margin-top: 50px; }
            .sign-box { text-align: center; width: 200px; }
            .sign-line { border-top: 1px solid #cbd5e1; margin-top: 50px; padding-top: 5px; font-weight: bold; color: #475569; }
          </style>
        </head>
        <body>
          ${renderPrintHeader(printSettings, `Ref: BUL-${Date.now().toString().slice(-6)} | Date: ${new Date().toLocaleDateString('fr-FR')}`)}

          <div class="document-title">Bulletin de Demande d'Examens Complementaires</div>

          ${urgente ? '<div style="text-align:center;margin-bottom:15px"><span class="urgence-badge">URGENT - PRIORITAIRE</span></div>' : '<div style="text-align:center;margin-bottom:15px"><span class="normal-badge">Demande standard</span></div>'}

          <div class="info-grid">
            <div>
              <h4>INFORMATIONS PATIENT</h4>
              <strong>Nom :</strong> ${patientNom}<br/>
              <strong>N° Patient :</strong> ${patientNumero || 'N/A'}<br/>
              <strong>Date :</strong> ${dateStr}
            </div>
            <div>
              <h4>MEDECIN DEMANDEUR</h4>
              <strong>Dr. :</strong> ${medecin}<br/>
              ${diagnostic ? `<strong>Diagnostic :</strong> ${diagnostic}<br/>` : ''}
              ${motif ? `<strong>Motif :</strong> ${motif}` : ''}
            </div>
          </div>

          <table>
            <thead>
              <tr>
                <th style="width:40px">N°</th>
                <th>Examen demande</th>
                <th style="width:120px">Categorie</th>
                <th>Notes / Precisions</th>
              </tr>
            </thead>
            <tbody>
              ${examensHTML}
            </tbody>
          </table>

          <div style="margin-top:20px;padding:10px;background:#f0fdf4;border:1px solid #bbf7d0;border-radius:6px">
            <strong style="color:#166534">Instructions pour le laboratoire :</strong>
            <p style="margin:5px 0 0 0;color:#334155">Veuillez realiser les examens ci-dessus et saisir les resultats dans le systeme. En cas d'anomalie, contacter le medecin prescripteur.</p>
          </div>

          <div class="signatures">
            <div class="sign-box">
              <p style="margin:0;color:#64748b;font-style:italic;font-size:8pt">Cachet de la clinique</p>
              <div class="sign-line">Service Medical</div>
            </div>
            <div class="sign-box">
              <p style="margin:0;color:#64748b;font-style:italic;font-size:8pt">Medecin prescripteur</p>
              <div class="sign-line">Dr. ${medecin}</div>
            </div>
          </div>

          ${renderPrintFooter(printSettings)}

          <script>window.onload = function() { window.print(); }</script>
        </body>
      </html>
    `;

    if (window.DANDALI_PRINT?.previewHtml) {
      window.DANDALI_PRINT.previewHtml(printContent);
    } else {
      const win = window.open('', '_blank');
      if (win) { win.document.write(printContent); win.document.close(); }
    }
  };

  return (
    <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4">
      <div className="bg-white dark:bg-slate-800 rounded-lg shadow-xl max-w-2xl w-full max-h-[90vh] overflow-y-auto">
        <div className="flex items-center justify-between p-4 border-b">
          <h3 className="text-base font-bold text-slate-800 dark:text-white flex items-center gap-2">
            <FlaskConical className="w-5 h-5 text-blue-600" />
            Bulletin de Demande d'Examens Complementaires
          </h3>
          <button onClick={onClose} className="p-1 hover:bg-slate-100 rounded">
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-4 space-y-4">
          {/* Info patient */}
          <div className="bg-slate-50 dark:bg-slate-700 p-3 rounded-lg border flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Stethoscope className="w-4 h-4 text-teal-600" />
              <span className="text-sm font-semibold">{patientNom}</span>
              <Badge variant="outline" className="text-[10px]">{patientNumero || 'N/A'}</Badge>
            </div>
            <span className="text-xs text-slate-500">Dr. {medecin}</span>
          </div>

          {showForm ? (
            <>
              {/* Diagnostic et motif */}
              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1">
                  <Label className="text-xs">Diagnostic</Label>
                  <Input
                    value={diagnostic}
                    onChange={e => setDiagnostic(e.target.value)}
                    placeholder="Diagnostic clinique..."
                    className="text-xs"
                  />
                </div>
                <div className="space-y-1">
                  <Label className="text-xs">Motif de la demande</Label>
                  <Input
                    value={motif}
                    onChange={e => setMotif(e.target.value)}
                    placeholder="Motif..."
                    className="text-xs"
                  />
                </div>
              </div>

              {/* Urgence */}
              <label className="flex items-center gap-2 text-sm cursor-pointer">
                <input
                  type="checkbox"
                  checked={urgente}
                  onChange={e => setUrgente(e.target.checked)}
                  className="rounded text-red-600"
                />
                <span className="text-red-600 font-semibold text-xs flex items-center gap-1">
                  <FlaskConical className="w-3 h-3" /> Demande urgente / prioritaire
                </span>
              </label>

              {/* Ajout d'examens */}
              <div className="border rounded-lg p-3 space-y-3 bg-slate-50/50">
                <h4 className="text-xs font-bold text-slate-700 flex items-center gap-2">
                  <Plus className="w-3 h-3" /> Ajouter un examen
                </h4>
                <div className="grid grid-cols-2 gap-2">
                  <div className="space-y-1">
                    <Label className="text-[10px]">Nom de l'examen *</Label>
                    <Input
                      value={newExamen.nom}
                      onChange={e => setNewExamen({ ...newExamen, nom: e.target.value })}
                      placeholder="Ex: NFS, Glycemie, Radiographie..."
                      className="text-xs h-8"
                    />
                  </div>
                  <div className="space-y-1">
                    <Label className="text-[10px]">Categorie</Label>
                    <select
                      value={newExamen.categorie}
                      onChange={e => setNewExamen({ ...newExamen, categorie: e.target.value })}
                      className="w-full h-8 rounded border bg-white px-2 text-xs"
                    >
                      {CATEGORIES_EXAMEN.map(cat => <option key={cat} value={cat}>{cat}</option>)}
                    </select>
                  </div>
                </div>
                <div className="space-y-1">
                  <Label className="text-[10px]">Notes / Precisions</Label>
                  <Input
                    value={newExamen.notes}
                    onChange={e => setNewExamen({ ...newExamen, notes: e.target.value })}
                    placeholder="Instructions speciales..."
                    className="text-xs h-8"
                  />
                </div>
                <Button type="button" size="sm" onClick={addExamen} className="bg-blue-600 hover:bg-blue-700 text-white text-xs">
                  <Plus className="w-3 h-3 mr-1" /> Ajouter a la liste
                </Button>
              </div>

              {/* Liste des examens ajoutes */}
              {examens.length > 0 && (
                <div className="space-y-2">
                  <h4 className="text-xs font-bold text-slate-700 flex items-center gap-2">
                    <FileText className="w-3 h-3" /> Examens demandes ({examens.length})
                  </h4>
                  <div className="space-y-1 max-h-48 overflow-y-auto">
                    {examens.map((ex, idx) => (
                      <div key={ex.id} className="flex items-center justify-between p-2 bg-white dark:bg-slate-700 border rounded-lg">
                        <div className="flex items-center gap-2">
                          <span className="text-xs font-bold text-slate-500 w-5">{idx + 1}.</span>
                          <div>
                            <p className="text-xs font-semibold">{ex.nom}</p>
                            <p className="text-[10px] text-slate-500">{ex.categorie} {ex.notes ? `| ${ex.notes}` : ''}</p>
                          </div>
                        </div>
                        <Button
                          type="button"
                          size="sm"
                          variant="ghost"
                          onClick={() => removeExamen(ex.id)}
                          className="text-red-500 h-6 w-6 p-0"
                        >
                          <Trash2 className="w-3 h-3" />
                        </Button>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Actions */}
              <div className="flex justify-end gap-2 pt-3 border-t">
                <Button type="button" variant="outline" size="sm" onClick={onClose}>Annuler</Button>
                <Button
                  type="button"
                  size="sm"
                  variant="outline"
                  onClick={printBulletin}
                  className="border-blue-200 text-blue-700"
                  disabled={examens.length === 0}
                >
                  <Printer className="w-3 h-3 mr-1" /> Apercu & Imprimer
                </Button>
                <Button type="button" size="sm" onClick={saveBulletin} className="bg-blue-600 hover:bg-blue-700 text-white" disabled={examens.length === 0}>
                  <FlaskConical className="w-3 h-3 mr-1" /> Enregistrer le bulletin
                </Button>
              </div>
            </>
          ) : (
            <div className="text-center py-8 space-y-4">
              <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto">
                <FileText className="w-8 h-8 text-green-600" />
              </div>
              <div>
                <p className="text-lg font-semibold text-green-700">Bulletin enregistre avec succes !</p>
                <p className="text-sm text-slate-500">Le bulletin de demande d'examens a ete enregistre et peut etre consulte dans le dossier patient.</p>
              </div>
              <div className="flex justify-center gap-2">
                <Button variant="outline" size="sm" onClick={onClose}>Fermer</Button>
                <Button size="sm" onClick={printBulletin} className="bg-blue-600 hover:bg-blue-700 text-white">
                  <Printer className="w-3 h-3 mr-1" /> Imprimer
                </Button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
