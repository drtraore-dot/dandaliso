import { useState, useEffect } from 'react';
import { useLocation, useNavigate, Outlet, Link } from 'react-router-dom';
import { 
  Activity, 
  User, 
  ChevronLeft, 
  ChevronRight, 
  LogOut,
  LayoutDashboard,
  Users,
  Calendar,
  BedDouble,
  Receipt,
  Settings,
  ClipboardList,
  Stethoscope,
  HeartPulse,
  Bed,
  FlaskConical,
  CreditCard,
  ShieldCheck,
  Pill,
  Building,
  Handshake,
  ExternalLink,
  Database,
  BarChart3,
  RefreshCw,
  FolderHeart,
  LucideIcon,
  Sun,
  Moon
} from 'lucide-react';
import toast, { Toaster } from 'react-hot-toast';
import { db } from '@/db';
import { useLiveQuery } from 'dexie-react-hooks';
import { useTheme } from '@/components/theme-provider';

// Custom Auth hook interface based on minified code
interface UserProfile {
  nom?: string;
  prenom?: string;
  username?: string;
  role: string;
}

interface AuthContextType {
  user: UserProfile | null;
  logout: () => void;
}

// Mock/imported useAuth hook (replace with your actual hook location if needed)
import { useAuth } from '@/hooks/useAuth';

interface ClinicSettings {
  nom_clinique?: string;
  type_structure?: string;
}

interface NavigationItem {
  path: string;
  label: string;
  icon: LucideIcon;
  roles: string[];
}

export interface NavigationSection {
  title: string;
  items: NavigationItem[];
}

// Grouped navigation sections featuring ALL specific modules
export const navigationSections: NavigationSection[] = [
  {
    title: "Général",
    items: [
      { 
        path: '/', 
        label: 'Tableau de bord', 
        icon: LayoutDashboard, 
        roles: ['administrateur', 'medecin', 'infirmier', 'laborantin', 'caissiere', 'comptable', 'receptionniste'] 
      },
    ]
  },
  {
    title: "Dossier Patient",
    items: [
      { 
        path: '/dossier-medical', 
        label: 'Dossier Médical', 
        icon: FolderHeart, 
        roles: ['administrateur', 'medecin', 'infirmier'] 
      },
      { 
        path: '/tous-patients', 
        label: 'Tous les patients', 
        icon: Users, 
        roles: ['administrateur', 'medecin', 'infirmier', 'laborantin', 'caissiere', 'comptable', 'receptionniste'] 
      },
      { 
        path: '/rendez-vous', 
        label: 'Rendez-vous', 
        icon: Calendar, 
        roles: ['administrateur', 'medecin', 'infirmier', 'receptionniste'] 
      },
      { 
        path: '/consultations', 
        label: 'Consultations', 
        icon: Stethoscope, 
        roles: ['administrateur', 'medecin', 'infirmier'] 
      },
    ]
  },
  {
    title: "Clinique & Soins",
    items: [
      { 
        path: '/soins', 
        label: 'Soins Infirmiers', 
        icon: HeartPulse, 
        roles: ['administrateur', 'infirmier'] 
      },
      { 
        path: '/hospitalisation', 
        label: 'Hospitalisation', 
        icon: Bed, 
        roles: ['administrateur', 'medecin', 'infirmier', 'caissiere'] 
      },
      { 
        path: '/laboratoire', 
        label: 'Examens Laboratoire', 
        icon: FlaskConical, 
        roles: ['administrateur', 'medecin', 'infirmier', 'laborantin'] 
      },
    ]
  },
  {
    title: "Finance & Logistique",
    items: [
      { 
        path: '/caisse', 
        label: 'Caisse', 
        icon: Receipt, 
        roles: ['administrateur', 'comptable', 'caissiere'] 
      },
      { 
        path: '/assurances',
        label: 'Assurances',
        icon: ShieldCheck,
        roles: ['administrateur', 'comptable', 'caissiere']
      },
      { 
        path: '/depenses', 
        label: 'Dépenses', 
        icon: CreditCard, 
        roles: ['administrateur', 'comptable'] 
      },
      { 
        path: '/Actes', 
        label: 'Gestion des Actes', 
        icon: Activity, 
        roles: ['administrateur', 'comptable'] 
      },
      { 
        path: '/pharmacie', 
        label: 'Pharmacie', 
        icon: Pill, 
        roles: ['administrateur', 'medecin', 'infirmier', 'caissiere'] 
      },
      { 
        path: '/chambres', 
        label: 'Chambres', 
        icon: BedDouble, 
        roles: ['administrateur', 'infirmier', 'receptionniste'] 
      },
    ]
  },
  {
    title: "Partenaires & Logs",
    items: [
      { 
        path: '/prescripteurs', 
        label: 'Prescripteurs', 
        icon: Building, 
        roles: ['administrateur', 'comptable'] 
      },
      { 
        path: '/prestataires', 
        label: 'Prestataires', 
        icon: Handshake, 
        roles: ['administrateur', 'comptable'] 
      },
      { 
        path: '/references', 
        label: 'Références Ext.', 
        icon: ExternalLink, 
        roles: ['administrateur', 'medecin', 'infirmier'] 
      },
      { 
        path: '/base-medicaments', 
        label: 'Base Médicaments', 
        icon: Database, 
        roles: ['administrateur', 'medecin', 'infirmier'] 
      },
    ]
  },
  {
    title: "Administration",
    items: [
      { 
        path: '/rapports', 
        label: 'Rapports', 
        icon: BarChart3, 
        roles: ['administrateur', 'comptable'] 
      },
      { 
        path: '/utilisateurs', 
        label: 'Utilisateurs', 
        icon: Users, 
        roles: ['administrateur'] 
      },
      { 
        path: '/synchronisation', 
        label: 'Synchronisation', 
        icon: RefreshCw, 
        roles: ['administrateur'] 
      },
      { 
        path: '/parametres', 
        label: 'Paramètres', 
        icon: Settings, 
        roles: ['administrateur'] 
      },
    ]
  }
];

export default function Layout() {
  const [isCollapsed, setIsCollapsed] = useState(false);
  const { theme, setTheme } = useTheme();
  const clinicSettings = useLiveQuery(async () => {
    const settings = await db.parametres.toArray();
    return settings.length > 0 ? settings[settings.length - 1] : null;
  });
  const location = useLocation();
  const navigate = useNavigate();
  const { user, logout } = useAuth() as any;

  const handleLogout = () => {
    logout();
    toast.success("Déconnecté");
    navigate("/login");
  };

  const filteredSections = navigationSections
    .map(section => ({
      ...section,
      items: section.items.filter(item => item.roles.includes(user?.role || ""))
    }))
    .filter(section => section.items.length > 0);

  const clinicName = clinicSettings?.nom_clinique || "DANDALISO 1.0";

  return (
    <div className="flex h-screen bg-slate-50 dark:bg-slate-900">
      {/* Sidebar Navigation */}
      <aside
        className={`${
          isCollapsed ? "w-16" : "w-60"
        } bg-slate-800 border-r border-slate-700 flex flex-col transition-all duration-200`}
      >
        {/* Header / Logo Section */}
        <div className="h-14 flex items-center gap-2 px-3 border-b border-slate-700">
          <div className="w-8 h-8 rounded-lg bg-teal-600 flex items-center justify-center flex-shrink-0">
            <Activity className="w-4 h-4 text-white" />
          </div>
          {!isCollapsed && (
            <div className="overflow-hidden">
              <h1 className="text-sm font-bold text-white truncate">
                {(clinicSettings?.type_structure || "CLINIQUE").toUpperCase()}
              </h1>
              <p className="text-xs text-teal-400 font-semibold truncate">
                {clinicName}
              </p>
            </div>
          )}
        </div>

        {/* Navigation Items Grouped by Section */}
        <nav className="flex-1 overflow-y-auto py-3 space-y-4 px-1 pb-10">
          {filteredSections.map((section) => (
            <div key={section.title} className="space-y-1">
              {!isCollapsed && (
                <div className="px-3 text-xs font-semibold text-slate-400 uppercase tracking-wider">
                  {section.title}
                </div>
              )}
              <div className="space-y-0.5">
                {section.items.map((item) => {
                  const isActive = location.pathname === item.path;
                  return (
                    <Link
                      key={item.path}
                      to={item.path}
                      className={`flex items-center gap-3 px-3 py-2 mx-1 rounded-md text-sm transition-colors ${
                        isActive
                          ? "bg-teal-700 text-white font-semibold"
                          : "text-slate-300 hover:bg-slate-700 hover:text-white"
                      }`}
                      title={isCollapsed ? item.label : undefined}
                    >
                      <item.icon className="w-5 h-5 flex-shrink-0" />
                      {!isCollapsed && <span className="truncate">{item.label}</span>}
                    </Link>
                  );
                })}
              </div>
            </div>
          ))}
        </nav>

        {/* User Info Section */}
        {user && (
          <div className="border-t border-slate-700 p-3">
            <div className={`flex items-center gap-2 ${isCollapsed ? "justify-center" : ""}`}>
              <div className="w-8 h-8 rounded-full bg-teal-600 flex items-center justify-center flex-shrink-0">
                <User className="w-5 h-5 text-white" />
              </div>
              {!isCollapsed && (
                <div className="overflow-hidden min-w-0">
                  <p className="text-sm font-semibold text-white truncate">
                    {user.prenom || user.username || 'Utilisateur'} {user.nom || ''}
                  </p>
                  <p className="text-xs text-slate-400 capitalize truncate">
                    {user.role}
                  </p>
                </div>
              )}
            </div>
          </div>
        )}

        {/* Sidebar Controls & Logout */}
        <div className="border-t border-slate-700 p-2 space-y-1">
          <button
            onClick={() => setTheme(theme === 'dark' ? 'light' : 'dark')}
            className="flex items-center gap-3 px-3 py-2 mx-1.5 rounded-lg text-sm text-slate-300 hover:bg-slate-700 hover:text-white w-full"
            title={isCollapsed ? (theme === 'dark' ? "Mode Clair" : "Mode Sombre") : undefined}
          >
            {theme === 'dark' ? (
              <>
                <Sun className="w-4 h-4 text-amber-400 flex-shrink-0" />
                {!isCollapsed && <span className="truncate">Mode Clair</span>}
              </>
            ) : (
              <>
                <Moon className="w-4 h-4 text-slate-300 flex-shrink-0" />
                {!isCollapsed && <span className="truncate">Mode Sombre</span>}
              </>
            )}
          </button>

          <button
            onClick={() => setIsCollapsed(!isCollapsed)}
            className="flex items-center gap-3 px-3 py-2 mx-1.5 rounded-lg text-sm text-slate-300 hover:bg-slate-700 hover:text-white w-full"
          >
            {isCollapsed ? (
              <ChevronRight className="w-4 h-4" />
            ) : (
              <ChevronLeft className="w-4 h-4" />
            )}
            {!isCollapsed && <span>Réduire</span>}
          </button>
          
          <button
            onClick={handleLogout}
            className="flex items-center gap-3 px-3 py-2 mx-1.5 rounded-lg text-sm text-red-400 hover:bg-red-900/30 hover:text-red-300 w-full"
          >
            <LogOut className="w-4 h-4" />
            {!isCollapsed && <span>Déconnexion</span>}
          </button>
        </div>
      </aside>

      {/* Main Content Area */}
      <main className="flex-1 overflow-auto">
        <div className="p-4 lg:p-6">
          <Outlet />
        </div>
      </main>

      {/* Toast Notification Provider */}
      <Toaster position="top-right" />
    </div>
  );
}

// Global Database Helper Functions (Interacting with Dexie 'db' instance)

/**
 * Gets the total record count of a specific store.
 */
export async function getCount(storeName: string): Promise<number> {
  try {
    return (await db[storeName as any]?.count()) || 0;
  } catch {
    return 0;
  }
}

/**
 * Retrieves all records from a specific store.
 */
export async function getAll<T>(storeName: string): Promise<T[]> {
  try {
    return (await db[storeName as any]?.toArray()) || [];
  } catch {
    return [];
  }
}

/**
 * Retrieves records matching a specific field value.
 */
export async function getByField<T>(
  storeName: string,
  fieldName: string,
  value: any
): Promise<T[]> {
  try {
    return (await db[storeName as any]?.where(fieldName).equals(value).toArray()) || [];
  } catch {
    return [];
  }
}

/**
 * Filters records using a callback function and returns the total count.
 */
export async function getCountWithFilter<T>(
  storeName: string,
  filterFn: (item: T) => boolean
): Promise<number> {
  try {
    return (await db[storeName as any]?.filter(filterFn).count()) || 0;
  } catch {
    return 0;
  }
}