import Dexie from 'dexie';

export class KouleDjakanDB_v2 extends Dexie {
  patients!: Dexie.Table<any, number>;
  patients_consultation!: Dexie.Table<any, number>;
  patients_laboratoire!: Dexie.Table<any, number>;
  patients_soins!: Dexie.Table<any, number>;
  patients_caisse!: Dexie.Table<any, number>;
  patients_hospitalisation!: Dexie.Table<any, number>;
  consultations!: Dexie.Table<any, number>;
  prestations!: Dexie.Table<any, number>;
  categoriesPrestation!: Dexie.Table<any, number>;
  categories!: Dexie.Table<any, number>;
  recettes!: Dexie.Table<any, number>;
  depenses!: Dexie.Table<any, number>;
  categoriesDepense!: Dexie.Table<any, number>;
  medicaments!: Dexie.Table<any, number>;
  base_medicaments!: Dexie.Table<any, number>;
  rendezVous!: Dexie.Table<any, number>;
  chambres!: Dexie.Table<any, number>;
  hospitalisations!: Dexie.Table<any, number>;
  assurances!: Dexie.Table<any, number>;
  prescripteurs!: Dexie.Table<any, number>;
  prestataires!: Dexie.Table<any, number>;
  prestationPrestataires!: Dexie.Table<any, number>;
  ristournes!: Dexie.Table<any, number>;
  remunerations!: Dexie.Table<any, number>;
  creditsPatients!: Dexie.Table<any, number>;
  soinsInfirmiers!: Dexie.Table<any, number>;
  typesSoinsInfirmiers!: Dexie.Table<any, number>;
  vaccins!: Dexie.Table<any, number>;
  vaccinationsPatient!: Dexie.Table<any, number>;
  ordonnances!: Dexie.Table<any, number>;
  parametres!: Dexie.Table<any, number>;
  examensLaboratoire!: Dexie.Table<any, number>;
  typeExamensLaboratoire!: Dexie.Table<any, number>;
  utilisateurs!: Dexie.Table<any, number>;
  references!: Dexie.Table<any, number>;
  bulletins_examens!: Dexie.Table<any, number>;

  constructor() {
    super('KouleDjakanDB_v2');
    this.version(4).stores({
      patients: '++id, nom_complet, telephone, created_at',
      patients_consultation: '++id, nom_complet, telephone, created_at',
      patients_laboratoire: '++id, nom_complet, telephone, created_at',
      patients_soins: '++id, nom_complet, telephone, created_at',
      patients_caisse: '++id, nom_complet, telephone, created_at',
      patients_hospitalisation: '++id, nom_complet, telephone, created_at',
      consultations: '++id, patient_id, date_consultation, created_at',
      prestations: '++id, categorie_id, nom, statut, created_at',
      categoriesPrestation: '++id, nom, ordre, actif, created_at',
      categories: '++id, nom, ordre, actif, created_at',
      recettes: '++id, date, mode_paiement, patient_id, created_at',
      depenses: '++id, date, type_depense, categorie_id, created_at',
      categoriesDepense: '++id, nom, ordre, actif, created_at',
      medicaments: '++id, nom_medicament, categorie, created_at',
      rendezVous: '++id, patient_id, date_rdv, statut, created_at',
      chambres: '++id, numero, type, statut, created_at',
      hospitalisations: '++id, patient_id, chambre_id, statut, created_at',
      assurances: '++id, nom, statut, created_at',
      prescripteurs: '++id, nom, prenom, statut, created_at',
      prestataires: '++id, nom, prenom, statut, created_at',
      prestationPrestataires: '++id, prestataire_id, prestation_id, created_at',
      ristournes: '++id, prescripteur_id, prestation_id, recette_id, mois, statut_paiement, created_at',
      remunerations: '++id, prestataire_id, prestation_id, recette_id, mois, statut_paiement, created_at',
      creditsPatients: '++id, patient_id, statut, created_at',
      soinsInfirmiers: '++id, patient_id, date_soin, statut, created_at',
      typesSoinsInfirmiers: '++id, nom, actif, created_at',
      vaccins: '++id, nom, created_at',
      vaccinationsPatient: '++id, patient_id, vaccin_id, created_at',
      ordonnances: '++id, patient_id, date_ordonnance, created_at',
      parametres: '++id, created_at',
      examensLaboratoire: '++id, patient_id, consultation_id, type_analyse, status, created_at',
      typeExamensLaboratoire: '++id, categorie, nom, actif, created_at',
      utilisateurs: '++id, nom_utilisateur, email, role, statut, created_at',
      references: '++id, categorie, nom, valeur, statut, created_at',
      examens: '++id, patient_id, created_at',
      soins: '++id, patient_id, created_at'
    });
    this.version(5).stores({
      base_medicaments: '++id, nom_medicament, dci, categorie, created_at'
    });
    this.version(6).stores({
      bulletins_examens: '++id, patient_id, consultation_id, medecin, statut, created_at'
    });
  }
}

export const db = new KouleDjakanDB_v2();


// ============================================
// UTILITAIRES BULLETINS D'EXAMENS
// ============================================
export async function createBulletinExamens(data: {
  patient_id: number;
  consultation_id?: number;
  medecin: string;
  examens_demandes: any[];
  diagnostic?: string;
  motif?: string;
  urgente?: boolean;
}): Promise<number> {
  const id = await db.bulletins_examens.add({
    ...data,
    consultation_id: data.consultation_id || null,
    statut: 'en_attente',
    created_at: new Date(),
    updated_at: new Date()
  });
  return id as number;
}

export async function getBulletinsByPatient(patient_id: number): Promise<any[]> {
  return await db.bulletins_examens
    .where('patient_id')
    .equals(patient_id)
    .reverse()
    .sortBy('created_at');
}
