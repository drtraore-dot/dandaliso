import React, { useState, useEffect } from 'react';
import { 
  Plus, 
  Search, 
  Trash2, 
  X, 
  UserPlus, 
  Settings, 
  FlaskConical, 
  Users, 
  Pencil, 
  AlertCircle,
  Printer,
  Eye,
  FileText
} from 'lucide-react';
import { toast } from 'react-hot-toast';
import { db } from '@/db';
import { useAuth } from '@/hooks/useAuth';
import { getPrintSettings, renderPrintHeader, renderPrintFooter, escapeHtml, renderPreviewToolbar, previewToolbarStyles, installPdfBridge } from '@/lib/printSettings';

// --- Local Reusable UI Components to Match Compiled Code Paths ---

const Card = ({ children, className = "" }: { children: React.ReactNode; className?: string }) => (
  <div className={`rounded-xl border bg-white shadow-sm ${className}`}>{children}</div>
);

const CardContent = ({ children, className = "" }: { children: React.ReactNode; className?: string }) => (
  <div className={className}>{children}</div>
);

const Label = ({ children, className = "" }: { children: React.ReactNode; className?: string }) => (
  <label className={`text-xs font-semibold text-slate-700 ${className}`}>{children}</label>
);

const Input = React.forwardRef<HTMLInputElement, React.InputHTMLAttributes<HTMLInputElement>>(
  ({ className = "", ...props }, ref) => (
    <input
      ref={ref}
      className={`flex h-9 w-full rounded-md border border-input bg-background px-3 py-1 text-sm shadow-sm transition-colors file:border-0 file:bg-transparent file:text-sm file:font-medium placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring disabled:cursor-not-allowed disabled:opacity-50 focus:border-blue-500 focus:ring-1 focus:ring-blue-500 ${className}`}
      {...props}
    />
  )
);
Input.displayName = 'Input';

interface ButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: 'default' | 'outline' | 'ghost';
  size?: 'default' | 'sm' | 'lg';
  children: React.ReactNode;
}

const Button = ({ variant = 'default', size = 'default', className = "", children, ...props }: ButtonProps) => {
  const baseStyle = "inline-flex items-center justify-center rounded-md font-semibold transition-all focus-visible:outline-none disabled:pointer-events-none disabled:opacity-70";
  const variants = {
    default: "bg-blue-600 text-white hover:bg-blue-700 shadow active:scale-95",
    outline: "border border-slate-300 bg-white text-slate-800 hover:bg-slate-100 hover:text-slate-950 active:scale-95 dark:bg-slate-800 dark:text-white dark:border-slate-600 dark:hover:bg-slate-700",
    ghost: "text-slate-800 hover:bg-slate-100 hover:text-slate-950 active:scale-95 dark:text-white dark:hover:bg-slate-700"
  };
  const sizes = {
    default: "h-9 px-4 py-2 text-sm",
    sm: "h-8 px-3 text-xs",
    lg: "h-10 px-8 text-sm"
  };
  return (
    <button
      className={`${baseStyle} ${variants[variant]} ${sizes[size]} ${className}`}
      {...props}
    >
      {children}
    </button>
  );
};

const Badge = ({ children, className = "", variant = 'default' }: { children: React.ReactNode; className?: string; variant?: 'default' | 'outline' }) => (
  <span className={`inline-flex items-center rounded-full px-2.5 py-0.5 text-xs font-semibold ${variant === 'outline' ? 'border border-slate-200 text-slate-700' : ''} ${className}`}>
    {children}
  </span>
);

// --- Interface Declarations ---

export interface PatientLaboratoire {
  id?: number;
  numero_patient: string;
  nom_complet: string;
  age: string;
  sexe: string;
  telephone: string;
  created_at?: Date;
}

export interface TypeExamenLaboratoire {
  id?: number | null;
  categorie: string;
  nom: string;
  valeur_normale?: string;
  unite?: string;
  prix?: number;
  actif?: boolean;
}

export interface ExamenLaboratoire {
  id?: number;
  patient_id: number;
  type_examen_id: number;
  type_analyse: string;
  sous_categorie?: string;
  resultat: string;
  interpretation: string;
  biologiste: string;
  prescripteur?: string;
  date_examen: string;
  urgence: boolean;
  status: 'valide' | 'en_attente';
  created_at?: Date;
}

// Constant category list corresponding to "wd" array
const EXAM_CATEGORIES = [
  "Biochimie",
  "Hématologie",
  "Immunologie",
  "Bactériologie",
  "Parasitologie",
  "Virologie"
];

export default function Laboratoire() {
  const { canEdit } = useAuth();

  // Navigation / Mode state
  const [view, setView] = useState<"list" | "newPatient" | "newType" | "editType" | "newExamen">("list");
  const [selectedExamenForPreview, setSelectedExamenForPreview] = useState<ExamenLaboratoire | null>(null);
  const [activeLabTab, setActiveLabTab] = useState<"analyses" | "catalogue">("analyses");

  // Database Data States
  const [patients, setPatients] = useState<PatientLaboratoire[]>([]);
  const [examens, setExamens] = useState<ExamenLaboratoire[]>([]);
  const [examTypes, setExamTypes] = useState<TypeExamenLaboratoire[]>([]);

  // Filtering and Search State
  const [searchTerm, setSearchTerm] = useState("");

  // Form States
  const [patientForm, setPatientForm] = useState<Omit<PatientLaboratoire, 'id'>>({
    numero_patient: "",
    nom_complet: "",
    age: "",
    sexe: "M",
    telephone: ""
  });

  const [typeForm, setTypeForm] = useState<TypeExamenLaboratoire>({
    id: null,
    categorie: EXAM_CATEGORIES[0],
    nom: "",
    valeur_normale: "",
    unite: "",
    prix: 0,
    actif: true
  });

  const [examForm, setExamForm] = useState({
    patient_id: "",
    type_examen_id: "",
    resultat: "",
    interpretation: "",
    biologiste: "",
    prescripteur: "",
    date_examen: new Date().toISOString().slice(0, 16),
    urgence: false
  });

  // --- Data Loading & Lifecycle ---

  const loadData = async () => {
    try {
      const pts = await db.patients_laboratoire.toArray();
      const exms = await db.examensLaboratoire.toArray();
      const typs = await db.typeExamensLaboratoire.toArray();
      setPatients(pts);
      setExamens(exms);
      setExamTypes(typs);
    } catch (error) {
      console.error("Erreur chargement laboratoire:", error);
    }
  };

  useEffect(() => {
    loadData();
  }, []);

  useEffect(() => {
    installPdfBridge();
  }, []);

  const printExamenResult = async (exam: ExamenLaboratoire) => {
    const printSettings = await getPrintSettings();
    const p = patients.find(pat => pat.id === exam.patient_id) || { nom_complet: "Inconnu", age: "N/A", sexe: "N/A", numero_patient: "N/A" };
    const typeInfo = examTypes.find(t => t.id === exam.type_examen_id);
    const dateStr = new Date(exam.date_examen).toLocaleString('fr-FR');
    
    const printContent = `
      <html>
        <head>
          <title>Rapport d'Examen Laboratoire - ${p.nom_complet}</title>
          <style>
            body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; padding: 18px 24px; color: #1e293b; background: white; max-width: 800px; margin: 0 auto; line-height: 1.18; font-size: 9pt; }
            ${previewToolbarStyles()}
            .print-logo-wrap { flex:0 0 auto; }
            .print-logo { width:52px; height:52px; object-fit:contain; display:block; }
            .print-header-main { flex:1; }
            .print-header-block { display: flex; justify-content: space-between; align-items: start; border-bottom: 2px solid #0f766e; padding-bottom: 5px; margin-bottom: 7px; }
            .print-clinic-name { font-size: 12pt; font-weight: 800; color: #0f766e; text-transform: uppercase; letter-spacing: .5px; }
            .print-clinic-sub, .print-custom-header { font-size: 7.5pt; color: #64748b; margin-top: 1px; line-height:1.15; }
            .print-doc-title { font-size:8pt; text-align:right; color:#64748b; max-width:210px; }
            .print-footer-block { border-top: 1px solid #cbd5e1; margin-top: 14px; padding-top: 4px; text-align:center; font-size:7.5pt; color:#64748b; line-height:1.15; }
            .report-title-container { text-align: center; margin: 7px 0; }
            .report-title { font-size: 10.5pt; font-weight: bold; border-bottom: 1px double #e2e8f0; display: inline-block; padding-bottom: 2px; color: #0f766e; text-transform: uppercase; letter-spacing: 1px; }
            .grid-info { display: grid; grid-template-columns: 1fr 1fr; gap: 6px; margin-bottom: 8px; padding: 6px; background-color: #f8fafc; border-radius: 5px; border: 1px solid #cbd5e1; font-size: 8.2pt; line-height: 1.25; }
            .grid-info h4 { margin: 0 0 8px 0; color: #0f766e; border-bottom: 1px solid #cbd5e1; padding-bottom: 3px; font-weight: bold; text-transform: uppercase; font-size: 9.5pt; }
            .main-table { width: 100%; border-collapse: collapse; margin: 12px 0; font-size: 8.5pt; }
            .main-table th { background-color: #0f766e; color: white; font-weight: 600; text-align: left; padding: 4px 5px; border: 1px solid #0f766e; }
            .main-table td { padding: 4px 5px; border: 1px solid #cbd5e1; }
            .badge { display: inline-block; padding: 2px 8px; font-size: 8pt; font-weight: bold; border-radius: 9999px; text-transform: uppercase; }
            .interpretation-box { margin-top: 10px; padding: 8px; background: #f0fdf4; border: 1px solid #bbf7d0; border-radius: 6px; line-height: 1.5; font-size: 10pt; }
            .interpretation-title { font-weight: bold; color: #166534; margin-bottom: 5px; }
            .footer-signs { display: flex; justify-content: space-between; margin-top: 30px; font-size: 10pt; }
            .sign-box { text-align: center; width: 220px; }
            .sign-line { border-top: 1px solid #cbd5e1; margin-top: 55px; padding-top: 5px; font-weight: bold; color: #475569; }
          </style>
        </head>
        <body>
          ${renderPreviewToolbar()}
          ${renderPrintHeader(printSettings, `Réf Examen: LAB-${exam.id?.toString().padStart(6, '0')} | Date: ${new Date().toLocaleDateString('fr-FR')}`)}

          <div class="report-title-container">
            <div class="report-title">BULLETIN DE RÉSULTATS DE LABORATOIRE</div>
          </div>

          <div class="grid-info">
            <div>
              <h4>INFORMATIONS PATIENT</h4>
              <strong>Nom Complet :</strong> ${p.nom_complet}<br/>
              <strong>Identifiant Patient :</strong> ${p.numero_patient || 'N/A'}<br/>
              <strong>Âge / Sexe :</strong> ${p.age ? p.age + ' ans' : 'N/A'} / ${p.sexe || 'N/A'}<br/>
              <strong>Téléphone :</strong> ${p.telephone || 'Non renseigné'}<br/>
            </div>
            <div>
              <h4>DÉTAILS EXAMEN</h4>
              <strong>Prescripteur :</strong> ${escapeHtml(exam.prescripteur || 'Non renseigné')}<br/>
              <strong>Date Prélèvement :</strong> ${dateStr}<br/>
              <strong>Laborantin :</strong> ${escapeHtml(exam.biologiste || 'Non renseigné')}<br/>
              <strong>Urgence :</strong> ${exam.urgence ? 'OUI (Prioritaire)' : 'NON'}<br/>
            </div>
          </div>

          <table class="main-table">
            <thead>
              <tr>
                <th>ANALYSE SOLICITÉE</th>
                <th>RÉSULTAT OBTENU</th>
                <th>UNITÉ</th>
                <th>VALEURS DE RÉFÉRENCE</th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <td style="font-weight: bold; font-size: 11pt; color: #111;">
                  ${exam.type_analyse}
                  ${exam.sous_categorie ? `<br/><span style="font-size: 9pt; font-weight: normal; color: #64748b;">(${exam.sous_categorie})</span>` : ''}
                </td>
                <td style="font-weight: bold; font-size: 12.5pt; color: #1d4ed8; font-family: monospace;">
                  ${exam.resultat}
                </td>
                <td>${typeInfo?.unite || '-'}</td>
                <td style="font-style: italic; color: #475569;">${typeInfo?.valeur_normale || 'Norme Labo'}</td>
              </tr>
            </tbody>
          </table>

          ${exam.interpretation ? `
            <div class="interpretation-box">
              <div class="interpretation-title">Conclusion / Interprétation Biologique :</div>
              <p style="margin: 0;">${exam.interpretation}</p>
            </div>
          ` : ''}

          <div class="footer-signs" style="justify-content:flex-end;">
            <div class="sign-box">
              <p style="margin:0; color: #64748b; font-style: italic; font-size: 8.5pt;">Laborantin</p>
              <div class="sign-line">${exam.biologiste || 'Signature du Laborantin'}</div>
            </div>
          </div>

          ${renderPrintFooter(printSettings)}

          <script>
            window.onload = function() { document.title = 'Aperçu résultat laboratoire - ${p.nom_complet}'; }
          </script>
        </body>
      </html>
    `;
    if (window.DANDALI_PRINT?.previewHtml) {
      window.DANDALI_PRINT.previewHtml(printContent);
    } else {
      const win = window.open("", "_blank");
      if (win) { win.document.write(printContent); win.document.close(); }
    }
  };

  // Helper helper to generate unique patient identifier based on current collection size
  const generatePatientNumber = (count: number) => {
    return `LAB-${String(count + 1).padStart(4, '0')}`;
  };

  // --- Form Action Handlers ---

  const handlePatientSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!patientForm.nom_complet) {
      toast.error("Veuillez renseigner le nom complet");
      return;
    }
    try {
      const computedNo = patientForm.numero_patient || generatePatientNumber(patients.length);
      await db.patients_laboratoire.add({
        ...patientForm,
        numero_patient: computedNo,
        created_at: new Date()
      });
      toast.success("Patient créé");
      setView("list");
      loadData();
      // Reset form
      setPatientForm({
        numero_patient: "",
        nom_complet: "",
        age: "",
        sexe: "M",
        telephone: ""
      });
    } catch (err) {
      console.error(err);
      toast.error("Erreur lors de la création du patient");
    }
  };

  const handleTypeSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!typeForm.nom) {
      toast.error("Veuillez renseigner le nom de l'examen");
      return;
    }
    try {
      if (typeForm.id) {
        await db.typeExamensLaboratoire.update(typeForm.id, {
          categorie: typeForm.categorie,
          nom: typeForm.nom,
          valeur_normale: typeForm.valeur_normale,
          unite: typeForm.unite,
          prix: typeForm.prix,
          actif: typeForm.actif
        });
        toast.success("Modifié");
      } else {
        await db.typeExamensLaboratoire.add({
          categorie: typeForm.categorie,
          nom: typeForm.nom,
          valeur_normale: typeForm.valeur_normale,
          unite: typeForm.unite,
          prix: typeForm.prix,
          actif: true
        });
        toast.success("Créé");
      }
      setView("list");
      loadData();
    } catch (err) {
      console.error(err);
      toast.error("Erreur d'enregistrement");
    }
  };

  const handleExamSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!examForm.patient_id || !examForm.type_examen_id) {
      toast.error("Veuillez sélectionner un patient et un type d'examen");
      return;
    }
    try {
      const selectedType = examTypes.find(t => String(t.id) === examForm.type_examen_id);
      await db.examensLaboratoire.add({
        patient_id: Number(examForm.patient_id),
        type_examen_id: Number(examForm.type_examen_id),
        type_analyse: selectedType?.nom || "",
        sous_categorie: selectedType?.categorie || "",
        resultat: examForm.resultat,
        interpretation: examForm.interpretation,
        biologiste: examForm.biologiste,
        prescripteur: examForm.prescripteur,
        date_examen: examForm.date_examen,
        urgence: examForm.urgence,
        status: "valide",
        created_at: new Date()
      });
      toast.success("Enregistré");
      setView("list");
      loadData();
      // Reset form
      setExamForm({
        patient_id: "",
        type_examen_id: "",
        resultat: "",
        interpretation: "",
        biologiste: "",
        date_examen: new Date().toISOString().slice(0, 16),
        urgence: false
      });
    } catch (err) {
      console.error(err);
      toast.error("Erreur d'enregistrement");
    }
  };

  const handleDeleteType = async (id: number) => {
    if (window.confirm("Supprimér ce type ?")) {
      await db.typeExamensLaboratoire.delete(id);
      toast.success("Supprimé");
      loadData();
    }
  };

  // --- Filtering Logic ---

  const filteredExamens = examens.filter(examen => {
    const matchingPatient = patients.find(p => p.id === examen.patient_id);
    return !searchTerm || (matchingPatient?.nom_complet || "").toLowerCase().includes(searchTerm.toLowerCase());
  });

  // --- Rendering UI Views ---

  if (view === "newPatient") {
    return (
      <div className="space-y-4 max-w-2xl">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <UserPlus className="w-6 h-6 text-blue-600" />
            <h2 className="text-xl font-bold text-slate-800">Nouveau Patient - Laboratoire</h2>
          </div>
          <Button variant="ghost" size="sm" onClick={() => setView("list")}>
            <X className="w-4 h-4" />
          </Button>
        </div>

        <Card>
          <CardContent className="p-4">
            <form onSubmit={handlePatientSubmit} className="space-y-3">
              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1">
                  <Label>No</Label>
                  <Input 
                    value={patientForm.numero_patient || generatePatientNumber(patients.length)}
                    onChange={e => setPatientForm(prev => ({ ...prev, numero_patient: e.target.value }))}
                  />
                </div>
                <div className="space-y-1">
                  <Label>Nom complet *</Label>
                  <Input 
                    value={patientForm.nom_complet}
                    onChange={e => setPatientForm(prev => ({ ...prev, nom_complet: e.target.value }))}
                    required
                  />
                </div>
              </div>

              <div className="grid grid-cols-3 gap-3">
                <div className="space-y-1">
                  <Label>Age</Label>
                  <Input 
                    type="number"
                    value={patientForm.age}
                    onChange={e => setPatientForm(prev => ({ ...prev, age: e.target.value }))}
                  />
                </div>
                <div className="space-y-1">
                  <Label>Sexe</Label>
                  <select
                    value={patientForm.sexe}
                    onChange={e => setPatientForm(prev => ({ ...prev, sexe: e.target.value }))}
                    className="w-full h-9 rounded-md border border-input bg-transparent px-3 py-1 text-sm focus:outline-none focus:ring-1 focus:ring-blue-500"
                  >
                    <option value="M">M</option>
                    <option value="F">F</option>
                  </select>
                </div>
                <div className="space-y-1">
                  <Label>Tel</Label>
                  <Input 
                    value={patientForm.telephone}
                    onChange={e => setPatientForm(prev => ({ ...prev, telephone: e.target.value }))}
                  />
                </div>
              </div>

              <div className="flex justify-end gap-2 pt-2">
                <Button type="button" variant="outline" onClick={() => setView("list")}>
                  Annuler
                </Button>
                {canEdit("examens") && (
                  <Button type="submit" className="bg-blue-600 hover:bg-blue-700">
                    Créer
                  </Button>
                )}
              </div>
            </form>
          </CardContent>
        </Card>
      </div>
    );
  }

  if (view === "newType" || view === "editType") {
    return (
      <div className="space-y-4 max-w-2xl">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <Settings className="w-6 h-6 text-blue-600" />
            <h2 className="text-xl font-bold text-slate-800">
              {typeForm.id ? "Modifiér" : "Nouveau"} Type d'examen
            </h2>
          </div>
          <Button variant="ghost" size="sm" onClick={() => setView("list")}>
            <X className="w-4 h-4" />
          </Button>
        </div>

        <Card>
          <CardContent className="p-4">
            <form onSubmit={handleTypeSubmit} className="space-y-3">
              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1">
                  <Label>Categorie</Label>
                  <select
                    value={typeForm.categorie}
                    onChange={e => setTypeForm(prev => ({ ...prev, categorie: e.target.value }))}
                    className="w-full h-9 rounded-md border border-input bg-transparent px-3 py-1 text-sm focus:outline-none focus:ring-1 focus:ring-blue-500"
                  >
                    {EXAM_CATEGORIES.map(category => (
                      <option key={category} value={category}>{category}</option>
                    ))}
                  </select>
                </div>
                <div className="space-y-1">
                  <Label>Nom *</Label>
                  <Input 
                    value={typeForm.nom}
                    onChange={e => setTypeForm(prev => ({ ...prev, nom: e.target.value }))}
                    placeholder="Ex: GB, CR, Glycemie..."
                    required
                  />
                </div>
              </div>

              <div className="grid grid-cols-3 gap-3">
                <div className="space-y-1">
                  <Label>Valeur normale</Label>
                  <Input 
                    value={typeForm.valeur_normale}
                    onChange={e => setTypeForm(prev => ({ ...prev, valeur_normale: e.target.value }))}
                  />
                </div>
                <div className="space-y-1">
                  <Label>Unite</Label>
                  <Input 
                    value={typeForm.unite}
                    onChange={e => setTypeForm(prev => ({ ...prev, unite: e.target.value }))}
                    placeholder="g/L, mmol/L..."
                  />
                </div>
                <div className="space-y-1">
                  <Label>Prix (FCFA)</Label>
                  <Input 
                    type="number"
                    value={typeForm.prix || ""}
                    onChange={e => setTypeForm(prev => ({ ...prev, prix: Number(e.target.value) }))}
                  />
                </div>
              </div>

              <div className="flex justify-end gap-2 pt-2">
                <Button type="button" variant="outline" onClick={() => setView("list")}>
                  Annuler
                </Button>
                {canEdit("examens") && (
                  <Button type="submit" className="bg-blue-600 hover:bg-blue-700">
                    {typeForm.id ? "Modifiér" : "Créer"}
                  </Button>
                )}
              </div>
            </form>
          </CardContent>
        </Card>
      </div>
    );
  }

  if (view === "newExamen") {
    return (
      <div className="space-y-4 max-w-4xl">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <FlaskConical className="w-6 h-6 text-blue-600" />
            <h2 className="text-xl font-bold text-slate-800">Nouvel Examen</h2>
          </div>
          <Button variant="ghost" size="sm" onClick={() => setView("list")}>
            <X className="w-4 h-4" />
          </Button>
        </div>

        {/* Quick Patient Selection Row */}
        <Card>
          <CardContent className="p-3">
            <div className="flex items-center justify-between mb-2">
              <div className="flex items-center gap-2">
                <Users className="w-4 h-4 text-blue-600" />
                <span className="text-sm font-semibold">Patients Laboratoire ({patients.length})</span>
              </div>
              {canEdit("examens") && (
                <Button type="button" size="sm" variant="outline" onClick={() => setView("newPatient")}>
                  <UserPlus className="w-3 h-3 mr-1" /> Nouveau patient
                </Button>
              )}
            </div>

            <div className="flex gap-2 overflow-x-auto pb-1">
              {patients.slice(0, 10).map(patient => (
                <button
                  key={patient.id}
                  type="button"
                  onClick={() => setExamForm(prev => ({ ...prev, patient_id: String(patient.id) }))}
                  className={`flex-shrink-0 px-3 py-2 rounded-lg border text-xs min-w-[140px] text-left transition-all ${
                    examForm.patient_id === String(patient.id)
                      ? "bg-blue-100 border-blue-300 ring-1 ring-blue-400"
                      : "bg-slate-50 hover:bg-slate-100"
                  }`}
                >
                  <p className="font-medium truncate">{patient.nom_complet}</p>
                  <p className="text-slate-500">{patient.numero_patient} | {patient.age} ans</p>
                </button>
              ))}
              {patients.length === 0 && (
                <span className="text-xs text-red-500 py-2">Créez un patient d'abord</span>
              )}
            </div>
          </CardContent>
        </Card>

        {/* Exam Creation Form */}
        <Card>
          <CardContent className="p-4">
            <form onSubmit={handleExamSubmit} className="space-y-3">
              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1">
                  <Label>Type d'examen</Label>
                  <select
                    value={examForm.type_examen_id}
                    onChange={e => setExamForm(prev => ({ ...prev, type_examen_id: e.target.value }))}
                    className="w-full h-9 rounded-md border border-input bg-transparent px-3 py-1 text-sm focus:outline-none focus:ring-1 focus:ring-blue-500"
                    required
                  >
                    <option value="">Sélectionner...</option>
                    {examTypes.map(type => (
                      <option key={type.id} value={String(type.id)}>
                        {type.categorie} - {type.nom}
                      </option>
                    ))}
                  </select>
                </div>

                <div className="space-y-1">
                  <Label>Patient selectionne</Label>
                  <Input 
                    value={
                      examForm.patient_id 
                        ? patients.find(p => p.id === Number(examForm.patient_id))?.nom_complet || ""
                        : "Aucun"
                    }
                    readOnly
                    className="bg-slate-50 font-medium"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1">
                  <Label>Resultat</Label>
                  <Input 
                    value={examForm.resultat}
                    onChange={e => setExamForm(prev => ({ ...prev, resultat: e.target.value }))}
                  />
                </div>
                <div className="space-y-1">
                  <Label>Interpretation</Label>
                  <select
                    value={examForm.interpretation}
                    onChange={e => setExamForm(prev => ({ ...prev, interpretation: e.target.value }))}
                    className="w-full h-9 rounded-md border border-input bg-transparent px-3 py-1 text-sm focus:outline-none focus:ring-1 focus:ring-blue-500"
                  >
                    <option value="">--</option>
                    <option value="normal">Normal</option>
                    <option value="anormal">Anormal</option>
                    <option value="inconclusif">Inconclusif</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1">
                  <Label>Prescripteur</Label>
                  <Input 
                    placeholder="Dr / Sage-femme / Service demandeur"
                    value={examForm.prescripteur}
                    onChange={e => setExamForm(prev => ({ ...prev, prescripteur: e.target.value }))}
                    required
                  />
                </div>
                <div className="space-y-1">
                  <Label>Laborantin</Label>
                  <Input 
                    placeholder="Nom du biologiste"
                    value={examForm.biologiste}
                    onChange={e => setExamForm(prev => ({ ...prev, biologiste: e.target.value }))}
                    required
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1">
                  <Label>Date</Label>
                  <Input 
                    type="datetime-local"
                    value={examForm.date_examen}
                    onChange={e => setExamForm(prev => ({ ...prev, date_examen: e.target.value }))}
                  />
                </div>
              </div>

              <label className="flex items-center gap-2 text-sm select-none cursor-pointer pt-1">
                <input 
                  type="checkbox"
                  checked={examForm.urgence}
                  onChange={e => setExamForm(prev => ({ ...prev, urgence: e.target.checked }))}
                  className="rounded border-slate-300 text-blue-600 focus:ring-blue-500"
                />
                <span className="font-semibold text-slate-700">Urgence</span>
              </label>

              <div className="flex justify-end gap-2 pt-2">
                <Button type="button" variant="outline" onClick={() => setView("list")}>
                  Annuler
                </Button>
                {canEdit("examens") && (
                  <Button type="submit" className="bg-blue-600 hover:bg-blue-700">
                    Enregistrer
                  </Button>
                )}
              </div>
            </form>
          </CardContent>
        </Card>
      </div>
    );
  }

  // --- Main Dashboard / List View ---
  return (
    <div className="space-y-4">
      {/* Top Header Card */}
      <div className="flex items-center justify-between flex-wrap gap-3">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-lg bg-blue-500 flex items-center justify-center shadow-md">
            <FlaskConical className="w-5 h-5 text-white" />
          </div>
          <div>
            <h2 className="text-lg font-semibold text-slate-800">Laboratoire</h2>
            <p className="text-sm text-slate-500">
              {examens.length} examen(s) | {patients.length} patient(s)
            </p>
          </div>
        </div>

        <div className="flex gap-2">
          {canEdit("examens") && (
            <>
              <Button 
                variant="outline" 
                onClick={() => setView("newPatient")}
                className="border-blue-200 text-blue-700 hover:bg-blue-50"
              >
                <UserPlus className="w-4 h-4 mr-1" /> Patient
              </Button>
              <Button 
                variant="outline" 
                onClick={() => {
                  setTypeForm({ id: null, categorie: EXAM_CATEGORIES[0], nom: "", valeur_normale: "", unite: "", prix: 0, actif: true });
                  setView("newType");
                }}
                className="border-blue-200 text-blue-700 hover:bg-blue-50"
              >
                <Settings className="w-4 h-4 mr-1" /> Types
              </Button>
              <Button 
                onClick={() => setView("newExamen")}
                className="bg-blue-600 hover:bg-blue-700"
              >
                <Plus className="w-4 h-4 mr-1" /> Examen
              </Button>
            </>
          )}
        </div>
      </div>

      {/* Patients quick status bar */}
      {patients.length > 0 && (
        <Card>
          <CardContent className="p-3">
            <div className="flex items-center gap-2 mb-2">
              <Users className="w-4 h-4 text-blue-600" />
              <span className="text-sm font-semibold text-slate-800">Patients Laboratoire ({patients.length})</span>
            </div>
            <div className="flex gap-2 overflow-x-auto pb-1">
              {patients.slice(0, 10).map(patient => (
                <div 
                  key={patient.id} 
                  className="flex-shrink-0 px-3 py-2 bg-slate-50 rounded-lg border border-slate-200 text-xs min-w-[140px]"
                >
                  <p className="font-medium text-slate-800 truncate">{patient.nom_complet}</p>
                  <p className="text-slate-500">{patient.numero_patient} | {patient.age} ans | {patient.sexe}</p>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      {/* Tabs list of examinations */}
      <div className="flex border-b border-slate-200 dark:border-slate-800 gap-1 mt-2">
        <button
          onClick={() => setActiveLabTab("analyses")}
          className={`px-4 py-2 text-xs font-bold border-b-2 transition-all flex items-center gap-2 ${
            activeLabTab === "analyses"
              ? "border-blue-600 text-blue-600 dark:text-blue-400"
              : "border-transparent text-slate-500 hover:text-slate-705 dark:text-slate-400"
          }`}
        >
          <FlaskConical className="w-4 h-4" />
          Suivi des Analyses Patients ({examens.length})
        </button>
        <button
          onClick={() => setActiveLabTab("catalogue")}
          className={`px-4 py-2 text-xs font-bold border-b-2 transition-all flex items-center gap-2 ${
            activeLabTab === "catalogue"
              ? "border-blue-600 text-blue-600 dark:text-blue-400"
              : "border-transparent text-slate-500 hover:text-slate-705 dark:text-slate-400"
          }`}
        >
          <FileText className="w-4 h-4" />
          Catalogue & Tarifs ({examTypes.length})
        </button>
      </div>

      {activeLabTab === "analyses" ? (
        <div className="space-y-4">
          {/* Main Search Filter */}
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
            <Input 
              placeholder="Rechercher une analyse..." 
              value={searchTerm} 
              onChange={e => setSearchTerm(e.target.value)} 
              className="pl-10"
            />
          </div>

          {/* Lab Exams Registered Table */}
          <Card>
            <CardContent className="p-0">
              <div className="overflow-x-auto">
                <table className="w-full text-sm text-slate-700">
                  <thead className="bg-slate-50 dark:bg-slate-800 text-slate-600 dark:text-slate-200 border-b">
                    <tr>
                      <th className="text-left py-3 px-4 font-semibold">Date</th>
                      <th className="text-left py-3 px-4 font-semibold">Patient</th>
                      <th className="text-left py-3 px-4 font-semibold">Type d'Analyse</th>
                      <th className="text-left py-3 px-4 font-semibold">Résultat obtenu</th>
                      <th className="text-right py-3 px-4 font-semibold">Actions</th>
                    </tr>
                  </thead>
                  <tbody>
                    {filteredExamens.map(exam => (
                      <tr key={exam.id} className="border-t dark:border-slate-800 hover:bg-slate-50 dark:hover:bg-slate-800/50 transition-colors">
                        <td className="py-3 px-4 text-xs font-medium text-slate-605">
                          {new Date(exam.date_examen).toLocaleDateString("fr-FR")}
                        </td>
                        <td className="py-3 px-4 font-bold text-xs text-slate-800">
                          {patients.find(p => p.id === exam.patient_id)?.nom_complet || "N/A"}
                        </td>
                        <td className="py-3 px-4 text-xs">
                          <span className="font-semibold text-slate-700">{exam.type_analyse}</span>
                          {exam.sous_categorie ? ` - ${exam.sous_categorie}` : ""}
                        </td>
                        <td className="py-3 px-4 text-xs font-mono text-blue-600 font-bold">
                          {exam.resultat || "Saisie en cours"}
                        </td>
                        <td className="py-3 px-4 text-right">
                          <div className="flex justify-end gap-1.5">
                            <Button 
                              size="sm" 
                              variant="outline" 
                              title="Détails"
                              className="h-7 px-2 flex items-center justify-center gap-1 border-slate-200"
                              onClick={() => setSelectedExamenForPreview(exam)}
                            >
                              <Eye className="w-3.5 h-3.5 text-slate-500" /> Voir
                            </Button>
                            <Button 
                              size="sm" 
                              variant="outline" 
                              title="Imprimer le Bulletin"
                              className="h-7 px-2 flex items-center justify-center gap-1 border-blue-200 bg-blue-50/50 hover:bg-blue-100"
                              onClick={() => printExamenResult(exam)}
                            >
                              <Printer className="w-3.5 h-3.5 text-blue-600" /> Imprimer
                            </Button>
                          </div>
                        </td>
                      </tr>
                    ))}
                    {filteredExamens.length === 0 && (
                      <tr>
                        <td colSpan={5} className="py-12 text-center text-slate-400 text-xs">
                          Aucune analyse enregistrée
                        </td>
                      </tr>
                    )}
                  </tbody>
                </table>
              </div>
            </CardContent>
          </Card>
        </div>
      ) : (
        <div className="space-y-4">
          {/* Search Catalogue */}
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
            <Input 
              placeholder="Rechercher une analyse dans le catalogue..." 
              value={searchTerm} 
              onChange={e => setSearchTerm(e.target.value)} 
              className="pl-10"
            />
          </div>

          {/* Catalogue section */}
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center justify-between mb-3 border-b pb-2">
                <h3 className="text-sm font-bold flex items-center gap-2 text-slate-800">
                  <Settings className="w-4 h-4 text-blue-600" />
                  Catalogue des Examens de Laboratoire ({examTypes.length} types)
                </h3>
                {canEdit("examens") && (
                  <Button 
                    size="sm" 
                    onClick={() => {
                      setTypeForm({ id: null, categorie: EXAM_CATEGORIES[0], nom: "", valeur_normale: "", unite: "", prix: 0, actif: true });
                      setView("newType");
                    }} 
                    className="h-8 text-xs bg-blue-600 hover:bg-blue-700"
                  >
                    <Plus className="w-3 h-3 mr-1" /> Nouvel Examen de Référence
                  </Button>
                )}
              </div>

              <div className="overflow-x-auto">
                <table className="w-full text-sm text-slate-700">
                  <thead className="bg-slate-50 text-slate-600 border-b">
                    <tr>
                      <th className="text-left py-2 px-3 font-semibold text-xs">Examen / Analyse</th>
                      <th className="text-left py-2 px-3 font-semibold text-xs">Catégorie</th>
                      <th className="text-left py-2 px-3 font-semibold text-xs">Valeur de Référence (Norme)</th>
                      <th className="text-left py-2 px-3 font-semibold text-xs">Unité</th>
                      <th className="text-right py-2 px-3 font-semibold text-xs">Tarif de l'Examen</th>
                      {canEdit("examens") && <th className="text-right py-2 px-3 font-semibold text-xs">Actions</th>}
                    </tr>
                  </thead>
                  <tbody>
                    {examTypes
                      .filter(type => type.nom.toLowerCase().includes(searchTerm.toLowerCase()) || type.categorie.toLowerCase().includes(searchTerm.toLowerCase()))
                      .map(type => (
                        <tr key={type.id} className="border-t hover:bg-slate-50 transition-colors text-xs">
                          <td className="py-2.5 px-3 font-bold text-slate-805">{type.nom}</td>
                          <td className="py-2.5 px-3">
                            <Badge variant="outline" className="text-[9px] bg-slate-50 text-slate-600 border-slate-200">
                              {type.categorie}
                            </Badge>
                          </td>
                          <td className="py-2.5 px-3 text-slate-500 italic">{type.valeur_normale || "Norme Labo"}</td>
                          <td className="py-2.5 px-3 text-slate-605">{type.unite || "S/U"}</td>
                          <td className="py-2.5 px-3 text-right font-bold text-emerald-600 font-mono">
                            {type.prix ? `${type.prix.toLocaleString()} FCFA` : "Gratuit"}
                          </td>
                          {canEdit("examens") && (
                            <td className="py-2.5 px-3 text-right">
                              <div className="flex gap-1 justify-end">
                                <Button 
                                  size="sm" 
                                  variant="ghost" 
                                  className="h-6 w-6 p-0 text-slate-500 hover:text-slate-700"
                                  onClick={() => {
                                    setTypeForm({
                                      id: type.id || null,
                                      categorie: type.categorie,
                                      nom: type.nom,
                                      valeur_normale: type.valeur_normale || "",
                                      unite: type.unite || "",
                                      prix: type.prix || 0,
                                      actif: type.actif ?? true
                                    });
                                    setView("editType");
                                  }}
                                >
                                  <Pencil className="w-3 h-3" />
                                </Button>
                                <Button 
                                  size="sm" 
                                  variant="ghost" 
                                  className="h-6 w-6 p-0 text-red-500 hover:text-red-700 hover:bg-red-50"
                                  onClick={() => type.id && handleDeleteType(Number(type.id))}
                                >
                                  <Trash2 className="w-3 h-3" />
                                </Button>
                              </div>
                            </td>
                          )}
                        </tr>
                      ))}
                    {examTypes.length === 0 && (
                      <tr>
                        <td colSpan={6} className="py-8 text-center text-slate-400 text-xs">
                          Aucun type d'examen créé
                        </td>
                      </tr>
                    )}
                  </tbody>
                </table>
              </div>
            </CardContent>
          </Card>
        </div>
      )}

      {/* Selected Examen Detail Preview Overlay Modal */}
      {selectedExamenForPreview && (() => {
        const exam = selectedExamenForPreview;
        const p = patients.find(pat => pat.id === exam.patient_id) || { nom_complet: "Inconnu", age: "N/A", sexe: "N/A", numero_patient: "N/A" };
        const typeInfo = examTypes.find(t => t.id === exam.type_examen_id);
        const formattedDateObj = new Date(exam.date_examen).toLocaleString("fr-FR");
        return (
          <div className="fixed inset-0 z-50 bg-black/55 flex items-center justify-center p-4">
            <div className="bg-white rounded-xl shadow-2xl max-w-lg w-full max-h-[90vh] overflow-hidden">
              <div className="flex justify-between items-center bg-slate-50 border-b p-4">
                <div>
                  <h4 className="font-bold text-slate-805 text-base">Bulletin de Laboratoire</h4>
                  <p className="text-[10px] text-slate-500 font-medium">Référence : LAB-{exam.id?.toString().padStart(6, '0')}</p>
                </div>
                <div className="flex items-center gap-1.5">
                  <Button 
                    className="bg-blue-600 hover:bg-blue-700 text-white text-xs px-2.5 py-1.5 flex items-center gap-1 h-8"
                    onClick={() => printExamenResult(exam)}
                  >
                    <Printer className="w-3.5 h-3.5" /> Imprimer
                  </Button>
                  <Button 
                    variant="ghost" 
                    className="px-2 hover:bg-slate-200 rounded h-8 text-xs flex items-center gap-1"
                    onClick={() => setSelectedExamenForPreview(null)}
                  >
                    <X className="w-4 h-4" /> Fermer
                  </Button>
                </div>
              </div>

              <div className="p-5 overflow-y-auto space-y-4 text-xs font-sans">
                {/* Panel Patient */}
                <div className="bg-slate-50 p-3 rounded-lg border border-slate-150 grid grid-cols-2 gap-3 leading-normal">
                  <div>
                    <p className="text-[10px] text-slate-450 uppercase tracking-tight font-semibold">PATIENT</p>
                    <p className="font-bold text-slate-850 uppercase text-[11px]">{p.nom_complet}</p>
                    <p className="text-slate-505">Âge / Sexe : {p.age ? p.age + ' ans' : 'N/A'} / {p.sexe}</p>
                    <p className="text-slate-505">Identifiant : {p.numero_patient}</p>
                  </div>
                  <div>
                    <p className="text-[10px] text-slate-450 uppercase tracking-tight font-semibold">PRÉLÈVEMENT & BIOLOGIE</p>
                    <p className="font-semibold text-slate-700">Responsable : {exam.biologiste || "Dr. Traoré"}</p>
                    <p className="text-slate-505">Date : {formattedDateObj}</p>
                    <p className="text-slate-505 font-medium flex items-center gap-1">Urgent : {exam.urgence ? <span className="text-red-500 font-bold">OUI</span> : "NON"}</p>
                  </div>
                </div>

                {/* Main description bar */}
                <div className="border border-slate-200 rounded-lg p-3 space-y-2">
                  <div className="font-bold text-blue-800 text-[11px] uppercase border-b pb-1">ANALYSE SOLICITÉE & CONSTANTES</div>
                  <div className="flex justify-between items-center py-1">
                    <span className="font-semibold text-slate-700 text-xs">{exam.type_analyse}</span>
                    <span className="font-bold text-blue-600 font-mono text-sm">{exam.resultat || "Attente de saisie"}</span>
                  </div>
                  <div className="flex justify-between text-slate-500 text-[10px] py-0.5 border-t border-dashed">
                    <span>Valeurs de référence (Norme) :</span>
                    <span className="font-medium text-slate-700">{typeInfo?.valeur_normale || "Norme Labo"}</span>
                  </div>
                  <div className="flex justify-between text-slate-500 text-[10px] py-0.5">
                    <span>Unité de constante :</span>
                    <span className="font-medium text-slate-700">{typeInfo?.unite || "Standard"}</span>
                  </div>
                </div>

                {/* Interpretation */}
                {exam.interpretation && (
                  <div className="bg-green-50/50 border border-green-100 rounded-lg p-3 space-y-1 text-slate-700 leading-normal">
                    <p className="font-bold text-green-800 text-[10px] uppercase">Raisonnement & Conclusion Clinique :</p>
                    <p>{exam.interpretation}</p>
                  </div>
                )}
              </div>
            </div>
          </div>
        );
      })()}
    </div>
  );
}