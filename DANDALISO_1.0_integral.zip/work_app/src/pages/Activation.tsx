import React, { useEffect, useState } from 'react';
import { ShieldCheck, Copy, LockKeyhole, RefreshCw } from 'lucide-react';
import toast from 'react-hot-toast';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';

interface ActivationProps {
  onActivated: () => void;
}

export default function Activation({ onActivated }: ActivationProps) {
  const [machineCode, setMachineCode] = useState('Chargement...');
  const [licenseKey, setLicenseKey] = useState('');
  const [isLoading, setIsLoading] = useState(true);
  const [isActivating, setIsActivating] = useState(false);

  const loadStatus = async () => {
    setIsLoading(true);
    try {
      if (!window.DANDALI_LICENSE) {
        setMachineCode('MODE-NAVIGATEUR-DEVELOPPEMENT');
        toast.error('Pour activer réellement, lancez en mode Electron ou compilez le .exe');
        return;
      }
      const status = await window.DANDALI_LICENSE.getStatus();
      setMachineCode(status.machineCode);
      if (status.activated) onActivated();
    } catch (_error) {
      toast.error('Impossible de lire le statut de licence');
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    loadStatus();
  }, []);

  const copyCode = async () => {
    try {
      if (window.DANDALI_LICENSE) {
        await window.DANDALI_LICENSE.copyMachineCode(machineCode);
      } else {
        await navigator.clipboard.writeText(machineCode);
      }
      toast.success('Code machine copié');
    } catch (_error) {
      toast.error('Copie impossible');
    }
  };

  const activate = async (event: React.FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    if (!licenseKey.trim()) {
      toast.error('Entrez la clé d’activation');
      return;
    }
    if (!window.DANDALI_LICENSE) {
      toast.error('Activation réelle disponible uniquement dans Electron / le .exe');
      return;
    }

    setIsActivating(true);
    try {
      const result = await window.DANDALI_LICENSE.activate(licenseKey);
      if (result.ok && result.activated) {
        toast.success(result.message || 'Activation réussie');
        onActivated();
      } else {
        toast.error(result.message || 'Clé invalide');
      }
    } catch (_error) {
      toast.error('Erreur pendant l’activation');
    } finally {
      setIsActivating(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-slate-100 via-teal-50 to-slate-200 px-4">
      <div className="w-full max-w-xl bg-white rounded-3xl shadow-2xl border border-slate-200 overflow-hidden">
        <div className="bg-teal-700 text-white p-6 flex items-center gap-4">
          <div className="w-14 h-14 rounded-2xl bg-white/15 flex items-center justify-center">
            <ShieldCheck className="w-8 h-8" />
          </div>
          <div>
            <h1 className="text-2xl font-bold">Activation DANDALISO 1.0</h1>
            <p className="text-sm text-teal-50">Protection contre la copie non autorisée</p>
          </div>
        </div>

        <div className="p-6 space-y-6">
          <div className="rounded-2xl border bg-slate-50 p-4 space-y-3">
            <div className="flex items-center gap-2 text-slate-700 font-semibold">
              <LockKeyhole className="w-5 h-5 text-teal-700" />
              Code machine de cet ordinateur
            </div>
            <div className="flex gap-2">
              <Input value={machineCode} readOnly className="font-mono text-sm bg-white" />
              <Button type="button" variant="outline" onClick={copyCode} disabled={isLoading}>
                <Copy className="w-4 h-4" />
              </Button>
            </div>
            <p className="text-xs text-slate-500">
              Envoyez ce code au propriétaire de l’application pour recevoir la clé d’activation.
              Une clé donnée pour ce PC ne fonctionnera pas sur un autre ordinateur.
              En mode navigateur simple, ce code est seulement un test visuel : utilisez npm run electron:dev pour obtenir le vrai code machine.
            </p>
          </div>

          <form onSubmit={activate} className="space-y-4">
            <div className="space-y-2">
              <Label>Clé d’activation</Label>
              <Input
                value={licenseKey}
                onChange={(e) => setLicenseKey(e.target.value.toUpperCase())}
                placeholder="XXXXX-XXXXX-XXXXX-XXXXX-XXXXX"
                className="font-mono"
                autoFocus
              />
            </div>

            <div className="flex flex-col sm:flex-row gap-3">
              <Button type="submit" className="flex-1 bg-teal-700 hover:bg-teal-800" disabled={isActivating || isLoading}>
                {isActivating ? 'Activation...' : 'Activer cette installation'}
              </Button>
              <Button type="button" variant="outline" onClick={loadStatus} disabled={isLoading}>
                <RefreshCw className="w-4 h-4 mr-2" /> Vérifier
              </Button>
            </div>
          </form>

          <div className="text-xs text-slate-500 border-t pt-4">
            Sécurité hors ligne : l’activation est enregistrée localement dans le dossier utilisateur Windows.
            Si le fichier .exe est copié sur un autre PC, une nouvelle activation sera demandée.
          </div>
        </div>
      </div>
    </div>
  );
}
