import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import { toast } from "react-hot-toast";
import { Stethoscope, Activity, ClipboardCheck } from "lucide-react";
import { useAuth } from "@/hooks/useAuth";
import { db } from "@/db";
import { cn } from "@/lib/utils";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";

export default function Login() {
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const { login } = useAuth();
  const navigate = useNavigate();

  const handleSubmit = async (event: React.FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    setIsLoading(true);
    try {
      const cleanUsername = username.trim();
      const cleanPassword = password.trim();

      // Query users in Dexie DB or use developer default accounts
      const usersInDb = await db.utilisateurs.toArray();
      let foundUser = usersInDb.find(u => 
        (u.nom_utilisateur || "").trim().toLowerCase() === cleanUsername.toLowerCase() && 
        (u.statut || "actif") === 'actif'
      );
      
      let passwordMatched = false;
      if (foundUser) {
        // Direct database user - compare actual registered password or fallback to user123
        const storedPwd = (foundUser.mot_de_passe || "").trim() || `${foundUser.nom_utilisateur.trim()}123`;
        if (cleanPassword === storedPwd || cleanPassword === `${foundUser.nom_utilisateur.trim()}123`) {
          passwordMatched = true;
        } else {
          foundUser = undefined;
        }
      }

      if (!foundUser) {
        const defaults: Record<string, 'administrateur' | 'infirmier' | 'medecin' | 'laborantin' | 'caissiere' | 'comptable' | 'receptionniste'> = {
          admin: 'administrateur',
          medecin: 'medecin',
          infirmier: 'infirmier',
          laborantin: 'laborantin',
          caissiere: 'caissiere',
          comptable: 'comptable',
          receptionniste: 'receptionniste'
        };
        const lowerUser = cleanUsername.toLowerCase();
        if (defaults[lowerUser] && cleanPassword === `${lowerUser}123`) {
          foundUser = {
            id: lowerUser,
            nom_utilisateur: lowerUser,
            role: defaults[lowerUser]
          };
          passwordMatched = true;
        }
      }

      if (foundUser && passwordMatched) {
        login({
          id: String(foundUser.id || foundUser.nom_utilisateur),
          username: foundUser.nom_utilisateur,
          role: foundUser.role
        });
        toast.success("Bienvenue !");
        navigate("/");
      } else {
        toast.error("Identifiants incorrects");
      }
    } catch {
      toast.error("Erreur de connexion");
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-teal-50 to-teal-100">
      <div className="w-full max-w-md mx-4">
        <div className="bg-white rounded-2xl shadow-xl p-8 space-y-6">
          <div className="text-center space-y-2">
            <div className="w-16 h-16 rounded-2xl bg-teal-600 flex items-center justify-center mx-auto">
              <Stethoscope className="w-8 h-8 text-white" />
            </div>
            <h1 className="text-2xl font-bold text-slate-800">
              DANDALISO 1.0
            </h1>
            <p className="text-sm text-slate-500">
              Gestion Clinique
            </p>
          </div>

          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="space-y-2">
              <Label>Nom d'utilisateur</Label>
              <Input
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                placeholder="Nom d'utilisateur"
                autoComplete="username"
              />
            </div>

            <div className="space-y-2">
              <Label>Mot de passe</Label>
              <Input
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="Mot de passe"
                autoComplete="current-password"
              />
            </div>

            <Button
              type="submit"
              className="w-full bg-teal-600 hover:bg-teal-700"
              disabled={isLoading}
            >
              {isLoading ? "Connexion..." : "Se connecter"}
            </Button>
          </form>
        </div>
      </div>
    </div>
  );
}

export interface TextareaProps
  extends React.TextareaHTMLAttributes<HTMLTextAreaElement> {}

export const Textarea = React.forwardRef<HTMLTextAreaElement, TextareaProps>(
  ({ className, ...props }, ref) => {
    return (
      <textarea
        ref={ref}
        className={cn(
          "border-input placeholder:text-muted-foreground focus-visible:border-ring focus-visible:ring-ring/50 aria-invalid:ring-destructive/20 dark:aria-invalid:ring-destructive/40 aria-invalid:border-destructive dark:bg-input/30 flex field-sizing-content min-h-16 w-full rounded-md border bg-transparent px-3 py-2 text-base shadow-xs transition-[color,box-shadow] outline-none focus-visible:ring-[3px] disabled:cursor-not-allowed disabled:opacity-50 md:text-sm",
          className
        )}
        {...props}
      />
    );
  }
);
Textarea.displayName = "Textarea";

export interface ExamField {
  key: string;
  label: string;
  type: "input" | "select";
  options?: string[];
}

export interface ExamSection {
  id: string;
  label: string;
  icon: React.ComponentType<{ className?: string }>;
  fields: ExamField[];
}

export const clinicalExamSchema: ExamSection[] = [
  {
    id: "signes_vitaux",
    label: "A. Signes vitaux",
    icon: Activity,
    fields: [
      { key: "temperature", label: "Température (°C)", type: "input" },
      { key: "tension", label: "Tension artérielle (mmHg)", type: "input" },
      { key: "pouls", label: "Pouls (bpm)", type: "input" },
      { key: "frequence_respiratoire", label: "FR (/min)", type: "input" },
      { key: "saturation_o2", label: "Sat O2 (%)", type: "input" },
      { key: "poids", label: "Poids (kg)", type: "input" },
      { key: "taille", label: "Taille (cm)", type: "input" },
      { key: "glycemie", label: "Glycémie (g/L)", type: "input" },
    ],
  },
  {
    id: "examen_general",
    label: "B. Examen général",
    icon: ClipboardCheck,
    fields: [
      {
        key: "etat_general",
        label: "État général",
        type: "select",
        options: ["Bon", "Moyen", "Altéré", "Grave"],
      },
      {
        key: "conscience",
        label: "Conscience",
        type: "select",
        options: ["Claire", "Obnubilée", "Coma"],
      },
    ],
  },
];