import React, { useState, useEffect, useMemo } from "react";
import { useLiveQuery } from "dexie-react-hooks";
import { db } from "@/db";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  Search,
  UserPlus,
  FileText,
  Stethoscope,
  Pill,
  FlaskConical,
  BedDouble,
  Activity,
  ChevronRight,
  Calendar,
  Phone,
  ShieldAlert,
  Printer,
  User,
  Clock,
  Heart,
  BriefcaseMedical,
} from "lucide-react";
import { toast } from "react-hot-toast";
import { getPrintSettings, renderPrintHeader, renderPrintFooter, renderPreviewToolbar, previewToolbarStyles, installPdfBridge } from "@/lib/printSettings";

export default function DossierMedical() {
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedPatientId, setSelectedPatientId] = useState<string | null>(
    null,
  );
  const [activeTab, setActiveTab] = useState<
    | "info"
    | "consultations"
    | "ordonnances"
    | "laboratoire"
    | "soins"
    | "hospitalisations"
  >("info");
  const [isNewPatientOpen, setIsNewPatientOpen] = useState(false);

  // New patient form state
  const [newPatient, setNewPatient] = useState({
    nom_complet: "",
    telephone: "",
    age: "",
    sexe: "M",
    allergies: "",
    antecedents: "",
    classe_sanguine: "",
    numero_insurance: "",
    assurer: "non",
  });

  useEffect(() => {
    installPdfBridge();
  }, []);

  const safeParseMedications = (raw: any): any[] => {
    if (!raw) return [];
    if (Array.isArray(raw)) return raw;
    try {
      const parsed = JSON.parse(raw);
      return Array.isArray(parsed) ? parsed : [];
    } catch {
      return [];
    }
  };


  const normalizePersonText = (value: any) => String(value || "").trim().toLowerCase().replace(/\s+/g, " ");
  const normalizePhone = (value: any) => String(value || "").replace(/\D/g, "");
  const isSamePerson = (servicePatient: any, dossierPatient: any) => {
    if (!servicePatient || !dossierPatient) return false;
    const sameName = normalizePersonText(servicePatient.nom_complet) === normalizePersonText(dossierPatient.nom_complet);
    if (!sameName) return false;
    const servicePhone = normalizePhone(servicePatient.telephone);
    const dossierPhone = normalizePhone(dossierPatient.telephone);
    // Si les deux téléphones existent, ils doivent correspondre. Sinon le nom exact suffit.
    return !servicePhone || !dossierPhone || servicePhone === dossierPhone;
  };

  // Dossier médical : uniquement les patients issus des consultations
  const consultationsPatients = useLiveQuery(() => db.patients_consultation.toArray()) || [];
  const consultations = useLiveQuery(() => db.consultations.toArray()) || [];
  const ordonnances = useLiveQuery(() => db.ordonnances.toArray()) || [];
  const laboratoire = useLiveQuery(() => db.examensLaboratoire.toArray()) || [];
  const soins = useLiveQuery(() => db.soinsInfirmiers.toArray()) || [];
  const hospitalisations = useLiveQuery(() => db.hospitalisations.toArray()) || [];
  const patients_cons = consultationsPatients;
  const patients = consultationsPatients;
  const patients_lab = useLiveQuery(() => db.patients_laboratoire.toArray()) || [];
  const patients_soins = useLiveQuery(() => db.patients_soins.toArray()) || [];
  const patients_hosp = useLiveQuery(() => db.patients_hospitalisation.toArray()) || [];

  const unifiedPatients = useMemo(() => {
    return consultationsPatients
      .map((p: any) => ({
        origin: "consultation",
        id: p.id,
        uniqueId: `consultation-${p.id}`,
        nom_complet: p.nom_complet,
        telephone: p.telephone || "",
        age: p.age || "",
        sexe: p.sexe || "M",
        allergies: p.allergies || "",
        antecedents: p.antecedents || "",
        classe_sanguine: p.classe_sanguine || "",
        numero_insurance: p.numero_insurance || "",
        assurer: p.assurer || "non",
        numero_patient: p.numero_patient || `CON-${String(p.id || 0).padStart(4, "0")}`,
        created_at: p.created_at || new Date(),
      }))
      .sort((a: any, b: any) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime());
  }, [consultationsPatients]);

  // Set first patient as default selected if none is selected
  useEffect(() => {
    if (unifiedPatients.length > 0 && selectedPatientId === null) {
      setSelectedPatientId(unifiedPatients[0].uniqueId);
    }
  }, [unifiedPatients, selectedPatientId]);

  // Handle active selected patient data
  const selectedPatient = useMemo(() => {
    return (
      unifiedPatients.find((p) => p.uniqueId === selectedPatientId) ||
      unifiedPatients[0] ||
      null
    );
  }, [unifiedPatients, selectedPatientId]);

  // Filter lists based on selected patient's name matching (since we have multiple patient ID sources)
  const patientConsultations = useMemo(() => {
    if (!selectedPatient) return [];
    return consultations.filter((c) => {
      // Find matching patient by ID or Name
      if (c.patient_id === selectedPatient.id) return true;
      // Also fallback on name match if needed
      const normalName = selectedPatient.nom_complet.trim().toLowerCase();
      const conPatient = patients_cons.find(
        (p) => p.id === Number(c.patient_id),
      );
      return (
        conPatient && conPatient.nom_complet.trim().toLowerCase() === normalName
      );
    });
  }, [selectedPatient, consultations, patients_cons]);

  const patientOrdonnances = useMemo(() => {
    if (!selectedPatient) return [];
    return ordonnances.filter((o) => {
      if (o.patient_id === selectedPatient.id) return true;
      const normalName = selectedPatient.nom_complet.trim().toLowerCase();
      // Look in other patient registries to cross-reference
      const globalPatient = patients.find((p) => p.id === Number(o.patient_id));
      if (
        globalPatient &&
        globalPatient.nom_complet.trim().toLowerCase() === normalName
      )
        return true;
      const conPatient = patients_cons.find(
        (p) => p.id === Number(o.patient_id),
      );
      return (
        conPatient && conPatient.nom_complet.trim().toLowerCase() === normalName
      );
    });
  }, [selectedPatient, ordonnances, patients, patients_cons]);

  const patientLaboratoire = useMemo(() => {
    if (!selectedPatient) return [];
    return laboratoire.filter((l) => {
      const labPatient = patients_lab.find((p) => p.id === Number(l.patient_id));
      // Important : ne jamais comparer directement les ID entre tables différentes.
      // Un ID laboratoire peut être identique à un ID consultation d'un autre malade.
      return isSamePerson(labPatient, selectedPatient);
    });
  }, [selectedPatient, laboratoire, patients_lab]);

  const patientSoins = useMemo(() => {
    if (!selectedPatient) return [];
    return soins.filter((s) => {
      const soinPatient = patients_soins.find((p) => p.id === Number(s.patient_id));
      return isSamePerson(soinPatient, selectedPatient);
    });
  }, [selectedPatient, soins, patients_soins]);

  const patientHospitalisations = useMemo(() => {
    if (!selectedPatient) return [];
    return hospitalisations.filter((h) => {
      const hospPatient = patients_hosp.find((p) => p.id === Number(h.patient_id));
      return isSamePerson(hospPatient, selectedPatient);
    });
  }, [selectedPatient, hospitalisations, patients_hosp]);

  // Search filtered patients
  const filteredPatients = useMemo(() => {
    if (!searchTerm) return unifiedPatients;
    const term = searchTerm.toLowerCase();
    return unifiedPatients.filter(
      (p) =>
        p.nom_complet.toLowerCase().includes(term) ||
        (p.telephone && p.telephone.includes(term)) ||
        (p.numero_patient && p.numero_patient.toLowerCase().includes(term)),
    );
  }, [unifiedPatients, searchTerm]);

  // Handle adding patient
  const handleCreatePatient = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newPatient.nom_complet) {
      toast.error("Veuillez saisir le nom complet");
      return;
    }

    try {
      const generatedId = `CON-${String(consultationsPatients.length + 1).padStart(4, "0")}`;
      const pId = await db.patients_consultation.add({
        nom_complet: newPatient.nom_complet,
        telephone: newPatient.telephone,
        age: newPatient.age,
        sexe: newPatient.sexe,
        allergies: newPatient.allergies,
        antecedents: newPatient.antecedents,
        classe_sanguine: newPatient.classe_sanguine,
        numero_insurance: newPatient.numero_insurance,
        assurer: newPatient.assurer,
        numero_patient: generatedId,
        created_at: new Date(),
      });

      toast.success("Patient ajouté au dossier médical des consultations");
      setSelectedPatientId(`consultation-${pId}`);
      setIsNewPatientOpen(false);
      setNewPatient({
        nom_complet: "",
        telephone: "",
        age: "",
        sexe: "M",
        allergies: "",
        antecedents: "",
        classe_sanguine: "",
        numero_insurance: "",
        assurer: "non",
      });
    } catch (err) {
      toast.error("Erreur lors de la création du patient");
    }
  };

  const printRecord = async () => {
    const printSettings = await getPrintSettings();
    if (!selectedPatient) return;

    const p = selectedPatient;
    const bloodType = p.classe_sanguine || "N/A";
    const ins =
      p.assurer === "oui" ? `Oui (N° ${p.numero_insurance || "N/A"})` : "Non";

    // Format consultations
    let consultationsHTML = "";
    if (patientConsultations.length === 0) {
      consultationsHTML =
        "<p class='no-data'>Aucune consultation répertoriée.</p>";
    } else {
      patientConsultations.forEach((c) => {
        consultationsHTML += `
          <div class="element-card">
            <div class="element-header">
              <span>🩺 Consultation - ${new Date(c.date_consultation).toLocaleDateString("fr-FR")}</span>
              <span>Constantes: TA: ${c.tension || "N/A"} mmHg | Pouls: ${c.pouls || "N/A"} bpm | Temp: ${c.temperature || "N/A"} °C</span>
            </div>
            <div class="element-body">
              <strong>Motif :</strong> ${c.motif || "Non renseigné"}<br/>
              <strong>Diagnostic clinique :</strong> ${c.diagnostic || "Non documenté"}<br/>
              <strong>Observation/Historique :</strong> ${c.observations || c.examen_clinique || "N/A"}<br/>
              ${c.examens_demandes || c.examens_complementaires_libres ? `<strong>Examens demandés :</strong> ${c.examens_demandes || c.examens_complementaires_libres}` : ""}
            </div>
          </div>
        `;
      });
    }

    // Format prescriptions
    let ordonnancesHTML = "";
    if (patientOrdonnances.length === 0) {
      ordonnancesHTML =
        "<p class='no-data'>Aucune prescription enregistrée.</p>";
    } else {
      patientOrdonnances.forEach((o) => {
        ordonnancesHTML += `
          <div class="element-card">
            <div class="element-header">
              <span>📋 Ordonnance Prescrite le ${new Date(o.date_ordonnance).toLocaleDateString("fr-FR")}</span>
              <span>Médecin : ${o.medecin || o["médecin"] || "Dr. Kouyaté"}</span>
            </div>
            <div class="element-body">
              <table class="sub-table">
                <thead>
                  <tr>
                    <th>Médicament / DCI</th>
                    <th>Posologie & Fréquence</th>
                    <th>Durée</th>
                  </tr>
                </thead>
                <tbody>
                  ${
                    (safeParseMedications(o.medicaments_data).length > 0
                      ? safeParseMedications(o.medicaments_data)
                      : Array.isArray(o.medicaments)
                        ? o.medicaments
                        : []
                    )
                      .map(
                        (med: any) => `
                    <tr>
                      <td><strong>${med.nom || med.brandName || med.nom_medicament || ""}</strong> (${med.dci || "N/A"})</td>
                      <td>${med.dosage || med.posologie || ""} • ${med.frequence || med.dosageInstructions || med.frequency || ""}</td>
                      <td>${med.duree || med.duration || ""}</td>
                    </tr>
                  `,
                      )
                      .join("") ||
                    (o.medicaments
                      ? `<tr><td colspan="3">${o.medicaments}</td></tr>`
                      : '<tr><td colspan="3">Aucun médicament répertorié</td></tr>')
                  }
                </tbody>
              </table>
              ${o.instructions ? `<div style="margin-top: 8px;"><strong>Instructions complémentaires :</strong> ${o.instructions}</div>` : ""}
            </div>
          </div>
        `;
      });
    }

    // Format Laboratory Results
    let labHTML = "";
    if (patientLaboratoire.length === 0) {
      labHTML = "<p class='no-data'>Aucun examen biologique enregistré.</p>";
    } else {
      labHTML += `
        <table class="main-table">
          <thead>
            <tr>
              <th>Date</th>
              <th>Analyse demandée</th>
              <th>Résultat obtenu</th>
              <th>Laborantin</th>
            </tr>
          </thead>
          <tbody>
            ${patientLaboratoire
              .map(
                (l) => `
              <tr>
                <td>${new Date(l.date_examen || l.created_at || new Date()).toLocaleDateString("fr-FR")}</td>
                <td><strong>${l.type_analyse || l.examen || ""}</strong> ${l.sous_categorie ? `(${l.sous_categorie})` : ""}</td>
                <td style="color:#1d4ed8; font-weight:bold; font-family:monospace;">${l.resultat || "En attente"}</td>
                <td>${l.biologiste || "Non renseigné"}</td>
              </tr>
            `,
              )
              .join("")}
          </tbody>
        </table>
      `;
    }

    // Format nursing care / observations
    let soinsHTML = "";
    if (patientSoins.length === 0) {
      soinsHTML =
        "<p class='no-data'>Aucun soin/observation infirmière documenté.</p>";
    } else {
      patientSoins.forEach((s) => {
        soinsHTML += `
          <div class="element-card">
            <div class="element-header">
              <span>💉 Acte de Soin - ${new Date(s.date_soin || s.created_at).toLocaleDateString("fr-FR")}</span>
              <span>Effectué par Infirmerie</span>
            </div>
            <div class="element-body font-sans">
              <strong>Type d'Acte / Soin :</strong> ${s.type_soin || "Observation"}<br/>
              <strong>Observations de l'Infirmier :</strong> ${s.observations || "N/A"}<br/>
              <strong>Constantes prises :</strong> Tension: ${s.tension || "N/A"} mmHg • Température: ${s.temperature || "N/A"} °C • Pouls: ${s.pouls || "N/A"} bpm
            </div>
          </div>
        `;
      });
    }

    // Format Hospitalisations
    let hospHTML = "";
    if (patientHospitalisations.length === 0) {
      hospHTML = "<p class='no-data'>Aucun historique d'hospitalisation.</p>";
    } else {
      hospHTML += `
        <table class="main-table">
          <thead>
            <tr>
              <th>Date d'Entrée</th>
              <th>Date de Sortie</th>
              <th>Service / Pavillon</th>
              <th>N° Chambre / Lit</th>
              <th>Motif d'Admission</th>
            </tr>
          </thead>
          <tbody>
            ${patientHospitalisations
              .map(
                (h) => `
              <tr>
                <td>${new Date(h.date_entree).toLocaleDateString("fr-FR")}</td>
                <td>${h.date_sortie ? new Date(h.date_sortie).toLocaleDateString("fr-FR") : "En cours"}</td>
                <td>${h.service || "N/A"}</td>
                <td>N° ${h.chambre || "N/A"} - Lit: ${h.lit || "N/A"}</td>
                <td>${h.motif_admission || "N/A"}</td>
              </tr>
            `,
              )
              .join("")}
          </tbody>
        </table>
      `;
    }

    const printContent = `
      <html>
        <head>
          <title>DOSSIER CLINIQUE COMPLET - ${p.nom_complet}</title>
          <style>
            body { font-family: 'Segoe UI', Arial, sans-serif; padding: 40px; color: #1e293b; background: white; font-size: 10pt; line-height: 1.5; }
            ${previewToolbarStyles()}
            .preview-toolbar { margin: -40px -40px 24px -40px; }
            @media print { body { padding: 0; } }
            .print-logo-wrap { flex:0 0 auto; }
            .print-logo { width:52px; height:52px; object-fit:contain; display:block; }
            .print-header-main { flex:1; }
            .print-header-block { display: flex; justify-content: space-between; border-bottom: 3px solid #0d9488; padding-bottom: 12px; margin-bottom: 25px; }
            .print-clinic-name { font-size: 18pt; font-weight: 800; color: #0f766e; text-transform: uppercase; }
            .print-clinic-sub, .print-custom-header { font-size: 9pt; color: #64748b; line-height:1.35; }
            .print-doc-title { font-size: 9.5pt; color: #64748b; text-align:right; line-height:1.4; }
            .print-footer-block { border-top: 1px solid #cbd5e1; margin-top: 20px; padding-top: 6px; text-align:center; font-size:8.5pt; color:#64748b; }
            .document-title { text-align: center; margin: 25px 0; font-size: 16pt; font-weight: bold; color: #0f766e; border-bottom: 2px double #0f766e; display: inline-block; padding-bottom: 5px; width: 100%; text-transform: uppercase; letter-spacing: 2px; }
            .civil-box { display: grid; grid-template-columns: 1fr 1fr; gap: 20px; border: 1px solid #cbd5e1; background-color: #f8fafc; padding: 15px; border-radius: 6px; margin-bottom: 30px; }
            .civil-box h3 { margin: 0 0 10px 0; font-size: 11pt; color: #0f766e; border-bottom: 1px solid #cbd5e1; padding-bottom: 3px; text-transform: uppercase; }
            .section-title { font-size: 12pt; font-weight: bold; color: #0d9488; border-left: 4px solid #0d9488; padding-left: 8px; margin: 30px 0 15px 0; text-transform: uppercase; letter-spacing: 1px; }
            .element-card { border: 1px solid #e2e8f0; border-radius: 6px; margin-bottom: 15px; overflow: hidden; page-break-inside: avoid; }
            .element-header { background-color: #f1f5f9; padding: 8px 12px; font-weight: bold; color: #334155; display: flex; justify-content: space-between; font-size: 9.5pt; border-bottom: 1px solid #e2e8f0; }
            .element-body { padding: 12px; font-size: 9.5pt; line-height: 1.6; }
            .main-table { width: 100%; border-collapse: collapse; margin-top: 10px; font-size: 9.5pt; page-break-inside: avoid; }
            .main-table th { background-color: #0d9488; color: white; padding: 10px; border: 1px solid #0d9488; text-align: left; }
            .main-table td { padding: 10px; border: 1px solid #e2e8f0; }
            .sub-table { width: 100%; border-collapse: collapse; margin-top: 5px; font-size: 9pt; }
            .sub-table th { background-color: #f1f5f9; color: #475569; padding: 6px; border: 1px solid #cbd5e1; text-align: left; }
            .sub-table td { padding: 6px; border: 1px solid #e2e8f0; }
            .no-data { font-style: italic; color: #64748b; padding: 8px 0; }
            .footer-signature { display: flex; justify-content: space-between; margin-top: 60px; font-size: 9.5pt; page-break-inside: avoid; }
            .sig-box { text-align: center; width: 200px; }
            .sig-line { border-top: 1px solid #cbd5e1; margin-top: 45px; font-weight: bold; padding-top: 4px; color: #475569; }
          </style>
        </head>
        <body>
          ${renderPreviewToolbar()}
          ${renderPrintHeader(printSettings, `N° Dossier : ${p.numero_patient || "PAT-N/A"} | Date : ${new Date().toLocaleDateString("fr-FR")}`)}

          <div class="document-title">DOSSIER MÉDICAL CLASSIQUE COMPLET</div>

          <div class="civil-box">
            <div>
              <h3>IDENTITÉ ET COORDONNÉES</h3>
              <strong>Nom Complet :</strong> ${p.nom_complet}<br/>
              <strong>Âge / Sexe :</strong> ${p.age ? p.age + " ans" : "N/A"} / ${p.sexe || "N/A"}<br/>
              <strong>Téléphone :</strong> ${p.telephone || "Non renseigné"}<br/>
              <strong>Création du Dossier :</strong> ${p.created_at ? new Date(p.created_at).toLocaleDateString("fr-FR") : "N/A"}<br/>
            </div>
            <div>
              <h3>PROFIL CLINIQUE & ASSURANCE</h3>
              <strong>Groupe Sanguin :</strong> <span style="color:#ef4444; font-weight:bold;">${bloodType}</span><br/>
              <strong>Prise en charge Assurance :</strong> ${ins}<br/>
              <strong>Allergies connues :</strong> <span style="font-weight:bold; color:#ef4444;">${p.allergies || "Aucune allergie signalée"}</span><br/>
              <strong>Antécédents / Pathologies :</strong> ${p.antecedents || "Aucun antécédent particulier renseigné"}<br/>
            </div>
          </div>

          <div class="section-title">1. Historique des Consultations</div>
          ${consultationsHTML}

          <div class="section-title">2. Prescriptions d'Ordonnances</div>
          ${ordonnancesHTML}

          <div class="section-title">3. Examens et Analyses Biologiques</div>
          ${labHTML}

          <div class="section-title">4. Actes de Soins et Observations Infirmières</div>
          ${soinsHTML}

          <div class="section-title">5. Séjours en Hospitalisation</div>
          ${hospHTML}

          <div class="footer-signature">
            <div class="sig-box">
              <span style="font-size: 8.5pt; color: #64748b; font-style: italic;">Cachet de l'Établissement</span>
              <div class="sig-line">Direction de la Clinique</div>
            </div>
            <div class="sig-box">
              <span style="font-size: 8.5pt; color: #64748b; font-style: italic;">Médecin Traitant Responsable</span>
              <div class="sig-line">${printSettings.medecin_responsable || "Médecin responsable"}</div>
            </div>
          </div>

          ${renderPrintFooter(printSettings)}

          <script>
            window.onload = function() {
              document.title = 'Aperçu dossier médical - ${p.nom_complet}';
            }
          </script>
        </body>
      </html>
    `;
    if (window.DANDALI_PRINT?.previewHtml) {
      window.DANDALI_PRINT.previewHtml(printContent);
    } else {
      const win = window.open("", "_blank");
      if (win) { win.document.write(printContent); win.document.close(); }
    }
  };

  return (
    <div className="space-y-6 container mx-auto px-4 py-4 min-h-screen">
      {/* Header section with Stats */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 border-b border-slate-100 dark:border-slate-800 pb-5">
        <div>
          <h1 className="text-2xl font-bold font-sans text-slate-800 dark:text-white flex items-center gap-2">
            <BriefcaseMedical className="h-7 w-7 text-teal-600" />
            Dossier Clinique Patient & Suivi Médical
          </h1>
          <p className="text-sm text-slate-500 dark:text-slate-400">
            Consultez le dossier médical complet des patients, examens de
            laboratoire, prescriptions, observations infirmières, et
            hospitalisations.
          </p>
        </div>
        <div className="flex gap-2">
          <Button
            onClick={() => setIsNewPatientOpen(!isNewPatientOpen)}
            className="bg-teal-600 hover:bg-teal-700 text-white flex items-center gap-2"
          >
            <UserPlus className="h-4 w-4" />
            Nouveau Patient
          </Button>
          {selectedPatient && (
            <Button
              onClick={printRecord}
              variant="outline"
              className="border-slate-200 text-slate-705 dark:text-slate-300 dark:border-slate-800"
            >
              <Printer className="h-4 w-4 mr-2" />
              Imprimer Dossier
            </Button>
          )}
        </div>
      </div>

      {/* New Patient Registration Overlay Modal */}
      {isNewPatientOpen && (
        <Card className="border-teal-200 dark:border-teal-900 bg-white dark:bg-slate-900 shadow-xl max-w-2xl mx-auto">
          <CardHeader className="bg-gradient-to-r from-teal-50 to-white dark:from-teal-900/10 dark:to-slate-900 border-b border-tea-100 dark:border-slate-800">
            <CardTitle className="text-teal-800 dark:text-teal-400 flex items-center gap-2 text-base">
              <UserPlus className="h-5 w-5" />
              Créer un Nouveau Dossier Patient Unique
            </CardTitle>
          </CardHeader>
          <CardContent className="pt-6">
            <form
              onSubmit={handleCreatePatient}
              className="grid grid-cols-1 md:grid-cols-2 gap-4"
            >
              <div className="space-y-2">
                <Label htmlFor="nom_complet">Nom complet *</Label>
                <Input
                  id="nom_complet"
                  value={newPatient.nom_complet}
                  onChange={(e) =>
                    setNewPatient({
                      ...newPatient,
                      nom_complet: e.target.value,
                    })
                  }
                  placeholder="Jean Dupont"
                  required
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="telephone">Téléphone</Label>
                <Input
                  id="telephone"
                  value={newPatient.telephone}
                  onChange={(e) =>
                    setNewPatient({ ...newPatient, telephone: e.target.value })
                  }
                  placeholder="+223 77 00 00 00"
                />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="age">Âge</Label>
                  <Input
                    id="age"
                    type="number"
                    value={newPatient.age}
                    onChange={(e) =>
                      setNewPatient({ ...newPatient, age: e.target.value })
                    }
                    placeholder="28"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="sexe">Sexe</Label>
                  <select
                    id="sexe"
                    value={newPatient.sexe}
                    onChange={(e) =>
                      setNewPatient({ ...newPatient, sexe: e.target.value })
                    }
                    className="w-full h-9 rounded-md border border-input px-3 py-1 bg-white dark:bg-slate-900 text-sm text-foreground focus-visible:outline-hidden focus-visible:ring-1 focus-visible:ring-ring"
                  >
                    <option value="M">Masculin</option>
                    <option value="F">Féminin</option>
                    <option value="Autre">Autre</option>
                  </select>
                </div>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="blood">Groupe Sanguin</Label>
                  <select
                    id="blood"
                    value={newPatient.classe_sanguine}
                    onChange={(e) =>
                      setNewPatient({
                        ...newPatient,
                        classe_sanguine: e.target.value,
                      })
                    }
                    className="w-full h-9 rounded-md border border-input px-3 py-1 bg-white dark:bg-slate-900 text-sm text-foreground"
                  >
                    <option value="">Sélectionner</option>
                    <option value="A+">A+</option>
                    <option value="A-">A-</option>
                    <option value="B+">B+</option>
                    <option value="B-">B-</option>
                    <option value="O+">O+</option>
                    <option value="O-">O-</option>
                    <option value="AB+">AB+</option>
                    <option value="AB-">AB-</option>
                  </select>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="assurer">Assuré ?</Label>
                  <select
                    id="assurer"
                    value={newPatient.assurer}
                    onChange={(e) =>
                      setNewPatient({ ...newPatient, assurer: e.target.value })
                    }
                    className="w-full h-9 rounded-md border border-input px-3 py-1 bg-white dark:bg-slate-900 text-sm text-foreground"
                  >
                    <option value="non">Non</option>
                    <option value="oui">Oui</option>
                  </select>
                </div>
              </div>
              {newPatient.assurer === "oui" && (
                <div className="space-y-2 md:col-span-2">
                  <Label htmlFor="num_insurance">
                    Numéro de Carte d'Assurance / Organisme
                  </Label>
                  <Input
                    id="num_insurance"
                    value={newPatient.numero_insurance}
                    onChange={(e) =>
                      setNewPatient({
                        ...newPatient,
                        numero_insurance: e.target.value,
                      })
                    }
                    placeholder="IN-382910"
                  />
                </div>
              )}
              <div className="space-y-2 md:col-span-2">
                <Label htmlFor="allergies">Allergies connues</Label>
                <Input
                  id="allergies"
                  value={newPatient.allergies}
                  onChange={(e) =>
                    setNewPatient({ ...newPatient, allergies: e.target.value })
                  }
                  placeholder="Ex: Pénicilline, arachides..."
                />
              </div>
              <div className="space-y-2 md:col-span-2">
                <Label htmlFor="antecedents">
                  Antécédents cliniques / Chroniques
                </Label>
                <Input
                  id="antecedents"
                  value={newPatient.antecedents}
                  onChange={(e) =>
                    setNewPatient({
                      ...newPatient,
                      antecedents: e.target.value,
                    })
                  }
                  placeholder="Ex: Hypertension artérielle, diabète de type 2..."
                />
              </div>
              <div className="md:col-span-2 flex justify-end gap-2 pt-4">
                <Button
                  type="button"
                  variant="outline"
                  onClick={() => setIsNewPatientOpen(false)}
                >
                  Annuler
                </Button>
                <Button
                  type="submit"
                  className="bg-teal-600 text-white hover:bg-teal-700"
                >
                  Valider et Enregistrer
                </Button>
              </div>
            </form>
          </CardContent>
        </Card>
      )}

      {/* Main layout: directory left side, clinical folder right side */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* LEFT COLUMN: Patient Registry Directory */}
        <div className="lg:col-span-4 space-y-4">
          <Card className="border-slate-200 dark:border-slate-800">
            <CardHeader className="pb-3">
              <CardTitle className="text-base font-sans text-slate-800 dark:text-white flex items-center justify-between">
                <span>Navigateur Patients ({filteredPatients.length})</span>
                <span className="text-xs bg-slate-100 text-slate-700 dark:bg-slate-800 dark:text-slate-300 font-normal px-2 py-0.5 rounded-full">
                  Dexie Offline
                </span>
              </CardTitle>
              <div className="relative pt-2">
                <Search className="absolute left-3 top-5 h-4 w-4 text-slate-400" />
                <Input
                  className="pl-9 bg-slate-50 dark:bg-slate-900 border-none"
                  placeholder="Rechercher nom, n° ou tel..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                />
              </div>
            </CardHeader>
            <CardContent className="p-0 max-h-[500px] overflow-y-auto">
              {filteredPatients.length === 0 ? (
                <div className="py-12 text-center text-slate-400 text-sm">
                  Aucun dossier trouvé.
                </div>
              ) : (
                <div className="divide-y divide-slate-100 dark:divide-slate-800">
                  {filteredPatients.map((patient) => {
                    const isSelected =
                      selectedPatient?.uniqueId === patient.uniqueId;
                    return (
                      <button
                        key={patient.uniqueId}
                        onClick={() => {
                          setSelectedPatientId(patient.uniqueId);
                          setActiveTab("info");
                        }}
                        className={`w-full text-left p-4 transition-all flex items-center justify-between group ${
                          isSelected
                            ? "bg-teal-50/50 dark:bg-teal-950/20 border-r-4 border-teal-600"
                            : "hover:bg-slate-50 dark:hover:bg-slate-800/40"
                        }`}
                      >
                        <div className="space-y-1">
                          <p
                            className={`font-bold text-sm ${isSelected ? "text-teal-700 dark:text-teal-400" : "text-slate-800 dark:text-white"}`}
                          >
                            {patient.nom_complet}
                          </p>
                          <div className="flex gap-2 text-xs text-slate-400">
                            <span>
                              {patient.sexe === "F" ? "Femme" : "Homme"},{" "}
                              {patient.age
                                ? `${patient.age} ans`
                                : "Âge inconnu"}
                            </span>
                            <span>•</span>
                            <span className="font-mono">
                              {patient.numero_patient}
                            </span>
                          </div>
                          {patient.telephone && (
                            <p className="text-[11px] text-slate-500 font-mono flex items-center gap-1">
                              <Phone className="h-3 w-3" /> {patient.telephone}
                            </p>
                          )}
                        </div>
                        <ChevronRight
                          className={`h-4 w-4 text-slate-300 transition-transform group-hover:translate-x-1 ${isSelected ? "text-teal-600 dark:text-teal-400" : ""}`}
                        />
                      </button>
                    );
                  })}
                </div>
              )}
            </CardContent>
          </Card>
        </div>

        {/* RIGHT COLUMN: Full Patient Clinical File (Record Details) */}
        <div className="lg:col-span-8">
          {selectedPatient ? (
            <div className="space-y-6">
              {/* Patient Core Summary Banner */}
              <div className="bg-gradient-to-br from-slate-900 via-teal-950 to-slate-904 p-6 rounded-2xl text-white shadow-md relative overflow-hidden">
                <div className="absolute right-0 bottom-0 opacity-10">
                  <Activity className="w-64 h-64 text-white" />
                </div>

                <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 relative z-10">
                  <div className="flex items-center gap-4">
                    <div className="w-16 h-16 rounded-full bg-teal-600 flex items-center justify-center text-white text-2xl font-bold font-sans">
                      {selectedPatient.nom_complet.slice(0, 2).toUpperCase()}
                    </div>
                    <div>
                      <div className="flex items-center gap-2 flex-wrap">
                        <h2 className="text-xl font-bold font-sans">
                          {selectedPatient.nom_complet}
                        </h2>
                        <Badge
                          className={`${selectedPatient.sexe === "M" ? "bg-blue-600" : "bg-pink-600"} text-xs text-white`}
                        >
                          {selectedPatient.sexe === "F"
                            ? "Féminin"
                            : "Masculin"}
                        </Badge>
                        {selectedPatient.classe_sanguine && (
                          <Badge className="bg-red-600 text-xs text-white font-mono">
                            Groupe: {selectedPatient.classe_sanguine}
                          </Badge>
                        )}
                        <Badge className="bg-slate-700/55 text-xs text-slate-205">
                          ID: {selectedPatient.numero_patient}
                        </Badge>
                      </div>
                      <p className="text-teal-200 text-sm mt-1">
                        Sexe: {selectedPatient.sexe} | Âge:{" "}
                        {selectedPatient.age
                          ? `${selectedPatient.age} ans`
                          : "Non renseigné"}{" "}
                        | Phone: {selectedPatient.telephone || "Aucun"}
                      </p>
                    </div>
                  </div>
                  {selectedPatient.allergies && (
                    <div className="bg-red-950/50 border border-red-500/30 rounded-xl px-4 py-2 flex items-center gap-2 max-w-sm">
                      <ShieldAlert className="h-5 w-5 text-red-400" />
                      <div className="text-xs">
                        <p className="font-semibold text-red-300">
                          Allergies Signalées
                        </p>
                        <p className="text-slate-300 truncate">
                          {selectedPatient.allergies}
                        </p>
                      </div>
                    </div>
                  )}
                </div>
              </div>

              {/* Navigation Tabs for Medical Folder Sections */}
              <div className="flex overflow-x-auto gap-1 border-b border-slate-200 dark:border-slate-800 pb-2">
                {[
                  { id: "info", label: "Clinique & Synthèse", icon: User },
                  {
                    id: "consultations",
                    label: `Consultations (${patientConsultations.length})`,
                    icon: Stethoscope,
                  },
                  {
                    id: "ordonnances",
                    label: `Ordonnances (${patientOrdonnances.length})`,
                    icon: Pill,
                  },
                  {
                    id: "laboratoire",
                    label: `Lab & Analyses (${patientLaboratoire.length})`,
                    icon: FlaskConical,
                  },
                  {
                    id: "soins",
                    label: `Observations Soins (${patientSoins.length})`,
                    icon: Activity,
                  },
                  {
                    id: "hospitalisations",
                    label: `Hospitalisations (${patientHospitalisations.length})`,
                    icon: BedDouble,
                  },
                ].map((tab) => {
                  const Icon = tab.icon;
                  const isActive = activeTab === tab.id;
                  return (
                    <button
                      key={tab.id}
                      onClick={() => setActiveTab(tab.id as any)}
                      className={`flex items-center gap-2 px-4 py-2.5 rounded-lg text-sm font-semibold transition-all whitespace-nowrap ${
                        isActive
                          ? "bg-teal-600 text-white"
                          : "text-slate-600 hover:text-slate-900 dark:text-slate-400 dark:hover:text-white hover:bg-slate-50 dark:hover:bg-slate-800"
                      }`}
                    >
                      <Icon className="h-4 w-4" />
                      {tab.label}
                    </button>
                  );
                })}
              </div>

              {/* Tab Sections render Content */}
              <div className="space-y-6">
                {/* TAB: Clinique & Synthèse */}
                {activeTab === "info" && (
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <Card className="border-slate-200 dark:border-slate-800">
                      <CardHeader>
                        <CardTitle className="text-sm font-bold text-slate-800 dark:text-white flex items-center gap-2">
                          <User className="h-4 w-4 text-teal-600" />
                          Informations Générales
                        </CardTitle>
                      </CardHeader>
                      <CardContent className="space-y-4 text-sm text-slate-650 dark:text-slate-350">
                        <div className="grid grid-cols-2 py-1.5 border-b border-dashed border-slate-100 dark:border-slate-800">
                          <span className="font-semibold">N° de Patient:</span>
                          <span className="font-mono text-xs">
                            {selectedPatient.numero_patient}
                          </span>
                        </div>
                        <div className="grid grid-cols-2 py-1.5 border-b border-dashed border-slate-100 dark:border-slate-800">
                          <span className="font-semibold">Âge / Sexe:</span>
                          <span>
                            {selectedPatient.age
                              ? `${selectedPatient.age} ans`
                              : "-"}{" "}
                            / {selectedPatient.sexe}
                          </span>
                        </div>
                        <div className="grid grid-cols-2 py-1.5 border-b border-dashed border-slate-100 dark:border-slate-800">
                          <span className="font-semibold">Téléphone:</span>
                          <span>
                            {selectedPatient.telephone || "Non renseigné"}
                          </span>
                        </div>
                        <div className="grid grid-cols-2 py-1.5 border-b border-dashed border-slate-100 dark:border-slate-800">
                          <span className="font-semibold">Assuré:</span>
                          <span className="capitalize">
                            {selectedPatient.assurer || "Non"}
                          </span>
                        </div>
                        {selectedPatient.numero_insurance && (
                          <div className="grid grid-cols-2 py-1.5 border-b border-dashed border-slate-100 dark:border-slate-800">
                            <span className="font-semibold">N° Assureur:</span>
                            <span>{selectedPatient.numero_insurance}</span>
                          </div>
                        )}
                        <div className="grid grid-cols-2 py-1.5">
                          <span className="font-semibold">
                            Création de Dossier:
                          </span>
                          <span className="text-xs">
                            {new Date(
                              selectedPatient.created_at,
                            ).toLocaleDateString("fr-FR")}
                          </span>
                        </div>
                      </CardContent>
                    </Card>

                    <Card className="border-slate-200 dark:border-slate-800">
                      <CardHeader>
                        <CardTitle className="text-sm font-bold text-slate-800 dark:text-white flex items-center gap-2">
                          <ShieldAlert className="h-4 w-4 text-red-500" />
                          Antécédents & Alerte Médicale
                        </CardTitle>
                      </CardHeader>
                      <CardContent className="space-y-4">
                        <div className="space-y-1">
                          <span className="text-xs font-semibold text-slate-400">
                            Allergies Connues :
                          </span>
                          <div className="p-3 bg-red-50 dark:bg-red-950/20 text-red-700 dark:text-red-400 rounded-lg text-sm font-medium">
                            {selectedPatient.allergies ||
                              "Aucune allergie documentée."}
                          </div>
                        </div>

                        <div className="space-y-1">
                          <span className="text-xs font-semibold text-slate-400">
                            Pathologies Chroniques & Antécédents :
                          </span>
                          <div className="p-3 bg-slate-50 dark:bg-slate-900 text-slate-705 dark:text-slate-300 rounded-lg text-sm border border-slate-200 dark:border-slate-800">
                            {selectedPatient.antecedents ||
                              "Aucun antécédent documenté dans le dossier clinique."}
                          </div>
                        </div>
                      </CardContent>
                    </Card>

                    {/* Quick Stats Grid */}
                    <Card className="md:col-span-2 border-slate-200 dark:border-slate-800">
                      <CardContent className="p-6 grid grid-cols-2 md:grid-cols-5 gap-4">
                        <div className="text-center p-3 bg-slate-50 dark:bg-slate-900 rounded-xl">
                          <p className="text-xs text-slate-400 font-semibold uppercase">
                            Consultations
                          </p>
                          <p className="text-2xl font-bold text-slate-800 dark:text-white mt-1">
                            {patientConsultations.length}
                          </p>
                        </div>
                        <div className="text-center p-3 bg-slate-50 dark:bg-slate-900 rounded-xl">
                          <p className="text-xs text-slate-400 font-semibold uppercase">
                            Ordonnances
                          </p>
                          <p className="text-2xl font-bold text-slate-800 dark:text-white mt-1">
                            {patientOrdonnances.length}
                          </p>
                        </div>
                        <div className="text-center p-3 bg-slate-50 dark:bg-slate-900 rounded-xl">
                          <p className="text-xs text-slate-400 font-semibold uppercase">
                            Analyses Lab
                          </p>
                          <p className="text-2xl font-bold text-slate-800 dark:text-white mt-1">
                            {patientLaboratoire.length}
                          </p>
                        </div>
                        <div className="text-center p-3 bg-slate-50 dark:bg-slate-900 rounded-xl">
                          <p className="text-xs text-slate-400 font-semibold uppercase">
                            Soin & Constante
                          </p>
                          <p className="text-2xl font-bold text-slate-800 dark:text-white mt-1">
                            {patientSoins.length}
                          </p>
                        </div>
                        <div className="text-center p-3 bg-slate-50 dark:bg-slate-900 rounded-xl col-span-2 md:col-span-1">
                          <p className="text-xs text-slate-400 font-semibold uppercase">
                            Hospitaux
                          </p>
                          <p className="text-2xl font-bold text-slate-800 dark:text-white mt-1">
                            {patientHospitalisations.length}
                          </p>
                        </div>
                      </CardContent>
                    </Card>
                  </div>
                )}

                {/* TAB: Consultations */}
                {activeTab === "consultations" && (
                  <div className="space-y-4">
                    {patientConsultations.length === 0 ? (
                      <div className="bg-slate-50 dark:bg-slate-900 p-8 text-center rounded-xl border border-dashed border-slate-200 dark:border-slate-800 text-slate-400 text-sm">
                        Aucune consultation enregistrée pour ce patient.
                      </div>
                    ) : (
                      patientConsultations.map((consultation, index) => (
                        <Card
                          key={index}
                          className="border-slate-200 dark:border-slate-800 hover:shadow-sm transition-shadow"
                        >
                          <CardHeader className="bg-slate-50 dark:bg-slate-900/40 p-4 border-b border-slate-100 dark:border-slate-805 flex flex-row items-center justify-between">
                            <div className="flex items-center gap-2">
                              <Calendar className="h-4 w-4 text-teal-600" />
                              <span className="font-bold text-sm text-slate-700 dark:text-slate-300">
                                Consultation du{" "}
                                {new Date(
                                  consultation.date_consultation ||
                                    consultation.created_at,
                                ).toLocaleDateString("fr-FR")}
                              </span>
                            </div>
                            <Badge className="bg-teal-100 text-teal-800 dark:bg-teal-900/35 dark:text-teal-400">
                              Dr. {consultation.medecin || "Généraliste"}
                            </Badge>
                          </CardHeader>
                          <CardContent className="p-4 space-y-3 text-sm">
                            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                              <div className="space-y-1">
                                <span className="text-xs text-slate-400 font-semibold">
                                  Motif de consultation :
                                </span>
                                <p className="font-medium text-slate-800 dark:text-slate-200">
                                  {consultation.motif}
                                </p>
                              </div>
                              <div className="space-y-1">
                                <span className="text-xs text-slate-400 font-semibold">
                                  Diagnostic :
                                </span>
                                <p className="font-medium text-slate-800 dark:text-slate-200">
                                  {consultation.diagnostic || "Non spécifié"}
                                </p>
                              </div>
                            </div>

                            {(consultation.tension ||
                              consultation.temperature) && (
                              <div className="p-3 bg-slate-50 dark:bg-slate-900 rounded-xl grid grid-cols-2 md:grid-cols-4 gap-2 text-xs text-slate-600 dark:text-slate-400">
                                {consultation.tension && (
                                  <div>
                                    <span className="font-semibold block text-[10px] uppercase text-slate-400">
                                      Tension :
                                    </span>
                                    <span>{consultation.tension} mmHg</span>
                                  </div>
                                )}
                                {consultation.temperature && (
                                  <div>
                                    <span className="font-semibold block text-[10px] uppercase text-slate-400">
                                      Température :
                                    </span>
                                    <span>{consultation.temperature} °C</span>
                                  </div>
                                )}
                                {consultation.poids && (
                                  <div>
                                    <span className="font-semibold block text-[10px] uppercase text-slate-400">
                                      Poids :
                                    </span>
                                    <span>{consultation.poids} kg</span>
                                  </div>
                                )}
                                {consultation.pouls && (
                                  <div>
                                    <span className="font-semibold block text-[10px] uppercase text-slate-400">
                                      Fréq. Cardiaque :
                                    </span>
                                    <span>{consultation.pouls} bpm</span>
                                  </div>
                                )}
                              </div>
                            )}

                            {consultation.observations && (
                              <div className="space-y-1 pt-2 border-t border-slate-100 dark:border-slate-800">
                                <span className="text-xs text-slate-400 font-semibold">
                                  Observations cliniques & remarques :
                                </span>
                                <p className="text-slate-600 dark:text-slate-300 bg-slate-50/50 dark:bg-slate-900/10 p-2.5 rounded-lg text-xs leading-relaxed">
                                  {consultation.observations}
                                </p>
                              </div>
                            )}

                            {consultation.examens_complementaires_libres && (
                              <div className="space-y-1 pt-2 border-t border-slate-100 dark:border-slate-800">
                                <span className="text-xs text-slate-400 font-semibold">
                                  Examens complémentaires demandés :
                                </span>
                                <p className="text-slate-700 dark:text-slate-200 bg-teal-50/25 dark:bg-slate-900/10 p-2.5 rounded-lg text-[11px] font-semibold leading-relaxed whitespace-pre-line border border-teal-100/40">
                                  {consultation.examens_complementaires_libres}
                                </p>
                              </div>
                            )}
                          </CardContent>
                        </Card>
                      ))
                    )}
                  </div>
                )}

                {/* TAB: Ordonnances */}
                {activeTab === "ordonnances" && (
                  <div className="space-y-4">
                    {patientOrdonnances.length === 0 ? (
                      <div className="bg-slate-50 dark:bg-slate-900 p-8 text-center rounded-xl border border-dashed border-slate-200 dark:border-slate-800 text-slate-400 text-sm">
                        Aucune ordonnance délivrée pour ce patient.
                      </div>
                    ) : (
                      patientOrdonnances.map((ord, index) => (
                        <Card
                          key={index}
                          className="border-slate-200 dark:border-slate-800"
                        >
                          <CardHeader className="bg-slate-50 dark:bg-slate-900/40 p-4 border-b border-slate-100 dark:border-slate-805 flex flex-row items-center justify-between">
                            <div className="flex items-center gap-2">
                              <Pill className="h-4 w-4 text-emerald-600" />
                              <span className="font-bold text-sm text-slate-700 dark:text-slate-300">
                                Ordonnance n° ORD-{ord.id || index}
                              </span>
                            </div>
                            <span className="text-xs text-slate-500 font-medium">
                              Date:{" "}
                              {new Date(
                                ord.date_ordonnance || ord.created_at,
                              ).toLocaleDateString("fr-FR")}
                            </span>
                          </CardHeader>
                          <CardContent className="p-4 space-y-3">
                            <div className="divide-y divide-slate-100 dark:divide-slate-800">
                              {(safeParseMedications(ord.medicaments_data)
                                .length > 0
                                ? safeParseMedications(ord.medicaments_data)
                                : Array.isArray(ord.medicaments)
                                  ? ord.medicaments
                                  : []
                              ).length > 0 ? (
                                (safeParseMedications(ord.medicaments_data)
                                  .length > 0
                                  ? safeParseMedications(ord.medicaments_data)
                                  : ord.medicaments
                                ).map((med: any, i: number) => (
                                  <div
                                    key={i}
                                    className="py-2.5 flex justify-between items-start text-sm"
                                  >
                                    <div>
                                      <p className="font-bold text-slate-800 dark:text-white">
                                        {med.nom_medicament ||
                                          med.nom ||
                                          med.brandName ||
                                          "Médicament"}
                                      </p>
                                      {med.dci && (
                                        <p className="text-[11px] text-slate-450 italic">
                                          DCI: {med.dci}
                                        </p>
                                      )}
                                      <p className="text-xs text-slate-500 mt-0.5">
                                        Posologie:{" "}
                                        {med.posologie ||
                                          med.dosageInstructions ||
                                          med.frequency ||
                                          med.dosage ||
                                          "Non précisée"}
                                      </p>
                                    </div>
                                    <div className="text-right">
                                      <Badge className="bg-slate-100 text-slate-700 dark:bg-slate-800 dark:text-slate-300 text-xs">
                                        Durée:{" "}
                                        {med.duree ||
                                          med.duration ||
                                          "Non précisée"}
                                      </Badge>
                                      {(med.quantite || med.quantity) && (
                                        <p className="text-xs text-slate-400 mt-1">
                                          Qté: {med.quantite || med.quantity}
                                        </p>
                                      )}
                                    </div>
                                  </div>
                                ))
                              ) : (
                                <p className="text-xs text-slate-500 italic py-2">
                                  {ord.medicaments ||
                                    ord.contenu ||
                                    ord.details ||
                                    "Aucun médicament répertorié."}
                                </p>
                              )}
                            </div>
                          </CardContent>
                        </Card>
                      ))
                    )}
                  </div>
                )}

                {/* TAB: Laboratoire */}
                {activeTab === "laboratoire" && (
                  <div className="space-y-4">
                    {patientLaboratoire.length === 0 ? (
                      <div className="bg-slate-50 dark:bg-slate-900 p-8 text-center rounded-xl border border-dashed border-slate-200 dark:border-slate-800 text-slate-400 text-sm">
                        Aucun examen ou analyse de laboratoire prescrit pour ce
                        patient.
                      </div>
                    ) : (
                      patientLaboratoire.map((lab, index) => (
                        <Card
                          key={index}
                          className="border-slate-200 dark:border-slate-800"
                        >
                          <CardHeader className="bg-slate-50 dark:bg-slate-900/40 p-4 border-b border-slate-100 dark:border-slate-805 flex flex-row items-center justify-between">
                            <div className="flex items-center gap-2">
                              <FlaskConical className="h-4 w-4 text-purple-600" />
                              <span className="font-bold text-sm text-slate-700 dark:text-slate-300">
                                Analyse: {lab.type_analyse || lab.examen}
                              </span>
                            </div>
                            <Badge
                              className={
                                lab.status === "termine" ||
                                lab.status === "Completed" ||
                                lab.resultat
                                  ? "bg-emerald-100 text-emerald-800 dark:bg-emerald-950/20 dark:text-emerald-400"
                                  : "bg-orange-100 text-orange-850 dark:bg-orange-950/20 dark:text-orange-400"
                              }
                            >
                              {lab.status === "termine" || lab.resultat
                                ? "Résultats disponibles"
                                : "En cours"}
                            </Badge>
                          </CardHeader>
                          <CardContent className="p-4 space-y-3">
                            <div className="flex justify-between items-center text-xs text-slate-500">
                              <span>
                                Prescrit le :{" "}
                                {new Date(lab.created_at).toLocaleDateString(
                                  "fr-FR",
                                )}
                              </span>
                              {lab.laborantin && (
                                <span>Technicien : {lab.laborantin}</span>
                              )}
                            </div>
                            <div className="bg-slate-50 dark:bg-slate-900 p-3.5 rounded-xl border border-slate-100 dark:border-slate-805">
                              <span className="text-[10px] font-semibold text-slate-400 block uppercase">
                                Résultats & Observations :
                              </span>
                              <p className="text-sm font-semibold text-slate-800 dark:text-white mt-1 leading-relaxed">
                                {lab.resultat ||
                                  "En attente d'analyse ou de validation des résultats par le laboratoire."}
                              </p>
                              {lab.interpretations && (
                                <p className="text-xs text-slate-500 mt-2 italic bg-white dark:bg-slate-950 p-2 rounded border border-slate-100 dark:border-slate-800">
                                  Interprétation: {lab.interpretations}
                                </p>
                              )}
                            </div>
                          </CardContent>
                        </Card>
                      ))
                    )}
                  </div>
                )}

                {/* TAB: Soins & Constantes */}
                {activeTab === "soins" && (
                  <div className="space-y-4">
                    {patientSoins.length === 0 ? (
                      <div className="bg-slate-50 dark:bg-slate-900 p-8 text-center rounded-xl border border-dashed border-slate-200 dark:border-slate-800 text-slate-400 text-sm">
                        Aucun acte ou soin infirmier documenté pour ce patient.
                      </div>
                    ) : (
                      patientSoins.map((soin, index) => (
                        <Card
                          key={index}
                          className="border-slate-200 dark:border-slate-800"
                        >
                          <CardHeader className="bg-slate-50 dark:bg-slate-900/40 p-4 border-b border-slate-100 dark:border-slate-805 flex flex-row items-center justify-between">
                            <div className="flex items-center gap-2">
                              <Activity className="h-4 w-4 text-blue-600" />
                              <span className="font-bold text-sm text-slate-700 dark:text-slate-300">
                                Soin:{" "}
                                {soin.type_soin || "Consultation soignante"}
                              </span>
                            </div>
                            <span className="text-xs text-slate-500">
                              Le:{" "}
                              {new Date(
                                soin.date_soin || soin.created_at,
                              ).toLocaleDateString("fr-FR")}{" "}
                              {soin.heure_soin ? `à ${soin.heure_soin}` : ""}
                            </span>
                          </CardHeader>
                          <CardContent className="p-4 space-y-3">
                            <div className="grid grid-cols-2 md:grid-cols-4 gap-2 text-xs bg-slate-50 dark:bg-slate-900 p-3 rounded-lg text-slate-600 dark:text-slate-400">
                              {soin.tension && (
                                <div>
                                  <span className="block text-[10px] text-slate-400 font-semibold uppercase">
                                    Tension :
                                  </span>
                                  <span className="font-medium text-slate-805 dark:text-white">
                                    {soin.tension} mmHg
                                  </span>
                                </div>
                              )}
                              {soin.temperature && (
                                <div>
                                  <span className="block text-[10px] text-slate-400 font-semibold uppercase">
                                    Température :
                                  </span>
                                  <span className="font-medium text-slate-805 dark:text-white">
                                    {soin.temperature} °C
                                  </span>
                                </div>
                              )}
                              {soin.poids && (
                                <div>
                                  <span className="block text-[10px] text-slate-400 font-semibold uppercase">
                                    Poids :
                                  </span>
                                  <span className="font-medium text-slate-805 dark:text-white">
                                    {soin.poids} kg
                                  </span>
                                </div>
                              )}
                              {soin.glycemie && (
                                <div>
                                  <span className="block text-[10px] text-slate-400 font-semibold uppercase">
                                    Glycémie :
                                  </span>
                                  <span className="font-medium text-slate-850 dark:text-white">
                                    {soin.glycemie} g/L
                                  </span>
                                </div>
                              )}
                            </div>

                            {soin.description_actes && (
                              <div className="space-y-1">
                                <span className="text-xs text-slate-400 font-semibold text-sky-850">
                                  Description des actes prodigués :
                                </span>
                                <p className="text-slate-750 dark:text-slate-305 text-xs bg-slate-50/60 dark:bg-slate-900/40 p-2.5 rounded-lg border border-slate-100 dark:border-slate-800">
                                  {soin.description_actes}
                                </p>
                              </div>
                            )}

                            {soin.observations && (
                              <div className="space-y-1">
                                <span className="text-xs text-slate-400 font-semibold">
                                  Observations & Évolutions cliniques :
                                </span>
                                <p className="text-slate-700 dark:text-slate-300 text-xs italic">
                                  "{soin.observations}"
                                </p>
                              </div>
                            )}
                          </CardContent>
                        </Card>
                      ))
                    )}
                  </div>
                )}

                {/* TAB: Hospitalisations */}
                {activeTab === "hospitalisations" && (
                  <div className="space-y-4">
                    {patientHospitalisations.length === 0 ? (
                      <div className="bg-slate-50 dark:bg-slate-900 p-8 text-center rounded-xl border border-dashed border-slate-200 dark:border-slate-800 text-slate-400 text-sm">
                        Aucun séjour ou hospitalisation enregistré pour ce
                        patient.
                      </div>
                    ) : (
                      patientHospitalisations.map((hosp, index) => (
                        <Card
                          key={index}
                          className="border-slate-200 dark:border-slate-800"
                        >
                          <CardHeader className="bg-slate-50 dark:bg-slate-900/40 p-4 border-b border-slate-100 dark:border-slate-805 flex flex-row items-center justify-between">
                            <div className="flex items-center gap-2">
                              <BedDouble className="h-4 w-4 text-cyan-600" />
                              <span className="font-bold text-sm text-slate-700 dark:text-slate-300">
                                Séjour en Chambre n°{" "}
                                {hosp.chambre_id ||
                                  hosp.numero_chambre ||
                                  "S/N"}
                              </span>
                            </div>
                            <Badge
                              className={
                                hosp.statut === "encours" ||
                                hosp.statut === "Active"
                                  ? "bg-cyan-100 text-cyan-800 dark:bg-cyan-950/20 dark:text-cyan-400"
                                  : "bg-slate-100 text-slate-700 dark:bg-slate-800 dark:text-slate-300"
                              }
                            >
                              {hosp.statut === "encours" ||
                              hosp.statut === "Active"
                                ? "Actif"
                                : "Sorti"}
                            </Badge>
                          </CardHeader>
                          <CardContent className="p-4 space-y-3 text-sm">
                            <div className="grid grid-cols-2 gap-4 text-xs text-slate-550 dark:text-slate-400">
                              <div>
                                <span className="font-semibold block uppercase text-[9px] text-slate-400">
                                  Date Entrée :
                                </span>
                                <span className="text-slate-800 dark:text-slate-200 font-medium">
                                  {new Date(
                                    hosp.date_entree || hosp.created_at,
                                  ).toLocaleDateString("fr-FR")}
                                </span>
                              </div>
                              <div>
                                <span className="font-semibold block uppercase text-[9px] text-slate-400">
                                  Date de Sortie :
                                </span>
                                <span className="text-slate-800 dark:text-slate-200 font-medium">
                                  {hosp.date_sortie
                                    ? new Date(
                                        hosp.date_sortie,
                                      ).toLocaleDateString("fr-FR")
                                    : "Séjour en cours"}
                                </span>
                              </div>
                            </div>
                            <div className="space-y-1">
                              <span className="text-xs text-slate-400 font-semibold">
                                Motif d'admission :
                              </span>
                              <p className="text-slate-705 dark:text-slate-200 font-medium bg-slate-50 dark:bg-slate-900 p-2.5 rounded-lg border border-slate-100 dark:border-slate-800">
                                {hosp.motif ||
                                  hosp.motif_hospitalisation ||
                                  "Non renseigné"}
                              </p>
                            </div>
                          </CardContent>
                        </Card>
                      ))
                    )}
                  </div>
                )}
              </div>
            </div>
          ) : (
            <Card className="border-dashed border-2 border-slate-205 dark:border-slate-805 py-24 text-center">
              <CardContent className="space-y-4">
                <div className="w-16 h-16 bg-teal-100 dark:bg-teal-900/30 text-teal-600 rounded-full flex items-center justify-center mx-auto">
                  <User className="h-8 w-8" />
                </div>
                <div className="max-w-md mx-auto space-y-2">
                  <h3 className="font-bold text-lg text-slate-800 dark:text-white">
                    Sélectionnez un Patient
                  </h3>
                  <p className="text-slate-400 text-sm">
                    Recherchez un dossier patient dans le navigateur ou créez un
                    nouveau dossier clinique complet pour explorer son
                    historique médical complet.
                  </p>
                </div>
                {!isNewPatientOpen && (
                  <Button
                    onClick={() => setIsNewPatientOpen(true)}
                    className="bg-teal-600 text-white hover:bg-teal-700"
                  >
                    Nouveau Patient
                  </Button>
                )}
              </CardContent>
            </Card>
          )}
        </div>
      </div>
    </div>
  );
}
