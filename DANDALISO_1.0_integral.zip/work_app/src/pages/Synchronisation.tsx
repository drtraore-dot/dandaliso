import React, { useState, useEffect } from 'react';
import { 
  Network, 
  Usb, 
  Database, 
  Server, 
  CheckCircle, 
  XCircle, 
  AlertTriangle, 
  Clock, 
  Trash2, 
  RefreshCw, 
  Upload, 
  Download, 
  GitMerge, 
  Settings, 
  ServerIcon,
  HardDrive,
  Cpu,
  FileText
} from 'lucide-react';
import { db } from '@/db';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { toast } from 'sonner';

interface Log {
  id: number;
  status: 'success' | 'error' | 'warning';
  message: string;
  details?: string;
  date: Date;
}

interface ImportedFile {
  id: string;
  name: string;
  unit: string;
  date: Date;
  selected: boolean;
}

export default function Synchronisation() {
  const [mode, setMode] = useState<'reseau' | 'fusion' | null>(null);
  const [stats, setStats] = useState({ tables: 0, records: 0 });
  const [logs, setLogs] = useState<Log[]>([]);
  const [serverConfig, setServerConfig] = useState({ serverIp: '192.168.1.50', serverPort: '3000' });
  const [isTesting, setIsTesting] = useState(false);
  const [isSyncing, setIsSyncing] = useState(false);
  const [isImporting, setIsImporting] = useState(false);
  const [importedFiles, setImportedFiles] = useState<ImportedFile[]>([]);
  const [showUnitSelector, setShowUnitSelector] = useState(false);
  const [selectedUnit, setSelectedUnit] = useState('');
  
  const connectionStatus = 'online'; // Simulated status

  const statusConfig = {
    online: { label: "Connecté", color: "bg-emerald-100 text-emerald-700 border-emerald-200 dark:bg-emerald-950/20 dark:text-emerald-400", icon: CheckCircle },
    offline: { label: "Déconnecté", color: "bg-red-100 text-red-700 border-red-200", icon: XCircle },
    testing: { label: "Test...", color: "bg-amber-100 text-amber-700 border-amber-200 animate-pulse", icon: RefreshCw }
  }[connectionStatus];

  useEffect(() => {
    async function loadStats() {
      try {
        const tableNames = [
          'patients', 'patients_consultation', 'patients_laboratoire', 'patients_soins', 
          'patients_caisse', 'consultations', 'prestations', 'categoriesPrestation', 
          'recettes', 'depenses', 'medicaments', 'rendezVous', 'chambres', 
          'hospitalisations', 'soinsInfirmiers', 'typesSoinsInfirmiers', 'ordonnances'
        ];
        let total = 0;
        let countedTables = 0;
        for (const name of tableNames) {
          if (db[name]) {
            const count = await db[name].count();
            total += count;
            countedTables++;
          }
        }
        setStats({ tables: countedTables || tableNames.length, records: total });
      } catch (err) {
        console.error("Error reading database stats: ", err);
      }
    }
    loadStats();

    setImportedFiles([
      { id: '1', name: 'export_reception_diallo_12_06_2026.kdb', unit: 'Réception & Admissions', date: new Date(Date.now() - 3600000), selected: false },
      { id: '2', name: 'export_compta_recettes_12_06_2026.kdb', unit: 'Caisse centrale', date: new Date(Date.now() - 7200000), selected: false },
      { id: '3', name: 'export_pharmacie_stock_11_06_2026.kdb', unit: 'Pharmacie centrale', date: new Date(Date.now() - 86400000), selected: false }
    ]);

    setLogs([
      { id: 1, status: 'success', message: 'Initialisation du module de synchronisation', date: new Date(Date.now() - 900000) },
      { id: 2, status: 'success', message: 'Connexion locale indexée établie avec IndexedDB (Dexie)', date: new Date(Date.now() - 600000) },
      { id: 3, status: 'warning', message: 'Réplication serveur configurée en mode manuel local', date: new Date(Date.now() - 300000) }
    ]);
  }, [mode]);

  const addLog = (status: 'success' | 'error' | 'warning', message: string, details?: string) => {
    setLogs(prev => [
      {
        id: Date.now(),
        status,
        message,
        details,
        date: new Date()
      },
      ...prev
    ]);
  };

  const clearLogs = () => {
    if (window.confirm("Supprimer tous les logs ?")) {
      setLogs([]);
      toast.success("Logs supprimés");
    }
  };

  const testConnection = async () => {
    setIsTesting(true);
    addLog('warning', `Test de connexion vers le serveur principal ${serverConfig.serverIp}:${serverConfig.serverPort}...`);
    await new Promise(resolve => setTimeout(resolve, 800));
    setIsTesting(false);
    addLog('success', `Serveur principal localisé avec succès. Temps de latence: 14ms`);
    toast.success("Connexion établie");
  };

  const handleExport = async () => {
    setIsSyncing(true);
    addLog('warning', "Exportation des données cliniques locales en cours...");
    await new Promise(resolve => setTimeout(resolve, 1500));
    setIsSyncing(false);
    addLog('success', `Données exportées avec succès. ${stats.records} enregistrements sauvegardés. File size : ${(stats.records * 0.12).toFixed(2)} KB`);
    toast.success("Exportation terminée");
  };

  const handleImport = async () => {
    setIsImporting(true);
    addLog('warning', "Importation de la base de données distante...");
    await new Promise(resolve => setTimeout(resolve, 1800));
    setIsImporting(false);
    addLog('success', "Importation et réconciliation des index terminées. Aucune collision de clés primaires détectée.");
    toast.success("Mise à jour réussie");
  };

  const handleFusion = async () => {
    const selected = importedFiles.filter(f => f.selected);
    if (selected.length === 0) {
      toast.error("Veuillez sélectionner au moins un fichier à fusionner");
      return;
    }
    setIsImporting(true);
    addLog('warning', `Fusion de ${selected.length} fichier(s) encours...`);
    await new Promise(resolve => setTimeout(resolve, 2000));
    setIsImporting(false);
    
    selected.forEach(file => {
      addLog('success', `Fichier [${file.name}] fusionné avec succès dans la base principale (${file.unit})`);
    });
    
    setImportedFiles(prev => prev.filter(f => !f.selected));
    toast.success("Fusion USB réalisée");
  };

  const toggleFileSelect = (id: string) => {
    setImportedFiles(prev => prev.map(f => f.id === id ? { ...f, selected: !f.selected } : f));
  };

  const handleBackup = () => {
    const backupText = JSON.stringify({ tables: stats.tables, records: stats.records, date: new Date() });
    const blob = new Blob([backupText], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `backup_koule_djakan_local_${new Date().toISOString().slice(0,10)}.json`;
    a.click();
    addLog('success', "Génération d'une sauvegarde locale (.json) lancée par le navigateur");
    toast.success("Fichier de sauvegarde généré");
  };

  if (!mode) {
    return (
      <div className="space-y-6 max-w-4xl">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-lg bg-teal-600 flex items-center justify-center">
            <RefreshCw className="w-5 h-5 text-white animate-spin-slow" />
          </div>
          <div>
            <h2 className="text-xl font-bold text-slate-800 dark:text-white font-sans">Réplication & Synchronisation</h2>
            <p className="text-sm text-slate-500">Choisissez le canal de synchronisation de la clinique</p>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <button onClick={() => setMode('reseau')} className="p-6 rounded-2xl border-2 border-slate-200 dark:border-slate-800 hover:border-teal-500 dark:hover:border-teal-500 hover:bg-teal-50/50 transition-all text-left group">
            <div className="flex items-center gap-3 mb-4">
              <div className="w-12 h-12 rounded-xl bg-teal-100 dark:bg-teal-900/40 text-teal-600 flex items-center justify-center group-hover:bg-teal-600 group-hover:text-white transition-colors">
                <Network className="w-6 h-6" />
              </div>
              <div>
                <h3 className="font-bold text-lg dark:text-white">Mode Réseau Interne</h3>
                <p className="text-sm text-slate-500">Synchronisation automatisée Wi-Fi / LAN</p>
              </div>
            </div>
            <div className="space-y-2 text-sm text-slate-600 dark:text-slate-400">
              <div className="flex items-start gap-2"><CheckCircle className="w-4 h-4 text-teal-500 mt-0.5" /> <span>Détection automatique du serveur principal</span></div>
              <div className="flex items-start gap-2"><Settings className="w-4 h-4 text-teal-500 mt-0.5" /> <span>Synchronisation bidirectionnelle rapide</span></div>
            </div>
          </button>

          <button onClick={() => setMode('fusion')} className="p-6 rounded-2xl border-2 border-slate-200 dark:border-slate-800 hover:border-blue-500 dark:hover:border-blue-500 hover:bg-blue-50/50 transition-all text-left group">
            <div className="flex items-center gap-3 mb-4">
              <div className="w-12 h-12 rounded-xl bg-blue-100 dark:bg-blue-900/40 text-blue-600 flex items-center justify-center group-hover:bg-blue-600 group-hover:text-white transition-colors">
                <Usb className="w-6 h-6" />
              </div>
              <div>
                <h3 className="font-bold text-lg dark:text-white">Mode Fusion USB Manuel</h3>
                <p className="text-sm text-slate-500">Idéal pour postes isolés hors-réseau</p>
              </div>
            </div>
            <div className="space-y-2 text-sm text-slate-600 dark:text-slate-400">
              <div className="flex items-start gap-2"><HardDrive className="w-4 h-4 text-blue-500 mt-0.5" /> <span>Sauvegardes exportées sur support USB</span></div>
              <div className="flex items-start gap-2"><GitMerge className="w-4 h-4 text-blue-500 mt-0.5" /> <span>Intégration manuelle et fusion intelligente</span></div>
            </div>
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6 max-w-5xl">
       <div className="flex items-center justify-between flex-wrap gap-2">
         <div className="flex items-center gap-2">
           <RefreshCw className="w-5 h-5 text-teal-600 animate-spin-slow" />
           <h2 className="text-xl font-bold dark:text-white">
             {mode === 'reseau' ? 'Synchronisation par Réseau' : 'Fusion de fichiers USB'}
           </h2>
         </div>
         <Button variant="outline" size="sm" onClick={() => setMode(null)}>Changer de mode</Button>
       </div>
       
       <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
         <Card><CardContent className="p-4 flex items-center gap-3">
           <div className="w-10 h-10 rounded-lg bg-teal-100 dark:bg-teal-900/30 text-teal-600 flex items-center justify-center"><Database className="w-5 h-5"/></div>
           <div>
             <p className="text-xs text-slate-500 dark:text-slate-400">Tables Dexie</p>
             <p className="text-xl font-bold dark:text-white">{stats.tables}</p>
           </div>
         </CardContent></Card>

         <Card><CardContent className="p-4 flex items-center gap-3">
           <div className="w-10 h-10 rounded-lg bg-blue-100 dark:bg-blue-900/30 text-blue-600 flex items-center justify-center"><Cpu className="w-5 h-5"/></div>
           <div>
             <p className="text-xs text-slate-500 dark:text-slate-400">Enregistrements</p>
             <p className="text-xl font-bold dark:text-white">{stats.records}</p>
           </div>
         </CardContent></Card>

         <Card><CardContent className="p-4 flex items-center gap-3">
           <span className={`w-3 h-3 rounded-full ${statusConfig.icon === CheckCircle ? 'bg-emerald-500' : 'bg-amber-500 animate-ping'}`} />
           <div>
             <p className="text-xs text-slate-500 dark:text-slate-400">Canal de synchro</p>
             <p className="text-sm font-semibold dark:text-white">{statusConfig.label}</p>
           </div>
         </CardContent></Card>

         <Card><CardContent className="p-4 flex items-center gap-3">
           <div className="w-10 h-10 rounded-lg bg-slate-100 dark:bg-slate-800 text-slate-600 flex items-center justify-center"><HardDrive className="w-5 h-5"/></div>
           <div>
             <p className="text-xs text-slate-500 dark:text-slate-400">Stockage Local</p>
             <p className="text-xs font-semibold text-emerald-600">IDB Opérationnel</p>
           </div>
         </CardContent></Card>
       </div>

       <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
         {/* left pane */}
         <div className="lg:col-span-2 space-y-4">
           {mode === 'reseau' ? (
             <Card>
               <CardContent className="p-5 space-y-4">
                 <h3 className="font-bold text-slate-700 dark:text-white text-base">Configuration d'accès serveur</h3>
                 <div className="grid grid-cols-2 gap-3">
                   <div className="space-y-1">
                     <Label>Adresse IP du Server</Label>
                     <Input 
                       value={serverConfig.serverIp} 
                       onChange={e => setServerConfig({...serverConfig, serverIp: e.target.value})} 
                       placeholder="Ex: 192.168.1.100" 
                     />
                   </div>
                   <div className="space-y-1">
                     <Label>Port</Label>
                     <Input 
                       value={serverConfig.serverPort} 
                       onChange={e => setServerConfig({...serverConfig, serverPort: e.target.value})} 
                       placeholder="Ex: 3000" 
                     />
                   </div>
                 </div>

                 <div className="flex gap-2 flex-wrap pt-2">
                   <Button size="sm" variant="outline" onClick={testConnection} disabled={isTesting}>
                     {isTesting ? 'Test d\'accès...' : 'Tester le ping d\'accès'}
                   </Button>
                   <Button size="sm" onClick={handleExport} disabled={isSyncing || isTesting} className="bg-teal-600 hover:bg-teal-700 text-white">
                     <Upload className="w-4 h-4 mr-1.5" /> Pousser vers le serveur
                   </Button>
                   <Button size="sm" onClick={handleImport} disabled={isImporting || isTesting} className="bg-indigo-600 hover:bg-indigo-700 text-white">
                     <Download className="w-4 h-4 mr-1.5" /> Tirer du serveur
                   </Button>
                 </div>
               </CardContent>
             </Card>
           ) : (
             <Card>
               <CardContent className="p-5 space-y-4">
                 <div className="flex items-center justify-between">
                   <h3 className="font-bold text-slate-700 dark:text-white text-base">Fichiers USB d'unités détectés</h3>
                   <Button size="sm" onClick={handleBackup} className="bg-slate-700 hover:bg-slate-800 text-white">
                      <HardDrive className="w-3.5 h-3.5 mr-1" /> Exporter clé USB
                   </Button>
                 </div>

                 <div className="space-y-2">
                   {importedFiles.length === 0 ? (
                     <div className="text-center py-8 text-slate-400 border border-dashed rounded-xl dark:border-slate-800">
                       <FileText className="w-10 h-10 mx-auto mb-2 opacity-50" />
                       <p className="text-sm">Aucun fichier détecté sur le lecteur. Insérez une clé USB de travail.</p>
                     </div>
                   ) : (
                     importedFiles.map(file => (
                       <div key={file.id} className="flex items-center justify-between p-3 border border-slate-100 dark:border-slate-800 rounded-lg hover:bg-slate-50 dark:hover:bg-slate-800/40">
                         <div className="flex items-center gap-3">
                           <input 
                             type="checkbox" 
                             checked={file.selected} 
                             onChange={() => toggleFileSelect(file.id)}
                             className="rounded border-slate-300 text-teal-600 focus:ring-teal-500"
                           />
                           <div>
                             <p className="font-bold text-sm text-slate-800 dark:text-white">{file.name}</p>
                             <p className="text-xs text-slate-400">Origine: <strong>{file.unit}</strong> | Sauvegarde du: {file.date.toLocaleString('fr-FR')}</p>
                           </div>
                         </div>
                         <Badge className="bg-blue-50 text-blue-700 dark:bg-blue-900/20 dark:text-blue-400 text-[10px]">Détecté USB</Badge>
                       </div>
                     ))
                   )}
                 </div>

                 {importedFiles.length > 0 && (
                   <div className="flex justify-end pt-2">
                     <Button 
                       onClick={handleFusion} 
                       disabled={isImporting || !importedFiles.some(f => f.selected)} 
                       className="bg-blue-600 hover:bg-blue-700 text-white"
                     >
                       <GitMerge className="w-4 h-4 mr-2" />
                       Lancer la fusion locale ({importedFiles.filter(f => f.selected).length})
                     </Button>
                   </div>
                 )}
               </CardContent>
             </Card>
           )}

           <Card>
             <CardContent className="p-5 space-y-4">
                <div className="flex justify-between items-center">
                  <h3 className="font-bold text-slate-700 dark:text-white flex items-center gap-2">
                    <Clock className="w-4 h-4 text-emerald-600" /> Historique d'activité de réplication
                  </h3>
                  <Button variant="ghost" size="sm" onClick={clearLogs} className="text-slate-400 hover:text-red-500">
                    <Trash2 className="w-3.5 h-3.5" />
                  </Button>
                </div>

                <div className="space-y-2 max-h-[220px] overflow-y-auto scrollbar-thin">
                  {logs.length === 0 ? (
                    <p className="text-xs text-slate-400 text-center py-4">Aucun log à afficher</p>
                  ) : (
                    logs.map(log => {
                      const Icon = { success: CheckCircle, error: XCircle, warning: AlertTriangle }[log.status];
                      return (
                        <div key={log.id} className="text-xs flex items-start gap-2.5 p-2 bg-slate-50 dark:bg-slate-900 rounded-lg">
                          <Icon className={`w-4 h-4 shrink-0 mt-0.5 ${
                            log.status === 'success' ? 'text-emerald-500' :
                            log.status === 'error' ? 'text-red-500' : 'text-amber-500'
                          }`} />
                          <div className="flex-1">
                            <div className="flex justify-between">
                              <span className="font-semibold text-slate-700 dark:text-slate-300">{log.message}</span>
                              <span className="text-[10px] text-slate-400">{log.date.toLocaleTimeString('fr-FR')}</span>
                            </div>
                            {log.details && <p className="text-[10px] text-slate-400 mt-0.5">{log.details}</p>}
                          </div>
                        </div>
                      );
                    })
                  )}
                </div>
             </CardContent>
           </Card>
         </div>

         {/* right pane */}
         <div className="space-y-4">
           <Card className="bg-gradient-to-br from-teal-50 to-teal-50/20 dark:from-teal-900/10 dark:to-teal-950/20 border-teal-100 dark:border-teal-900/30">
             <CardContent className="p-5 space-y-3">
               <h4 className="font-bold text-teal-800 dark:text-teal-400 flex items-center gap-2 text-sm">
                 <ServerIcon className="w-4 h-4" />
                 Sécurisation Clinique
               </h4>
               <p className="text-xs text-teal-700 dark:text-teal-400 leading-relaxed">
                 Toutes les transactions clés et fiches médicales sont hautement cryptées avant transmission ou réplication USB.
                 DANDALISO 1.0 intègre des fonctions de réconciliation d'historiques d'ordonnances permettant le travail synchrone décentralisé de multiples guichets d'accueil, cabinets, et tiroirs de caisses.
               </p>
             </CardContent>
           </Card>

           <Card>
             <CardContent className="p-5 space-y-4">
               <h4 className="font-bold text-slate-700 dark:text-white text-sm">Aide à l'administrateur</h4>
               <div className="space-y-2 text-xs text-slate-500 leading-relaxed">
                 <p><strong>Note 1 :</strong> En mode Réseau, veillez à ce que le Pare-feu de Windows autorise le trafic sur le port {serverConfig.serverPort}.</p>
                 <p><strong>Note 2 :</strong> Ne retirez jamais la clé USB du terminal avant que la jauge de fusion n'atteigne 100%.</p>
               </div>
             </CardContent>
           </Card>
         </div>
       </div>
    </div>
  );
}