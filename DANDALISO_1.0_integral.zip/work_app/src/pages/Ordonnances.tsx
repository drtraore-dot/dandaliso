import React, { useState, useEffect, useMemo } from 'react';
import { db } from '@/db';
import { interactions } from '../data/interactionData';
import { 
  Bed, Plus, Search, Trash, X, FileText, User, Stethoscope, 
  AlertTriangle, FileCheck, Eye, Edit2, Calendar, Pill, Info, ChevronRight, CheckCircle2,
  Printer
} from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { useAuth } from '@/hooks/useAuth';
import { toast } from 'sonner';
import { getPrintSettings, renderPrintHeader, renderPrintFooter, escapeHtml } from '@/lib/printSettings';

interface Medication {
  medicationId: number;
  brandName: string;
  dci: string;
  dosage: string;
  quantity: number;
  form: string;
  dosageInstructions: string;
  duration: string;
  classTherapeutic: string;
  category: string;
  isCustom?: boolean;
}

interface Ordonnance {
  id: number;
  patient_id: number;
  patient_nom: string;
  médecin: string;
  medicaments: string;
  date_ordonnance: Date;
  instructions: string;
}

const PDF_MEDICATIONS = [
  { brandName: "Viagra", dci: "Sildénafil", classTherapeutic: "Vasodilatateur / Troubles de l'érection", dosage: "50mg", form: "Comprimé" },
  { brandName: "Viagra", dci: "Sildénafil", classTherapeutic: "Vasodilatateur / Troubles de l'érection", dosage: "100mg", form: "Comprimé" },
  { brandName: "Natispray", dci: "Trinitrine", classTherapeutic: "Vasodilatateur / Antiangoreux / Angine de poitrine", dosage: "0.4mg/dose", form: "Spray sublingual" },
  { brandName: "Nitrone", dci: "Trinitrine", classTherapeutic: "Vasodilatateur / Antiangoreux / Angine de poitrine", dosage: "2.5mg", form: "Comprimé" },
  { brandName: "ATryn", dci: "Antithrombine III", classTherapeutic: "Anticoagulant naturel", dosage: "1000 UI", form: "Poudre pour solution injectable" },
  { brandName: "ATryn", dci: "Antithrombine III", classTherapeutic: "Anticoagulant naturel", dosage: "500 UI", form: "Poudre pour solution injectable" },
  { brandName: "Abacavir", dci: "Abacavir", classTherapeutic: "Antirétroviral (NRTI)", dosage: "300mg", form: "Comprimé" },
  { brandName: "Abacavir", dci: "Abacavir", classTherapeutic: "Antirétroviral (NRTI)", dosage: "300mg", form: "Sirop" },
  { brandName: "Abacavir", dci: "Abacavir", classTherapeutic: "Antirétroviral (NRTI)", dosage: "600mg", form: "Comprimé" },
  { brandName: "Abasaglar", dci: "Insuline glargine", classTherapeutic: "Insuline (Basale longue)", dosage: "100 UI/ml", form: "Injection IM/IV" },
  { brandName: "Abasaglar", dci: "Insuline glargine", classTherapeutic: "Insuline (Basale longue)", dosage: "300 UI/ml", form: "Injection IM/IV" },
  { brandName: "Abbocillin", dci: "Penicilline V", classTherapeutic: "Antibiotique (Pénicilline)", dosage: "1MUI", form: "Comprimé" },
  { brandName: "Abbocillin", dci: "Penicilline V", classTherapeutic: "Antibiotique (Pénicilline)", dosage: "1MUI", form: "Sirop" },
  { brandName: "Abbocillin", dci: "Penicilline V", classTherapeutic: "Antibiotique (Pénicilline)", dosage: "250mg", form: "Comprimé" },
  { brandName: "Abbocillin", dci: "Penicilline V", classTherapeutic: "Antibiotique (Pénicilline)", dosage: "500mg", form: "Comprimé" },
  { brandName: "Abboticine", dci: "Erythromycine", classTherapeutic: "Antibiotique (Macrolide)", dosage: "250mg", form: "Comprimé" },
  { brandName: "Abboticine", dci: "Erythromycine", classTherapeutic: "Antibiotique (Macrolide)", dosage: "250mg", form: "Gélule" },
  { brandName: "Abboticine", dci: "Erythromycine", classTherapeutic: "Antibiotique (Macrolide)", dosage: "250mg", form: "Injection IM/IV" },
  { brandName: "Abboticine", dci: "Erythromycine", classTherapeutic: "Antibiotique (Macrolide)", dosage: "500mg", form: "Comprimé" },
  { brandName: "Abecma", dci: "Idécabtagène vicleucel", classTherapeutic: "Thérapie CAR-T anti-BCMA", dosage: "Dose personnalisée", form: "Injection IM/IV" },
  { brandName: "Abelcet", dci: "Amphotéricine B", classTherapeutic: "Antifongique (Polyène)", dosage: "100mg", form: "Injection IM/IV" },
  { brandName: "Abelcet", dci: "Amphotéricine B", classTherapeutic: "Antifongique (Polyène)", dosage: "50mg", form: "Injection IM/IV" },
  { brandName: "Abilify", dci: "Aripiprazole", classTherapeutic: "Antipsychotique atypique", dosage: "10mg", form: "Comprimé" },
  { brandName: "Abilify", dci: "Aripiprazole", classTherapeutic: "Antipsychotique atypique", dosage: "10mg", form: "Sirop" },
  { brandName: "Abilify", dci: "Aripiprazole", classTherapeutic: "Antipsychotique atypique", dosage: "15mg", form: "Comprimé" },
  { brandName: "Abilify", dci: "Aripiprazole", classTherapeutic: "Antipsychotique atypique", dosage: "30mg", form: "Comprimé" },
  { brandName: "Abilify", dci: "Aripiprazole", classTherapeutic: "Antipsychotique atypique", dosage: "5mg", form: "Comprimé" },
  { brandName: "Abraxane", dci: "Abraxane (Paclitaxel albumine)", classTherapeutic: "Taxane (Nanoparticules)", dosage: "100mg", form: "Injection IM/IV" },
  { brandName: "Abreva", dci: "Docosanol", classTherapeutic: "Antiviral cutané (Herpès labial)", dosage: "10%", form: "Comprimé" },
  { brandName: "Abricycline", dci: "Tetracycline", classTherapeutic: "Antibiotique (Tétracycline)", dosage: "250mg", form: "Gélule" },
  { brandName: "Abricycline", dci: "Tetracycline", classTherapeutic: "Antibiotique (Tétracycline)", dosage: "500mg", form: "Gélule" },
  { brandName: "Abseamed", dci: "Érythropoïétine (EPO)", classTherapeutic: "Facteur de croissance érythroïde", dosage: "1000 UI", form: "Injection IM/IV" },
  { brandName: "Abseamed", dci: "Érythropoïétine (EPO)", classTherapeutic: "Facteur de croissance érythroïde", dosage: "2000 UI", form: "Injection IM/IV" },
  { brandName: "Abseamed", dci: "Érythropoïétine (EPO)", classTherapeutic: "Facteur de croissance érythroïde", dosage: "4000 UI", form: "Injection IM/IV" },
  { brandName: "Acarbose", dci: "Acarbose", classTherapeutic: "Antidiabétique (Alpha-glucosidase)", dosage: "50mg", form: "Comprimé" },
  { brandName: "Acarbose", dci: "Acarbose", classTherapeutic: "Antidiabétique (Alpha-glucosidase)", dosage: "100mg", form: "Comprimé" },
  { brandName: "Accofil", dci: "Filgrastim", classTherapeutic: "Facteur de croissance G-CSF", dosage: "30MU/0.5ml", form: "Injection IM/IV" },
  { brandName: "Accofil", dci: "Filgrastim", classTherapeutic: "Facteur de croissance G-CSF", dosage: "48MU/0.5ml", form: "Injection IM/IV" },
  { brandName: "Aciclovir", dci: "Aciclovir", classTherapeutic: "Antiviral cutané (Herpès labial)", dosage: "5%", form: "Comprimé" },
  { brandName: "Acide aminocaproïque", dci: "Acide aminocaproïque", classTherapeutic: "Antifibrinolytique", dosage: "500mg", form: "Sirop" },
  { brandName: "Acide borique", dci: "Acide borique", classTherapeutic: "Antiseptique vaginal", dosage: "500mg", form: "Comprimé" },
  { brandName: "Acide folique", dci: "Acide folique", classTherapeutic: "Vitamine B9", dosage: "5mg", form: "Comprimé" },
  { brandName: "Acide tranexamique", dci: "Acide tranexamique", classTherapeutic: "Antifibrinolytique", dosage: "500mg", form: "Comprimé" },
  { brandName: "Augmentin", dci: "Amoxicilline + Acide Clavulanique", classTherapeutic: "Antibiotiques & Antibactériens", dosage: "1g / 125mg", form: "Sachet" },
  { brandName: "Clamoxyl", dci: "Amoxicilline", classTherapeutic: "Antibiotiques & Antibactériens", dosage: "500mg", form: "Gélule" },
  { brandName: "Dolypraine", dci: "Paracétamol", classTherapeutic: "Antalgiques & Antipyrétiques", dosage: "1g", form: "Comprimé" }
];

export const Ordonnances = () => {
  const { canEdit, user } = useAuth() as any;
  const [ordonnances, setOrdonnances] = useState<Ordonnance[]>([]);
  const [patients, setPatients] = useState<any[]>([]);
  const [searchQuery, setSearchQuery] = useState("");
  const [isFormOpen, setIsFormOpen] = useState(false);
  const [selectedOrdonnance, setSelectedOrdonnance] = useState<Ordonnance | null>(null);

  // Autocomplete Suggestions State
  const [suggestions, setSuggestions] = useState<any[]>([]);
  const [showSuggestions, setShowSuggestions] = useState(false);

  // New Prescription State
  const [selectedPatientId, setSelectedPatientId] = useState<number | null>(null);
  const [medecin, setMedecin] = useState("");
  const [instructions, setInstructions] = useState("");
  const [prescribedMedications, setPrescribedMedications] = useState<Medication[]>([]);
  const [registeredMedications, setRegisteredMedications] = useState<any[]>([]);
  
  // Custom Medication Base Search states
  const [showBaseMedicamentsModal, setShowBaseMedicamentsModal] = useState(false);
  const [baseSearchQuery, setBaseSearchQuery] = useState("");
  const [dbBaseMedicaments, setDbBaseMedicaments] = useState<any[]>([]);

  useEffect(() => {
    if (!showBaseMedicamentsModal) {
      setDbBaseMedicaments([]);
      return;
    }
    const searchVal = baseSearchQuery.trim().toLowerCase();
    if (!searchVal) {
      db.base_medicaments.limit(100).toArray().then(items => {
        setDbBaseMedicaments(items);
      });
    } else {
      db.base_medicaments
        .filter(bm => 
          (bm.nom_medicament || "").toLowerCase().includes(searchVal) ||
          (bm.dci || "").toLowerCase().includes(searchVal) ||
          (bm.categorie || "").toLowerCase().includes(searchVal)
        )
        .limit(200)
        .toArray()
        .then(items => {
          setDbBaseMedicaments(items);
        });
    }
  }, [showBaseMedicamentsModal, baseSearchQuery]);
  
  // Temporary Form Inputs for current medication
  const [currentMed, setCurrentMed] = useState({
    brandName: "",
    dci: "",
    classTherapeutic: "",
    category: "",
    dosage: "",
    form: "Comprimé",
    quantity: 1,
    dosageInstructions: "",
    duration: ""
  });

  const detectedInteractions = useMemo(() => {
    if (prescribedMedications.length < 2) return [];
    const found: any[] = [];
    const seenPairs = new Set<string>();

    for (let i = 0; i < prescribedMedications.length; i++) {
      for (let j = i + 1; j < prescribedMedications.length; j++) {
        const medA = prescribedMedications[i];
        const medB = prescribedMedications[j];

        const dciA = (medA.dci || "").trim().toLowerCase();
        const brandA = (medA.brandName || "").trim().toLowerCase();
        const dciB = (medB.dci || "").trim().toLowerCase();
        const brandB = (medB.brandName || "").trim().toLowerCase();

        for (const inter of interactions) {
          const target1 = inter.drug1Dci.toLowerCase();
          const target2 = inter.drug2Dci.toLowerCase();

          const match1 = (dciA === target1 || brandA === target1) && (dciB === target2 || brandB === target2);
          const match2 = (dciA === target2 || brandA === target2) && (dciB === target1 || brandB === target1);

          if (match1 || match2) {
            const pairKey = [medA.medicationId, medB.medicationId].sort().join('-');
            if (!seenPairs.has(pairKey)) {
              seenPairs.add(pairKey);
              found.push({
                medA,
                medB,
                interaction: inter
              });
            }
          }
        }
      }
    }
    return found;
  }, [prescribedMedications]);

  useEffect(() => {
    loadData();
  }, []);

  useEffect(() => {
    if (user) {
      db.utilisateurs.where("nom_utilisateur").equals(user.username || "").first()
        .then(u => {
          if (u) {
            setMedecin(`${u.prenom || ""} ${u.nom || ""}`.trim());
          } else {
            setMedecin(user.username || "");
          }
        })
        .catch(() => {
          setMedecin(user.username || "");
        });
    }
  }, [user]);

  async function loadData() {
    const [patientsData, ordos, meds] = await Promise.all([
      db.patients_consultation.toArray(),
      db.ordonnances.toArray(),
      db.medicaments.toArray()
    ]);
    setPatients(patientsData);
    setOrdonnances(ordos.reverse());
    setRegisteredMedications(meds);
  }

  const handleMedNameChange = async (val: string) => {
    setCurrentMed(prev => ({ ...prev, brandName: val }));
    if (val.trim()) {
      const lowerVal = val.toLowerCase();

      const filteredMeds = registeredMedications
        .filter(m => 
          (m.nom_medicament || "").toLowerCase().includes(lowerVal) ||
          (m.brandName || "").toLowerCase().includes(lowerVal) ||
          (m.dci || "").toLowerCase().includes(lowerVal)
        )
        .map(m => ({
          brandName: m.nom_medicament || m.brandName || "",
          dosage: m.dosage || "",
          form: m.forme || m.form || "Comprimé",
          dci: m.dci || "",
          classTherapeutic: m.classTherapeutic || ""
        }));

      const filteredPdf = PDF_MEDICATIONS.filter(p =>
        (p.brandName || "").toLowerCase().includes(lowerVal) ||
        (p.dci || "").toLowerCase().includes(lowerVal) ||
        (p.classTherapeutic || "").toLowerCase().includes(lowerVal)
      );

      const staticList = [...filteredMeds, ...filteredPdf];

      let dbMatches: any[] = [];
      try {
        const baseMeds = await db.base_medicaments
          .filter(bm => 
            (bm.nom_medicament || "").toLowerCase().includes(lowerVal) || 
            (bm.dci || "").toLowerCase().includes(lowerVal)
          )
          .limit(15)
          .toArray();
        dbMatches = baseMeds.map(bm => ({
          brandName: bm.nom_medicament,
          dosage: bm.dosage || "",
          form: bm.forme || "Comprimé",
          dci: bm.dci || "",
          classTherapeutic: bm.categorie || ""
        }));
      } catch (e) {
        console.error(e);
      }

      const mergedList = [...staticList, ...dbMatches];

      // Remove exact duplicate name patterns for cleaner list
      const seen = new Set();
      const uniqueMerged = mergedList.filter(item => {
        const key = `${item.brandName.toLowerCase()}_${item.dosage.toLowerCase()}_${item.form.toLowerCase()}`;
        if (seen.has(key)) return false;
        seen.add(key);
        return true;
      });

      const matches = uniqueMerged.slice(0, 10);

      setSuggestions(matches);
      setShowSuggestions(true);
    } else {
      setSuggestions([]);
      setShowSuggestions(false);
    }
  };

  const handleSelectSuggestion = (sug: any) => {
    setCurrentMed(prev => ({
      ...prev,
      brandName: sug.brandName,
      dci: sug.dci || "",
      classTherapeutic: sug.classTherapeutic || "",
      category: sug.category || "specialite",
      dosage: sug.dosage || prev.dosage,
      form: sug.form || prev.form,
    }));
    setShowSuggestions(false);
  };

  const handleAddMedication = () => {
    if (!currentMed.brandName) {
      toast.error("Veuillez saisir ou choisir un médicament");
      return;
    }

    let finalDci = currentMed.dci || "";
    let finalClass = currentMed.classTherapeutic || "Générique";
    let finalCategory = currentMed.category || "DCI";

    if (!finalDci) {
      const lowerBrandName = currentMed.brandName.trim().toLowerCase();
      // Search in registeredMedications or PDF_MEDICATIONS to auto-resolve DCI if typed without suggest
      const foundPreset = registeredMedications.find(m => (m.nom_medicament || m.brandName || m.nom || "").toLowerCase() === lowerBrandName);
      if (foundPreset) {
        finalDci = foundPreset.dci || "";
        finalClass = foundPreset.classTherapeutic || foundPreset.categorie || "Générique";
      } else {
        const foundPdf = PDF_MEDICATIONS.find(m => m.brandName.toLowerCase() === lowerBrandName);
        if (foundPdf) {
          finalDci = foundPdf.dci || "";
          finalClass = foundPdf.classTherapeutic || "Générique";
        }
      }
    }

    const newMed: Medication = {
      medicationId: Date.now(),
      brandName: currentMed.brandName,
      dci: finalDci || "",
      dosage: currentMed.dosage || "N/A",
      quantity: Number(currentMed.quantity) || 1,
      form: currentMed.form || "Comprimé",
      dosageInstructions: currentMed.dosageInstructions || "Selon prescription",
      duration: currentMed.duration || "N/A",
      classTherapeutic: finalClass,
      category: finalCategory,
      isCustom: !finalDci
    };

    setPrescribedMedications(prev => {
      const updated = [...prev, newMed];
      return updated;
    });

    // Reset individual medicine fields
    setCurrentMed({
      brandName: "",
      dci: "",
      classTherapeutic: "",
      category: "",
      dosage: "",
      form: "Comprimé",
      quantity: 1,
      dosageInstructions: "",
      duration: ""
    });
    toast.success("Médicament ajouté à la prescription");
  };

  const handleRemoveMedication = (id: number) => {
    setPrescribedMedications(prev => prev.filter(m => m.medicationId !== id));
  };

  const printOrdonnance = async (ord: any) => {
    const printSettings = await getPrintSettings();
    const pNom = ord.patient_nom || "Patient Inconnu";
    const dateStr = new Date(ord.date_ordonnance).toLocaleDateString('fr-FR');
    
    // Split medicaments string by commas to show nicely
    const medsListHTML = ord.medicaments.split(", ").map((med: string) => {
      return `<li style="margin-bottom: 12px; font-size: 11.5pt; color: #1e293b;">➡️ <strong>${med}</strong></li>`;
    }).join("");

    const printContent = `
      <html>
        <head>
          <title>Ordonnance Médicale - ${pNom}</title>
          <style>
            body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; padding: 40px; color: #1e293b; background: white; max-width: 700px; margin: 0 auto; line-height: 1.6; }
            .print-header-block { display:flex; justify-content:space-between; align-items:center; gap:12px; border-bottom: 2px solid #0d9488; padding-bottom: 15px; margin-bottom: 20px; }
            .print-logo { width:64px; height:64px; object-fit:contain; display:block; }
            .print-header-main { flex:1; }
            .print-clinic-name { font-size: 16pt; font-weight: 800; color: #0f766e; text-transform: uppercase; letter-spacing: 1px; }
            .print-clinic-sub, .print-custom-header { font-size: 9pt; color: #64748b; margin-top: 2px; }
            .print-doc-title { text-align:right; font-size:9pt; color:#64748b; line-height:1.4; }
            .print-footer-block { margin-top:20px; padding-top:8px; border-top:1px solid #cbd5e1; text-align:center; font-size:8pt; color:#64748b; }
            .patient-box { background-color: #f8fafc; border: 1px solid #e2e8f0; border-radius: 6px; padding: 15px; margin-bottom: 40px; font-size: 10.5pt; }
            .rx-title { text-align: center; font-size: 20pt; font-weight: bold; color: #0f766e; margin-bottom: 25px; letter-spacing: 2px; }
            .meds-container { min-height: 250px; margin-bottom: 40px; }
            .instructions-container { border-top: 1px dashed #cbd5e1; padding-top: 20px; font-size: 10.5pt; color: #475569; margin-bottom: 45px; }
            .footer-sig { display: flex; justify-content: space-between; font-size: 10pt; margin-top: 50px; }
            .sig-box { text-align: center; width: 220px; }
            .sig-line { border-top: 1px solid #cbd5e1; margin-top: 55px; padding-top: 5px; font-weight: bold; color: #475569; }
          </style>
        </head>
        <body>
          ${renderPrintHeader(printSettings, `N° Ord : Rx-${ord.id?.toString().padStart(6, '0')}<br/>Date : ${dateStr}`)}

          <div class="rx-title">ORDONNANCE MÉDICALE</div>

          <div class="patient-box">
            <strong>Nom du Patient :</strong> ${pNom}<br/>
            <strong>Prescripteur :</strong> ${ord.médecin || ord.medecin || 'Dr. Traoré'}<br/>
            <strong>Date de délivrance :</strong> ${dateStr}
          </div>

          <div class="meds-container">
            <p style="font-size: 12pt; font-weight: bold; color: #0f766e; border-bottom: 1px solid #e2e8f0; padding-bottom: 4px; margin-bottom: 15px;">℞ Traitement Recommandé :</p>
            <ul style="list-style-type: none; padding-left: 0; margin: 0;">
              ${medsListHTML}
            </ul>
          </div>

          \${ord.instructions ? `
            <div class="instructions-container">
              <strong>Posologie & Instructions complémentaires :</strong>
              <p style="margin: 6px 0 0 0; line-height: 1.5; font-style: italic;">\${ord.instructions}</p>
            </div>
          ` : ''}

          <div class="footer-sig">
            <div class="sig-box">
              <span style="font-size: 8.5pt; color: #64748b; font-style: italic;">Cachet de la Pharmacie</span>
              <div class="sig-line">Date de Délivrance</div>
            </div>
            <div class="sig-box">
              <span style="font-size: 8.5pt; color: #64748b; font-style: italic;">Signature du Praticien</span>
              <div class="sig-line">\${ord.médecin || ord.medecin || 'Dr. Traoré'}</div>
            </div>
          </div>

          ${renderPrintFooter(printSettings)}
          <script>
            window.onload = function() {
              window.print();
              setTimeout(function() { window.close(); }, 500);
            }
          </script>
        </body>
      </html>
    `;
    if (window.DANDALI_PRINT?.previewHtml) {
      window.DANDALI_PRINT.previewHtml(printContent);
    } else {
      const win = window.open("", "_blank");
      if (win) { win.document.write(printContent); win.document.close(); }
    }
  };

  const handleSavePrescription = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedPatientId) {
      toast.error("Veuillez sélectionner un patient");
      return;
    }
    if (prescribedMedications.length === 0) {
      toast.error("Veuillez ajouter au moins un médicament à l'ordonnance");
      return;
    }

    const patient = patients.find(p => p.id === Number(selectedPatientId));
    const patientNom = patient ? patient.nom_complet : "Patient Inconnu";
    const medListStr = prescribedMedications.map(m => `${m.brandName} ${m.dosage} (${m.form}) - Qté: ${m.quantity}`).join(", ");

    try {
      await db.ordonnances.add({
        patient_id: Number(selectedPatientId),
        patient_nom: patientNom,
        médecin: medecin || "Dr. Traoré",
        medicaments: medListStr,
        instructions: instructions || prescribedMedications.map(m => `${m.brandName}: ${m.dosageInstructions} pendant ${m.duration}`).join(". "),
        date_ordonnance: new Date(),
        created_at: new Date()
      });

      toast.success("Ordonnance enregistrée avec succès");
      resetForm();
      loadData();
    } catch (err) {
      console.error(err);
      toast.error("Erreur lors de l'enregistrement de l'ordonnance");
    }
  };

  const filteredOrdonnances = ordonnances.filter(o => 
    `${o.patient_nom} ${o.médecin} ${o.medicaments}`.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const resetForm = () => {
    setIsFormOpen(false);
    setPrescribedMedications([]);
    setInstructions("");
    setSelectedPatientId(null);
  };

  return (
    <div className="space-y-6 max-w-6xl">
      {!isFormOpen && (
        <div className="flex items-center justify-between flex-wrap gap-3">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg bg-teal-600 flex items-center justify-center">
              <FileText className="w-5 h-5 text-white" />
            </div>
            <div>
              <h2 className="text-xl font-bold text-slate-800 dark:text-white">Ordonnances</h2>
              <p className="text-sm text-slate-500">Ordonnances intelligentes avec vérification médicamenteuse</p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <Button variant="outline" className="border-teal-201 text-teal-700 hover:bg-teal-50" onClick={() => setShowBaseMedicamentsModal(true)}>
              <Pill className="w-4 h-4 mr-1" /> Base Médicaments
            </Button>
            {canEdit("ordonnances") && (
              <Button onClick={() => setIsFormOpen(true)} className="bg-teal-600 hover:bg-teal-700">
                <Plus className="w-4 h-4 mr-1" /> Nouvelle ordonnance
              </Button>
            )}
          </div>
        </div>
      )}

      {isFormOpen ? (
        <div className="space-y-6">
          <div className="flex items-center justify-between border-b pb-3">
            <div className="flex items-center gap-3">
              <FileCheck className="w-6 h-6 text-teal-600" />
              <div>
                <h2 className="text-xl font-bold">Nouvelle Prescription</h2>
                <p className="text-xs text-slate-500">Ajoutez des médicaments et définissez les posologies pour le patient.</p>
              </div>
            </div>
            <Button variant="ghost" size="sm" onClick={resetForm} className="hover:bg-slate-100">
              <X className="w-4 h-4 mr-1" /> Annuler & Fermer
            </Button>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
            {/* Left side: Setup and Med builder */}
            <div className="lg:col-span-7 space-y-4">
              <Card>
                <CardContent className="p-4 space-y-3">
                  <h3 className="font-semibold text-slate-700 pb-1">1. Informations Générales</h3>
                  
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div className="space-y-1">
                      <Label>Patient *</Label>
                      <select
                        value={selectedPatientId || ""}
                        onChange={e => setSelectedPatientId(Number(e.target.value) || null)}
                        className="w-full h-10 rounded-md border border-input bg-transparent px-3 py-1 text-sm text-slate-900"
                        required
                      >
                        <option value="">Choisir le patient...</option>
                        {patients.map(p => (
                          <option key={p.id} value={p.id}>
                            {p.nom_complet} {p.telephone ? `(Tel: ${p.telephone})` : ""}
                          </option>
                        ))}
                      </select>
                    </div>

                    <div className="space-y-1">
                      <Label>Médecin prescripteur *</Label>
                      <Input 
                        placeholder="Dr. Traoré"
                        value={medecin}
                        onChange={e => setMedecin(e.target.value)}
                        required
                      />
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="border-teal-100">
                <CardContent className="p-4 space-y-3">
                  <h3 className="font-semibold text-teal-700 flex items-center gap-1.5 pb-1">
                    <Pill className="w-4 h-4" /> 2. Ajouter un Médicament
                  </h3>

                  <div className="grid grid-cols-2 gap-3">
                    <div className="col-span-2 space-y-1">
                      <div className="flex justify-between items-center">
                        <Label>Médicament outil de recherche & Saisie libellé *</Label>
                        <button
                          type="button"
                          onClick={() => setShowBaseMedicamentsModal(true)}
                          className="text-xs text-teal-600 hover:text-teal-800 hover:underline flex items-center gap-1 font-medium"
                        >
                          <Search className="w-3 h-3" /> Rechercher dans la base de données
                        </button>
                      </div>
                      <div className="relative">
                        <Input
                          placeholder="Rechercher ou saisir un médicament..."
                          value={currentMed.brandName}
                          onChange={e => handleMedNameChange(e.target.value)}
                          onFocus={() => { if (currentMed.brandName.trim()) setShowSuggestions(true); }}
                          onBlur={() => { setTimeout(() => setShowSuggestions(false), 200); }}
                          className="w-full"
                        />
                        {showSuggestions && suggestions.length > 0 && (
                          <div className="absolute left-0 right-0 top-full mt-1 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-md shadow-lg max-h-60 overflow-y-auto z-50 text-slate-900 dark:text-slate-100 divide-y divide-slate-100 dark:divide-slate-700">
                            {suggestions.map((sug, i) => (
                              <div
                                key={i}
                                className="p-2.5 text-xs hover:bg-teal-50 dark:hover:bg-teal-950/40 cursor-pointer flex flex-col gap-0.5"
                                onMouseDown={() => handleSelectSuggestion(sug)}
                              >
                                <div className="font-semibold text-teal-700 dark:text-teal-400">
                                  {sug.brandName} {sug.dosage && `- ${sug.dosage}`}
                                </div>
                                <div className="text-[10px] text-slate-500 dark:text-slate-400">
                                  {sug.dci && `${sug.dci} `}({sug.form || "N/A"}) {sug.classTherapeutic && `- ${sug.classTherapeutic}`}
                                </div>
                              </div>
                            ))}
                          </div>
                        )}
                      </div>
                    </div>

                    <div className="space-y-1">
                      <Label>Dosage (Ex: 500mg)</Label>
                      <Input
                        placeholder="500mg, 1g, etc."
                        value={currentMed.dosage}
                        onChange={e => setCurrentMed(prev => ({ ...prev, dosage: e.target.value }))}
                      />
                    </div>

                    <div className="space-y-1">
                      <Label>Forme</Label>
                      <select
                        value={currentMed.form}
                        onChange={e => setCurrentMed(prev => ({ ...prev, form: e.target.value }))}
                        className="w-full h-10 rounded-md border text-sm"
                      >
                        <option value="Comprimé">Comprimé</option>
                        <option value="Sirop">Sirop</option>
                        <option value="Gélule">Gélule</option>
                        <option value="Sachet">Sachet</option>
                        <option value="Injection IM/IV">Injection IM/IV</option>
                        <option value="Suspension buvable">Suspension</option>
                        <option value="Suppositoire">Suppositoire</option>
                        <option value="Pommade">Pommade</option>
                      </select>
                    </div>

                    <div className="space-y-1">
                      <Label>Quantité / Boîtes / Flacons</Label>
                      <Input
                        type="number"
                        min={1}
                        value={currentMed.quantity}
                        onChange={e => setCurrentMed(prev => ({ ...prev, quantity: Number(e.target.value) || 1 }))}
                      />
                    </div>

                    <div className="space-y-1">
                      <Label>Durée du traitement (Ex: 5 jours)</Label>
                      <Input
                        placeholder="Ex: 5 jours, 1 semaine"
                        value={currentMed.duration}
                        onChange={e => setCurrentMed(prev => ({ ...prev, duration: e.target.value }))}
                      />
                    </div>

                    <div className="col-span-2 space-y-1">
                      <Label>Instructions de prise / Posologie *</Label>
                      <Input
                        placeholder="Ex: 1 comprimé matin, midi et soir après le repas"
                        value={currentMed.dosageInstructions}
                        onChange={e => setCurrentMed(prev => ({ ...prev, dosageInstructions: e.target.value }))}
                      />
                    </div>
                  </div>

                  <div className="pt-2">
                    <Button 
                      type="button" 
                      onClick={handleAddMedication} 
                      className="w-full bg-slate-800 hover:bg-slate-900 text-white text-xs h-9"
                    >
                      <Plus className="w-4 h-4 mr-1" /> Ajouter ce médicament à l'ordonnance
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Right side: Receipt preview & finalize */}
            <div className="lg:col-span-5 space-y-4">
              <Card className="border-teal-200">
                <CardContent className="p-4 space-y-4">
                  <div className="border-b pb-2">
                    <h3 className="font-bold text-slate-800 flex items-center gap-1.5">
                      <FileText className="w-4 h-4 text-teal-600" /> Ordonnance en cours
                    </h3>
                    <p className="text-xs text-slate-500">
                      Patient: <strong className="text-slate-800">{patients.find(p => p.id === selectedPatientId)?.nom_complet || "Aucun choisi"}</strong>
                    </p>
                  </div>

                  {/* Real-time Drug Interaction Alerts */}
                  {detectedInteractions.length > 0 && (
                    <div id="ddi-alerts-panel" className="space-y-2">
                      <div className="p-3 bg-red-50 dark:bg-red-950/20 border border-red-200 dark:border-red-900 rounded-lg animate-pulse">
                        <div className="flex items-start gap-2">
                          <AlertTriangle className="w-5 h-5 text-red-600 dark:text-red-400 shrink-0 mt-0.5" />
                          <div className="space-y-1">
                            <h4 className="text-xs font-bold text-red-800 dark:text-red-400 uppercase tracking-wide">
                              Alerte d'Interactions Médicamenteuses ({detectedInteractions.length})
                            </h4>
                            <p className="text-[11px] text-red-700 dark:text-red-300">
                              Des interactions potentiellement dangereuses ont été détectées en temps réel :
                            </p>
                          </div>
                        </div>

                        <div className="mt-2 text-y-auto space-y-2 max-h-[220px] overflow-y-auto pr-1">
                          {detectedInteractions.map((item, index) => {
                            const isContreIndique = item.interaction.severity === 'contre_indiquee';
                            const isMajeur = item.interaction.severity === 'majeure';
                            
                            let severityLabel = "Modérée";
                            let severityBadgeClass = "bg-amber-100 text-amber-800 dark:bg-amber-900/30 dark:text-amber-400 border-amber-200";
                            
                            if (isContreIndique) {
                              severityLabel = "CONTRE-INDICATION ABSOLUE";
                              severityBadgeClass = "bg-red-600 text-white dark:bg-red-700 dark:text-white border-red-700 text-[8px]";
                            } else if (isMajeur) {
                              severityLabel = "DANGEREUSE / MAJEURE";
                              severityBadgeClass = "bg-red-100 text-red-800 dark:bg-red-900/40 dark:text-red-400 border-red-200 dark:border-red-800";
                            }

                            return (
                              <div key={index} className="p-2 rounded border border-red-100 dark:border-red-900/40 bg-white dark:bg-slate-900 text-[11px] space-y-1 text-slate-755 dark:text-slate-200">
                                <div className="flex items-center justify-between gap-1 flex-wrap">
                                  <span className="font-bold text-red-700 dark:text-red-400 uppercase tracking-tight text-[10px]">
                                    {item.medA.brandName} ↔ {item.medB.brandName}
                                  </span>
                                  <span className={`text-[9px] font-bold px-1.5 py-0.5 rounded border ${severityBadgeClass}`}>
                                    {severityLabel}
                                  </span>
                                </div>
                                <p className="font-semibold text-slate-900 dark:text-white leading-tight">
                                  {item.interaction.description}
                                </p>
                                {item.interaction.mechanism && (
                                  <p className="text-[10px] text-slate-500 leading-normal">
                                    <strong>Mécanisme :</strong> {item.interaction.mechanism}
                                  </p>
                                )}
                                {item.interaction.recommendation && (
                                  <p className="text-[10px] text-teal-800 dark:text-teal-400 bg-teal-50 dark:bg-teal-950/20 p-1.5 rounded leading-normal mt-1 border border-teal-100 dark:border-teal-900/30 font-sans">
                                    <strong>Conduite à tenir :</strong> {item.interaction.recommendation}
                                  </p>
                                )}
                              </div>
                            );
                          })}
                        </div>
                      </div>
                    </div>
                  )}

                  {prescribedMedications.length === 0 ? (
                    <div className="text-center py-10 text-slate-400 text-sm">
                      <Pill className="w-10 h-10 mx-auto mb-2 opacity-30" />
                       Aucun médicament prescrit pour l'instant
                    </div>
                  ) : (
                    <div className="space-y-3 max-h-[300px] overflow-y-auto pr-1">
                      {prescribedMedications.map(m => (
                        <div key={m.medicationId} className="p-3 bg-slate-50 rounded border text-xs relative group flex justify-between items-start gap-1">
                          <div className="space-y-1">
                            <p className="font-semibold text-teal-800">{m.brandName} {m.dosage}</p>
                            <p className="text-slate-500">Forme: {m.form} | Qté: {m.quantity} | Durée: {m.duration}</p>
                            <p className="italic text-slate-600 mt-1">✓ {m.dosageInstructions}</p>
                          </div>
                          <Button 
                            variant="ghost" 
                            size="icon" 
                            title="Supprimer" 
                            onClick={() => handleRemoveMedication(m.medicationId)}
                            className="text-red-500 hover:text-red-700 h-6 w-6 shrink-0"
                          >
                            <X className="w-3.5 h-3.5" />
                          </Button>
                        </div>
                      ))}
                    </div>
                  )}

                  <div className="space-y-1">
                    <Label>Instructions ou recommandations globales (Facultatif)</Label>
                    <Textarea
                      placeholder="Recommandations générales, dates de reprise, etc."
                      value={instructions}
                      onChange={e => setInstructions(e.target.value)}
                      rows={3}
                    />
                  </div>

                  <div className="pt-2 border-t mt-4">
                    <Button 
                      onClick={handleSavePrescription}
                      disabled={!selectedPatientId || prescribedMedications.length === 0}
                      className="w-full bg-teal-600 hover:bg-teal-700 text-white font-semibold"
                    >
                      <CheckCircle2 className="w-4 h-4 mr-2" /> Valider & Enregistrer l'ordonnance
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      ) : (
        <>
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            <Card>
              <CardContent className="p-3 flex items-center gap-2">
                <div className="w-8 h-8 rounded-lg bg-teal-100 text-teal-600 flex items-center justify-center">
                  <FileText className="w-4 h-4" />
                </div>
                <div>
                  <p className="text-xs text-slate-500">Total</p>
                  <p className="text-lg font-bold">{ordonnances.length}</p>
                </div>
              </CardContent>
            </Card>
            {/* Additional Stats Cards */}
          </div>

          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
            <Input 
              placeholder="Rechercher une ordonnance..." 
              value={searchQuery} 
              onChange={(e) => setSearchQuery(e.target.value)} 
              className="pl-9"
            />
          </div>

          <div className="space-y-2">
            {filteredOrdonnances.length === 0 ? (
              <div className="text-center py-12 text-slate-400">
                <FileText className="w-12 h-12 mx-auto mb-2 opacity-50" />
                <p>Aucune ordonnance trouvée</p>
              </div>
            ) : (
              filteredOrdonnances.map(ordonnance => (
                <Card key={ordonnance.id}>
                  <CardContent className="p-4">
                    <div className="flex items-start justify-between gap-3">
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2 flex-wrap">
                          <User className="w-4 h-4 text-slate-400" />
                          <span className="font-semibold">{ordonnance.patient_nom}</span>
                          <Badge variant="outline" className="bg-teal-50 text-teal-700 text-xs">
                            <Stethoscope className="w-3 h-3 mr-1" /> {ordonnance.médecin}
                          </Badge>
                        </div>
                        <p className="text-xs text-slate-500 mt-1 flex items-center gap-1">
                          <Calendar className="w-3 h-3" />
                          {new Date(ordonnance.date_ordonnance).toLocaleString("fr-FR")}
                        </p>
                        <div className="mt-2 flex flex-wrap gap-1">
                          {ordonnance.medicaments.split(",").map((med, idx) => (
                            <Badge key={idx} variant="outline" className="bg-slate-50 text-xs">
                              <Pill className="w-3 h-3 mr-1" /> {med.trim()}
                            </Badge>
                          ))}
                        </div>
                      </div>
                      <div className="flex items-center gap-1 flex-shrink-0">
                        <Button 
                          variant="ghost" 
                          size="sm" 
                          title="Imprimer l'Ordonnance"
                          className="hover:bg-emerald-50"
                          onClick={() => printOrdonnance(ordonnance)}
                        >
                          <Printer className="w-4 h-4 text-emerald-600" />
                        </Button>
                        <Button 
                          variant="ghost" 
                          size="sm" 
                          title="Détails"
                          onClick={() => {
                            // Let's print too since it constitutes the standard preview action
                            printOrdonnance(ordonnance);
                          }}
                        >
                          <Eye className="w-4 h-4 text-blue-500" />
                        </Button>
                        {canEdit("ordonnances") && (
                          <>
                            <Button variant="ghost" size="sm">
                              <Edit2 className="w-4 h-4" />
                            </Button>
                            <Button variant="ghost" size="sm" className="text-red-500 hover:text-red-700">
                              <Trash className="w-4 h-4" />
                            </Button>
                          </>
                        )}
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))
            )}
          </div>
        </>
      )}

      {/* Medication Base Search Modal */}
      {showBaseMedicamentsModal && (() => {
        // Merge preset drugs + customized ones + dynamic indexedDB reference base meds!
        const allAvailableMeds = [
          ...registeredMedications.map(m => ({
            brandName: m.nom_medicament || m.brandName || "",
            dci: m.dci || "",
            classTherapeutic: m.classTherapeutic || m.categorie || "Général",
            dosage: m.dosage || "",
            form: m.form || m.forme || "Comprimé"
          })),
          ...dbBaseMedicaments.map(m => ({
            brandName: m.nom_medicament || "",
            dci: m.dci || "",
            classTherapeutic: m.categorie || "Classe de la base",
            dosage: m.dosage || "",
            form: m.forme || m.form || "Comprimé"
          })),
          ...PDF_MEDICATIONS
        ];

        // Deduplicate
        const seen = new Set();
        const deduplicatedMeds = allAvailableMeds.filter(item => {
          const key = `${item.brandName.toLowerCase()}_${item.dci.toLowerCase()}_${item.dosage.toLowerCase()}_${item.form.toLowerCase()}`;
          if (seen.has(key)) return false;
          seen.add(key);
          return true;
        });

        const filteredMedsForModal = !baseSearchQuery.trim()
          ? deduplicatedMeds.slice(0, 50)
          : deduplicatedMeds.filter(m => 
              m.brandName.toLowerCase().includes(baseSearchQuery.toLowerCase()) || 
              m.dci.toLowerCase().includes(baseSearchQuery.toLowerCase()) ||
              m.classTherapeutic.toLowerCase().includes(baseSearchQuery.toLowerCase())
            );

        return (
          <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm z-50 flex items-center justify-center p-4">
            <div className="bg-white dark:bg-slate-900 rounded-xl max-w-4xl w-full max-h-[85vh] flex flex-col shadow-2xl border border-slate-200 dark:border-slate-800 transition-all">
              <div className="p-5 border-b border-slate-100 dark:border-slate-800 flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-lg bg-teal-50 dark:bg-teal-950 flex items-center justify-center text-teal-600 dark:text-teal-400">
                    <Pill className="w-5 h-5 flex-shrink-0" />
                  </div>
                  <div>
                    <h3 className="font-bold text-slate-800 dark:text-white text-lg">Base de Données Médicaments</h3>
                    <p className="text-xs text-slate-500">Consultez des milliers de spécialités et DCI (ex: sildénafil, trinitrine)</p>
                  </div>
                </div>
                <Button variant="ghost" size="sm" onClick={() => { setShowBaseMedicamentsModal(false); setBaseSearchQuery(""); }} className="hover:bg-slate-100 dark:hover:bg-slate-800">
                  <X className="w-5 h-5" />
                </Button>
              </div>

              <div className="px-5 py-3 bg-slate-50 dark:bg-slate-900/40 border-b border-slate-100 dark:border-slate-800 flex gap-2">
                <div className="relative flex-1">
                  <Search className="absolute left-3 top-2.5 h-4 w-4 text-slate-400" />
                  <Input
                    className="pl-9 bg-white dark:bg-slate-900"
                    placeholder="Rechercher par Nom commercial, DCI (Sildénafil, Trinitrine) ou Classe thérapeutique..."
                    value={baseSearchQuery}
                    onChange={(e) => setBaseSearchQuery(e.target.value)}
                  />
                </div>
                {baseSearchQuery && (
                  <Button variant="ghost" size="sm" onClick={() => setBaseSearchQuery("")} className="text-xs">
                    Effacer
                  </Button>
                )}
              </div>

              {/* Results body */}
              <div className="p-5 overflow-y-auto flex-1 min-h-[300px] max-h-[50vh]">
                <div className="text-xs text-slate-400 mb-3 flex items-center justify-between">
                  <span>{filteredMedsForModal.length} médicaments trouvés</span>
                  {!baseSearchQuery && <span>(Affichage des 50 premiers éléments)</span>}
                </div>

                {filteredMedsForModal.length === 0 ? (
                  <div className="text-center py-12 text-slate-500">
                    <AlertTriangle className="w-10 h-10 mx-auto text-amber-500 mb-2" />
                    <p className="font-semibold text-slate-700 dark:text-slate-300">Aucun médicament trouvé</p>
                    <p className="text-xs mt-1">Essayez d'autres mots-clés ou saisissez-le directement dans le formulaire.</p>
                  </div>
                ) : (
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-3 pb-4">
                    {filteredMedsForModal.map((med, index) => (
                      <div 
                        key={index} 
                        className="p-3.5 rounded-lg border border-slate-100 dark:border-slate-800 bg-white dark:bg-slate-900 flex flex-col justify-between hover:border-teal-200 dark:hover:border-teal-900 transition-all hover:shadow-sm"
                      >
                        <div className="space-y-1">
                          <div className="flex items-start justify-between gap-2">
                            <span className="font-bold text-sm text-slate-800 dark:text-white flex items-center gap-1.5">
                              <span className="w-1.5 h-1.5 rounded-full bg-teal-500" />
                              {med.brandName}
                            </span>
                            <Badge variant="secondary" className="text-[10px] bg-teal-50 text-teal-700 hover:bg-teal-50 dark:bg-teal-950/40 dark:text-teal-400">
                              {med.form}
                            </Badge>
                          </div>
                          <p className="text-xs text-slate-500">
                            <span className="font-semibold text-slate-600 dark:text-slate-400 text-slate-700 dark:text-slate-300">DCI:</span> {med.dci || "N/A"}
                          </p>
                          <p className="text-[11px] text-slate-400 leading-tight">
                            <span className="font-semibold text-slate-500 dark:text-slate-400">Classe:</span> {med.classTherapeutic}
                          </p>
                          {med.dosage && (
                            <p className="text-[11px] text-slate-500">
                              <span className="font-semibold text-slate-600 dark:text-slate-400">Dosage standard:</span> {med.dosage}
                            </p>
                          )}
                        </div>

                        <div className="mt-3 pt-3 border-t border-slate-100 dark:border-slate-800 flex justify-end">
                          <Button
                            size="sm"
                            type="button"
                            className="bg-teal-600 hover:bg-teal-700 text-white text-xs h-8 px-3"
                            onClick={() => {
                              setCurrentMed(prev => ({
                                ...prev,
                                brandName: med.brandName,
                                dosage: med.dosage || "",
                                form: med.form || "Comprimé",
                                dci: med.dci || "",
                                classTherapeutic: med.classTherapeutic || "Générique",
                                category: "specialite"
                              }));
                              
                              if (!isFormOpen) {
                                setIsFormOpen(true);
                              }
                              
                              setShowBaseMedicamentsModal(false);
                              setBaseSearchQuery("");
                              toast.success(`Sélectionné : ${med.brandName} (${med.dosage || "Dosage libre"})`);
                            }}
                          >
                            {isFormOpen ? "Insérer dans l'ordonnance" : "Prescrire ce médicament"}
                          </Button>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>

              <div className="p-4 bg-slate-50 dark:bg-slate-900/60 border-t border-slate-100 dark:border-slate-800 flex justify-between items-center text-xs text-slate-500">
                <span className="flex items-center gap-1">
                  <Info className="w-3.5 h-3.5 text-teal-600" />
                  Sélectionnez un médicament pour l'insérer directement dans votre ordonnance.
                </span>
                <Button size="sm" variant="outline" type="button" onClick={() => { setShowBaseMedicamentsModal(false); setBaseSearchQuery(""); }}>
                  Fermer
                </Button>
              </div>
            </div>
          </div>
        );
      })()}
    </div>
  );
};

export default Ordonnances;