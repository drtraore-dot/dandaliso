export {};

declare global {
  interface Window {
    DANDALI_PRINT?: {
      saveHtmlAsPdf: (html: string) => Promise<{ ok: boolean; path?: string; canceled?: boolean }>;
      previewHtml: (html: string) => Promise<{ ok: boolean }>;
    };
    DANDALI_LICENSE?: {
      getStatus: () => Promise<{
        activated: boolean;
        machineCode: string;
        licensePath?: string;
        activatedAt?: string | null;
      }>;
      activate: (licenseKey: string) => Promise<{
        ok: boolean;
        activated: boolean;
        machineCode: string;
        message: string;
      }>;
      copyMachineCode: (machineCode: string) => Promise<{ ok: boolean }>;
    };
  }
}
