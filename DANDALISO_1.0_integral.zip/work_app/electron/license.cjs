const crypto = require('crypto');
const fs = require('fs');
const os = require('os');
const path = require('path');
const { execSync } = require('child_process');

// IMPORTANT : changez ce secret avant de distribuer l'application finale.
// Gardez la même valeur dans scripts/generate-license.cjs.
const LICENSE_SECRET = 'DANDALISO-1.0-CHANGEZ-CE-SECRET-AVANT-COMPILATION-2026';
const APP_DIR_NAME = 'DANDALISO-1.0';

function safeExec(command) {
  try {
    return execSync(command, { windowsHide: true, timeout: 2500, encoding: 'utf8' }).trim();
  } catch (_error) {
    return '';
  }
}

function normalize(value) {
  return String(value || '')
    .replace(/\r/g, '')
    .split('\n')
    .map((line) => line.trim())
    .filter(Boolean)
    .filter((line) => !/uuid|serialnumber|processorid|macaddress|name/i.test(line))
    .join('|')
    .trim();
}

function getHardwareSource() {
  const parts = [];

  if (process.platform === 'win32') {
    parts.push(normalize(safeExec('wmic csproduct get uuid')));
    parts.push(normalize(safeExec('wmic bios get serialnumber')));
    parts.push(normalize(safeExec('wmic cpu get processorid')));
    parts.push(normalize(safeExec('wmic diskdrive get serialnumber')));
    parts.push(normalize(safeExec('getmac /fo csv /nh')));
  }

  const nets = os.networkInterfaces();
  const macs = Object.values(nets)
    .flat()
    .filter(Boolean)
    .map((net) => net.mac)
    .filter((mac) => mac && mac !== '00:00:00:00:00:00')
    .sort()
    .join('|');

  parts.push(os.hostname());
  parts.push(os.platform());
  parts.push(os.arch());
  parts.push(macs);

  return parts.filter(Boolean).join('||') || 'UNKNOWN-MACHINE';
}

function getMachineId() {
  return crypto
    .createHash('sha256')
    .update(getHardwareSource())
    .digest('hex')
    .toUpperCase();
}

function getMachineCode() {
  const id = getMachineId();
  return `DN-${id.slice(0, 4)}-${id.slice(4, 8)}-${id.slice(8, 12)}-${id.slice(12, 16)}-${id.slice(16, 20)}`;
}

function makeLicenseKey(machineCode) {
  const cleanCode = String(machineCode || '').trim().toUpperCase();
  const digest = crypto
    .createHmac('sha256', LICENSE_SECRET)
    .update(cleanCode)
    .digest('hex')
    .toUpperCase();

  return [digest.slice(0, 5), digest.slice(5, 10), digest.slice(10, 15), digest.slice(15, 20), digest.slice(20, 25)].join('-');
}

function verifyLicenseKey(machineCode, licenseKey) {
  const expected = makeLicenseKey(machineCode);
  const received = String(licenseKey || '').trim().toUpperCase();
  return expected === received;
}

function getLicensePath(app) {
  const base = app && app.getPath ? app.getPath('userData') : path.join(os.homedir(), 'AppData', 'Roaming', APP_DIR_NAME);
  return path.join(base, 'licence.json');
}

function readStoredLicense(app) {
  const file = getLicensePath(app);
  try {
    if (!fs.existsSync(file)) return null;
    return JSON.parse(fs.readFileSync(file, 'utf8'));
  } catch (_error) {
    return null;
  }
}

function saveStoredLicense(app, licenseKey) {
  const file = getLicensePath(app);
  fs.mkdirSync(path.dirname(file), { recursive: true });
  const machineCode = getMachineCode();
  const payload = {
    product: 'DANDALISO 1.0',
    machineCode,
    licenseKey: String(licenseKey || '').trim().toUpperCase(),
    activatedAt: new Date().toISOString()
  };
  fs.writeFileSync(file, JSON.stringify(payload, null, 2), 'utf8');
  return payload;
}

function getLicenseStatus(app) {
  const machineCode = getMachineCode();
  const stored = readStoredLicense(app);
  const activated = !!(stored && verifyLicenseKey(machineCode, stored.licenseKey));
  return {
    activated,
    machineCode,
    licensePath: getLicensePath(app),
    activatedAt: activated ? stored.activatedAt : null
  };
}

function activate(app, licenseKey) {
  const machineCode = getMachineCode();
  if (!verifyLicenseKey(machineCode, licenseKey)) {
    return {
      ok: false,
      activated: false,
      machineCode,
      message: 'Clé d’activation invalide pour cet ordinateur.'
    };
  }

  saveStoredLicense(app, licenseKey);
  return {
    ok: true,
    activated: true,
    machineCode,
    message: 'Activation réussie.'
  };
}

module.exports = {
  getMachineCode,
  makeLicenseKey,
  verifyLicenseKey,
  getLicenseStatus,
  activate,
  LICENSE_SECRET
};
