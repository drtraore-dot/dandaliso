const fs = require('fs');
const path = require('path');
const { pathToFileURL } = require('url');
const { app, BrowserWindow, ipcMain, clipboard, dialog } = require('electron');
const license = require('./license.cjs');

// Evite certaines pages blanches liées au GPU sur quelques PC Windows anciens.
app.commandLine.appendSwitch('disable-gpu');
app.commandLine.appendSwitch('disable-gpu-compositing');


function detectPageSize(html) {
  const text = String(html || '').toLowerCase();
  if (/@page[^}]*a5/.test(text) || /size\s*:\s*a5/.test(text)) return 'A5';
  if (/@page[^}]*a4/.test(text) || /size\s*:\s*a4/.test(text)) return 'A4';
  return 'A4';
}

function addPreviewToolbar(html) {
  const toolbar = `
    <div class="dandali-preview-toolbar">
      <strong>Aperçu avant impression</strong>
      <span class="dandali-spacer"></span>
      <button onclick="require('electron').ipcRenderer.invoke('print:printThisWindow')">Imprimer</button>
      <button onclick="require('electron').ipcRenderer.invoke('print:saveThisWindowAsPdf')">Exporter PDF</button>
      <button class="secondary" onclick="window.close()">Fermer</button>
    </div>`;
  const styles = `
    <style>
      .dandali-preview-toolbar{position:sticky;top:0;z-index:2147483647;background:#0f766e;color:#fff;padding:10px 14px;display:flex;align-items:center;gap:10px;font-family:Arial,sans-serif;box-shadow:0 2px 8px rgba(15,23,42,.18)}
      .dandali-preview-toolbar .dandali-spacer{flex:1}
      .dandali-preview-toolbar button{border:0;border-radius:7px;padding:8px 13px;font-weight:700;cursor:pointer;background:#ffffff;color:#0f172a}
      .dandali-preview-toolbar button.secondary{background:#e2e8f0;color:#0f172a}
      @media print{.dandali-preview-toolbar{display:none!important}}
    </style>`;
  let out = String(html || '');
  out = out.replace(/<script>\s*window\.onload[\s\S]*?<\/script>/gi, '');
  out = out.replace(/<script>\s*window\.addEventListener\(['\"]load['\"][\s\S]*?<\/script>/gi, '');
  if (/<\/head>/i.test(out)) out = out.replace(/<\/head>/i, styles + '</head>');
  else out = styles + out;
  if (/<body[^>]*>/i.test(out)) out = out.replace(/<body[^>]*>/i, m => m + toolbar);
  else out = toolbar + out;
  return out;
}

let mainWindow;

function findIndexHtml() {
  const candidates = [
    path.join(app.getAppPath(), 'dist', 'index.html'),
    path.join(app.getAppPath(), 'index.html'),
    path.join(process.resourcesPath || '', 'app', 'dist', 'index.html'),
    path.join(process.resourcesPath || '', 'app', 'index.html'),
    path.join(__dirname, '..', 'dist', 'index.html'),
    path.join(__dirname, '..', 'index.html')
  ];

  for (const file of candidates) {
    try {
      if (file && fs.existsSync(file)) return file;
    } catch (_) {}
  }

  return candidates[0];
}

function createWindow() {
  mainWindow = new BrowserWindow({
    width: 1280,
    height: 820,
    minWidth: 1024,
    minHeight: 700,
    title: 'DANDALISO 1.0',
    backgroundColor: '#f8fafc',
    autoHideMenuBar: true,
    show: false,
    webPreferences: {
      preload: path.join(__dirname, 'preload.cjs'),
      nodeIntegration: false,
      contextIsolation: true,
      sandbox: false,
      webSecurity: false
    }
  });

  mainWindow.once('ready-to-show', () => {
    mainWindow.show();
  });

  mainWindow.webContents.on('did-fail-load', (_event, errorCode, errorDescription, validatedURL) => {
    dialog.showErrorBox('Erreur de chargement DANDALISO 1.0', `Code: ${errorCode}\n${errorDescription}\n${validatedURL}`);
  });

  mainWindow.webContents.on('render-process-gone', (_event, details) => {
    dialog.showErrorBox('Erreur DANDALISO 1.0', `Le processus d'affichage a quitté : ${details.reason}`);
  });

  // En cas de page blanche, cette ligne permet de voir l'erreur exacte avec :
  // set DANDALI_DEBUG=1 puis lancer le .exe depuis PowerShell.
  if (process.env.DANDALI_DEBUG === '1') {
    mainWindow.webContents.openDevTools({ mode: 'detach' });
  }

  if (!app.isPackaged && process.env.NODE_ENV === 'development') {
    mainWindow.loadURL('http://localhost:3000');
  } else {
    const indexPath = findIndexHtml();
    mainWindow.loadURL(pathToFileURL(indexPath).toString());
  }
}

ipcMain.handle('license:getStatus', () => license.getLicenseStatus(app));
ipcMain.handle('license:activate', (_event, licenseKey) => license.activate(app, licenseKey));

ipcMain.handle('print:saveHtmlAsPdf', async (_event, html) => {
  const pdfWindow = new BrowserWindow({
    show: false,
    webPreferences: { sandbox: false, contextIsolation: true }
  });
  try {
    await pdfWindow.loadURL('data:text/html;charset=utf-8,' + encodeURIComponent(String(html || '')));
    const pdfData = await pdfWindow.webContents.printToPDF({
      printBackground: true,
      pageSize: 'A4',
      margins: { marginType: 'default' }
    });
    const result = await dialog.showSaveDialog(mainWindow, {
      title: 'Enregistrer en PDF',
      defaultPath: `document-${new Date().toISOString().slice(0,10)}.pdf`,
      filters: [{ name: 'PDF', extensions: ['pdf'] }]
    });
    if (!result.canceled && result.filePath) {
      fs.writeFileSync(result.filePath, pdfData);
      return { ok: true, path: result.filePath };
    }
    return { ok: false, canceled: true };
  } finally {
    if (!pdfWindow.isDestroyed()) pdfWindow.close();
  }
});



ipcMain.handle('print:previewHtml', async (_event, html) => {
  const previewWindow = new BrowserWindow({
    width: 980,
    height: 760,
    title: 'Aperçu avant impression - DANDALISO 1.0',
    backgroundColor: '#f8fafc',
    autoHideMenuBar: true,
    parent: mainWindow || undefined,
    modal: false,
    webPreferences: {
      nodeIntegration: true,
      contextIsolation: false,
      sandbox: false,
      webSecurity: false
    }
  });
  await previewWindow.loadURL('data:text/html;charset=utf-8,' + encodeURIComponent(addPreviewToolbar(html)));
  return { ok: true };
});

ipcMain.handle('print:printThisWindow', async (event) => {
  const win = BrowserWindow.fromWebContents(event.sender);
  if (!win) return { ok: false };
  return new Promise((resolve) => {
    win.webContents.print({ printBackground: true }, (success, failureReason) => {
      resolve({ ok: !!success, error: failureReason || null });
    });
  });
});

ipcMain.handle('print:saveThisWindowAsPdf', async (event) => {
  const win = BrowserWindow.fromWebContents(event.sender);
  if (!win) return { ok: false };
  const pdfData = await win.webContents.printToPDF({
    printBackground: true,
    pageSize: detectPageSize(await win.webContents.executeJavaScript('document.documentElement.outerHTML')),
    margins: { marginType: 'default' }
  });
  const result = await dialog.showSaveDialog(win, {
    title: 'Exporter en PDF',
    defaultPath: `document-${new Date().toISOString().slice(0,10)}.pdf`,
    filters: [{ name: 'PDF', extensions: ['pdf'] }]
  });
  if (!result.canceled && result.filePath) {
    fs.writeFileSync(result.filePath, pdfData);
    return { ok: true, path: result.filePath };
  }
  return { ok: false, canceled: true };
});

ipcMain.handle('license:copyMachineCode', (_event, machineCode) => {
  clipboard.writeText(String(machineCode || ''));
  return { ok: true };
});

app.whenReady().then(createWindow);

app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') app.quit();
});

app.on('activate', () => {
  if (BrowserWindow.getAllWindows().length === 0) createWindow();
});
