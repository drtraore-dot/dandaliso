import { medicationsSeed } from './src/data/medicationData';
import { dciData } from './src/data/dciData';
import { specialtiesData } from './src/data/specialtiesData';
import { consumablesData } from './src/data/consumablesData';

console.log('medicationsSeed count:', medicationsSeed.length);
console.log('dciData count:', dciData.length);
console.log('specialtiesData count:', specialtiesData.length);
console.log('consumablesData count:', consumablesData.length);

let totalExpandedSpecialties = 0;
specialtiesData.forEach(spec => {
  totalExpandedSpecialties += spec.specialties.length;
});
console.log('totalExpandedSpecialties count:', totalExpandedSpecialties);
