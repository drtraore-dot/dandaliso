import * as React from "react";
import { useState, useEffect } from "react";
import * as SwitchPrimitives from "@radix-ui/react-switch";
import { cn } from "@/lib/utils";
import { db } from "@/db";
import { toast } from "sonner";
import {
  Building,
  Settings,
  Database,
  Save,
  Download,
  Loader2,
  Mail,
  Phone,
  MapPin,
  Coins,
  AlertTriangle,
  LayoutGrid
} from "lucide-react";

// ==========================================
// SWITCH UI COMPONENT
// ==========================================

interface SwitchProps extends React.ComponentPropsWithoutRef<typeof SwitchPrimitives.Root> {
  className?: string;
  checked?: boolean;
  onCheckedChange?: (checked: boolean) => void;
}

const Switch = React.forwardRef<
  React.ElementRef<typeof SwitchPrimitives.Root>,
  SwitchProps
>(({ className, ...props }, ref) => (
  <SwitchPrimitives.Root
    className={cn(
      "peer data-[state=checked]:bg-primary data-[state=unchecked]:bg-input focus-visible:border-ring focus-visible:ring-ring/50 dark:data-[state=unchecked]:bg-input/80 inline-flex h-[1.15rem] w-8 shrink-0 items-center rounded-full border border-transparent shadow-xs transition-all outline-none focus-visible:ring-[3px] disabled:cursor-not-allowed disabled:opacity-50",
      className
    )}
    {...props}
    ref={ref}
  >
    <SwitchPrimitives.Thumb
      className={cn(
        "bg-background dark:data-[state=unchecked]:bg-foreground dark:data-[state=checked]:bg-primary-foreground pointer-events-none block size-4 rounded-full ring-0 transition-transform data-[state=checked]:translate-x-[calc(100%-2px)] data-[state=unchecked]:translate-x-0"
      )}
    />
  </SwitchPrimitives.Root>
));

Switch.displayName = SwitchPrimitives.Root.displayName;

export { Switch };

// ==========================================
// SETTINGS / PARAMETRES DATA STRUCTURES
// ==========================================

export interface Parametres {
  id?: number;
  nom_clinique: string;
  type_structure: string;
  adresse: string;
  telephone: string;
  email: string;
  devise: string;
  couleur_primaire: string;
  couleur_secondaire: string;
  mode_sombre: boolean;
  sauvegarde_auto: boolean;
  frequence_sauvegarde: number;
  alerte_expiration_jours: number;
  alerte_stock_min: number;
  created_at: Date;
}

const DEFAULT_SETTINGS: Parametres = {
  nom_clinique: "Clinique Koule Djakan",
  type_structure: "clinique",
  adresse: "Abidjan, Cote d'Ivoire",
  telephone: "",
  email: "",
  devise: "FCFA",
  couleur_primaire: "#0f766e",
  couleur_secondaire: "#14b8a6",
  mode_sombre: false,
  sauvegarde_auto: true,
  frequence_sauvegarde: 30,
  alerte_expiration_jours: 30,
  alerte_stock_min: 10,
  created_at: new Date(),
};

// ==========================================
// PARAMETRES MANAGEMENT PAGE COMPONENT
// ==========================================

export default function ParametresPage() {
  const [settings, setSettings] = useState<Parametres>(DEFAULT_SETTINGS);
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [activeTab, setActiveTab] = useState<string>("structure");

  useEffect(() => {
    loadSettings();
  }, []);

  // Fetch parameters from Dexie IDB
  async function loadSettings() {
    try {
      const records = await db.parametres.toArray();
      if (records.length > 0) {
        setSettings(records[records.length - 1]);
      } else {
        await db.parametres.add(DEFAULT_SETTINGS);
        setSettings(DEFAULT_SETTINGS);
      }
    } catch (error) {
      toast.error("Erreur de chargement des paramètres");
    } finally {
      setIsLoading(false);
    }
  }

  // Update a single setting field reactively
  function updateField<K extends keyof Parametres>(key: K, value: Parametres[K]) {
    setSettings((prev) => ({
      ...prev,
      [key]: value,
    }));
  }

  // Save parameters to local Dexie database and cache in localStorage
  async function saveSettings() {
    try {
      const records = await db.parametres.toArray();
      const updatedSettings = {
        ...settings,
        created_at: new Date(),
      };

      if (records.length > 0 && records[0].id) {
        await db.parametres.update(records[0].id, updatedSettings);
      } else {
        await db.parametres.add(updatedSettings);
      }

      localStorage.setItem("clinique_config", JSON.stringify(updatedSettings));
      toast.success("Paramètres sauvegardés avec succès");
    } catch (error) {
      toast.error("Erreur lors de la sauvegarde");
    }
  }

  // Export database settings schema as JSON backup
  function exportSettings() {
    try {
      const blob = new Blob([JSON.stringify(settings, null, 2)], {
        type: "application/json",
      });
      const url = URL.createObjectURL(blob);
      const link = document.createElement("a");
      link.href = url;
      link.download = `backup_configuration_${settings.nom_clinique.toLowerCase().replace(/\s+/g, "_")}.json`;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      URL.revokeObjectURL(url);
      toast.success("Fichier de configuration exporté");
    } catch (error) {
      toast.error("Échec de l'exportation");
    }
  }

  if (isLoading) {
    return (
      <div className="flex h-screen w-full items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  return (
    <div className="container mx-auto max-w-5xl p-6 space-y-8">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b pb-5">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Configuration de l'établissement</h1>
          <p className="text-muted-foreground mt-1">
            Gérez les détails de votre clinique, la facturation et les politiques d'alertes de stock.
          </p>
        </div>
        <div className="flex items-center gap-3">
          <button
            onClick={exportSettings}
            className="inline-flex items-center justify-center gap-2 rounded-lg border border-input bg-background px-4 py-2 text-sm font-medium shadow-xs hover:bg-accent transition-colors"
          >
            <Download className="h-4 w-4" />
            Exporter
          </button>
          <button
            onClick={saveSettings}
            className="inline-flex items-center justify-center gap-2 rounded-lg bg-primary px-4 py-2 text-sm font-medium text-primary-foreground shadow-xs hover:bg-primary/90 transition-colors"
          >
            <Save className="h-4 w-4" />
            Enregistrer
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        {/* Navigation Tabs */}
        <div className="flex flex-row md:flex-col gap-1 overflow-x-auto pb-2 md:pb-0">
          <button
            onClick={() => setActiveTab("structure")}
            className={cn(
              "inline-flex items-center gap-2 px-3 py-2.5 text-sm font-medium rounded-lg whitespace-nowrap transition-colors",
              activeTab === "structure"
                ? "bg-primary/10 text-primary"
                : "text-muted-foreground hover:bg-accent"
            )}
          >
            <Building className="h-4 w-4" />
            Informations Structure
          </button>
          <button
            onClick={() => setActiveTab("preferences")}
            className={cn(
              "inline-flex items-center gap-2 px-3 py-2.5 text-sm font-medium rounded-lg whitespace-nowrap transition-colors",
              activeTab === "preferences"
                ? "bg-primary/10 text-primary"
                : "text-muted-foreground hover:bg-accent"
            )}
          >
            <Settings className="h-4 w-4" />
            Préférences & Design
          </button>
          <button
            onClick={() => setActiveTab("sauvegarde")}
            className={cn(
              "inline-flex items-center gap-2 px-3 py-2.5 text-sm font-medium rounded-lg whitespace-nowrap transition-colors",
              activeTab === "sauvegarde"
                ? "bg-primary/10 text-primary"
                : "text-muted-foreground hover:bg-accent"
            )}
          >
            <Database className="h-4 w-4" />
            Sécurité & Seuils
          </button>
        </div>

        {/* Tab Contents */}
        <div className="md:col-span-3 bg-card border rounded-xl p-6 shadow-xs">
          {activeTab === "structure" && (
            <div className="space-y-6">
              <div>
                <h3 className="text-lg font-medium">Informations sur l'établissement</h3>
                <p className="text-sm text-muted-foreground">Identité et coordonnées de votre structure médicale.</p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <label className="text-sm font-medium">Nom de la Clinique / Cabinet</label>
                  <div className="relative">
                    <Building className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                    <input
                      type="text"
                      value={settings.nom_clinique}
                      onChange={(e) => updateField("nom_clinique", e.target.value)}
                      className="w-full pl-9 pr-3 py-2 rounded-lg border border-input bg-background text-sm focus:ring-1 focus:ring-primary outline-none"
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <label className="text-sm font-medium">Type de Structure</label>
                  <select
                    value={settings.type_structure}
                    onChange={(e) => updateField("type_structure", e.target.value)}
                    className="w-full px-3 py-2 rounded-lg border border-input bg-background text-sm focus:ring-1 focus:ring-primary outline-none"
                  >
                    <option value="clinique">Clinique</option>
                    <option value="cabinet">Cabinet Médical</option>
                    <option value="hopital">Hôpital</option>
                    <option value="dispensaire">Dispensaire</option>
                  </select>
                </div>

                <div className="space-y-2 md:col-span-2">
                  <label className="text-sm font-medium">Adresse</label>
                  <div className="relative">
                    <MapPin className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                    <input
                      type="text"
                      value={settings.adresse}
                      onChange={(e) => updateField("adresse", e.target.value)}
                      className="w-full pl-9 pr-3 py-2 rounded-lg border border-input bg-background text-sm focus:ring-1 focus:ring-primary outline-none"
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <label className="text-sm font-medium">Téléphone</label>
                  <div className="relative">
                    <Phone className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                    <input
                      type="tel"
                      value={settings.telephone}
                      onChange={(e) => updateField("telephone", e.target.value)}
                      className="w-full pl-9 pr-3 py-2 rounded-lg border border-input bg-background text-sm focus:ring-1 focus:ring-primary outline-none"
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <label className="text-sm font-medium">E-mail</label>
                  <div className="relative">
                    <Mail className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                    <input
                      type="email"
                      value={settings.email}
                      onChange={(e) => updateField("email", e.target.value)}
                      className="w-full pl-9 pr-3 py-2 rounded-lg border border-input bg-background text-sm focus:ring-1 focus:ring-primary outline-none"
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <label className="text-sm font-medium">Devise monétaire</label>
                  <div className="relative">
                    <Coins className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                    <input
                      type="text"
                      value={settings.devise}
                      onChange={(e) => updateField("devise", e.target.value)}
                      className="w-full pl-9 pr-3 py-2 rounded-lg border border-input bg-background text-sm focus:ring-1 focus:ring-primary outline-none"
                    />
                  </div>
                </div>
              </div>
            </div>
          )}

          {activeTab === "preferences" && (
            <div className="space-y-6">
              <div>
                <h3 className="text-lg font-medium">Préférences d'Affichage</h3>
                <p className="text-sm text-muted-foreground">Personnalisez l'identité visuelle de votre application.</p>
              </div>

              <div className="space-y-4">
                <div className="flex items-center justify-between border-b pb-4">
                  <div className="space-y-0.5">
                    <label className="text-sm font-medium">Mode Sombre</label>
                    <p className="text-xs text-muted-foreground">Passer à l'affichage à faible luminosité.</p>
                  </div>
                  <Switch
                    checked={settings.mode_sombre}
                    onCheckedChange={(checked) => updateField("mode_sombre", checked)}
                  />
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pt-2">
                  <div className="space-y-2">
                    <label className="text-sm font-medium">Couleur Primaire</label>
                    <div className="flex items-center gap-3">
                      <input
                        type="color"
                        value={settings.couleur_primaire}
                        onChange={(e) => updateField("couleur_primaire", e.target.value)}
                        className="h-9 w-12 rounded cursor-pointer border-none bg-transparent"
                      />
                      <span className="text-xs font-mono uppercase text-muted-foreground">
                        {settings.couleur_primaire}
                      </span>
                    </div>
                  </div>

                  <div className="space-y-2">
                    <label className="text-sm font-medium">Couleur Secondaire</label>
                    <div className="flex items-center gap-3">
                      <input
                        type="color"
                        value={settings.couleur_secondaire}
                        onChange={(e) => updateField("couleur_secondaire", e.target.value)}
                        className="h-9 w-12 rounded cursor-pointer border-none bg-transparent"
                      />
                      <span className="text-xs font-mono uppercase text-muted-foreground">
                        {settings.couleur_secondaire}
                      </span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          )}

          {activeTab === "sauvegarde" && (
            <div className="space-y-6">
              <div>
                <h3 className="text-lg font-medium">Sauvegardes & Alertes Métier</h3>
                <p className="text-sm text-muted-foreground">Configurez la sécurité de vos données et vos règles d'alerte.</p>
              </div>

              <div className="space-y-4">
                <div className="flex items-center justify-between border-b pb-4">
                  <div className="space-y-0.5">
                    <label className="text-sm font-medium">Sauvegarde Automatique</label>
                    <p className="text-xs text-muted-foreground">Sauvegarde automatique des données du navigateur.</p>
                  </div>
                  <Switch
                    checked={settings.sauvegarde_auto}
                    onCheckedChange={(checked) => updateField("sauvegarde_auto", checked)}
                  />
                </div>

                {settings.sauvegarde_auto && (
                  <div className="space-y-2 pt-2">
                    <label className="text-sm font-medium">Fréquence de Sauvegarde (minutes)</label>
                    <input
                      type="number"
                      value={settings.frequence_sauvegarde}
                      onChange={(e) => updateField("frequence_sauvegarde", parseInt(e.target.value) || 30)}
                      className="max-w-[150px] w-full px-3 py-2 rounded-lg border border-input bg-background text-sm focus:ring-1 focus:ring-primary outline-none"
                    />
                  </div>
                )}

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pt-4 border-t">
                  <div className="space-y-2">
                    <div className="flex items-center gap-1.5">
                      <AlertTriangle className="h-4 w-4 text-amber-500" />
                      <label className="text-sm font-medium">Alerte Expiration Stock (jours)</label>
                    </div>
                    <input
                      type="number"
                      value={settings.alerte_expiration_jours}
                      onChange={(e) => updateField("alerte_expiration_jours", parseInt(e.target.value) || 30)}
                      className="w-full px-3 py-2 rounded-lg border border-input bg-background text-sm focus:ring-1 focus:ring-primary outline-none"
                    />
                    <p className="text-xs text-muted-foreground">Signaler les médicaments expirant bientôt.</p>
                  </div>

                  <div className="space-y-2">
                    <div className="flex items-center gap-1.5">
                      <LayoutGrid className="h-4 w-4 text-amber-500" />
                      <label className="text-sm font-medium">Seuil de Stock Minimal</label>
                    </div>
                    <input
                      type="number"
                      value={settings.alerte_stock_min}
                      onChange={(e) => updateField("alerte_stock_min", parseInt(e.target.value) || 10)}
                      className="w-full px-3 py-2 rounded-lg border border-input bg-background text-sm focus:ring-1 focus:ring-primary outline-none"
                    />
                    <p className="text-xs text-muted-foreground">Alerte de réapprovisionnement critique.</p>
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}