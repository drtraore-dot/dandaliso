import * as React from "react";
import { cn } from "@/lib/utils";
import { Activity, Stethoscope } from "lucide-react";

export interface TextareaProps
  extends React.TextareaHTMLAttributes<HTMLTextAreaElement> {}

const Textarea = React.forwardRef<HTMLTextAreaElement, TextareaProps>(
  ({ className, ...props }, ref) => {
    return (
      <textarea
        data-slot="textarea"
        className={cn(
          "border-input placeholder:text-muted-foreground focus-visible:border-ring focus-visible:ring-ring/50 aria-invalid:ring-destructive/20 dark:aria-invalid:ring-destructive/40 aria-invalid:border-destructive dark:bg-input/30 flex field-sizing-content min-h-16 w-full rounded-md border bg-transparent px-3 py-2 text-base shadow-xs transition-[color,box-shadow] outline-none focus-visible:ring-[3px] disabled:cursor-not-allowed disabled:opacity-50 md:text-sm",
          className
        )}
        ref={ref}
        {...props}
      />
    );
  }
);
Textarea.displayName = "Textarea";

export { Textarea };

export interface FormFieldDefinition {
  key: string;
  label: string;
  type: "input" | "select";
  options?: string[];
}

export interface FormSectionDefinition {
  id: string;
  label: string;
  icon: React.ElementType;
  fields: FormFieldDefinition[];
}

export const medicalAssessmentSections: FormSectionDefinition[] = [
  {
    id: "signes_vitaux",
    label: "A. Signes vitaux",
    icon: Activity,
    fields: [
      { key: "temperature", label: "Temperature (°C)", type: "input" },
      { key: "tension", label: "Tension arterielle (mmHg)", type: "input" },
      { key: "pouls", label: "Pouls (bpm)", type: "input" },
      { key: "frequence_respiratoire", label: "FR (/min)", type: "input" },
      { key: "saturation_o2", label: "Sat O2 (%)", type: "input" },
      { key: "poids", label: "Poids (kg)", type: "input" },
      { key: "taille", label: "Taille (cm)", type: "input" },
      { key: "glycemie", label: "Glycemie (g/L)", type: "input" },
    ],
  },
  {
    id: "examen_general",
    label: "B. Examen general",
    icon: Stethoscope,
    fields: [
      { key: "etat_general", label: "Etat general", type: "select", options: ["Bon", "Moyen", "Altere", "Grave"] },
      { key: "conscience", label: "Conscience", type: "select", options: ["Claire", "Obnubilee", "Confusion", "Coma"] },
      { key: "hydratation", label: "Hydratation", type: "select", options: ["Normale", "Deshydratation legere", "Deshydratation severe"] },
      { key: "nutrition", label: "Nutrition", type: "select", options: ["Normale", "Denutrition"] },
    ],
  },
];