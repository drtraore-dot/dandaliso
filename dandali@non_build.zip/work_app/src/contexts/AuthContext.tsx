import React, { createContext, useContext, useState, useCallback, useEffect, ReactNode } from 'react';
import { db } from '@/db';

export interface User {
  id: string;
  username: string;
  role: 'administrateur' | 'infirmier' | 'medecin' | 'laborantin' | 'caissiere' | 'comptable' | 'receptionniste';
}

interface AuthContextType {
  user: User | null;
  loading: boolean;
  login: (user: User) => void;
  logout: () => void;
  canAccess: (roles: string | string[]) => boolean;
  canEdit: (feature: string) => boolean;
  isAdmin: () => boolean;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider = ({ children }: { children: ReactNode }) => {
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // Check local storage or session for persistent auth
    const storedUser = localStorage.getItem('auth_user');
    if (storedUser) {
      setUser(JSON.parse(storedUser));
    }
    setLoading(false);
  }, []);

  const login = (userData: User) => {
    setUser(userData);
    localStorage.setItem('auth_user', JSON.stringify(userData));
  };

  const logout = () => {
    setUser(null);
    localStorage.removeItem('auth_user');
  };

  const canAccess = useCallback((roles: string | string[]) => {
    if (!user) return false;
    const roleList = Array.isArray(roles) ? roles : [roles];
    return roleList.includes(user.role as any);
  }, [user]);

  const canEdit = useCallback((feature: string) => {
    if (!user) return false;

    switch (user.role) {
      case 'administrateur':
        return true;
      case 'infirmier':
        return ['soins', 'hospitalisation'].includes(feature);
      case 'medecin':
        return ['consultations', 'ordonnances', 'examens'].includes(feature);
      case 'laborantin':
        return feature === 'examens';
      case 'caissiere':
        return feature === 'caisse';
      case 'comptable':
        return ['caisse', 'depenses', 'actes', 'prescripteurs', 'prestataires'].includes(feature);
      case 'receptionniste':
        return ['rendezvous', 'chambres'].includes(feature);
      default:
        return false;
    }
  }, [user]);

  const isAdmin = useCallback(() => user?.role === 'administrateur', [user]);

  return (
    <AuthContext.Provider value={{ user, loading, login, logout, canAccess, canEdit, isAdmin }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error("useAuth must be used within AuthProvider");
  }
  return context;
};