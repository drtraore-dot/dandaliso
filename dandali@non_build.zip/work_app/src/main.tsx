import React, { StrictMode } from 'react';
import { createRoot } from 'react-dom/client';
import App from '@/App';
import { ThemeProvider } from '@/components/theme-provider';
import './index.css';

/**
 * Main application entry point.
 * Renders the application within the necessary providers.
 */
function Main() {
  return <App />;
}

const rootElement = document.getElementById('root');

if (rootElement) {
  createRoot(rootElement).render(
    <StrictMode>
      <ThemeProvider defaultTheme="light" storageKey="app-ui-theme">
        <Main />
      </ThemeProvider>
    </StrictMode>
  );
}