import { db } from '@/db';

export interface PrintSettings {
  nom_clinique: string;
  type_structure: string;
  telephone: string;
  email: string;
  adresse: string;
  impression_entete: string;
  impression_pied_page: string;
  logo_data_url?: string;
  medecin_responsable?: string;
}

export const defaultPrintSettings: PrintSettings = {
  nom_clinique: 'Clinique Médicale',
  type_structure: 'Structure sanitaire',
  telephone: '',
  email: '',
  adresse: '',
  impression_entete: '',
  impression_pied_page: '',
  logo_data_url: '',
  medecin_responsable: '',
};

export function escapeHtml(value: any): string {
  return String(value ?? '')
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#039;');
}

export function nl2br(value: any): string {
  return escapeHtml(value).replace(/\n/g, '<br/>');
}

export async function getPrintSettings(): Promise<PrintSettings> {
  const rows = await db.parametres.toArray().catch(() => []);
  const cfg = rows?.[0] || {};
  return { ...defaultPrintSettings, ...cfg };
}

export function renderPrintHeader(settings: PrintSettings, title?: string): string {
  const customHeader = settings.impression_entete?.trim();
  const logo = settings.logo_data_url?.trim();
  return `
    <div class="print-header-block">
      ${logo ? `<div class="print-logo-wrap"><img class="print-logo" src="${escapeHtml(logo)}" alt="Logo" /></div>` : ''}
      <div class="print-header-main">
        <div class="print-clinic-name">${escapeHtml(settings.nom_clinique)}</div>
        <div class="print-clinic-sub">${escapeHtml(settings.type_structure || '')}</div>
        <div class="print-clinic-sub">${escapeHtml(settings.adresse || '')}${settings.telephone ? ' - Tél: ' + escapeHtml(settings.telephone) : ''}${settings.email ? ' - ' + escapeHtml(settings.email) : ''}</div>
        ${customHeader ? `<div class="print-custom-header">${nl2br(customHeader)}</div>` : ''}
      </div>
      ${title ? `<div class="print-doc-title">${escapeHtml(title)}</div>` : ''}
    </div>`;
}

export function renderPrintFooter(settings: PrintSettings): string {
  const footer = settings.impression_pied_page?.trim() || settings.nom_clinique;
  return `<div class="print-footer-block">${nl2br(footer)}</div>`;
}


export function renderPreviewToolbar(): string {
  return `
    <div class="preview-toolbar">
      <button class="print-btn" onclick="window.print()">Imprimer</button>
      <button class="pdf-btn" onclick="window.opener && window.opener.postMessage({type:'DANDALI_SAVE_PDF', html: document.documentElement.outerHTML}, '*')">Télécharger PDF</button>
      <button class="close-btn" onclick="window.close()">Fermer</button>
    </div>`;
}

export function previewToolbarStyles(): string {
  return `
    .preview-toolbar { position: sticky; top: 0; z-index: 9999; margin: -18px -24px 18px -24px; padding: 12px 18px; background: #f8fafc; border-bottom: 1px solid #cbd5e1; display: flex; justify-content: flex-end; gap: 10px; }
    .preview-toolbar button { border: 0; border-radius: 7px; padding: 9px 14px; font-weight: 800; cursor: pointer; font-size: 12px; }
    .preview-toolbar .print-btn { background: #2563eb; color: #fff; }
    .preview-toolbar .pdf-btn { background: #16a34a; color: #fff; }
    .preview-toolbar .close-btn { background: #e2e8f0; color: #0f172a; }
    @media print { .preview-toolbar { display: none !important; } }`;
}

export function installPdfBridge(): void {
  if (typeof window === 'undefined') return;
  if ((window as any).__DANDALI_PDF_BRIDGE__) return;
  (window as any).__DANDALI_PDF_BRIDGE__ = true;
  window.addEventListener('message', async (event: MessageEvent) => {
    const data: any = event.data || {};
    if (data.type !== 'DANDALI_SAVE_PDF' || !data.html) return;
    if (window.DANDALI_PRINT?.saveHtmlAsPdf) {
      await window.DANDALI_PRINT.saveHtmlAsPdf(data.html);
    } else {
      const blob = new Blob([data.html], { type: 'text/html;charset=utf-8' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = 'apercu-impression.html';
      a.click();
      URL.revokeObjectURL(url);
      alert('PDF direct disponible dans le .exe. En mode navigateur, un fichier HTML a été téléchargé.');
    }
  });
}
