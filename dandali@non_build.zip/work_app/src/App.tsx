import React, { StrictMode } from 'react';
import { createRoot } from 'react-dom/client';
import { HashRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { db } from '@/db';
import { useAuth } from '@/hooks/useAuth';
import { AuthProvider } from '@/contexts/AuthContext';

// Components imports (Actual localized pages)
import LoginPage from '@/pages/Login';
import Layout from '@/components/Layout';
import Dashboard from '@/pages/Dashboard';
import MedicalRecords from '@/pages/DossierMedical';
import TousPatients from '@/pages/TousPatients';
import Consultations from '@/pages/Consultations';
import References from '@/pages/References';
import DrugDatabase from '@/pages/BaseMedicaments';
import Billing from '@/pages/Caisse';
import Expenses from '@/pages/Depenses';
import Acts from '@/pages/Actes';
import Prescribers from '@/pages/Prescripteurs';
import Providers from '@/pages/Prestataires';
import Reports from '@/pages/Rapports';
import Assurances from '@/pages/Assurances';
import Laboratory from '@/pages/Laboratoire';
import Pharmacy from '@/pages/Pharmacie';
import Hospitalization from '@/pages/Hospitalisation';
import Rooms from '@/pages/Chambres';
import Care from '@/pages/SoinsInfirmiers';
import Appointments from '@/pages/RendezVous';
import Settings from '@/pages/Parametres';
import Synchronization from '@/pages/Synchronisation';
import Users from '@/pages/Utilisateurs';
import Activation from '@/pages/Activation';

interface RoleGuardProps {
  children: React.ReactNode;
  allowedRoles: string[];
}

function RoleGuard({ children, allowedRoles }: RoleGuardProps) {
  const { user, loading, canAccess } = useAuth();

  if (loading) {
    return <div className="flex items-center justify-center h-full text-slate-500">Chargement...</div>;
  }

  if (!user) {
    return <Navigate to="/login" replace />;
  }

  return canAccess(allowedRoles) ? (
    <>{children}</>
  ) : (
    <div className="flex items-center justify-center h-full text-slate-500">Acces refuse</div>
  );
}

function AuthGuard({ children }: { children: React.ReactNode }) {
  const { user, loading } = useAuth();

  if (loading) {
    return <div className="flex items-center justify-center h-screen text-slate-500">Chargement...</div>;
  }

  return user ? <>{children}</> : <Navigate to="/login" replace />;
}

function AppRoutes() {
  const { user } = useAuth();

  return (
    <Routes>
      <Route path="/login" element={user ? <Navigate to="/" replace /> : <LoginPage />} />
      <Route element={<AuthGuard><Layout /></AuthGuard>}>
        <Route path="/" element={<Dashboard />} />
        <Route path="/dossier-medical" element={<RoleGuard allowedRoles={["administrateur", "medecin", "infirmier"]}><MedicalRecords /></RoleGuard>} />
        <Route path="/tous-patients" element={<RoleGuard allowedRoles={["administrateur", "medecin", "infirmier", "laborantin", "caissiere", "comptable", "receptionniste"]}><TousPatients /></RoleGuard>} />
        <Route path="/consultations" element={<RoleGuard allowedRoles={["administrateur", "medecin", "infirmier"]}><Consultations /></RoleGuard>} />
        <Route path="/references" element={<RoleGuard allowedRoles={["administrateur", "medecin", "infirmier"]}><References /></RoleGuard>} />
        <Route path="/base-medicaments" element={<RoleGuard allowedRoles={["administrateur", "medecin", "infirmier"]}><DrugDatabase /></RoleGuard>} />
        <Route path="/caisse" element={<RoleGuard allowedRoles={["administrateur", "comptable", "caissiere"]}><Billing /></RoleGuard>} />
        <Route path="/assurances" element={<RoleGuard allowedRoles={["administrateur", "comptable", "caissiere"]}><Assurances /></RoleGuard>} />
        <Route path="/depenses" element={<RoleGuard allowedRoles={["administrateur", "comptable"]}><Expenses /></RoleGuard>} />
        <Route path="/Actes" element={<RoleGuard allowedRoles={["administrateur", "comptable"]}><Acts /></RoleGuard>} />
        <Route path="/prescripteurs" element={<RoleGuard allowedRoles={["administrateur", "comptable"]}><Prescribers /></RoleGuard>} />
        <Route path="/prestataires" element={<RoleGuard allowedRoles={["administrateur", "comptable"]}><Providers /></RoleGuard>} />
        <Route path="/rapports" element={<RoleGuard allowedRoles={["administrateur", "comptable"]}><Reports /></RoleGuard>} />
        <Route path="/laboratoire" element={<RoleGuard allowedRoles={["administrateur", "medecin", "infirmier", "laborantin"]}><Laboratory /></RoleGuard>} />
        <Route path="/pharmacie" element={<RoleGuard allowedRoles={["administrateur", "medecin", "infirmier", "caissiere"]}><Pharmacy /></RoleGuard>} />
        <Route path="/hospitalisation" element={<RoleGuard allowedRoles={["administrateur", "medecin", "infirmier", "caissiere"]}><Hospitalization /></RoleGuard>} />
        <Route path="/chambres" element={<RoleGuard allowedRoles={["administrateur", "infirmier", "receptionniste"]}><Rooms /></RoleGuard>} />
        <Route path="/soins" element={<RoleGuard allowedRoles={["administrateur", "infirmier"]}><Care /></RoleGuard>} />
        <Route path="/rendez-vous" element={<RoleGuard allowedRoles={["administrateur", "medecin", "infirmier", "receptionniste"]}><Appointments /></RoleGuard>} />
        <Route path="/parametres" element={<RoleGuard allowedRoles={["administrateur"]}><Settings /></RoleGuard>} />
        <Route path="/synchronisation" element={<RoleGuard allowedRoles={["administrateur"]}><Synchronization /></RoleGuard>} />
        <Route path="/utilisateurs" element={<RoleGuard allowedRoles={["administrateur"]}><Users /></RoleGuard>} />
      </Route>
    </Routes>
  );
}

function ActivationGate({ children }: { children: React.ReactNode }) {
  const [checking, setChecking] = React.useState(true);
  const [activated, setActivated] = React.useState(false);

  React.useEffect(() => {
    let mounted = true;
    async function checkLicense() {
      try {
        // Si l'API licence n'est pas disponible, on bloque aussi l'accès.
        // Cela permet de voir la page d'activation pendant npm run dev et évite tout contournement par navigateur.
        if (!window.DANDALI_LICENSE) {
          if (mounted) setActivated(false);
          return;
        }
        const status = await window.DANDALI_LICENSE.getStatus();
        if (mounted) setActivated(!!status.activated);
      } catch (_error) {
        if (mounted) setActivated(false);
      } finally {
        if (mounted) setChecking(false);
      }
    }
    checkLicense();
    return () => { mounted = false; };
  }, []);

  if (checking) {
    return <div className="min-h-screen flex items-center justify-center text-slate-500">Vérification de la licence...</div>;
  }

  if (!activated) {
    return <Activation onActivated={() => setActivated(true)} />;
  }

  return <>{children}</>;
}

export default function App() {
  return (
    <ActivationGate>
      <AuthProvider>
        <Router>
          <AppRoutes />
        </Router>
      </AuthProvider>
    </ActivationGate>
  );
}