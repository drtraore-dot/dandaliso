import React, { useState, useEffect, useMemo } from 'react';
import { 
  Stethoscope, 
  Plus, 
  Search, 
  Trash, 
  X, 
  Bed, 
  AlertTriangle, 
  CheckCircle2, 
  User, 
  Calendar, 
  MapPin, 
  Edit2,
  AlertCircle
} from 'lucide-react';
import { db } from '@/db';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { toast } from 'sonner';

interface Reference {
  id: number;
  patient_id: number;
  patient_nom: string;
  motif: string;
  destination: string;
  medecin: string;
  type: 'reference' | 'evacuation' | 'transfert';
  urgence: 'non_urgent' | 'urgent' | 'extreme_urgence';
  statut: 'en_cours' | 'complete' | 'annule';
  date_reference: string;
  telephone_dest: string;
  adresse_dest: string;
  diagnostic: string;
  traitement_recu: string;
  examens_realises: string;
  observation: string;
}

const URGENCY_STYLES = {
  non_urgent: 'bg-blue-50 text-blue-700',
  urgent: 'bg-amber-50 text-amber-700',
  extreme_urgence: 'bg-red-50 text-red-700'
};

const URGENCY_LABELS = {
  non_urgent: 'Non urgent',
  urgent: 'Urgent',
  extreme_urgence: 'Extrême urgence'
};

const TYPE_LABELS = {
  reference: 'Référence',
  evacuation: 'Évacuation',
  transfert: 'Transfert'
};

const STATUS_LABELS = {
  en_cours: 'En cours',
  complete: 'Complétée',
  annule: 'Annulé'
};

export default function ReferencesPage() {
  const [references, setReferences] = useState<Reference[]>([]);
  const [patients, setPatients] = useState<any[]>([]);
  const [isFormOpen, setIsFormOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");
  const [patientSearch, setPatientSearch] = useState("");
  const [showPatientResults, setShowPatientResults] = useState(false);
  const [editingRef, setEditingRef] = useState<Reference | null>(null);

  const [formData, setFormData] = useState<Partial<Reference>>({
    type: 'reference',
    urgence: 'non_urgent',
    statut: 'en_cours'
  });

  const handleDelete = async (id: number) => {
    if (!window.confirm("Supprimer cette référence ?")) return;
    await db.references.delete(id);
    toast.success("Référence supprimée");
    fetchData();
  };

  const fetchData = async () => {
    const refs = await db.references.toArray();
    const pts = await db.patients.toArray();
    setReferences(refs);
    setPatients(pts);
  };

  useEffect(() => {
    fetchData();
  }, []);

  const filteredPatients = patients.filter(p => 
    p.nom_complet.toLowerCase().includes(patientSearch.toLowerCase()) || 
    p.numero_patient.toLowerCase().includes(patientSearch.toLowerCase())
  );

  const filteredReferences = references.filter(ref => 
    `${ref.patient_nom} ${ref.motif} ${ref.destination} ${ref.medecin} ${ref.type}`
      .toLowerCase()
      .includes(searchQuery.toLowerCase())
  );

  const handleUpdateField = (key: keyof Reference, value: any) => {
    setFormData(prev => ({ ...prev, [key]: value }));
  };

  const handleSave = async () => {
    if (editingRef) {
      await db.references.update(editingRef.id, formData);
      toast.success("Référence mise à jour");
    } else {
      await db.references.add({ ...formData, date_reference: new Date().toISOString() } as any);
      toast.success("Référence créée");
    }
    setIsFormOpen(false);
    setEditingRef(null);
    setFormData({ type: 'reference', urgence: 'non_urgent', statut: 'en_cours' });
    fetchData();
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between flex-wrap gap-3">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-lg bg-red-600 flex items-center justify-center">
            <Stethoscope className="w-5 h-5 text-white" />
          </div>
          <div>
            <h2 className="text-xl font-bold text-slate-800 dark:text-white">Références & Évacuations</h2>
            <p className="text-sm text-slate-500">Gestion des transferts et références de patients</p>
          </div>
        </div>
        <Button onClick={() => setIsFormOpen(true)} className="bg-red-600 hover:bg-red-700">
          <Plus className="w-4 h-4 mr-1" /> Nouvelle référence
        </Button>
      </div>

      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        <Card><CardContent className="p-3 flex items-center gap-2"><div className="w-8 h-8 rounded-lg bg-blue-100 text-blue-600 flex items-center justify-center"><Stethoscope className="w-4 h-4" /></div><div><p className="text-xs text-slate-500">Total</p><p className="text-lg font-bold">{references.length}</p></div></CardContent></Card>
        <Card><CardContent className="p-3 flex items-center gap-2"><div className="w-8 h-8 rounded-lg bg-amber-100 text-amber-600 flex items-center justify-center"><AlertCircle className="w-4 h-4" /></div><div><p className="text-xs text-slate-500">En cours</p><p className="text-lg font-bold">{references.filter(r => r.statut === 'en_cours').length}</p></div></CardContent></Card>
        <Card><CardContent className="p-3 flex items-center gap-2"><div className="w-8 h-8 rounded-lg bg-red-100 text-red-600 flex items-center justify-center"><AlertTriangle className="w-4 h-4" /></div><div><p className="text-xs text-slate-500">Urgences</p><p className="text-lg font-bold">{references.filter(r => r.urgence !== 'non_urgent').length}</p></div></CardContent></Card>
        <Card><CardContent className="p-3 flex items-center gap-2"><div className="w-8 h-8 rounded-lg bg-emerald-100 text-emerald-600 flex items-center justify-center"><CheckCircle2 className="w-4 h-4" /></div><div><p className="text-xs text-slate-500">Complétées</p><p className="text-lg font-bold">{references.filter(r => r.statut === 'complete').length}</p></div></CardContent></Card>
      </div>

      <div className="relative">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
        <Input placeholder="Rechercher..." value={searchQuery} onChange={(e) => setSearchQuery(e.target.value)} className="pl-9" />
      </div>

      {isFormOpen && (
        <Card className="border-red-200">
          <CardContent className="p-4 space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="font-semibold flex items-center gap-2 text-red-700">
                <Stethoscope className="w-5 h-5 text-red-600" /> {editingRef ? 'Modifier la référence' : 'Nouvelle Référence / Évacuation'}
              </h3>
              <Button variant="ghost" size="sm" onClick={() => { setIsFormOpen(false); setEditingRef(null); }}>
                <X className="w-4 h-4" />
              </Button>
            </div>
            
            <div className="p-1 space-y-3">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {/* Patient Search / Selection */}
                <div className="space-y-1 relative">
                  <Label className="text-xs font-bold text-slate-700">Patient *</Label>
                  <Input 
                    placeholder="Saisir ou rechercher le patient..." 
                    value={patientSearch} 
                    onChange={(e) => {
                      setPatientSearch(e.target.value);
                      handleUpdateField('patient_nom', e.target.value);
                      setShowPatientResults(true);
                    }} 
                    required
                    className="h-9 text-xs"
                  />
                  {showPatientResults && filteredPatients.length > 0 && (
                    <div className="absolute z-50 top-full left-0 right-0 max-h-40 overflow-y-auto bg-white border rounded shadow-lg mt-1">
                      {filteredPatients.map(pt => (
                        <div 
                          key={pt.id} 
                          onClick={() => {
                            handleUpdateField('patient_id', pt.id);
                            handleUpdateField('patient_nom', pt.nom_complet);
                            setPatientSearch(pt.nom_complet);
                            setShowPatientResults(false);
                          }}
                          className="p-2 hover:bg-slate-50 cursor-pointer text-xs flex justify-between border-b"
                        >
                          <span className="font-semibold text-slate-800">{pt.nom_complet}</span>
                          <span className="text-slate-400">{pt.numero_patient}</span>
                        </div>
                      ))}
                    </div>
                  )}
                </div>

                {/* Motif */}
                <div className="space-y-1">
                  <Label className="text-xs font-bold text-slate-700">Motif de la Référence *</Label>
                  <Input 
                    placeholder="Ex: Complications respiratoires, trauma..." 
                    value={formData.motif || ''} 
                    onChange={e => handleUpdateField('motif', e.target.value)} 
                    required 
                    className="h-9 text-xs"
                  />
                </div>
              </div>

              {/* Urgencies and Types selection options */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div className="space-y-1">
                  <Label className="text-xs font-bold text-slate-700">Type de transfert</Label>
                  <select
                    value={formData.type || 'reference'}
                    onChange={e => handleUpdateField('type', e.target.value)}
                    className="w-full h-9 rounded border text-xs px-2 bg-white"
                  >
                    <option value="reference">Référence</option>
                    <option value="evacuation">Évacuation</option>
                    <option value="transfert">Transfert</option>
                  </select>
                </div>
                <div className="space-y-1">
                  <Label className="text-xs font-bold text-slate-700">Niveau d'Urgence</Label>
                  <select
                    value={formData.urgence || 'non_urgent'}
                    onChange={e => handleUpdateField('urgence', e.target.value)}
                    className="w-full h-9 rounded border text-xs px-2 bg-white"
                  >
                    <option value="non_urgent">Non urgent (Stable)</option>
                    <option value="urgent">Urgent</option>
                    <option value="extreme_urgence">Extrême urgence</option>
                  </select>
                </div>
                <div className="space-y-1">
                  <Label className="text-xs font-bold text-slate-700">Statut</Label>
                  <select
                    value={formData.statut || 'en_cours'}
                    onChange={e => handleUpdateField('statut', e.target.value)}
                    className="w-full h-9 rounded border text-xs px-2 bg-white"
                  >
                    <option value="en_cours">En cours (En transit)</option>
                    <option value="complete">Complétée</option>
                    <option value="annule">Annulé</option>
                  </select>
                </div>
              </div>

              {/* Destinations and Referring professionals */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div className="space-y-1">
                  <Label className="text-xs font-bold text-slate-700">Structure d'Accueil Destinataire *</Label>
                  <Input 
                    placeholder="Ex: CSREF, Hôpital Gabriel Touré..." 
                    value={formData.destination || ''} 
                    onChange={e => handleUpdateField('destination', e.target.value)} 
                    required 
                    className="h-9 text-xs"
                  />
                </div>
                <div className="space-y-1">
                  <Label className="text-xs font-bold text-slate-700">Médecin Référent / Accompagnant</Label>
                  <Input 
                    placeholder="Ex: Dr. Sissoko..." 
                    value={formData.medecin || ''} 
                    onChange={e => handleUpdateField('medecin', e.target.value)} 
                    className="h-9 text-xs"
                  />
                </div>
                <div className="space-y-1">
                  <Label className="text-xs font-bold text-slate-700 font-sans">Téléphone Destination</Label>
                  <Input 
                    placeholder="Ex: +223 76001122" 
                    value={formData.telephone_dest || ''} 
                    onChange={e => handleUpdateField('telephone_dest', e.target.value)} 
                    className="h-9 text-xs"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div className="space-y-1">
                  <Label className="text-xs font-bold text-slate-700">Diagnostic de présomption</Label>
                  <Input 
                    placeholder="Ex: Paludisme grave, détresse respiratoire..." 
                    value={formData.diagnostic || ''} 
                    onChange={e => handleUpdateField('diagnostic', e.target.value)}
                    className="h-9 text-xs"
                  />
                </div>
                <div className="space-y-1">
                  <Label className="text-xs font-bold text-slate-700">Traitement administré en premier recours</Label>
                  <Input 
                    placeholder="Ex: Perfusion de sérum physiol, Paracetamol..." 
                    value={formData.traitement_recu || ''} 
                    onChange={e => handleUpdateField('traitement_recu', e.target.value)}
                    className="h-9 text-xs"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div className="space-y-1">
                  <Label className="text-xs font-bold text-slate-700">Examens de labo réalisés</Label>
                  <Input 
                    placeholder="Ex: GE / Flash, NFS..." 
                    value={formData.examens_realises || ''} 
                    onChange={e => handleUpdateField('examens_realises', e.target.value)}
                    className="h-9 text-xs"
                  />
                </div>
                <div className="space-y-1">
                  <Label className="text-xs font-bold text-slate-700">Remarques / Observations cliniques</Label>
                  <Input 
                    placeholder="Ex: État hémodynamique stable..." 
                    value={formData.observation || ''} 
                    onChange={e => handleUpdateField('observation', e.target.value)}
                    className="h-9 text-xs"
                  />
                </div>
              </div>

              <div className="flex justify-end gap-2 pt-3 border-t mt-3">
                <Button type="button" variant="outline" size="sm" onClick={() => { setIsFormOpen(false); setEditingRef(null); }}>
                  Mettre de côté
                </Button>
                <Button type="button" size="sm" className="bg-red-600 hover:bg-red-700 text-white font-semibold" onClick={handleSave}>
                  {editingRef ? 'Enregistrer les modifications' : 'Confirmer & Créer la référence'}
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      <div className="space-y-2">
        {filteredReferences.length === 0 ? (
          <div className="text-center py-12 text-slate-400">
            <Stethoscope className="w-12 h-12 mx-auto mb-2 opacity-50" />
            <p>Aucune référence</p>
          </div>
        ) : (
          filteredReferences.map(ref => (
            <Card key={ref.id} className={ref.statut === 'annule' ? 'opacity-50' : ''}>
              <CardContent className="p-4">
                <div className="flex items-start justify-between gap-3">
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 flex-wrap">
                      <Badge variant="outline" className={URGENCY_STYLES[ref.urgence]}>{URGENCY_LABELS[ref.urgence]}</Badge>
                      <Badge variant="outline" className="bg-slate-100">{TYPE_LABELS[ref.type]}</Badge>
                      <span className="font-semibold">{ref.patient_nom}</span>
                    </div>
                    <div className="flex items-center gap-3 text-xs text-slate-500 mt-1 flex-wrap">
                      <span className="flex items-center gap-1"><User className="w-3 h-3" /> {ref.medecin || '-'}</span>
                      <span className="flex items-center gap-1"><Calendar className="w-3 h-3" /> {new Date(ref.date_reference).toLocaleDateString()}</span>
                      <span className="flex items-center gap-1"><MapPin className="w-3 h-3" /> {ref.destination}</span>
                    </div>
                  </div>
                  <div className="flex items-center gap-1">
                    <Button variant="ghost" size="sm" onClick={() => { setEditingRef(ref); setFormData(ref); setIsFormOpen(true); }}><Edit2 className="w-4 h-4" /></Button>
                    <Button variant="ghost" size="sm" className="text-red-500" onClick={() => handleDelete(ref.id)}><Trash className="w-4 h-4" /></Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))
        )}
      </div>
    </div>
  );
}