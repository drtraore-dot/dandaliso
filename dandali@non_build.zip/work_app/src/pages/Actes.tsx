import React, { useState, useEffect } from 'react';
import { db } from '@/db';
import { 
  Stethoscope, 
  Search, 
  Plus, 
  X, 
  Settings,
  AlertCircle
} from 'lucide-react';
import { toast } from 'react-hot-toast';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';

interface Prestation {
  id?: number;
  nom: string;
  categorie_id: number;
  prix: number;
  taux_remuneration?: number;
  montant_ristourne: number;
  statut: 'actif' | 'inactif';
  created_at: Date;
}

interface Categorie {
  id?: number;
  nom: string;
  description: string;
  ordre: number;
  actif: boolean;
}

export default function Actes() {
  const [activeTab, setActiveTab] = useState<'prestations' | 'categories'>('prestations');
  const [prestations, setPrestations] = useState<Prestation[]>([]);
  const [categories, setCategories] = useState<Categorie[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  
  const [showCatModal, setShowCatModal] = useState(false);
  const [showPresModal, setShowPresModal] = useState(false);

  const [newCat, setNewCat] = useState<Omit<Categorie, 'id' | 'actif'>>({ nom: '', description: '', ordre: 0 });
  const [newPres, setNewPres] = useState<Omit<Prestation, 'id' | 'statut' | 'created_at'>>({ 
    nom: '', 
    categorie_id: 0, 
    prix: 0, 
    taux_remuneration: 0, 
    montant_ristourne: 0 
  });

  useEffect(() => {
    fetchData();
  }, []);

  async function fetchData() {
    const [pts, cats] = await Promise.all([
      db.prestations.toArray(),
      db.categories.toArray()
    ]);
    setPrestations(pts);
    setCategories(cats);
  }

  async function handleCreatePrestation(e: React.FormEvent) {
    e.preventDefault();
    await db.prestations.add({
      ...newPres,
      categorie_id: Number(newPres.categorie_id),
      statut: 'actif',
      created_at: new Date()
    });
    toast.success('Prestation créée');
    setShowPresModal(false);
    fetchData();
  }

  async function handleCreateCategorie(e: React.FormEvent) {
    e.preventDefault();
    await db.categories.add({
      ...newCat,
      actif: true
    });
    toast.success('Catégorie créée');
    setShowCatModal(false);
    fetchData();
  }

  const filteredPrestations = prestations.filter(p => 
    !searchQuery || p.nom.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="space-y-4">
      <div className="flex items-center gap-3">
        <div className="w-10 h-10 rounded-lg bg-cyan-500 flex items-center justify-center">
          <Stethoscope className="w-5 h-5 text-white" />
        </div>
        <div>
          <h2 className="text-lg font-semibold">Prestations & Catégories</h2>
        </div>
      </div>

      <div className="flex gap-1 bg-slate-100 p-1 rounded-lg w-fit">
        <button 
          onClick={() => setActiveTab('prestations')}
          className={`px-4 py-2 rounded-md text-sm font-medium transition-colors ${activeTab === 'prestations' ? 'bg-white shadow-sm text-slate-900' : 'text-slate-600'}`}
        >
          Prestations
        </button>
        <button 
          onClick={() => setActiveTab('categories')}
          className={`px-4 py-2 rounded-md text-sm font-medium transition-colors ${activeTab === 'categories' ? 'bg-white shadow-sm text-slate-900' : 'text-slate-600'}`}
        >
          Catégories
        </button>
      </div>

      {activeTab === 'prestations' && (
        <div className="space-y-4">
          <div className="flex justify-between">
            <div className="relative flex-1 max-w-sm">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
              <Input 
                placeholder="Rechercher..." 
                value={searchQuery} 
                onChange={(e) => setSearchQuery(e.target.value)} 
                className="pl-10" 
              />
            </div>
            <Button onClick={() => setShowPresModal(true)} className="bg-teal-600 hover:bg-teal-700">
              <Plus className="w-4 h-4 mr-1" /> Nouvelle
            </Button>
          </div>
          <Card className="p-0">
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead className="bg-slate-50">
                  <tr>
                    <th className="text-left py-3 px-4 font-semibold">Nom</th>
                    <th className="text-left py-3 px-4 font-semibold">Catégorie</th>
                    <th className="text-right py-3 px-4 font-semibold">Prix</th>
                    <th className="text-right py-3 px-4 font-semibold">Rémun. %</th>
                    <th className="text-right py-3 px-4 font-semibold">Ristourne</th>
                  </tr>
                </thead>
                <tbody>
                  {filteredPrestations.map(p => (
                    <tr key={p.id} className="border-t hover:bg-slate-50">
                      <td className="py-3 px-4 font-medium">{p.nom}</td>
                      <td className="py-3 px-4 text-xs">{categories.find(c => c.id === p.categorie_id)?.nom}</td>
                      <td className="py-3 px-4 text-right">{p.prix.toLocaleString()} FCFA</td>
                      <td className="py-3 px-4 text-right text-violet-600">{p.taux_remuneration ? `${p.taux_remuneration}%` : '-'}</td>
                      <td className="py-3 px-4 text-right text-amber-600">{p.montant_ristourne > 0 ? `${p.montant_ristourne.toLocaleString()} FCFA` : '-'}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </Card>
        </div>
      )}

      {activeTab === 'categories' && (
        <div className="space-y-4">
          <Button onClick={() => setShowCatModal(true)} className="bg-teal-600 hover:bg-teal-700">
            <Plus className="w-4 h-4 mr-1" /> Nouvelle catégorie
          </Button>
          <Card className="p-0">
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead className="bg-slate-50">
                  <tr>
                    <th className="text-left py-3 px-4 font-semibold">Nom</th>
                    <th className="text-left py-3 px-4 font-semibold">Description</th>
                    <th className="text-left py-3 px-4 font-semibold">Ordre</th>
                  </tr>
                </thead>
                <tbody>
                  {categories.filter(c => c.actif).sort((a, b) => a.ordre - b.ordre).map(c => (
                    <tr key={c.id} className="border-t hover:bg-slate-50">
                      <td className="py-3 px-4 font-medium">{c.nom}</td>
                      <td className="py-3 px-4 text-xs text-slate-500">{c.description}</td>
                      <td className="py-3 px-4">{c.ordre}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </Card>
        </div>
      )}

      {showCatModal && (
        <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4">
          <div className="bg-white dark:bg-slate-800 rounded-lg shadow-xl max-w-md w-full">
            <div className="flex items-center justify-between p-4 border-b border-slate-200">
              <h3 className="text-lg font-semibold">Nouvelle Catégorie</h3>
              <button onClick={() => setShowCatModal(false)} className="p-1 hover:bg-slate-100 rounded"><X className="w-5 h-5" /></button>
            </div>
            <form onSubmit={handleCreateCategorie} className="p-4 space-y-3">
              <div className="space-y-1">
                <Label>Nom</Label>
                <Input value={newCat.nom} onChange={e => setNewCat({...newCat, nom: e.target.value})} required />
              </div>
              <div className="space-y-1">
                <Label>Description</Label>
                <Input value={newCat.description} onChange={e => setNewCat({...newCat, description: e.target.value})} />
              </div>
              <div className="space-y-1">
                <Label>Ordre</Label>
                <Input type="number" value={newCat.ordre} onChange={e => setNewCat({...newCat, ordre: Number(e.target.value)})} />
              </div>
              <div className="flex justify-end gap-2">
                <Button type="button" variant="outline" onClick={() => setShowCatModal(false)}>Annuler</Button>
                <Button type="submit" className="bg-teal-600 hover:bg-teal-700">Créer</Button>
              </div>
            </form>
          </div>
        </div>
      )}

      {showPresModal && (
        <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4">
          <div className="bg-white dark:bg-slate-800 rounded-lg shadow-xl max-w-md w-full">
            <div className="flex items-center justify-between p-4 border-b border-slate-200">
              <h3 className="text-lg font-semibold">Nouvelle Prestation</h3>
              <button onClick={() => setShowPresModal(false)} className="p-1 hover:bg-slate-100 rounded"><X className="w-5 h-5" /></button>
            </div>
            <form onSubmit={handleCreatePrestation} className="p-4 space-y-3">
              <div className="space-y-1">
                <Label>Nom</Label>
                <Input value={newPres.nom} onChange={e => setNewPres({...newPres, nom: e.target.value})} required />
              </div>
              <div className="space-y-1">
                <Label>Catégorie</Label>
                <select value={newPres.categorie_id} onChange={e => setNewPres({...newPres, categorie_id: Number(e.target.value)})} className="w-full h-10 rounded-md border border-input bg-transparent px-3 py-1 text-sm" required>
                  <option value="">Choisir une catégorie</option>
                  {categories.filter(c => c.actif).map(c => <option key={c.id} value={c.id}>{c.nom}</option>)}
                </select>
              </div>
              <div className="grid grid-cols-3 gap-3">
                <div className="space-y-1">
                  <Label>Prix (FCFA)</Label>
                  <Input type="number" value={newPres.prix} onChange={e => setNewPres({...newPres, prix: Number(e.target.value)})} />
                </div>
                <div className="space-y-1">
                  <Label>Rémun. (%)</Label>
                  <Input type="number" min={0} max={100} value={newPres.taux_remuneration} onChange={e => setNewPres({...newPres, taux_remuneration: Number(e.target.value)})} />
                </div>
                <div className="space-y-1">
                  <Label>Ristourne (FCFA)</Label>
                  <Input type="number" value={newPres.montant_ristourne} onChange={e => setNewPres({...newPres, montant_ristourne: Number(e.target.value)})} />
                </div>
              </div>
              <div className="flex justify-end gap-2">
                <Button type="button" variant="outline" onClick={() => setShowPresModal(false)}>Annuler</Button>
                <Button type="submit" className="bg-teal-600 hover:bg-teal-700">Créer</Button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}