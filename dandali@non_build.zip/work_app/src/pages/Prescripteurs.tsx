import React, { useState, useEffect } from 'react';
import { 
  Users, 
  Receipt, 
  Plus, 
  Search, 
  CheckCircle2, 
  AlertCircle, 
  X, 
  Calendar,
  Stethoscope
} from 'lucide-react';
import { db } from '@/db';
import { toast } from 'sonner';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';

interface Prescripteur {
  id?: number;
  nom: string;
  prenom: string;
  specialite: string;
  telephone: string;
  email: string;
  statut: 'actif' | 'inactif';
}

interface Ristourne {
  id: number;
  prescripteur_id: number;
  prestation_id: number;
  montant_ristourne: number;
  statut_paiement: 'paye' | 'en_attente';
  mois: string;
  mode_paiement?: string;
  observation?: string;
}

interface Prestation {
  id: number;
  nom: string;
}

export default function Prescripteurs() {
  const [activeTab, setActiveTab] = useState<'prescripteurs' | 'ristournes'>('prescripteurs');
  const [prescripteurs, setPrescripteurs] = useState<Prescripteur[]>([]);
  const [ristournes, setRistournes] = useState<Ristourne[]>([]);
  const [prestations, setPrestations] = useState<Prestation[]>([]);
  
  const [search, setSearch] = useState("");
  const [filterStatut, setFilterStatut] = useState("all");
  const [filterMonth, setFilterMonth] = useState("");
  
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [isPaymentModalOpen, setIsPaymentModalOpen] = useState(false);
  
  const [newPrescripteur, setNewPrescripteur] = useState({ nom: "", prenom: "", specialite: "", telephone: "", email: "", statut: "actif" as const });
  const [paiementInfo, setPaiementInfo] = useState({ mode_paiement: "virement", reference: "" });
  const [selectedRistourne, setSelectedRistourne] = useState<Ristourne | null>(null);

  useEffect(() => {
    loadData();
  }, []);

  async function loadData() {
    const [p, r, pr] = await Promise.all([
      db.prescripteurs.toArray(),
      db.ristournes.toArray(),
      db.prestations.toArray()
    ]);
    setPrescripteurs(p);
    setRistournes(r.reverse());
    setPrestations(pr);
  }

  const getPrescripteurName = (id: number) => {
    const p = prescripteurs.find(item => item.id === id);
    return p ? `${p.prenom} ${p.nom}` : "N/A";
  };

  const getPrestationName = (id: number) => {
    const p = prestations.find(item => item.id === id);
    return p ? p.nom : "N/A";
  };

  const handleCreatePrescripteur = async (e: React.FormEvent) => {
    e.preventDefault();
    await db.prescripteurs.add({ ...newPrescripteur, created_at: new Date() });
    toast.success("Prescripteur créé avec succès");
    setIsModalOpen(false);
    loadData();
  };

  const handlePayRistourne = async () => {
    if (!selectedRistourne) return;
    
    await db.ristournes.update(selectedRistourne.id, {
      statut_paiement: "paye",
      mode_paiement: paiementInfo.mode_paiement,
      date_paiement: new Date(),
      observation: (selectedRistourne.observation || "") + " | PAYE le " + new Date().toLocaleDateString("fr-FR")
    });

    let category = await db.categoriesDepense.where("nom").equalsIgnoreCase("Partenaires & Rémunérations").first();
    let categoryId: number | undefined;
    if (!category) {
      try {
        categoryId = await db.categoriesDepense.add({
          nom: "Partenaires & Rémunérations",
          icon: "Users2",
          created_at: new Date()
        });
      } catch (err) {
        console.error(err);
      }
    } else {
      categoryId = category.id;
    }

    const prescripteur = prescripteurs.find(p => p.id === selectedRistourne.prescripteur_id);
    await db.depenses.add({
      date: new Date(),
      type_depense: "Ristourne - " + (prescripteur ? `${prescripteur.prenom} ${prescripteur.nom}` : ""),
      montant: selectedRistourne.montant_ristourne,
      fournisseur: prescripteur ? `${prescripteur.prenom} ${prescripteur.nom}` : "",
      description: "Paiement ristourne | " + paiementInfo.mode_paiement + " | Ref: " + paiementInfo.reference,
      categorie_id: categoryId,
      created_at: new Date()
    });

    toast.success("Ristourne payée et enregistrée en dépenses");
    setIsPaymentModalOpen(false);
    loadData();
  };

  const totalPaye = ristournes.filter(r => r.statut_paiement === "paye").reduce((acc, curr) => acc + curr.montant_ristourne, 0);
  const totalImpaye = ristournes.filter(r => r.statut_paiement === "en_attente").reduce((acc, curr) => acc + curr.montant_ristourne, 0);

  return (
    <div className="space-y-4">
      <div className="flex items-center gap-3">
        <div className="w-10 h-10 rounded-lg bg-amber-500 flex items-center justify-center">
          <Stethoscope className="w-5 h-5 text-white" />
        </div>
        <div>
          <h2 className="text-lg font-semibold">Prescripteurs & Ristournes</h2>
        </div>
      </div>

      <div className="flex gap-1 bg-slate-100 p-1 rounded-lg w-fit">
        <button onClick={() => setActiveTab("prescripteurs")} className={`flex items-center gap-1 px-4 py-2 rounded-md text-sm font-medium transition-colors ${activeTab === "prescripteurs" ? "bg-white shadow-sm text-slate-900" : "text-slate-600"}`}>
          <Users className="w-4 h-4" /> Prescripteurs
        </button>
        <button onClick={() => setActiveTab("ristournes")} className={`flex items-center gap-1 px-4 py-2 rounded-md text-sm font-medium transition-colors ${activeTab === "ristournes" ? "bg-white shadow-sm text-slate-900" : "text-slate-600"}`}>
          <Receipt className="w-4 h-4" /> Paiement Ristournes
        </button>
      </div>

      {activeTab === "prescripteurs" && (
        <div className="space-y-4">
          <div className="flex justify-between">
            <div className="relative flex-1 max-w-sm">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
              <Input placeholder="Rechercher..." value={search} onChange={(e) => setSearch(e.target.value)} className="pl-10" />
            </div>
            <Button onClick={() => setIsModalOpen(true)} className="bg-teal-600 hover:bg-teal-700">
              <Plus className="w-4 h-4 mr-1" /> Nouveau
            </Button>
          </div>
          <Card className="p-0">
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead className="bg-slate-50">
                  <tr>
                    <th className="text-left py-3 px-4 font-semibold">Nom</th>
                    <th className="text-left py-3 px-4 font-semibold">Spécialité</th>
                    <th className="text-left py-3 px-4 font-semibold">Contact</th>
                    <th className="text-left py-3 px-4 font-semibold">Statut</th>
                  </tr>
                </thead>
                <tbody>
                  {prescripteurs.filter(p => !search || `${p.prenom} ${p.nom}`.toLowerCase().includes(search.toLowerCase())).map(p => (
                    <tr key={p.id} className="border-t hover:bg-slate-50">
                      <td className="py-3 px-4 font-medium">{p.prenom} {p.nom}</td>
                      <td className="py-3 px-4"><span className="px-2 py-0.5 rounded-full bg-amber-100 text-amber-700 text-xs">{p.specialite}</span></td>
                      <td className="py-3 px-4 text-xs text-slate-500">{p.telephone}</td>
                      <td className="py-3 px-4"><Badge className={p.statut === "actif" ? "bg-emerald-100 text-emerald-700" : "bg-red-100 text-red-700"}>{p.statut}</Badge></td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </Card>
        </div>
      )}

      {activeTab === "ristournes" && (
        <div className="space-y-4">
          <div className="grid grid-cols-3 gap-3">
            <Card className="p-4"><p className="text-xs text-slate-500">Total</p><p className="text-lg font-bold">{ristournes.length}</p></Card>
            <Card className="p-4"><p className="text-xs text-slate-500">Impayées</p><p className="text-lg font-bold text-red-600">{totalImpaye.toLocaleString()} FCFA</p></Card>
            <Card className="p-4"><p className="text-xs text-slate-500">Payées</p><p className="text-lg font-bold text-emerald-600">{totalPaye.toLocaleString()} FCFA</p></Card>
          </div>
          
          <div className="flex gap-2">
            <select value={filterStatut} onChange={(e) => setFilterStatut(e.target.value)} className="h-10 px-3 rounded-md border border-slate-200 text-sm">
              <option value="all">Tous</option>
              <option value="en_attente">Impayé</option>
              <option value="paye">Payé</option>
            </select>
            <div className="flex items-center gap-2">
              <Calendar className="w-4 h-4 text-slate-400" />
              <Input type="month" value={filterMonth} onChange={(e) => setFilterMonth(e.target.value)} className="w-40" />
            </div>
          </div>

          <Card className="p-0">
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead className="bg-slate-50">
                  <tr>
                    <th className="text-left py-3 px-4 font-semibold">Mois</th>
                    <th className="text-left py-3 px-4 font-semibold">Prescripteur</th>
                    <th className="text-left py-3 px-4 font-semibold">Acte</th>
                    <th className="text-left py-3 px-4 font-semibold">Montant</th>
                    <th className="text-left py-3 px-4 font-semibold">Statut</th>
                    <th className="text-center py-3 px-4 font-semibold">Action</th>
                  </tr>
                </thead>
                <tbody>
                  {ristournes.map(r => (
                    <tr key={r.id} className={`border-t hover:bg-slate-50 ${r.statut_paiement === "en_attente" ? "bg-red-50/50" : ""}`}>
                      <td className="py-3 px-4 text-xs">{r.mois}</td>
                      <td className="py-3 px-4 font-medium text-xs">{getPrescripteurName(r.prescripteur_id)}</td>
                      <td className="py-3 px-4 text-xs">{getPrestationName(r.prestation_id)}</td>
                      <td className="py-3 px-4 font-semibold">{r.montant_ristourne.toLocaleString()} FCFA</td>
                      <td className="py-3 px-4">
                        {r.statut_paiement === "paye" ? 
                          <Badge className="bg-emerald-100 text-emerald-700"><CheckCircle2 className="w-3 h-3 mr-1" /> Payé</Badge> : 
                          <Badge variant="outline" className="border-red-300 text-red-600"><AlertCircle className="w-3 h-3 mr-1" /> Impayé</Badge>
                        }
                      </td>
                      <td className="py-3 px-4 text-center">
                        {r.statut_paiement === "en_attente" && (
                          <Button size="sm" variant="outline" className="text-emerald-600 border-emerald-300" onClick={() => { setSelectedRistourne(r); setIsPaymentModalOpen(true); }}>
                            <CheckCircle2 className="w-3 h-3 mr-1" /> Payer
                          </Button>
                        )}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </Card>
        </div>
      )}

      {isModalOpen && (
        <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-lg shadow-xl max-w-lg w-full">
            <div className="flex items-center justify-between p-4 border-b">
              <h3 className="text-lg font-semibold">Nouveau Prescripteur</h3>
              <button onClick={() => setIsModalOpen(false)}><X className="w-5 h-5" /></button>
            </div>
            <form onSubmit={handleCreatePrescripteur} className="p-4 space-y-3">
              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1"><Label>Nom</Label><Input value={newPrescripteur.nom} onChange={e => setNewPrescripteur({...newPrescripteur, nom: e.target.value.toUpperCase()})} required /></div>
                <div className="space-y-1"><Label>Prénom</Label><Input value={newPrescripteur.prenom} onChange={e => setNewPrescripteur({...newPrescripteur, prenom: e.target.value})} required /></div>
              </div>
              <div className="space-y-1"><Label>Spécialité</Label><Input value={newPrescripteur.specialite} onChange={e => setNewPrescripteur({...newPrescripteur, specialite: e.target.value})} /></div>
              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1"><Label>Téléphone</Label><Input value={newPrescripteur.telephone} onChange={e => setNewPrescripteur({...newPrescripteur, telephone: e.target.value})} /></div>
                <div className="space-y-1"><Label>Email</Label><Input value={newPrescripteur.email} onChange={e => setNewPrescripteur({...newPrescripteur, email: e.target.value})} /></div>
              </div>
              <div className="flex justify-end gap-2 pt-2">
                <Button type="button" variant="outline" onClick={() => setIsModalOpen(false)}>Annuler</Button>
                <Button type="submit" className="bg-teal-600 hover:bg-teal-700">Créer</Button>
              </div>
            </form>
          </div>
        </div>
      )}

      {isPaymentModalOpen && selectedRistourne && (
        <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-lg shadow-xl max-w-md w-full">
            <div className="flex items-center justify-between p-4 border-b">
              <h3 className="text-lg font-semibold">Payer la Ristourne</h3>
              <button onClick={() => setIsPaymentModalOpen(false)}><X className="w-5 h-5" /></button>
            </div>
            <div className="p-4 space-y-4">
              <div className="p-3 bg-amber-50 border border-amber-200 rounded-lg text-sm">
                <p><strong>Prescripteur:</strong> {getPrescripteurName(selectedRistourne.prescripteur_id)}</p>
                <p><strong>Montant:</strong> {selectedRistourne.montant_ristourne.toLocaleString()} FCFA</p>
              </div>
              <div className="space-y-2">
                <Label>Mode de paiement</Label>
                <select value={paiementInfo.mode_paiement} onChange={e => setPaiementInfo({...paiementInfo, mode_paiement: e.target.value})} className="w-full h-10 rounded-md border border-slate-200 px-3 py-1 text-sm">
                  <option value="virement">Virement</option>
                  <option value="especes">Espèces</option>
                  <option value="cheque">Chèque</option>
                  <option value="mobile_money">Mobile Money</option>
                </select>
              </div>
              <div className="space-y-2"><Label>Référence</Label><Input value={paiementInfo.reference} onChange={e => setPaiementInfo({...paiementInfo, reference: e.target.value})} /></div>
              <div className="p-3 bg-blue-50 border border-blue-200 rounded-lg text-xs text-blue-700">Ce paiement sera automatiquement enregistré dans les Dépenses.</div>
              <div className="flex justify-end gap-2">
                <Button variant="outline" onClick={() => setIsPaymentModalOpen(false)}>Annuler</Button>
                <Button onClick={handlePayRistourne} className="bg-emerald-600 hover:bg-emerald-700"><CheckCircle2 className="w-4 h-4 mr-1" /> Confirmer</Button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}