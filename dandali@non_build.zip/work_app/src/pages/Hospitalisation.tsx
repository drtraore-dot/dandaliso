import React, { useState } from 'react';
import { db } from '@/db';
import { useLiveQuery } from 'dexie-react-hooks';
import { 
  Bed, 
  Plus, 
  Search, 
  LogOut, 
  X, 
  Calendar, 
  User, 
  Activity, 
  History,
  DoorOpen
} from 'lucide-react';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { toast } from 'sonner';
import { useAuth } from '@/hooks/useAuth';

interface Patient {
  id: number;
  nom_complet: string;
  telephone?: string;
}

interface Chambre {
  id: number;
  numero: string;
  type: string;
  prix_journalier: number;
  statut: 'disponible' | 'occupe';
}

interface Hospitalisation {
  id?: number;
  patient_id: number;
  chambre_id: number;
  date_entrée: string;
  date_sortie?: string | null;
  médecin_traitant: string;
  diagnostic_entrée: string;
  soins_prescrits?: string;
}

export default function HospitalisationPage() {
  const { canEdit } = useAuth();
  const [tab, setTab] = useState<'actifs' | 'historique'>('actifs');
  const [searchQuery, setSearchQuery] = useState('');
  const [showAdmissionModal, setShowAdmissionModal] = useState(false);
  const [showExitModal, setShowExitModal] = useState(false);
  const [selectedHospitalisation, setSelectedHospitalisation] = useState<Hospitalisation | null>(null);

  const [admissionForm, setAdmissionForm] = useState({
    patient_id: '',
    chambre_id: '',
    médecin_traitant: '',
    diagnostic_entrée: '',
    soins_prescrits: ''
  });

  // Independent patient storage for Hospitalisation module
  const [newPatientMode, setNewPatientMode] = useState(false);
  const [newPatientName, setNewPatientName] = useState("");
  const [newPatientTel, setNewPatientTel] = useState("");
  const [newPatientInfo, setNewPatientInfo] = useState("");

  // Database Queries
  const hospitalisations = useLiveQuery(() => db.hospitalisations.toArray()) || [];
  const patients = useLiveQuery(() => db.patients_hospitalisation.toArray()) || [];
  const chambres = useLiveQuery(() => db.chambres.toArray()) || [];

  // Active hospitalisations (no exit date yet)
  const activeHospitalisations = hospitalisations.filter(h => !h.date_sortie);

  // Available chambers
  const availableChambres = chambres.filter(c => c.statut === 'disponible');

  // Helper: calculate stay duration in days
  function calculateStayDuration(h: Hospitalisation): number {
    const entry = new Date(h.date_entrée);
    const exit = h.date_sortie ? new Date(h.date_sortie) : new Date();
    const diffTime = Math.ceil((exit.getTime() - entry.getTime()) / (1000 * 60 * 60 * 24));
    return diffTime > 0 ? diffTime : 1;
  }

  // Historic hospitalisations (exited this month)
  const currentMonth = new Date().getMonth();
  const currentYear = new Date().getFullYear();
  const historicHospitalisations = hospitalisations.filter(h => {
    if (!h.date_sortie) return false;
    const exitDate = new Date(h.date_sortie);
    return exitDate.getMonth() === currentMonth && exitDate.getFullYear() === currentYear;
  });

  // Filter active hospitalisations based on patient name search query
  const filteredActiveHospitalisations = activeHospitalisations.filter(h => {
    const patientName = getPatientName(h.patient_id).toLowerCase();
    return patientName.includes(searchQuery.toLowerCase());
  });

  // Helpers to get Patient and Chamber info
  function getPatientName(patientId: number): string {
    const patient = patients.find(p => p.id === patientId);
    return patient ? patient.nom_complet : 'Patient inconnu';
  }

  // Find room details
  function getChambreNumero(chambreId: number): string {
    const chambre = chambres.find(c => c.id === chambreId);
    return chambre ? chambre.numero : 'N/A';
  }

  function getChambreType(chambreId: number): string {
    const chambre = chambres.find(c => c.id === chambreId);
    return chambre ? chambre.type : 'N/A';
  }

  // Handle Admission Submission
  async function handleAdmissionSubmit(e: React.FormEvent) {
    e.preventDefault();
    
    if (!newPatientMode && !admissionForm.patient_id) {
      toast.error('Sélectionnez un patient ou créez-en un nouveau');
      return;
    }
    if (!admissionForm.chambre_id) {
      toast.error('Sélectionnez une chambre');
      return;
    }

    try {
      let patientId: number;
      if (newPatientMode) {
        if (!newPatientName.trim()) {
          toast.error("Veuillez saisir le nom complet pour le nouveau patient");
          return;
        }
        patientId = await db.patients_hospitalisation.add({
          numero_patient: `HOS-${String(patients.length + 1).padStart(4, "0")}`,
          nom_complet: newPatientName,
          telephone: newPatientTel || "N/A",
          info: newPatientInfo || "",
          created_at: new Date()
        });
      } else {
        patientId = Number(admissionForm.patient_id);
      }

      const chambreId = Number(admissionForm.chambre_id);

      await db.hospitalisations.add({
        patient_id: patientId,
        chambre_id: chambreId,
        date_entrée: new Date().toISOString(),
        médecin_traitant: admissionForm.médecin_traitant,
        diagnostic_entrée: admissionForm.diagnostic_entrée,
        soins_prescrits: admissionForm.soins_prescrits,
        date_sortie: null
      });

      // Reset new patient state
      setNewPatientMode(false);
      setNewPatientName("");
      setNewPatientTel("");
      setNewPatientInfo("");

      // Mark the selected chamber as occupied
      await db.chambres.update(chambreId, { statut: 'occupe' });

      toast.success('Patient admis avec succès');
      setShowAdmissionModal(false);
      setAdmissionForm({
        patient_id: '',
        chambre_id: '',
        médecin_traitant: '',
        diagnostic_entrée: '',
        soins_prescrits: ''
      });
    } catch (error) {
      console.error(error);
      toast.error("Erreur lors de l'enregistrement de l'admission");
    }
  }

  // Handle Exit Confirmation
  async function handleConfirmExit() {
    if (!selectedHospitalisation) return;
    try {
      const exitDate = new Date().toISOString();

      await db.hospitalisations.update(selectedHospitalisation.id!, {
        date_sortie: exitDate
      });

      // Free up the chamber
      await db.chambres.update(selectedHospitalisation.chambre_id, {
        statut: 'disponible'
      });

      toast.success("Sortie d'hospitalisation confirmée");
      setShowExitModal(false);
      setSelectedHospitalisation(null);
    } catch (error) {
      console.error(error);
      toast.error("Erreur lors de la confirmation de la sortie");
    }
  }

  return (
    <div className="space-y-4">
      {/* Header section */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-lg bg-indigo-500 flex items-center justify-center">
            <Bed className="w-5 h-5 text-white" />
          </div>
          <div>
            <h2 className="text-lg font-semibold">Hospitalisation</h2>
            <p className="text-sm text-slate-500">
              {activeHospitalisations.length} patient{activeHospitalisations.length > 1 ? 's' : ''} hospitalisé{activeHospitalisations.length > 1 ? 's' : ''} | {availableChambres.length} chambre{availableChambres.length > 1 ? 's' : ''} disponible{availableChambres.length > 1 ? 's' : ''}
            </p>
          </div>
        </div>
        {canEdit('hospitalisation') && (
          <Button
            onClick={() => setShowAdmissionModal(true)}
            className="bg-teal-600 hover:bg-teal-700 text-white"
          >
            <Plus className="w-4 h-4 mr-1" /> Nouvelle admission
          </Button>
        )}
      </div>

      {/* Stats Cards Row */}
      <div className="grid grid-cols-4 gap-3">
        <Card>
          <CardContent className="p-4 flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg bg-indigo-100 flex items-center justify-center">
              <Activity className="w-5 h-5 text-indigo-600" />
            </div>
            <div>
              <p className="text-2xl font-bold">{activeHospitalisations.length}</p>
              <p className="text-xs text-slate-500">Hospitalisés</p>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4 flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg bg-emerald-100 flex items-center justify-center">
              <Bed className="w-5 h-5 text-emerald-600" />
            </div>
            <div>
              <p className="text-2xl font-bold">{availableChambres.length}</p>
              <p className="text-xs text-slate-500">Chambres libres</p>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4 flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg bg-amber-100 flex items-center justify-center">
              <History className="w-5 h-5 text-amber-600" />
            </div>
            <div>
              <p className="text-2xl font-bold">
                {activeHospitalisations.length > 0
                  ? Math.max(...activeHospitalisations.map(h => calculateStayDuration(h)))
                  : 0}
              </p>
              <p className="text-xs text-slate-500">Jours max</p>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4 flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg bg-slate-100 flex items-center justify-center">
              <DoorOpen className="w-5 h-5 text-slate-600" />
            </div>
            <div>
              <p className="text-2xl font-bold">{historicHospitalisations.length}</p>
              <p className="text-xs text-slate-500">Sortis ce mois</p>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Tabs list toggle */}
      <div className="flex gap-1 bg-slate-100 p-1 rounded-lg w-fit">
        <button
          onClick={() => setTab('actifs')}
          className={`flex items-center gap-1 px-4 py-2 rounded-md text-sm font-medium transition-colors ${
            tab === 'actifs'
              ? 'bg-white shadow-sm text-slate-900'
              : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          <Activity className="w-4 h-4" /> Hospitalisés ({activeHospitalisations.length})
        </button>
        <button
          onClick={() => setTab('historique')}
          className={`flex items-center gap-1 px-4 py-2 rounded-md text-sm font-medium transition-colors ${
            tab === 'historique'
              ? 'bg-white shadow-sm text-slate-900'
              : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          <History className="w-4 h-4" /> Historique ({historicHospitalisations.length})
        </button>
      </div>

      {/* Active Patients Tab */}
      {tab === 'actifs' && (
        <div className="space-y-4">
          <div className="flex items-center gap-2">
            <Search className="w-4 h-4 text-slate-400" />
            <Input
              placeholder="Rechercher un patient..."
              value={searchQuery}
              onChange={e => setSearchQuery(e.target.value)}
              className="max-w-sm"
            />
          </div>

          {filteredActiveHospitalisations.length === 0 ? (
            <Card>
              <CardContent className="p-8 text-center text-slate-500">
                <Bed className="w-12 h-12 mx-auto mb-3 opacity-30" />
                <p>Aucun patient hospitalisé actuellement</p>
                <Button
                  onClick={() => setShowAdmissionModal(true)}
                  variant="outline"
                  className="mt-3"
                >
                  <Plus className="w-4 h-4 mr-1" /> Admettre un patient
                </Button>
              </CardContent>
            </Card>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              {filteredActiveHospitalisations.map(h => (
                <Card key={h.id} className="border-l-4 border-l-indigo-500">
                  <CardContent className="p-4">
                    <div className="flex items-start justify-between">
                      <div className="space-y-1">
                        <h3 className="font-semibold text-base">{getPatientName(h.patient_id)}</h3>
                        <div className="flex items-center gap-2 text-sm text-slate-500">
                          <Bed className="w-4 h-4" />
                          Chambre <strong>{getChambreNumero(h.chambre_id)}</strong>
                          <Badge variant="outline" className="text-xs">
                            {getChambreType(h.chambre_id)}
                          </Badge>
                        </div>
                        <div className="flex items-center gap-2 text-sm text-slate-500">
                          <Calendar className="w-4 h-4" />
                          Entrée: {new Date(h.date_entrée).toLocaleDateString('fr-FR')}
                          <span className="text-indigo-600 font-medium">
                            ({calculateStayDuration(h)} jour{calculateStayDuration(h) > 1 ? 's' : ''})
                          </span>
                        </div>
                        <div className="flex items-center gap-2 text-sm text-slate-500">
                          <User className="w-4 h-4" />
                          {h.médecin_traitant}
                        </div>
                        {h.diagnostic_entrée && (
                          <p className="text-sm text-slate-600 mt-1">
                            <strong>Diag:</strong> {h.diagnostic_entrée}
                          </p>
                        )}
                      </div>
                      {canEdit('hospitalisation') && (
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() => {
                            setSelectedHospitalisation(h);
                            setShowExitModal(true);
                          }}
                          className="text-red-600 border-red-200 hover:bg-red-50"
                        >
                          <LogOut className="w-4 h-4 mr-1" /> Sortie
                        </Button>
                      )}
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </div>
      )}

      {/* History Tab */}
      {tab === 'historique' && (
        <div className="space-y-4">
          {historicHospitalisations.length === 0 ? (
            <Card>
              <CardContent className="p-8 text-center text-slate-500">
                <History className="w-12 h-12 mx-auto mb-3 opacity-30" />
                <p>Aucun historique d'hospitalisation</p>
              </CardContent>
            </Card>
          ) : (
            <Card>
              <CardContent className="p-0">
                <div className="overflow-x-auto">
                  <table className="w-full text-sm">
                    <thead className="bg-slate-50">
                      <tr>
                        <th className="text-left py-3 px-4 font-semibold">Patient</th>
                        <th className="text-left py-3 px-4 font-semibold">Chambre</th>
                        <th className="text-left py-3 px-4 font-semibold">Entrée</th>
                        <th className="text-left py-3 px-4 font-semibold">Sortie</th>
                        <th className="text-left py-3 px-4 font-semibold">Durée</th>
                        <th className="text-left py-3 px-4 font-semibold">Diagnostic</th>
                        <th className="text-left py-3 px-4 font-semibold">Médecin</th>
                      </tr>
                    </thead>
                    <tbody>
                      {historicHospitalisations.map(h => (
                        <tr key={h.id} className="border-t hover:bg-slate-50">
                          <td className="py-3 px-4 font-medium">{getPatientName(h.patient_id)}</td>
                          <td className="py-3 px-4">{getChambreNumero(h.chambre_id)}</td>
                          <td className="py-3 px-4">{new Date(h.date_entrée).toLocaleDateString('fr-FR')}</td>
                          <td className="py-3 px-4">
                            {h.date_sortie ? new Date(h.date_sortie).toLocaleDateString('fr-FR') : '-'}
                          </td>
                          <td className="py-3 px-4">{calculateStayDuration(h)} jours</td>
                          <td className="py-3 px-4 text-xs">{h.diagnostic_entrée}</td>
                          <td className="py-3 px-4 text-xs">{h.médecin_traitant}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </CardContent>
            </Card>
          )}
        </div>
      )}

      {/* New Admission Modal */}
      {showAdmissionModal && (
        <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4">
          <div className="bg-white dark:bg-slate-800 rounded-lg shadow-xl max-w-lg w-full max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between p-4 border-b border-slate-200 dark:border-slate-700">
              <h3 className="text-lg font-semibold">Nouvelle Admission</h3>
              <button
                onClick={() => setShowAdmissionModal(false)}
                className="p-1 hover:bg-slate-100 rounded"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
            <form onSubmit={handleAdmissionSubmit} className="p-4 space-y-3">
              <div className="border border-slate-200 dark:border-slate-700 p-3 rounded-lg bg-slate-50 dark:bg-slate-900/50 space-y-2">
                <div className="flex items-center justify-between">
                  <Label className="text-sm font-semibold">Patient</Label>
                  <button 
                    type="button" 
                    onClick={() => {
                      setNewPatientMode(!newPatientMode);
                      setAdmissionForm(prev => ({ ...prev, patient_id: "" }));
                    }}
                    className="text-xs text-teal-600 hover:text-teal-800 font-medium"
                  >
                    {newPatientMode ? "📂 Liste des patients" : "➕ Enregistrer un nouveau patient"}
                  </button>
                </div>

                {newPatientMode ? (
                  <div className="space-y-2">
                    <div>
                      <Label className="text-xs text-slate-500">Nom Complet *</Label>
                      <Input 
                        placeholder="Ex: Jean Dupont" 
                        value={newPatientName} 
                        onChange={e => setNewPatientName(e.target.value)} 
                        className="bg-white dark:bg-slate-800 text-xs h-9" 
                        required
                      />
                    </div>
                    <div className="grid grid-cols-2 gap-2 text-xs">
                      <div>
                        <Label className="text-xs text-slate-500">Téléphone</Label>
                        <Input 
                          placeholder="Ex: +223 76..." 
                          value={newPatientTel} 
                          onChange={e => setNewPatientTel(e.target.value)} 
                          className="bg-white dark:bg-slate-800 text-xs h-9" 
                        />
                      </div>
                      <div>
                        <Label className="text-xs text-slate-500">Âge / Sexe / Obs</Label>
                        <Input 
                          placeholder="Ex: 42 ans, M" 
                          value={newPatientInfo} 
                          onChange={e => setNewPatientInfo(e.target.value)} 
                          className="bg-white dark:bg-slate-800 text-xs h-9" 
                        />
                      </div>
                    </div>
                  </div>
                ) : (
                  <select
                    value={admissionForm.patient_id}
                    onChange={e => setAdmissionForm({ ...admissionForm, patient_id: e.target.value })}
                    className="w-full h-10 rounded-md border border-input bg-transparent px-3 py-1 text-sm bg-white dark:bg-slate-800"
                    required
                  >
                    <option value="">Choisir un patient...</option>
                    {patients.map(p => (
                      <option key={p.id} value={String(p.id)}>
                        {p.nom_complet}
                      </option>
                    ))}
                  </select>
                )}
              </div>

              <div className="space-y-1">
                <Label>Chambre disponible</Label>
                <select
                  value={admissionForm.chambre_id}
                  onChange={e => setAdmissionForm({ ...admissionForm, chambre_id: e.target.value })}
                  className="w-full h-10 rounded-md border border-input bg-transparent px-3 py-1 text-sm"
                  required
                >
                  <option value="">
                    {availableChambres.length > 0
                      ? `Choisir une chambre (${availableChambres.length} dispo)`
                      : 'Aucune chambre disponible'}
                  </option>
                  {availableChambres.map(c => (
                    <option key={c.id} value={String(c.id)}>
                      {c.numero} - {c.type} ({c.prix_journalier.toLocaleString()} FCFA/j)
                    </option>
                  ))}
                </select>
              </div>

              <div className="space-y-1">
                <Label>Médecin traitant</Label>
                <Input
                  value={admissionForm.médecin_traitant}
                  onChange={e => setAdmissionForm({ ...admissionForm, médecin_traitant: e.target.value })}
                  placeholder="Dr."
                  required
                />
              </div>

              <div className="space-y-1">
                <Label>Diagnostic d'entrée</Label>
                <Input
                  value={admissionForm.diagnostic_entrée}
                  onChange={e => setAdmissionForm({ ...admissionForm, diagnostic_entrée: e.target.value })}
                  placeholder="Diagnostic principal"
                  required
                />
              </div>

              <div className="space-y-1">
                <Label>Soins prescrits</Label>
                <Input
                  value={admissionForm.soins_prescrits}
                  onChange={e => setAdmissionForm({ ...admissionForm, soins_prescrits: e.target.value })}
                  placeholder="Soins à administrer"
                />
              </div>

              <div className="flex justify-end gap-2 pt-2">
                <Button
                  type="button"
                  variant="outline"
                  onClick={() => setShowAdmissionModal(false)}
                >
                  Annuler
                </Button>
                <Button
                  type="submit"
                  className="bg-teal-600 hover:bg-teal-700 text-white"
                  disabled={availableChambres.length === 0}
                >
                  <Plus className="w-4 h-4 mr-1" /> Admettre
                </Button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Confirm Exit Modal */}
      {showExitModal && selectedHospitalisation && (
        <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4">
          <div className="bg-white dark:bg-slate-800 rounded-lg shadow-xl max-w-md w-full">
            <div className="flex items-center justify-between p-4 border-b border-slate-200 dark:border-slate-700">
              <h3 className="text-lg font-semibold">Sortie d'hospitalisation</h3>
              <button
                onClick={() => setShowExitModal(false)}
                className="p-1 hover:bg-slate-100 rounded"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
            <div className="p-4 space-y-3">
              <p className="text-sm text-slate-600">
                Confirmer la sortie de{' '}
                <strong>{getPatientName(selectedHospitalisation.patient_id)}</strong> de la chambre{' '}
                <strong>{getChambreNumero(selectedHospitalisation.chambre_id)}</strong> ?
              </p>
              <p className="text-sm text-slate-500">
                Durée du séjour : <strong>{calculateStayDuration(selectedHospitalisation)} jour{calculateStayDuration(selectedHospitalisation) > 1 ? 's' : ''}</strong>
              </p>
              <p className="text-sm text-amber-600 font-medium">
                La chambre sera libérée et remise à disposition.
              </p>
              <div className="flex justify-end gap-2 pt-2">
                <Button
                  type="button"
                  variant="outline"
                  onClick={() => setShowExitModal(false)}
                >
                  Annuler
                </Button>
                <Button
                  onClick={handleConfirmExit}
                  className="bg-red-600 hover:bg-red-700 text-white"
                >
                  <LogOut className="w-4 h-4 mr-1" /> Confirmer la sortie
                </Button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}