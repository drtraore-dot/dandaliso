import React, { useState, useEffect } from 'react';
import { db } from '@/db';
import { 
  Users, 
  Briefcase, 
  Search, 
  Plus, 
  X, 
  CheckCircle, 
  AlertCircle, 
  Calendar, 
  User, 
  CreditCard 
} from 'lucide-react';
import { toast } from 'sonner'; // Assuming a standard toast library
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';

interface Prestataire {
  id?: number;
  nom: string;
  prenom: string;
  type_prestataire: string;
  specialite: string;
  telephone: string;
  email: string;
}

interface Remuneration {
  id?: number;
  prestataire_id: number;
  prestation_id: number;
  montant_remuneration: number;
  statut_paiement: 'paye' | 'en_attente';
  mode_paiement?: string;
  date_paiement?: Date;
  mois: string;
}

export default function Prestataires() {
  const [activeTab, setActiveTab] = useState<'prestataires' | 'remunerations'>('prestataires');
  const [prestataires, setPrestataires] = useState<Prestataire[]>([]);
  const [remunerations, setRemunerations] = useState<Remuneration[]>([]);
  const [prestations, setPrestations] = useState<any[]>([]); // Simplified types for context
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');
  const [monthFilter, setMonthFilter] = useState('');
  const [showAddModal, setShowAddModal] = useState(false);
  const [showPaymentModal, setShowPaymentModal] = useState(false);
  const [selectedRemuneration, setSelectedRemuneration] = useState<Remuneration | null>(null);
  
  const [newPrestataire, setNewPrestataire] = useState({ nom: '', prenom: '', type_prestataire: 'médecin', specialite: '', telephone: '', email: '' });
  const [paymentDetails, setPaymentDetails] = useState({ mode_paiement: 'virement', reference: '' });

  useEffect(() => {
    loadData();
  }, []);

  async function loadData() {
    const [p, r, pr] = await Promise.all([
      db.prestataires.toArray(),
      db.remunerations.toArray(),
      db.prestations.toArray()
    ]);
    setPrestataires(p);
    setRemunerations(r);
    setPrestations(pr);
  }

  async function handleConfirmPayment() {
    if (!selectedRemuneration) return;
    
    await db.remunerations.update(selectedRemuneration.id!, {
      statut_paiement: 'paye',
      mode_paiement: paymentDetails.mode_paiement,
      date_paiement: new Date()
    });

    let category = await db.categoriesDepense.where("nom").equalsIgnoreCase("Partenaires & Rémunérations").first();
    let categoryId: number | undefined;
    if (!category) {
      try {
        categoryId = await db.categoriesDepense.add({
          nom: "Partenaires & Rémunérations",
          icon: "Users2",
          created_at: new Date()
        });
      } catch (err) {
        console.error(err);
      }
    } else {
      categoryId = category.id;
    }

    const provider = prestataires.find(p => p.id === selectedRemuneration.prestataire_id);
    const fullName = provider ? `${provider.prenom} ${provider.nom}` : "Inconnu";

    await db.depenses.add({
      date: new Date(),
      type_depense: `Remuneration - ${fullName}`,
      montant: selectedRemuneration.montant_remuneration,
      fournisseur: fullName,
      description: `Paiement remuneration | ${paymentDetails.mode_paiement} | Ref: ${paymentDetails.reference}`,
      categorie_id: categoryId,
      created_at: new Date()
    });

    toast.success("Rémunération payée avec succès");
    setShowPaymentModal(false);
    loadData();
  }

  async function handleAddPrestataire(e: React.FormEvent) {
    e.preventDefault();
    if (!newPrestataire.nom.trim() || !newPrestataire.prenom.trim()) {
      toast.error("Veuillez saisir le prénom et le nom");
      return;
    }
    
    try {
      await db.prestataires.add({
        nom: newPrestataire.nom.trim(),
        prenom: newPrestataire.prenom.trim(),
        type_prestataire: newPrestataire.type_prestataire,
        specialite: newPrestataire.specialite.trim(),
        telephone: newPrestataire.telephone.trim(),
        email: newPrestataire.email.trim(),
        statut: "actif",
        created_at: new Date()
      });
      toast.success("Nouveau prestataire enregistré !");
      setShowAddModal(false);
      
      // Reset form
      setNewPrestataire({ 
        nom: '', 
        prenom: '', 
        type_prestataire: 'médecin', 
        specialite: '', 
        telephone: '', 
        email: '' 
      });
      loadData();
    } catch (err) {
      toast.error("Erreur d'enregistrement");
    }
  }

  const filteredPrestataires = prestataires.filter(p => 
    !searchTerm || `${p.prenom} ${p.nom}`.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const filteredRemunerations = remunerations.filter(r => 
    !(statusFilter !== "all" && r.statut_paiement !== statusFilter) &&
    (!monthFilter || r.mois === monthFilter)
  );

  const getPrestataireName = (id: number) => prestataires.find(p => p.id === id)?.prenom + " " + prestataires.find(p => p.id === id)?.nom || "N/A";
  const getPrestationName = (id: number) => prestations.find(p => p.id === id)?.nom || "N/A";

  const totalPaid = filteredRemunerations.filter(r => r.statut_paiement === 'paye').reduce((acc, curr) => acc + curr.montant_remuneration, 0);
  const totalPending = filteredRemunerations.filter(r => r.statut_paiement === 'en_attente').reduce((acc, curr) => acc + curr.montant_remuneration, 0);

  return (
    <div className="space-y-4">
      <div className="flex items-center gap-3">
        <div className="w-10 h-10 rounded-lg bg-violet-500 flex items-center justify-center">
          <Briefcase className="w-5 h-5 text-white" />
        </div>
        <div>
          <h2 className="text-lg font-semibold">Prestataires & Rémunérations</h2>
        </div>
      </div>

      <div className="flex gap-1 bg-slate-100 p-1 rounded-lg w-fit">
        <Button variant={activeTab === 'prestataires' ? 'secondary' : 'ghost'} onClick={() => setActiveTab('prestataires')} size="sm">
          <Users className="w-4 h-4 mr-2" /> Prestataires
        </Button>
        <Button variant={activeTab === 'remunerations' ? 'secondary' : 'ghost'} onClick={() => setActiveTab('remunerations')} size="sm">
          <CreditCard className="w-4 h-4 mr-2" /> Rémunérations
        </Button>
      </div>

      {activeTab === 'prestataires' && (
        <div className="space-y-4">
          <div className="flex justify-between">
            <div className="relative flex-1 max-w-sm">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
              <Input placeholder="Rechercher..." value={searchTerm} onChange={(e) => setSearchTerm(e.target.value)} className="pl-10" />
            </div>
            <Button onClick={() => setShowAddModal(true)} className="bg-teal-600 hover:bg-teal-700">
              <Plus className="w-4 h-4 mr-1" /> Nouveau
            </Button>
          </div>
          <Card className="p-0">
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead className="bg-slate-50">
                  <tr>
                    <th className="text-left py-3 px-4 font-semibold">Nom</th>
                    <th className="text-left py-3 px-4 font-semibold">Type</th>
                    <th className="text-left py-3 px-4 font-semibold">Spécialité</th>
                    <th className="text-left py-3 px-4 font-semibold">Contact</th>
                  </tr>
                </thead>
                <tbody>
                  {filteredPrestataires.map(p => (
                    <tr key={p.id} className="border-t hover:bg-slate-50">
                      <td className="py-3 px-4 font-medium">{p.prenom} {p.nom}</td>
                      <td className="py-3 px-4"><Badge className="bg-violet-100 text-violet-700">{p.type_prestataire}</Badge></td>
                      <td className="py-3 px-4 text-xs">{p.specialite}</td>
                      <td className="py-3 px-4 text-xs text-slate-500">{p.telephone}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </Card>
        </div>
      )}

      {activeTab === 'remunerations' && (
        <div className="space-y-4">
          <div className="grid grid-cols-3 gap-3">
            <Card className="p-4"><p className="text-xs text-slate-500">Total</p><p className="text-lg font-bold">{filteredRemunerations.length}</p></Card>
            <Card className="p-4"><p className="text-xs text-slate-500">À payer</p><p className="text-lg font-bold text-red-600">{totalPending.toLocaleString()} FCFA</p></Card>
            <Card className="p-4"><p className="text-xs text-slate-500">Payé</p><p className="text-lg font-bold text-emerald-600">{totalPaid.toLocaleString()} FCFA</p></Card>
          </div>
          
          <div className="flex gap-2">
            <select value={statusFilter} onChange={(e) => setStatusFilter(e.target.value)} className="h-10 px-3 rounded-md border border-input bg-background text-sm">
              <option value="all">Tous</option>
              <option value="en_attente">Impayé</option>
              <option value="paye">Payé</option>
            </select>
            <div className="flex items-center gap-2">
              <Calendar className="w-4 h-4 text-slate-400" />
              <Input type="month" value={monthFilter} onChange={(e) => setMonthFilter(e.target.value)} className="w-40" />
            </div>
          </div>

          <Card className="p-0">
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead className="bg-slate-50">
                  <tr>
                    <th className="text-left py-3 px-4 font-semibold">Mois</th>
                    <th className="text-left py-3 px-4 font-semibold">Prestataire</th>
                    <th className="text-left py-3 px-4 font-semibold">Acte</th>
                    <th className="text-left py-3 px-4 font-semibold">Montant</th>
                    <th className="text-left py-3 px-4 font-semibold">Statut</th>
                    <th className="text-center py-3 px-4 font-semibold">Action</th>
                  </tr>
                </thead>
                <tbody>
                  {filteredRemunerations.map(r => (
                    <tr key={r.id} className={`border-t ${r.statut_paiement === 'en_attente' ? 'bg-red-50/50' : ''}`}>
                      <td className="py-3 px-4 text-xs">{r.mois}</td>
                      <td className="py-3 px-4 font-medium text-xs">{getPrestataireName(r.prestataire_id)}</td>
                      <td className="py-3 px-4 text-xs">{getPrestationName(r.prestation_id)}</td>
                      <td className="py-3 px-4 font-semibold">{r.montant_remuneration.toLocaleString()} FCFA</td>
                      <td className="py-3 px-4">
                        {r.statut_paiement === 'paye' ? 
                          <Badge className="bg-emerald-100 text-emerald-700"><CheckCircle className="w-3 h-3 mr-1" /> Payé</Badge> : 
                          <Badge variant="outline" className="border-red-300 text-red-600"><AlertCircle className="w-3 h-3 mr-1" /> Impayé</Badge>
                        }
                      </td>
                      <td className="py-3 px-4 text-center">
                        {r.statut_paiement === 'en_attente' && (
                          <Button size="sm" variant="outline" className="text-emerald-600 border-emerald-300" onClick={() => { setSelectedRemuneration(r); setShowPaymentModal(true); }}>
                            <CheckCircle className="w-3 h-3 mr-1" /> Payer
                          </Button>
                        )}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </Card>
        </div>
      )}

      {showPaymentModal && selectedRemuneration && (
        <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4">
          <Card className="max-w-md w-full">
            <div className="flex items-center justify-between p-4 border-b">
              <h3 className="text-lg font-semibold">Payer la Rémunération</h3>
              <Button variant="ghost" size="icon" onClick={() => setShowPaymentModal(false)}><X className="w-5 h-5" /></Button>
            </div>
            <div className="p-4 space-y-4">
              <div className="p-3 bg-violet-50 border border-violet-200 rounded-lg text-sm">
                <p><strong>Prestataire:</strong> {getPrestataireName(selectedRemuneration.prestataire_id)}</p>
                <p><strong>Montant:</strong> {selectedRemuneration.montant_remuneration.toLocaleString()} FCFA</p>
              </div>
              <div className="space-y-2">
                <Label>Mode de paiement</Label>
                <select value={paymentDetails.mode_paiement} onChange={(e) => setPaymentDetails({...paymentDetails, mode_paiement: e.target.value})} className="w-full h-10 rounded-md border px-3">
                  <option value="virement">Virement</option>
                  <option value="especes">Espèces</option>
                  <option value="cheque">Chèque</option>
                  <option value="mobile_money">Mobile Money</option>
                </select>
              </div>
              <div className="space-y-2">
                <Label>Référence</Label>
                <Input value={paymentDetails.reference} onChange={(e) => setPaymentDetails({...paymentDetails, reference: e.target.value})} />
              </div>
              <div className="flex justify-end gap-2">
                <Button variant="outline" onClick={() => setShowPaymentModal(false)}>Annuler</Button>
                <Button className="bg-emerald-600 hover:bg-emerald-700" onClick={handleConfirmPayment}>Confirmer</Button>
              </div>
            </div>
          </Card>
        </div>
      )}

      {showAddModal && (
        <div className="fixed inset-0 bg-black/60 z-50 flex items-center justify-center p-4 backdrop-blur-xs">
          <Card className="max-w-md w-full bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 shadow-2xl text-slate-900 dark:text-slate-100">
            <div className="flex items-center justify-between p-4 border-b border-slate-100 dark:border-slate-700">
              <h3 className="text-base font-bold text-slate-900 dark:text-white">Nouveau Prestataire</h3>
              <Button variant="ghost" size="icon" onClick={() => setShowAddModal(false)} className="text-slate-500 dark:text-slate-400">
                <X className="w-5 h-5" />
              </Button>
            </div>
            
            <form onSubmit={handleAddPrestataire} className="p-4 space-y-3">
              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1">
                  <Label className="text-slate-700 dark:text-slate-300">Prénom *</Label>
                  <Input 
                    value={newPrestataire.prenom} 
                    onChange={e => setNewPrestataire({...newPrestataire, prenom: e.target.value})} 
                    required 
                    placeholder="Ex: Amadou"
                    className="h-9 text-xs bg-white dark:bg-slate-900 text-slate-900 dark:text-slate-100 border-slate-200 dark:border-slate-700"
                  />
                </div>
                <div className="space-y-1">
                  <Label className="text-slate-700 dark:text-slate-300">Nom *</Label>
                  <Input 
                    value={newPrestataire.nom} 
                    onChange={e => setNewPrestataire({...newPrestataire, nom: e.target.value})} 
                    required 
                    placeholder="Ex: Keita"
                    className="h-9 text-xs bg-white dark:bg-slate-900 text-slate-900 dark:text-slate-100 border-slate-200 dark:border-slate-700"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1">
                  <Label className="text-slate-700 dark:text-slate-300">Type prestataire</Label>
                  <select 
                    value={newPrestataire.type_prestataire} 
                    onChange={e => setNewPrestataire({...newPrestataire, type_prestataire: e.target.value})} 
                    className="w-full h-9 rounded-md border border-slate-200 dark:border-slate-700 text-xs bg-white dark:bg-slate-900 text-slate-900 dark:text-slate-100 px-2"
                  >
                    <option value="médecin">Médecin</option>
                    <option value="infirmier">Infirmier / Sage-femme</option>
                    <option value="pharmacien">Pharmacien</option>
                    <option value="technicien">Technicien Laboratoire</option>
                    <option value="administration">Administration</option>
                    <option value="autre">Autre</option>
                  </select>
                </div>
                <div className="space-y-1">
                  <Label className="text-slate-700 dark:text-slate-300">Spécialité</Label>
                  <Input 
                    placeholder="Ex: Pédiatrie..." 
                    value={newPrestataire.specialite} 
                    onChange={e => setNewPrestataire({...newPrestataire, specialite: e.target.value})} 
                    className="h-9 text-xs bg-white dark:bg-slate-900 text-slate-900 dark:text-slate-100 border-slate-200 dark:border-slate-700"
                  />
                </div>
              </div>

              <div className="space-y-1">
                <Label className="text-slate-700 dark:text-slate-300">Téléphone</Label>
                <Input 
                  placeholder="Ex: 76123456" 
                  value={newPrestataire.telephone} 
                  onChange={e => setNewPrestataire({...newPrestataire, telephone: e.target.value})} 
                  className="h-9 text-xs bg-white dark:bg-slate-900 text-slate-900 dark:text-slate-100 border-slate-200 dark:border-slate-700"
                />
              </div>

              <div className="space-y-1">
                <Label className="text-slate-700 dark:text-slate-300">Email</Label>
                <Input 
                  type="email" 
                  placeholder="Ex: contact@djakan.com" 
                  value={newPrestataire.email} 
                  onChange={e => setNewPrestataire({...newPrestataire, email: e.target.value})} 
                  className="h-9 text-xs bg-white dark:bg-slate-900 text-slate-900 dark:text-slate-100 border-slate-200 dark:border-slate-700"
                />
              </div>

              <div className="flex justify-end gap-2 pt-3 border-t border-slate-100 dark:border-slate-700">
                <Button type="button" variant="outline" size="sm" onClick={() => setShowAddModal(false)} className="text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-700">Annuler</Button>
                <Button type="submit" size="sm" className="bg-teal-600 hover:bg-teal-700 text-white font-semibold">Enregistrer</Button>
              </div>
            </form>
          </Card>
        </div>
      )}
    </div>
  );
}