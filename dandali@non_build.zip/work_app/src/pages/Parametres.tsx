import React, { useState, useEffect } from 'react';
import { db } from '@/db';
import { 
  Settings, 
  Upload, 
  Download, 
  Save, 
  Building2, 
  Palette, 
  Database, 
  FileUp,
  AlertTriangle,
  RotateCcw,
  Printer,
  Image as ImageIcon
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { Card, CardContent } from '@/components/ui/card';
import { toast } from 'sonner';

interface ParametresType {
  nom_clinique: string;
  type_structure: string;
  telephone: string;
  email: string;
  devise: string;
  adresse: string;
  couleur_primaire: string;
  couleur_secondaire: string;
  mode_sombre: boolean;
  alerte_stock_min: number;
  alerte_expiration_jours: number;
  frequence_sauvegarde: number;
  sauvegarde_auto: boolean;
  impression_entete: string;
  impression_pied_page: string;
  logo_data_url?: string;
  medecin_responsable?: string;
}

export default function Parametres() {
  const [loading, setLoading] = useState(false);
  const [activeTab, setActiveTab] = useState<'structure' | 'apparence' | 'impressions' | 'donnees'>('structure');
  const [config, setConfig] = useState<ParametresType>({
    nom_clinique: 'Maternité Djakan',
    type_structure: 'Clinique Privée',
    telephone: '+223 76 54 32 10',
    email: 'contact@djakan.com',
    devise: 'FCFA',
    adresse: 'Faladié ISEC, Bamako, Mali',
    couleur_primaire: '#0d9488',
    couleur_secondaire: '#06b6d4',
    mode_sombre: false,
    alerte_stock_min: 5,
    alerte_expiration_jours: 30,
    frequence_sauvegarde: 7,
    sauvegarde_auto: true,
    impression_entete: '',
    impression_pied_page: '',
    logo_data_url: '',
    medecin_responsable: '',
  });

  useEffect(() => {
    async function loadConfig() {
      setLoading(true);
      try {
        const saved = await db.parametres.toArray();
        if (saved && saved.length > 0) {
          setConfig({
            ...config,
            ...saved[0]
          });
        } else {
          await db.parametres.add(config);
        }
      } catch (err) {
        console.error("Erreur d'initialisation des paramètres", err);
      } finally {
        setLoading(false);
      }
    }
    loadConfig();
  }, []);

  const handleSaveConfig = async () => {
    try {
      await db.parametres.clear();
      await db.parametres.add(config);
      toast.success("Paramètres enregistrés avec succès !");
    } catch (err) {
      toast.error("Échec d'enregistrement des paramètres");
    }
  };


  const handleLogoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    if (!file.type.startsWith('image/')) {
      toast.error('Veuillez choisir une image pour le logo');
      return;
    }
    const reader = new FileReader();
    reader.onload = () => updateConfig('logo_data_url', String(reader.result || ''));
    reader.readAsDataURL(file);
  };

  const removeLogo = () => updateConfig('logo_data_url', '');

  const handleFileImport = async () => {
    const input = document.createElement("input");
    input.type = "file";
    input.accept = ".json";
    input.onchange = async (e: any) => {
      const file = e.target.files?.[0];
      if (file && window.confirm("ATTENTION : Cela va remplacer TOUTES les données actuelles de la clinique par celles du fichier. Continuer ?")) {
        try {
          toast.info("Importation en cours...");
          const text = await file.text();
          const parsed = JSON.parse(text);
          const data = parsed.data || parsed;

          for (const [tableName, records] of Object.entries(data)) {
            if (tableName === "parametres" || tableName === "version" || tableName === "export_date") continue;
            const table = db.table(tableName);
            if (table && Array.isArray(records)) {
              await table.clear();
              if (records.length > 0) await table.bulkAdd(records);
            }
          }

          if (parsed.parametres) {
            setConfig(parsed.parametres);
            await db.parametres.clear();
            await db.parametres.put(parsed.parametres);
          }
          
          toast.success("Toutes les données clínicas ont été importées. Redémarrage...");
          setTimeout(() => window.location.reload(), 1500);
        } catch (err) {
          toast.error("Erreur lors de l'import : format JSON non valide ou endommagé");
        }
      }
    };
    input.click();
  };

  const handleExportBackup = async () => {
    try {
      const [
        p, c, o, h, d, m, pr, r, re, cr, ph, u, cat, catD
      ] = await Promise.all([
        db.patients.toArray(),
        db.consultations.toArray(),
        db.ordonnances.toArray(),
        db.hospitalisations.toArray(),
        db.depenses.toArray(),
        db.medicaments.toArray(),
        db.prestataires.toArray(),
        db.references.toArray(),
        db.recettes.toArray(),
        db.creditsPatients.toArray(),
        db.patients_hospitalisation.toArray(),
        db.utilisateurs.toArray(),
        db.categories.toArray(),
        db.categoriesDepense.toArray()
      ]);

      const fullBackup = {
        version: 1,
        source: "Djakan Clinique",
        export_date: new Date().toISOString(),
        parametres: config,
        data: {
          patients: p,
          consultations: c,
          ordonnances: o,
          hospitalisations: h,
          depenses: d,
          medicaments: m,
          prestataires: pr,
          references: r,
          recettes: re,
          creditsPatients: cr,
          patients_hospitalisation: ph,
          utilisateurs: u,
          categories: cat,
          categoriesDepense: catD
        }
      };

      const blob = new Blob([JSON.stringify(fullBackup, null, 2)], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.download = `sauvegarde_djakan_clinique_${new Date().toISOString().split('T')[0]}.json`;
      link.click();
      toast.success("Exportation de la base de données réussie !");
    } catch (err) {
      toast.error("Échec de la génération de sauvegarde");
    }
  };

  const handleResetDatabase = async () => {
    if (window.confirm("Êtes-vous certain de vouloir RÉINITIALISER toute la clinique ? Toutes les recettes, ordonnances, dossiers patients, consultations et hospitalisations seront DEFINATIVEMENT supprimées.")) {
      if (window.confirm("CONFIRMATION FINALE : Tapez 'OK' pour valider la suppression définitive.")) {
        try {
          const tables = [
            'patients', 'consultations', 'ordonnances', 'hospitalisations', 
            'depenses', 'medicaments', 'prestataires', 'references', 
            'recettes', 'creditsPatients', 'patients_hospitalisation',
            'categories', 'categoriesDepense'
          ];
          for (const t of tables) {
            await db.table(t).clear();
          }
          toast.success("La base de données clinique a été réinitialisée.");
          setTimeout(() => window.location.reload(), 1500);
        } catch (err) {
          toast.error("Erreur lors de la réinitialisation");
        }
      }
    }
  };

  const updateConfig = (key: keyof ParametresType, value: any) => {
    setConfig(prev => ({ ...prev, [key]: value }));
  };

  if (loading) return <div className="flex items-center justify-center h-screen text-slate-500">Chargement...</div>;

  return (
    <div className="space-y-4 max-w-4xl">
      <div className="flex items-center justify-between flex-wrap gap-2">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-lg bg-slate-600 flex items-center justify-center">
            <Settings className="w-5 h-5 text-white" />
          </div>
          <div>
            <h2 className="text-lg font-bold text-slate-850">Paramètres Généraux</h2>
            <p className="text-xs text-slate-500">Configuration clinique et stockage de sécurité</p>
          </div>
        </div>
        <div className="flex gap-2 flex-wrap">
          <Button variant="outline" size="sm" onClick={handleFileImport}>
            <Upload className="w-4 h-4 mr-1" /> Importer config
          </Button>
          <Button variant="outline" size="sm" onClick={handleExportBackup}>
            <Download className="w-4 h-4 mr-1" /> Exporter config
          </Button>
          <Button onClick={handleSaveConfig} className="bg-teal-600 hover:bg-teal-700 font-semibold text-white">
            <Save className="w-4 h-4 mr-1" /> Sauvegarder
          </Button>
        </div>
      </div>

      <div className="flex gap-1 bg-slate-100 p-1 rounded-lg w-fit">
        {(['structure', 'apparence', 'impressions', 'donnees'] as const).map((tab) => (
          <button
            key={tab}
            type="button"
            onClick={() => setActiveTab(tab)}
            className={`flex items-center gap-1.5 px-4 py-2 rounded-md text-sm font-semibold transition-colors ${activeTab === tab ? "bg-white shadow-sm text-slate-950" : "text-slate-600 hover:text-slate-900"}`}
          >
            {tab === 'structure' && <Building2 className="w-4 h-4" />}
            {tab === 'apparence' && <Palette className="w-4 h-4" />}
            {tab === 'impressions' && <Printer className="w-4 h-4" />}
            {tab === 'donnees' && <Database className="w-4 h-4" />}
            {tab === 'structure' ? 'Structure Clinique' : tab === 'apparence' ? 'Apparence & Alertes' : tab === 'impressions' ? 'Impressions' : 'Gestion des Données'}
          </button>
        ))}
      </div>

      <Card>
        <CardContent className="p-5">
          {activeTab === 'structure' && (
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="space-y-1">
                <Label>Nom de la clinique</Label>
                <Input value={config.nom_clinique} onChange={(e) => updateConfig('nom_clinique', e.target.value)} />
              </div>
              <div className="space-y-1">
                <Label>Type de structure</Label>
                <Input value={config.type_structure} onChange={(e) => updateConfig('type_structure', e.target.value)} placeholder="Clinique, Hôpital, Centre de santé..." />
              </div>
              <div className="space-y-1">
                <Label>Téléphone de contact</Label>
                <Input value={config.telephone} onChange={(e) => updateConfig('telephone', e.target.value)} />
              </div>
              <div className="space-y-1">
                <Label>Email</Label>
                <Input type="email" value={config.email} onChange={(e) => updateConfig('email', e.target.value)} />
              </div>
              <div className="space-y-1">
                <Label>Devise monétaire</Label>
                <Input value={config.devise} onChange={(e) => updateConfig('devise', e.target.value)} />
              </div>
              <div className="space-y-1 col-span-full">
                <Label>Adresse complète</Label>
                <Textarea value={config.adresse} onChange={(e) => updateConfig('adresse', e.target.value)} rows={3} />
              </div>
            </div>
          )}

          {activeTab === 'apparence' && (
            <div className="space-y-5">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="space-y-1">
                  <Label>Seuil Alerte Stock Minimum (Unités)</Label>
                  <Input 
                    type="number" 
                    value={config.alerte_stock_min} 
                    onChange={(e) => updateConfig('alerte_stock_min', Number(e.target.value))} 
                  />
                  <p className="text-[11px] text-slate-400">Le stock d'un produit s'affiche en rouge en dessous de ce seuil</p>
                </div>
                <div className="space-y-1">
                  <Label>Seuil Alerte Expiration Médicament (Jours)</Label>
                  <Input 
                    type="number" 
                    value={config.alerte_expiration_jours} 
                    onChange={(e) => updateConfig('alerte_expiration_jours', Number(e.target.value))} 
                  />
                  <p className="text-[11px] text-slate-400">Alerter avant la date de péremption du lot</p>
                </div>
              </div>

              <div className="border-t pt-4">
                <h4 className="text-sm font-bold text-slate-800 mb-3 flex items-center gap-1.5">
                  <Palette className="w-4 h-4 text-teal-600" /> Palette de couleurs
                </h4>
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-1.5">
                    <Label>Couleur Primaire</Label>
                    <div className="flex gap-2">
                      <Input type="color" value={config.couleur_primaire} onChange={e => updateConfig('couleur_primaire', e.target.value)} className="w-12 h-9 p-1 cursor-pointer" />
                      <Input type="text" value={config.couleur_primaire} onChange={e => updateConfig('couleur_primaire', e.target.value)} className="font-mono" />
                    </div>
                  </div>
                  <div className="space-y-1.5">
                    <Label>Couleur Secondaire (Accents)</Label>
                    <div className="flex gap-2">
                      <Input type="color" value={config.couleur_secondaire} onChange={e => updateConfig('couleur_secondaire', e.target.value)} className="w-12 h-9 p-1 cursor-pointer" />
                      <Input type="text" value={config.couleur_secondaire} onChange={e => updateConfig('couleur_secondaire', e.target.value)} className="font-mono" />
                    </div>
                  </div>
                </div>
              </div>
            </div>
          )}


          {activeTab === 'impressions' && (
            <div className="space-y-5">
              <div className="p-4 rounded-lg bg-teal-50 border border-teal-200 text-sm">
                <h4 className="font-bold text-teal-800 flex items-center gap-1.5 mb-1">
                  <Printer className="w-4 h-4" /> Personnalisation commune des impressions
                </h4>
                <p className="text-xs text-teal-700">
                  Ces textes seront repris dans les tickets de caisse, résultats de laboratoire, ordonnances et dossiers médicaux imprimables.
                </p>
              </div>
              <div className="space-y-2 rounded-lg border bg-white p-4">
                <Label className="flex items-center gap-2"><ImageIcon className="w-4 h-4 text-teal-600" /> Logo sur toutes les impressions</Label>
                <Input type="file" accept="image/*" onChange={handleLogoUpload} />
                <p className="text-[11px] text-slate-500">Le logo sera intégré automatiquement aux tickets de caisse, ordonnances, résultats de laboratoire et dossiers médicaux.</p>
                {config.logo_data_url && (
                  <div className="flex items-center gap-3 pt-2">
                    <img src={config.logo_data_url} alt="Logo des impressions" className="h-16 w-16 rounded border object-contain bg-white" />
                    <Button type="button" variant="outline" size="sm" onClick={removeLogo} className="text-red-600 border-red-200 hover:bg-red-50">Supprimer le logo</Button>
                  </div>
                )}
              </div>
              <div className="space-y-1.5">
                <Label>Médecin traitant responsable</Label>
                <Input
                  value={config.medecin_responsable || ''}
                  onChange={(e) => updateConfig('medecin_responsable', e.target.value)}
                  placeholder="Exemple : Dr TRAORÉ Aliou"
                />
                <p className="text-[11px] text-slate-500">Ce nom sera utilisé automatiquement sur le dossier médical imprimé.</p>
              </div>
              <div className="space-y-1.5">
                <Label>Texte personnalisé de l'en-tête</Label>
                <Textarea
                  value={config.impression_entete}
                  onChange={(e) => updateConfig('impression_entete', e.target.value)}
                  rows={5}
                  placeholder="Exemple : Autorisation, slogan, horaires, service, mentions administratives..."
                />
              </div>
              <div className="space-y-1.5">
                <Label>Texte personnalisé du pied de page</Label>
                <Textarea
                  value={config.impression_pied_page}
                  onChange={(e) => updateConfig('impression_pied_page', e.target.value)}
                  rows={5}
                  placeholder="Exemple : Merci pour votre confiance - Urgences 24h/24 - Signature/cachet..."
                />
              </div>
              <div className="rounded border bg-white p-4 text-xs text-slate-600">
                <div className="font-bold text-slate-800 mb-2">Aperçu simplifié</div>
                <div className="border-b pb-2 mb-2 flex items-start gap-3">
                  {config.logo_data_url && <img src={config.logo_data_url} alt="Logo" className="h-12 w-12 object-contain rounded border bg-white" />}
                  <div className="flex-1">
                  <div className="font-extrabold uppercase text-teal-700">{config.nom_clinique}</div>
                  <div>{config.type_structure}</div>
                  <div>{config.adresse} {config.telephone ? `- Tél: ${config.telephone}` : ''}</div>
                  {config.impression_entete && <div className="mt-2 whitespace-pre-wrap text-slate-800">{config.impression_entete}</div>}
                  </div>
                </div>
                <div className="pt-2 border-t text-center whitespace-pre-wrap">
                  {config.impression_pied_page || config.nom_clinique}
                </div>
              </div>
            </div>
          )}

          {activeTab === 'donnees' && (
            <div className="space-y-6">
              <div className="p-4 rounded-lg bg-amber-50 border border-amber-200 text-sm space-y-2">
                <h4 className="font-bold text-amber-800 flex items-center gap-1.5">
                  <AlertTriangle className="w-4 h-4" /> Zone de Sécurité des Données
                </h4>
                <p className="text-amber-700 text-xs leading-relaxed">
                  Toutes vos données cliniques sont stockées localement dans votre navigateur (IndexedDB). 
                  Il est fortement recommandé d'effectuer régulièrement des exports de configurations et de sauvegardes pour éviter toute perte de données accidentelle.
                </p>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <Card className="border-slate-200">
                  <CardContent className="p-4 space-y-2">
                    <h5 className="font-semibold text-sm text-slate-800 flex items-center gap-1">
                      <Download className="w-4 h-4 text-teal-600" /> Exporter les données
                    </h5>
                    <p className="text-xs text-slate-500">
                      Générez un fichier de sauvegarde (.json) contenant l'ensemble de votre base de données locale.
                    </p>
                    <Button onClick={handleExportBackup} size="sm" className="bg-teal-600 hover:bg-teal-700 text-white mt-1">
                      Télécharger la sauvegarde
                    </Button>
                  </CardContent>
                </Card>

                <Card className="border-slate-200">
                  <CardContent className="p-4 space-y-2">
                    <h5 className="font-semibold text-sm text-slate-800 flex items-center gap-1">
                      <Upload className="w-4 h-4 text-emerald-600" /> Importer des données
                    </h5>
                    <p className="text-xs text-slate-500">
                      Restaurer une sauvegarde antérieure à partir d'un fichier .json. Vos données courantes seront écrasées.
                    </p>
                    <Button onClick={handleFileImport} size="sm" variant="outline" className="border-emerald-600 text-emerald-600 hover:bg-emerald-50 mt-1">
                      Sélectionner et importer
                    </Button>
                  </CardContent>
                </Card>
              </div>

              <div className="border-t pt-4">
                <div className="flex items-center justify-between p-4 rounded-lg bg-red-50 border border-red-200">
                  <div className="space-y-1">
                    <h5 className="font-bold text-sm text-red-800 flex items-center gap-1.5">
                      <RotateCcw className="w-4 h-4" /> Réinitialisation totale de la clinique
                    </h5>
                    <p className="text-xs text-red-600">
                      Cette action supprimera irréversiblement toutes les fiches, recettes cliniques, et consultations.
                    </p>
                  </div>
                  <Button onClick={handleResetDatabase} size="sm" variant="destructive" className="bg-red-600 hover:bg-red-700 font-semibold text-white">
                    Réinitialiser
                  </Button>
                </div>
              </div>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
