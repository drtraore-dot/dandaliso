import React, { useState, useEffect } from 'react';
import { db } from '@/db';
import { 
  Pill, 
  Plus, 
  Search, 
  Pencil, 
  Trash2, 
  X, 
  AlertCircle,
  ShoppingCart,
  History,
  Check,
  User,
  Barcode,
  CalendarDays,
  FileSpreadsheet,
  BadgeDollarSign
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { useAuth } from '@/hooks/useAuth';
import { toast } from 'sonner';

interface Medicament {
  id?: number;
  nom_medicament: string;
  categorie: string;
  forme: string;
  dosage: string;
  quantite: number;
  quantite_min: number;
  prix_unitaire: number;
  fournisseur: string;
  date_expiration: string;
}

interface CartItem {
  id: number;
  nom_medicament: string;
  dosage: string;
  prix_unitaire: number;
  quantite_stock: number;
  quantite_vente: number;
}

export default function Pharmacie() {
  const { canEdit } = useAuth();
  
  // Tabs: "stock" | "vente" | "historique"
  const [activeTab, setActiveTab] = useState<"stock" | "vente" | "historique">("stock");

  // Medicaments & Categories State
  const [medicaments, setMedicaments] = useState<Medicament[]>([]);
  const [categories, setCategories] = useState<any[]>([]);
  const [patients, setPatients] = useState<any[]>([]);
  
  const [isCategoryModalOpen, setIsCategoryModalOpen] = useState(false);
  const [newCategoryName, setNewCategoryName] = useState("");
  const [searchTerm, setSearchTerm] = useState("");
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingId, setEditingId] = useState<number | null>(null);
  
  // Stock edit formData
  const [formData, setFormData] = useState<Medicament>({
    nom_medicament: "",
    categorie: "",
    forme: "",
    dosage: "",
    quantite: 0,
    quantite_min: 0,
    prix_unitaire: 0,
    fournisseur: "",
    date_expiration: ""
  });

  // Ventes (Sales) Panel Configuration
  const [cart, setCart] = useState<CartItem[]>([]);
  const [selectedMedId, setSelectedMedId] = useState<string>("");
  const [venteQuantite, setVenteQuantite] = useState<number>(1);
  const [selectedPatientId, setSelectedPatientId] = useState<string>("anonyme");
  const [customPatientNom, setCustomPatientNom] = useState<string>("");
  const [paymentMode, setPaymentMode] = useState<string>("especes");

  // Ventes Historical Audit log
  const [salesHistory, setSalesHistory] = useState<any[]>([]);
  const [salesSearch, setSalesSearch] = useState("");

  useEffect(() => {
    loadMedicaments();
    loadPatients();
    loadSalesHistory();
  }, []);

  const loadMedicaments = async () => {
    const [medsData, catsData] = await Promise.all([
      db.medicaments.toArray(),
      db.categories.toArray()
    ]);
    setMedicaments(medsData);
    setCategories(catsData);
  };

  const loadPatients = async () => {
    const patientsData = await db.patients.toArray();
    setPatients(patientsData);
  };

  const loadSalesHistory = async () => {
    try {
      const recettesArr = await db.recettes.toArray();
      // Filter receipts that are pharmacy sales entries
      const pharmSales = recettesArr.filter((r: any) => {
        const lib = (r.libelle || "").toLowerCase();
        return r.categorie === "Pharmacie" || lib.includes("pharmacie") || lib.includes("vente pharmacie") || lib.includes("médicament") || lib.includes("medicament");
      });
      // Sort desc by date
      pharmSales.sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
      setSalesHistory(pharmSales);
    } catch (error) {
      console.error("Erreur de chargement d'historique ventes", error);
    }
  };

  const handleAddCategory = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newCategoryName.trim()) {
      toast.error("Veuillez spécifier le nom de la catégorie");
      return;
    }
    try {
      await db.categories.add({
        nom: newCategoryName.trim(),
        ordre: categories.length + 1,
        actif: true,
        created_at: new Date()
      });
      toast.success("Catégorie de médicament créée");
      setNewCategoryName("");
      loadMedicaments();
    } catch (err) {
      toast.error("Erreur d'ajout de la catégorie");
    }
  };

  const resetForm = () => {
    setFormData({
      nom_medicament: "",
      categorie: "",
      forme: "",
      dosage: "",
      quantite: 0,
      quantite_min: 0,
      prix_unitaire: 0,
      fournisseur: "",
      date_expiration: ""
    });
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (editingId) {
      await db.medicaments.update(editingId, formData);
      toast.success("Médicament mis à jour");
    } else {
      await db.medicaments.add(formData);
      toast.success("Médicament ajouté au stock");
    }
    setIsModalOpen(false);
    loadMedicaments();
  };

  const handleEdit = (med: Medicament) => {
    setEditingId(med.id || null);
    setFormData(med);
    setIsModalOpen(true);
  };

  const handleDelete = async (id: number) => {
    if (confirm("Supprimer ce médicament ?")) {
      await db.medicaments.delete(id);
      loadMedicaments();
    }
  };

  // Cart operations
  const handleAddToCart = () => {
    if (!selectedMedId) {
      toast.error("Veuillez sélectionner un médicament");
      return;
    }
    const med = medicaments.find(m => m.id === Number(selectedMedId));
    if (!med) return;

    if (venteQuantite <= 0) {
      toast.error("La quantité doit être supérieure à 0");
      return;
    }

    if (venteQuantite > med.quantite) {
      toast.error(`Stock insuffisant. Quantité maximale disponible : ${med.quantite}`);
      return;
    }

    const existing = cart.find(item => item.id === med.id);
    if (existing) {
      const newQty = existing.quantite_vente + venteQuantite;
      if (newQty > med.quantite) {
        toast.error(`Stock insuffisant. Panier : ${existing.quantite_vente}. Dispo total : ${med.quantite}`);
        return;
      }
      setCart(cart.map(item => item.id === med.id ? { ...item, quantite_vente: newQty } : item));
    } else {
      setCart([...cart, {
        id: med.id!,
        nom_medicament: med.nom_medicament,
        dosage: med.dosage,
        prix_unitaire: med.prix_unitaire,
        quantite_stock: med.quantite,
        quantite_vente: venteQuantite
      }]);
    }

    toast.success(`${med.nom_medicament} ajouté au panier.`);
    setSelectedMedId("");
    setVenteQuantite(1);
  };

  const handleRemoveFromCart = (id: number) => {
    setCart(cart.filter(item => item.id !== id));
    toast.message("Article retiré du panier");
  };

  const handleCheckout = async () => {
    if (cart.length === 0) {
      toast.error("Votre panier est vide");
      return;
    }

    let finalPatientNom = "Client de Passage";
    let finalPatientId: number | null = null;

    if (selectedPatientId !== "anonyme") {
      const p = patients.find(pat => pat.id === Number(selectedPatientId));
      if (p) {
        finalPatientNom = p.nom_complet;
        finalPatientId = p.id;
      }
    } else if (customPatientNom.trim()) {
      finalPatientNom = customPatientNom.trim();
    }

    const totalAmount = cart.reduce((sum, item) => sum + (item.prix_unitaire * item.quantite_vente), 0);

    try {
      // 1. Deduct stock for each item
      for (const item of cart) {
        const dbMed = await db.medicaments.get(item.id);
        if (dbMed) {
          const newQty = Math.max(0, dbMed.quantite - item.quantite_vente);
          await db.medicaments.update(item.id, { quantite: newQty });
        }
      }

      // 2. Format details label
      const detailsLabel = cart.map(item => `${item.nom_medicament} (${item.dosage}) x${item.quantite_vente}`).join(', ');

      // 3. Register receipts in DB which updates caisse automatically
      await db.recettes.add({
        patient_id: finalPatientId,
        patient_nom: finalPatientNom,
        prestation_id: null,
        libelle: `Vente Pharmacie : ${detailsLabel}`,
        montant: totalAmount,
        mode_paiement: paymentMode,
        categorie: "Pharmacie", // Explicit field for Reports/Rapports analytics
        date: new Date().toISOString(),
        created_at: new Date()
      });

      toast.success("Vente enregistrée avec succès! Stock mis à jour et transaction de caisse créée.");
      setCart([]);
      setCustomPatientNom("");
      setSelectedPatientId("anonyme");
      
      // Reload states
      await loadMedicaments();
      await loadSalesHistory();
      setActiveTab("stock");
    } catch (error: any) {
      toast.error("Erreur lors de la validation : " + (error.message || error));
    }
  };

  const filteredMedicaments = medicaments.filter(m => 
    m.nom_medicament.toLowerCase().includes(searchTerm.toLowerCase()) ||
    m.categorie.toLowerCase().includes(searchTerm.toLowerCase()) || 
    m.fournisseur.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const filteredSalesHistory = salesHistory.filter(s => 
    (s.patient_nom || "").toLowerCase().includes(salesSearch.toLowerCase()) ||
    (s.libelle || "").toLowerCase().includes(salesSearch.toLowerCase()) ||
    (s.mode_paiement || "").toLowerCase().includes(salesSearch.toLowerCase())
  );

  const stockAlerts = medicaments.filter(m => m.quantite <= m.quantite_min);

  return (
    <div className="space-y-4 max-w-6xl">
      {/* Page Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-white dark:bg-slate-900 p-4 rounded-xl border border-slate-100 dark:border-slate-800 shadow-sm">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-lg bg-teal-600 flex items-center justify-center">
            <Pill className="w-5 h-5 text-white" />
          </div>
          <div>
            <h2 className="text-lg font-bold text-slate-800 dark:text-slate-100">Pharmacie Professionnelle</h2>
            <p className="text-xs text-slate-500">
              {medicaments.length} produits enregistrés | {stockAlerts.length} alerte(s) rupture de stock
            </p>
          </div>
        </div>

        {/* Dynamic Action Buttons based on activeTab */}
        <div className="flex items-center gap-2">
          {activeTab === "stock" && canEdit('pharmacie') && (
            <>
              <Button
                onClick={() => setIsCategoryModalOpen(true)}
                variant="outline"
                className="border-teal-600 text-teal-600 hover:bg-teal-50 dark:hover:bg-teal-900/10 text-xs h-9"
              >
                📁 Catégories
              </Button>
              <Button 
                onClick={() => { setIsModalOpen(true); setEditingId(null); resetForm(); }} 
                className="bg-teal-600 hover:bg-teal-700 text-white font-semibold text-xs h-9"
              >
                <Plus className="w-4 h-4 mr-1.5" /> Nouveau Produit
              </Button>
            </>
          )}
        </div>
      </div>

      {/* Navigation Tabs bar */}
      <div className="flex gap-1 bg-slate-150 dark:bg-slate-850 p-1.5 rounded-lg w-fit">
        <button 
          onClick={() => setActiveTab("stock")} 
          className={`flex items-center gap-1.5 px-4 py-2 rounded-md text-xs font-semibold transition-colors ${activeTab === "stock" ? "bg-white dark:bg-slate-900 text-teal-700 shadow-sm" : "text-slate-600 dark:text-slate-400 hover:bg-slate-100/50"}`}
        >
          <Pill className="w-3.5 h-3.5" />
          Inventaire & Stock
        </button>
        <button 
          onClick={() => setActiveTab("vente")} 
          className={`flex items-center gap-1.5 px-4 py-2 rounded-md text-xs font-semibold transition-colors ${activeTab === "vente" ? "bg-white dark:bg-slate-900 text-teal-700 shadow-sm" : "text-slate-600 dark:text-slate-400 hover:bg-slate-100/50"}`}
        >
          <ShoppingCart className="w-3.5 h-3.5" />
          Enregistrer une Vente
          {cart.length > 0 && (
            <Badge className="bg-red-500 hover:bg-red-600 text-[10px] text-white px-1.5 py-0.5 ml-1">
              {cart.reduce((sum, item) => sum + item.quantite_vente, 0)}
            </Badge>
          )}
        </button>
        <button 
          onClick={() => setActiveTab("historique")} 
          className={`flex items-center gap-1.5 px-4 py-2 rounded-md text-xs font-semibold transition-colors ${activeTab === "historique" ? "bg-white dark:bg-slate-900 text-teal-700 shadow-sm" : "text-slate-600 dark:text-slate-400 hover:bg-slate-100/50"}`}
        >
          <History className="w-3.5 h-3.5" />
          Journal des Ventes
        </button>
      </div>

      {/* Stock Alerts Widget */}
      {stockAlerts.length > 0 && activeTab === "stock" && (
        <div className="p-3 bg-red-55/10 border border-red-200/50 rounded-xl flex gap-3 items-start animate-pulse">
          <AlertCircle className="w-5 h-5 text-red-500 shrink-0 mt-0.5" />
          <div>
            <p className="text-xs font-bold text-red-700">Ruptures ou Niveau critique détecté ({stockAlerts.length} articles) :</p>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-y-1 gap-x-4 mt-1.5">
              {stockAlerts.map(m => (
                <p key={m.id} className="text-[11px] text-red-600 font-medium">
                  • {m.nom_medicament} ({m.dosage}) : <span className="font-bold">{m.quantite} restant(s)</span> (Seuil: {m.quantite_min})
                </p>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* Render Stock Tab */}
      {activeTab === "stock" && (
        <div className="space-y-4">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
            <Input 
              placeholder="Rechercher par nom, catégorie, ou fournisseur..." 
              value={searchTerm} 
              onChange={(e) => setSearchTerm(e.target.value)} 
              className="pl-10 h-10 bg-white dark:bg-slate-950"
            />
          </div>

          <Card className="rounded-xl overflow-hidden shadow-sm border border-slate-200 dark:border-slate-800">
            <CardContent className="p-0">
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead className="bg-[#f8fafc] dark:bg-slate-900 text-slate-550 border-b border-slate-100 dark:border-slate-800">
                    <tr>
                      <th className="text-left py-3 px-4 font-bold text-xs">Nom du Produit</th>
                      <th className="text-left py-3 px-4 font-bold text-xs">Classe/Catégorie</th>
                      <th className="text-left py-3 px-4 font-bold text-xs">Dosage</th>
                      <th className="text-left py-3 px-4 font-bold text-xs">Stock Médicaments</th>
                      <th className="text-left py-3 px-4 font-bold text-xs">Prix Unitaire</th>
                      <th className="text-left py-3 px-4 font-bold text-xs">Date Expiration</th>
                      <th className="text-center py-3 px-4 font-bold text-xs">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100 dark:divide-slate-800 bg-white dark:bg-slate-950">
                    {filteredMedicaments.length === 0 ? (
                      <tr>
                        <td colSpan={7} className="text-center py-8 text-xs text-slate-450 font-medium">
                          Aucun médicament trouvé correspondant à la recherche.
                        </td>
                      </tr>
                    ) : (
                      filteredMedicaments.map(m => {
                        const alert = m.quantite <= m.quantite_min;
                        return (
                          <tr key={m.id} className={`hover:bg-slate-50/50 dark:hover:bg-slate-900/30 transition-colors ${alert ? 'bg-red-50/30 dark:bg-red-950/10' : ''}`}>
                            <td className="py-3 px-4 font-bold text-slate-800 dark:text-slate-200">{m.nom_medicament}</td>
                            <td className="py-3 px-4">
                              <Badge variant="outline" className="text-[10px] uppercase font-bold tracking-wider py-0 px-2 bg-slate-50/50">
                                {m.categorie || "Pharmacie"}
                              </Badge>
                            </td>
                            <td className="py-3 px-4 text-xs font-mono text-slate-500">{m.dosage || "N/A"}</td>
                            <td className="py-3 px-4 font-semibold">
                              <span className={alert ? "text-red-650 font-bold" : "text-slate-700 dark:text-slate-300"}>
                                {m.quantite} u
                              </span>
                              {alert && (
                                <Badge className="ml-2 bg-red-150 text-red-700 text-[9px] hover:bg-red-150 py-0 px-1 font-bold">Rupture</Badge>
                              )}
                            </td>
                            <td className="py-3 px-4 font-bold text-emerald-650">{m.prix_unitaire.toLocaleString()} FCFA</td>
                            <td className="py-3 px-4 text-xs font-medium text-slate-500">
                              {m.date_expiration ? (
                                <span className={new Date(m.date_expiration) < new Date() ? "text-red-500 font-bold" : ""}>
                                  {new Date(m.date_expiration).toLocaleDateString("fr-FR")}
                                </span>
                              ) : "Non précisée"}
                            </td>
                            <td className="py-3 px-4 text-center">
                              {canEdit('pharmacie') && (
                                <div className="flex justify-center gap-1">
                                  <Button variant="ghost" size="sm" onClick={() => handleEdit(m)} className="h-8 w-8 p-0 text-slate-500 hover:text-teal-600">
                                    <Pencil className="w-3.5 h-3.5" />
                                  </Button>
                                  <Button variant="ghost" size="sm" className="h-8 w-8 p-0 text-red-500 hover:text-red-700" onClick={() => m.id && handleDelete(m.id)}>
                                    <Trash2 className="w-3.5 h-3.5" />
                                  </Button>
                                </div>
                              )}
                            </td>
                          </tr>
                        );
                      })
                    )}
                  </tbody>
                </table>
              </div>
            </CardContent>
          </Card>
        </div>
      )}

      {/* Render Nouvelle Vente Panel Container */}
      {activeTab === "vente" && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
          
          {/* Sale Creation & Medicine selector form */}
          <div className="lg:col-span-1 space-y-4">
            <Card className="rounded-xl border border-slate-200 dark:border-slate-800 shadow-sm p-4 space-y-4 bg-white dark:bg-slate-900">
              <h3 className="text-sm font-bold text-slate-800 dark:text-white flex items-center gap-2 border-b pb-2">
                <ShoppingCart className="w-4 h-4 text-teal-600" />
                Sélection des Produits
              </h3>

              <div className="space-y-3">
                {/* Medicine select list */}
                <div className="space-y-1">
                  <Label className="text-xs text-slate-500 font-semibold">Médicament à vendre</Label>
                  <select
                    value={selectedMedId}
                    onChange={(e) => {
                      setSelectedMedId(e.target.value);
                      setVenteQuantite(1);
                    }}
                    className="w-full text-xs h-10 rounded-md border border-slate-200 bg-transparent px-3 text-slate-800 dark:text-slate-200 bg-white dark:bg-slate-950 font-medium"
                  >
                    <option value="">Sélectionner un produit du stock...</option>
                    {medicaments
                      .filter(m => m.quantite > 0)
                      .map(m => (
                        <option key={m.id} value={m.id}>
                          {m.nom_medicament} ({m.dosage}) — {m.prix_unitaire} F | (Stock: {m.quantite})
                        </option>
                      ))}
                  </select>
                </div>

                {/* Show available stock feedback */}
                {selectedMedId && (
                  (() => {
                    const sel = medicaments.find(x => x.id === Number(selectedMedId));
                    if (!sel) return null;
                    return (
                      <div className="p-2.5 bg-teal-50/50 dark:bg-teal-950/20 border border-teal-100 rounded text-[11px] space-y-1">
                        <p className="font-semibold text-teal-800 dark:text-teal-400">Détails de l'article :</p>
                        <p className="text-slate-600 dark:text-slate-350">Stock restant : <span className="font-bold text-slate-800 dark:text-white">{sel.quantite} unités</span></p>
                        <p className="text-slate-600 dark:text-slate-350">Prix unitaire : <span className="font-bold text-slate-800 dark:text-white">{sel.prix_unitaire.toLocaleString()} FCFA</span></p>
                        <p className="text-slate-600 dark:text-slate-350">Classe : {sel.categorie}</p>
                      </div>
                    );
                  })()
                )}

                {/* Sell quantity */}
                <div className="space-y-1">
                  <Label className="text-xs text-slate-500 font-semibold">Quantité à vendre</Label>
                  <div className="flex gap-2">
                    <Input 
                      type="number" 
                      min="1" 
                      value={venteQuantite} 
                      onChange={(e) => setVenteQuantite(Math.max(1, Number(e.target.value)))} 
                      className="bg-white dark:bg-slate-950 h-9 font-mono"
                    />
                    <Button 
                      type="button" 
                      onClick={handleAddToCart}
                      className="bg-teal-600 hover:bg-teal-700 h-9 px-4 text-xs font-semibold text-white shrink-0"
                    >
                      Ajouter
                    </Button>
                  </div>
                </div>
              </div>
            </Card>

            <Card className="rounded-xl border border-slate-200 dark:border-slate-800 shadow-sm p-4 space-y-4 bg-white dark:bg-slate-900">
              <h3 className="text-sm font-bold text-slate-800 dark:text-white flex items-center gap-2 border-b pb-2">
                <User className="w-4 h-4 text-teal-600" />
                Client & Règlement
              </h3>

              <div className="space-y-3">
                {/* Patient selection */}
                <div className="space-y-1">
                  <Label className="text-xs text-slate-500 font-semibold">Associer à un Patient</Label>
                  <select
                    value={selectedPatientId}
                    onChange={(e) => {
                      setSelectedPatientId(e.target.value);
                      if (e.target.value !== "anonyme") {
                        setCustomPatientNom("");
                      }
                    }}
                    className="w-full text-xs h-10 rounded-md border border-slate-200 bg-transparent px-3 text-slate-800 dark:text-slate-200 bg-white dark:bg-slate-950"
                  >
                    <option value="anonyme">Client de passage / Anonyme</option>
                    {patients.map(p => (
                      <option key={p.id} value={p.id}>
                        {p.nom_complet} — {p.id_patient || p.telephone || "Clinique patient"}
                      </option>
                    ))}
                  </select>
                </div>

                {/* Custom Name for Anonymous clients */}
                {selectedPatientId === "anonyme" && (
                  <div className="space-y-1">
                    <Label className="text-xs text-slate-500 font-semibold">Nom du client (optionnel)</Label>
                    <Input 
                      placeholder="Ex: M. Diallo" 
                      value={customPatientNom}
                      onChange={(e) => setCustomPatientNom(e.target.value)}
                      className="bg-white dark:bg-slate-950 h-9 text-xs font-medium"
                    />
                  </div>
                )}

                {/* Mode paiement */}
                <div className="space-y-1">
                  <Label className="text-xs text-slate-500 font-semibold">Mode de Règlement</Label>
                  <select
                    value={paymentMode}
                    onChange={(e) => setPaymentMode(e.target.value)}
                    className="w-full text-xs h-10 rounded-md border border-slate-200 bg-transparent px-3 text-slate-800 dark:text-slate-200 bg-white dark:bg-slate-950"
                  >
                    <option value="especes">💵 Espèces</option>
                    <option value="orange_money">🍊 Orange Money</option>
                    <option value="wave">🌊 Wave / Mobile Money</option>
                    <option value="cb">💳 Carte Bancaire</option>
                    <option value="cheque">✍️ Chèque</option>
                  </select>
                </div>
              </div>
            </Card>
          </div>

          {/* Cart checklist / summary */}
          <div className="lg:col-span-2">
            <Card className="rounded-xl border border-slate-200 dark:border-slate-800 shadow-sm bg-white dark:bg-slate-900 h-full flex flex-col justify-between">
              <div>
                <CardHeader className="border-b pb-3.5">
                  <div className="flex items-center justify-between">
                    <div>
                      <CardTitle className="text-xs uppercase font-bold text-slate-400">Panier Courant</CardTitle>
                      <p className="text-xs text-slate-500 mt-1">Vérifiez les médicaments sélectionnés pour la facturation caisse.</p>
                    </div>
                    {cart.length > 0 && (
                      <Button variant="ghost" size="sm" onClick={() => setCart([])} className="text-xs text-red-500 hover:text-red-700 h-8 font-semibold">
                        Vider panier
                      </Button>
                    )}
                  </div>
                </CardHeader>

                <div className="p-0">
                  {cart.length === 0 ? (
                    <div className="text-center py-16 px-4">
                      <ShoppingCart className="w-10 h-10 text-slate-350 mx-auto mb-3" />
                      <p className="text-sm font-semibold text-slate-600 dark:text-slate-300">Votre panier est vide</p>
                      <p className="text-xs text-slate-400 mt-1 max-w-xs mx-auto leading-relaxed">
                        Sélectionnez un médicament disponible en stock dans le menu latéral gauche, ajustez la quantité et cliquez sur Ajouter.
                      </p>
                    </div>
                  ) : (
                    <div className="overflow-x-auto">
                      <table className="w-full text-sm">
                        <thead className="bg-[#f8fafc] dark:bg-slate-900 border-b border-slate-100 dark:border-slate-800 text-slate-550">
                          <tr>
                            <th className="text-left py-2.5 px-4 font-bold text-xs">Produit</th>
                            <th className="text-center py-2.5 px-4 font-bold text-xs">PU</th>
                            <th className="text-center py-2.5 px-4 font-bold text-xs">Quantité</th>
                            <th className="text-right py-2.5 px-4 font-bold text-xs">Total Ligne</th>
                            <th className="text-center py-2.5 px-4 font-bold text-xs">Retirer</th>
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                          {cart.map(item => (
                            <tr key={item.id} className="hover:bg-slate-55/30 transition-colors">
                              <td className="py-2.5 px-4">
                                <p className="font-bold text-slate-800 dark:text-slate-200">{item.nom_medicament}</p>
                                <p className="text-[10px] text-slate-450 font-mono">Dosage : {item.dosage}</p>
                              </td>
                              <td className="py-2.5 px-4 text-center font-semibold text-xs">{item.prix_unitaire.toLocaleString()} F</td>
                              <td className="py-2.5 px-4 text-center font-bold text-xs font-mono">{item.quantite_vente} u</td>
                              <td className="py-2.5 px-4 text-right font-bold text-teal-700 text-xs">
                                {(item.prix_unitaire * item.quantite_vente).toLocaleString()} F
                              </td>
                              <td className="py-2.5 px-4 text-center">
                                <Button 
                                  variant="ghost" 
                                  size="sm" 
                                  onClick={() => handleRemoveFromCart(item.id)}
                                  className="h-7 w-7 p-0 text-red-500 hover:text-red-700"
                                >
                                  <X className="w-3.5 h-3.5" />
                                </Button>
                              </td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  )}
                </div>
              </div>

              {/* Cart Footer Grand Total & Submit */}
              {cart.length > 0 && (
                <div className="p-4 bg-slate-50 dark:bg-slate-900 border-t border-slate-100 dark:border-slate-800 rounded-b-xl flex flex-col sm:flex-row justify-between items-center gap-3">
                  <div className="text-center sm:text-left">
                    <p className="text-xs text-slate-450 font-bold uppercase">Montant Total à Payer</p>
                    <p className="text-xl font-black text-emerald-650">
                      {cart.reduce((sum, item) => sum + (item.prix_unitaire * item.quantite_vente), 0).toLocaleString()} FCFA
                    </p>
                  </div>
                  
                  <Button 
                    onClick={handleCheckout} 
                    className="w-full sm:w-auto bg-teal-600 hover:bg-teal-700 text-white text-xs font-bold px-6 h-10 rounded-md shrink-0 flex items-center justify-center gap-2 shadow-sm"
                  >
                    <Check className="w-4 h-4" />
                    Enregistrer la Vente & Caisse
                  </Button>
                </div>
              )}
            </Card>
          </div>

        </div>
      )}

      {/* Render Historical Journal of sales */}
      {activeTab === "historique" && (
        <div className="space-y-4">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
            <Input 
              placeholder="Filtrer l'historique par patient, médicaments vendus, ou mode..." 
              value={salesSearch} 
              onChange={(e) => setSalesSearch(e.target.value)} 
              className="pl-10 h-10 bg-white dark:bg-slate-950"
            />
          </div>

          <Card className="rounded-xl overflow-hidden shadow-sm border border-slate-200 dark:border-slate-800">
            <CardContent className="p-0">
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead className="bg-[#f8fafc] dark:bg-slate-900 border-b border-slate-100 dark:border-slate-800 text-slate-550">
                    <tr>
                      <th className="text-left py-3 px-4 font-bold text-xs">Date Vente</th>
                      <th className="text-left py-3 px-4 font-bold text-xs">Bénéficiaire / Client</th>
                      <th className="text-left py-3 px-4 font-bold text-xs">Détails articles vendus</th>
                      <th className="text-right py-3 px-4 font-bold text-xs">Montant payé</th>
                      <th className="text-center py-3 px-4 font-bold text-xs">Mode</th>
                      <th className="text-center py-3 px-4 font-bold text-xs">Caisse Statut</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100 dark:divide-slate-800 bg-white dark:bg-slate-900">
                    {filteredSalesHistory.length === 0 ? (
                      <tr>
                        <td colSpan={6} className="text-center py-12 text-xs text-slate-400 font-semibold">
                          Aucune vente enregistrée dans le journal.
                        </td>
                      </tr>
                    ) : (
                      filteredSalesHistory.map(sale => (
                        <tr key={sale.id} className="hover:bg-slate-50/50 dark:hover:bg-slate-950/20 text-xs">
                          <td className="py-3 px-4 font-mono text-slate-500 whitespace-nowrap">
                            {sale.date ? new Date(sale.date).toLocaleString("fr-FR") : "N/A"}
                          </td>
                          <td className="py-3 px-4 font-bold text-slate-750">{sale.patient_nom || "Client de passage"}</td>
                          <td className="py-3 px-4 font-medium text-slate-600 dark:text-slate-300 max-w-xs truncate" title={sale.libelle}>
                            {sale.libelle ? sale.libelle.replace("Vente Pharmacie : ", "") : "N/A"}
                          </td>
                          <td className="py-3 px-4 text-right font-black text-emerald-650">{sale.montant.toLocaleString()} F</td>
                          <td className="py-3 px-4 text-center">
                            <Badge variant="outline" className="text-[9px] font-bold tracking-wider capitalize py-0 px-1.5 bg-slate-50">
                              {sale.mode_paiement || "especes"}
                            </Badge>
                          </td>
                          <td className="py-3 px-4 text-center">
                            <Badge className="bg-emerald-100 text-emerald-800 text-[9px] hover:bg-emerald-100 font-bold">
                              Enregistré Caisse
                            </Badge>
                          </td>
                        </tr>
                      ))
                    )}
                  </tbody>
                </table>
              </div>
            </CardContent>
          </Card>
        </div>
      )}

      {/* Stock Edit Modal dialog */}
      {isModalOpen && (
        <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4">
          <div className="bg-white dark:bg-slate-900 rounded-xl shadow-xl max-w-lg w-full overflow-hidden border">
            <div className="flex items-center justify-between p-4 border-b border-slate-200 dark:border-slate-800">
              <h3 className="text-base font-bold text-slate-800 dark:text-white flex items-center gap-1.5">
                <Pill className="w-4 h-4 text-teal-600" />
                {editingId ? "Modifier le Produit" : "Nouveau médicament en stock"}
              </h3>
              <button onClick={() => setIsModalOpen(false)} className="p-1 hover:bg-slate-100 dark:hover:bg-slate-800 rounded">
                <X className="w-5 h-5 text-slate-500" />
              </button>
            </div>
            <form onSubmit={handleSubmit} className="p-4 space-y-3">
              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1">
                  <Label className="text-xs font-semibold text-slate-500">Nom du médicament</Label>
                  <Input value={formData.nom_medicament} onChange={(e) => setFormData({...formData, nom_medicament: e.target.value})} required className="bg-white dark:bg-slate-950 text-xs" />
                </div>
                <div className="space-y-1">
                  <Label className="text-xs font-semibold text-slate-500">Catégorie Thérapeutique</Label>
                  <select
                    value={formData.categorie}
                    onChange={(e) => setFormData({...formData, categorie: e.target.value})}
                    className="w-full h-10 rounded-md border border-slate-200 bg-transparent px-3 text-xs bg-white dark:bg-slate-950 text-slate-800"
                  >
                    <option value="">Définir une catégorie...</option>
                    {categories.map(c => (
                      <option key={c.id} value={c.nom}>{c.nom}</option>
                    ))}
                    <option value="Divers / Autre">Divers / Autre</option>
                  </select>
                </div>
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1">
                  <Label className="text-xs font-semibold text-slate-500">Forme Galénique</Label>
                  <Input value={formData.forme} onChange={(e) => setFormData({...formData, forme: e.target.value})} placeholder="Ex: Comprimé, Sirop" className="bg-white dark:bg-slate-950 text-xs" />
                </div>
                <div className="space-y-1">
                  <Label className="text-xs font-semibold text-slate-500">Dosage / Présentation</Label>
                  <Input value={formData.dosage} onChange={(e) => setFormData({...formData, dosage: e.target.value})} placeholder="Ex: 500mg, 1g" className="bg-white dark:bg-slate-950 text-xs" />
                </div>
              </div>
              <div className="grid grid-cols-3 gap-3">
                <div className="space-y-1">
                  <Label className="text-xs font-semibold text-slate-500">Quantité en stock</Label>
                  <Input type="number" min="0" value={formData.quantite} onChange={(e) => setFormData({...formData, quantite: Number(e.target.value)})} className="bg-white dark:bg-slate-950 font-mono text-xs" />
                </div>
                <div className="space-y-1">
                  <Label className="text-xs font-semibold text-slate-500">Seuil alerte (Min)</Label>
                  <Input type="number" min="0" value={formData.quantite_min} onChange={(e) => setFormData({...formData, quantite_min: Number(e.target.value)})} className="bg-white dark:bg-slate-950 font-mono text-xs" />
                </div>
                <div className="space-y-1">
                  <Label className="text-xs font-semibold text-slate-500">Prix unitaire (Vente)</Label>
                  <Input type="number" min="0" value={formData.prix_unitaire} onChange={(e) => setFormData({...formData, prix_unitaire: Number(e.target.value)})} className="bg-white dark:bg-slate-950 font-mono text-xs" />
                </div>
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1">
                  <Label className="text-xs font-semibold text-slate-500">Fournisseur / Labo</Label>
                  <Input value={formData.fournisseur} onChange={(e) => setFormData({...formData, fournisseur: e.target.value})} className="bg-white dark:bg-slate-950 text-xs" />
                </div>
                <div className="space-y-1">
                  <Label className="text-xs font-semibold text-slate-500">Date d'expiration</Label>
                  <Input type="date" value={formData.date_expiration} onChange={(e) => setFormData({...formData, date_expiration: e.target.value})} className="bg-white dark:bg-slate-950 text-xs" />
                </div>
              </div>
              <div className="flex justify-end gap-2 pt-3 border-t">
                <Button type="button" variant="outline" onClick={() => setIsModalOpen(false)} className="text-xs">Annuler</Button>
                <Button type="submit" className="bg-teal-600 hover:bg-teal-700 text-white text-xs font-bold">{editingId ? "Sauvegarder" : "Ajouter"}</Button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Categories dialog */}
      {isCategoryModalOpen && (
        <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4">
          <div className="bg-white dark:bg-slate-900 rounded-xl shadow-xl max-w-sm w-full border">
            <div className="flex items-center justify-between p-4 border-b">
              <h3 className="text-sm font-bold text-slate-800 dark:text-white">Catégories thérapeutiques</h3>
              <button onClick={() => setIsCategoryModalOpen(false)} className="p-1 hover:bg-slate-100 rounded">
                <X className="w-5 h-5 text-slate-500" />
              </button>
            </div>

            <div className="p-4 space-y-4">
              <form onSubmit={handleAddCategory} className="flex gap-2">
                <div className="flex-1">
                  <Input 
                    placeholder="Nouvelle classe..." 
                    value={newCategoryName} 
                    onChange={e => setNewCategoryName(e.target.value)} 
                    required 
                    className="h-9 text-xs"
                  />
                </div>
                <Button type="submit" className="bg-teal-600 hover:bg-teal-700 text-white font-semibold text-xs h-9">
                  Créer
                </Button>
              </form>

              <div className="space-y-1 max-h-[200px] overflow-y-auto">
                <p className="text-[10px] text-slate-405 font-bold uppercase tracking-wider pb-1">Liste actuelle :</p>
                {categories.length === 0 ? (
                  <p className="text-xs text-slate-400 py-3 text-center italic">Aucune classe thérapeutique enregistrée</p>
                ) : (
                  categories.map(c => (
                    <div key={c.id} className="flex items-center justify-between p-2 rounded bg-slate-50 dark:bg-slate-900 border text-xs">
                      <span className="font-semibold text-slate-700 dark:text-slate-300">{c.nom}</span>
                      <button
                        type="button"
                        onClick={async () => {
                          if (confirm("Supprimer cette catégorie ?")) {
                            await db.categories.delete(c.id);
                            toast.success("Catégorie supprimée");
                            loadMedicaments();
                          }
                        }}
                        className="text-[10px] text-red-650 hover:underline px-1"
                      >
                        Supprimer
                      </button>
                    </div>
                  ))
                )}
              </div>
            </div>

            <div className="flex justify-end p-4 border-t">
              <Button type="button" variant="outline" onClick={() => setIsCategoryModalOpen(false)} className="text-xs">Fermer</Button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
