import React, { useState, useEffect } from 'react';
import { db } from '@/db';
import { 
  Users, 
  Plus, 
  Search, 
  Trash, 
  X, 
  CheckCircle, 
  UserCog, 
  Stethoscope, 
  Phone, 
  Mail, 
  User, 
  Ban, 
  Power, 
  Pencil,
  AlertCircle
} from 'lucide-react';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { toast } from 'sonner';

interface Utilisateur {
  id: number;
  nom: string;
  prenom: string;
  nom_utilisateur: string;
  email: string;
  telephone: string;
  specialite: string;
  role: 'administrateur' | 'medecin' | 'infirmier' | 'comptable' | 'laborantin';
  statut: 'actif' | 'inactif';
  mot_de_passe?: string;
}

const ROLES = [
  { value: 'administrateur', label: 'Administrateur' },
  { value: 'medecin', label: 'Médecin' },
  { value: 'infirmier', label: 'Infirmier(ière)' },
  { value: 'comptable', label: 'Comptable' },
  { value: 'laborantin', label: 'Laborantin' },
];

const ROLE_STYLES: Record<string, string> = {
  administrateur: 'bg-purple-100 text-purple-700 dark:bg-purple-900/30 dark:text-purple-300',
  medecin: 'bg-blue-100 text-blue-700 dark:bg-blue-900/30 dark:text-blue-300',
  infirmier: 'bg-teal-100 text-teal-700 dark:bg-teal-900/30 dark:text-teal-300',
  comptable: 'bg-emerald-100 text-emerald-700 dark:bg-emerald-900/30 dark:text-emerald-300',
  laborantin: 'bg-pink-100 text-pink-700 dark:bg-pink-900/30 dark:text-pink-300',
};

export default function Utilisateurs() {
  const [utilisateurs, setUtilisateurs] = useState<Utilisateur[]>([]);
  const [recherche, setRecherche] = useState('');
  const [formOuvert, setFormOuvert] = useState(false);
  const [editionMode, setEditionMode] = useState(false);
  const [formData, setFormData] = useState<Partial<Utilisateur>>({});

  const chargerUtilisateurs = async () => {
    const data = await db.utilisateurs.toArray();
    setUtilisateurs(data);
  };

  useEffect(() => {
    chargerUtilisateurs();
  }, []);

  const basculerStatut = async (user: Utilisateur) => {
    const nouveauStatut = user.statut === 'actif' ? 'inactif' : 'actif';
    await db.utilisateurs.update(user.id, { statut: nouveauStatut });
    toast.success(`Utilisateur ${nouveauStatut}`);
    chargerUtilisateurs();
  };

  const supprimerUtilisateur = async (id: number) => {
    if (confirm('Supprimer cet utilisateur ?')) {
      await db.utilisateurs.delete(id);
      chargerUtilisateurs();
    }
  };

  const handleInputChange = (field: keyof Utilisateur, value: any) => {
    setFormData((prev) => ({ ...prev, [field]: value }));
  };

  const sauvegarderUtilisateur = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.nom?.trim() || !formData.prenom?.trim() || !formData.nom_utilisateur?.trim()) {
      toast.error("Veuillez remplir les champs obligatoires (*)");
      return;
    }

    try {
      if (editionMode) {
        await db.utilisateurs.update(formData.id!, {
          nom: formData.nom.trim(),
          prenom: formData.prenom.trim(),
          nom_utilisateur: formData.nom_utilisateur.trim(),
          email: formData.email?.trim() || '',
          telephone: formData.telephone?.trim() || '',
          specialite: formData.specialite?.trim() || '',
          role: formData.role || 'infirmier',
          statut: formData.statut || 'actif',
          ...(formData.mot_de_passe ? { mot_de_passe: formData.mot_de_passe } : {})
        });
        toast.success("Utilisateur mis à jour");
      } else {
        await db.utilisateurs.add({
          nom: formData.nom.trim(),
          prenom: formData.prenom.trim(),
          nom_utilisateur: formData.nom_utilisateur.trim(),
          email: formData.email?.trim() || '',
          telephone: formData.telephone?.trim() || '',
          specialite: formData.specialite?.trim() || '',
          role: formData.role || 'infirmier',
          statut: formData.statut || 'actif',
          mot_de_passe: formData.mot_de_passe || '123456'
        } as any);
        toast.success("Utilisateur créé avec succès");
      }
      setFormOuvert(false);
      chargerUtilisateurs();
    } catch (err) {
      toast.error("Erreur durant l'enregistrement");
    }
  };

  const utilisateursFiltres = utilisateurs.filter(u => 
    `${u.nom} ${u.prenom} ${u.nom_utilisateur} ${u.email} ${u.role}`
      .toLowerCase()
      .includes(recherche.toLowerCase())
  );

  const nbActifs = utilisateurs.filter(u => u.statut === 'actif').length;

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between flex-wrap gap-3">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-lg bg-slate-700 flex items-center justify-center">
            <Users className="w-5 h-5 text-white" />
          </div>
          <div>
            <h2 className="text-xl font-bold text-slate-800 dark:text-white">Utilisateurs</h2>
            <p className="text-sm text-slate-500">Gestion des comptes ({utilisateurs.length})</p>
          </div>
        </div>
        <Button onClick={() => { setFormOuvert(true); setEditionMode(false); setFormData({}); }} className="bg-teal-600 hover:bg-teal-700">
          <Plus className="w-4 h-4 mr-1" /> Nouvel utilisateur
        </Button>
      </div>

      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        <Card className="p-3 flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-blue-100 text-blue-600 flex items-center justify-center">
              <Users className="w-4 h-4" />
            </div>
            <div>
              <p className="text-xs text-slate-500">Total</p>
              <p className="text-lg font-bold">{utilisateurs.length}</p>
            </div>
        </Card>
        <Card className="p-3 flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-emerald-100 text-emerald-600 flex items-center justify-center">
              <CheckCircle className="w-4 h-4" />
            </div>
            <div>
              <p className="text-xs text-slate-500">Actifs</p>
              <p className="text-lg font-bold">{nbActifs}</p>
            </div>
        </Card>
        <Card className="p-3 flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-teal-100 text-teal-600 flex items-center justify-center">
              <UserCog className="w-4 h-4" />
            </div>
            <div>
              <p className="text-xs text-slate-500">Admins</p>
              <p className="text-lg font-bold">{utilisateurs.filter(u => u.role === 'administrateur').length}</p>
            </div>
        </Card>
        <Card className="p-3 flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-purple-100 text-purple-600 flex items-center justify-center">
              <Stethoscope className="w-4 h-4" />
            </div>
            <div>
              <p className="text-xs text-slate-500">Médecins</p>
              <p className="text-lg font-bold">{utilisateurs.filter(u => u.role === 'medecin').length}</p>
            </div>
        </Card>
      </div>

      <div className="relative">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
        <Input placeholder="Rechercher un utilisateur..." value={recherche} onChange={(e) => setRecherche(e.target.value)} className="pl-9" />
      </div>

      {formOuvert && (
        <Card className="border-teal-200 p-4 space-y-4 bg-slate-50 dark:bg-slate-900 shadow-sm">
          <div className="flex items-center justify-between">
            <h3 className="font-bold text-teal-800 dark:text-teal-400">
              {editionMode ? 'Modifier' : 'Créer'} l'utilisateur
            </h3>
            <Button variant="ghost" size="sm" onClick={() => setFormOuvert(false)}>
              <X className="w-4 h-4" />
            </Button>
          </div>
          <form onSubmit={sauvegarderUtilisateur} className="space-y-4">
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
              <div className="space-y-1">
                <Label className="text-xs font-bold text-slate-700">Nom *</Label>
                <Input 
                  value={formData.nom || ''} 
                  onChange={(e) => handleInputChange('nom', e.target.value)} 
                  required
                  className="h-9 text-xs"
                />
              </div>
              <div className="space-y-1">
                <Label className="text-xs font-bold text-slate-700">Prénom *</Label>
                <Input 
                  value={formData.prenom || ''} 
                  onChange={(e) => handleInputChange('prenom', e.target.value)} 
                  required
                  className="h-9 text-xs"
                />
              </div>
              <div className="space-y-1">
                <Label className="text-xs font-bold text-slate-700">Nom d'utilisateur *</Label>
                <Input 
                  value={formData.nom_utilisateur || ''} 
                  onChange={(e) => handleInputChange('nom_utilisateur', e.target.value)} 
                  required
                  className="h-9 text-xs"
                />
              </div>
              <div className="space-y-1">
                <Label className="text-xs font-bold text-slate-700">Mot de passe {!editionMode && '*'}</Label>
                <Input 
                  type="password"
                  placeholder={editionMode ? "(Inchangé si vide)" : "Saisir mot de passe..."}
                  value={formData.mot_de_passe || ''} 
                  onChange={(e) => handleInputChange('mot_de_passe', e.target.value)} 
                  required={!editionMode}
                  className="h-9 text-xs"
                />
              </div>
              <div className="space-y-1">
                <Label className="text-xs font-semibold text-slate-700 dark:text-slate-300">Rôle</Label>
                <select
                  value={formData.role || 'infirmier'}
                  onChange={e => handleInputChange('role', e.target.value as any)}
                  className="w-full h-9 rounded border border-slate-200 dark:border-slate-700 text-xs px-2 bg-white dark:bg-slate-900 text-slate-900 dark:text-slate-100"
                >
                  {ROLES.map(r => (
                    <option key={r.value} value={r.value}>{r.label}</option>
                  ))}
                </select>
              </div>
              <div className="space-y-1">
                <Label className="text-xs font-bold text-slate-700">Statut</Label>
                <select
                  value={formData.statut || 'actif'}
                  onChange={e => handleInputChange('statut', e.target.value)}
                  className="w-full h-9 rounded border text-xs px-2 bg-white"
                >
                  <option value="actif">Actif</option>
                  <option value="inactif">Inactif</option>
                </select>
              </div>
              <div className="space-y-1">
                <Label className="text-xs font-bold text-slate-700">E-mail</Label>
                <Input 
                  type="email"
                  value={formData.email || ''} 
                  onChange={(e) => handleInputChange('email', e.target.value)} 
                  className="h-9 text-xs"
                />
              </div>
              <div className="space-y-1">
                <Label className="text-xs font-bold text-slate-700">Téléphone</Label>
                <Input 
                  value={formData.telephone || ''} 
                  onChange={(e) => handleInputChange('telephone', e.target.value)} 
                  className="h-9 text-xs"
                />
              </div>
              <div className="space-y-1">
                <Label className="text-xs font-bold text-slate-700">Spécialité (si médecin)</Label>
                <Input 
                  value={formData.specialite || ''} 
                  onChange={(e) => handleInputChange('specialite', e.target.value)} 
                  className="h-9 text-xs"
                  placeholder="Ex: Généraliste, Gynécologue..."
                />
              </div>
            </div>
            <div className="flex justify-end gap-2 pt-2 border-t">
              <Button type="button" variant="outline" size="sm" onClick={() => setFormOuvert(false)}>
                Annuler
              </Button>
              <Button type="submit" size="sm" className="bg-teal-600 hover:bg-teal-700 text-white font-semibold">
                {editionMode ? 'Sauvegarder les modifications' : 'Enregistrer'}
              </Button>
            </div>
          </form>
        </Card>
      )}

      <div className="space-y-2">
        {utilisateursFiltres.length === 0 ? (
          <div className="text-center py-12 text-slate-400">
            <AlertCircle className="w-12 h-12 mx-auto mb-2 opacity-50" />
            <p>Aucun utilisateur trouvé</p>
          </div>
        ) : (
          utilisateursFiltres.map((user) => (
            <Card key={user.id} className={user.statut === 'inactif' ? 'opacity-60' : ''}>
              <CardContent className="p-4 flex items-center justify-between flex-wrap gap-3">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-full bg-slate-100 flex items-center justify-center text-slate-600 font-bold text-sm">
                    {user.prenom[0] || ''}{user.nom[0] || ''}
                  </div>
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="font-semibold text-slate-900 dark:text-white">{user.prenom} {user.nom}</span>
                      <Badge variant="outline" className={ROLE_STYLES[user.role]}>
                        {ROLES.find(r => r.value === user.role)?.label || user.role}
                      </Badge>
                    </div>
                    <div className="flex items-center gap-3 text-xs text-slate-500 mt-1">
                      <span className="flex items-center gap-1"><Phone className="w-3 h-3"/> {user.telephone || '-'}</span>
                      <span className="flex items-center gap-1"><Mail className="w-3 h-3"/> {user.email || '-'}</span>
                      <span className="flex items-center gap-1"><User className="w-3 h-3"/> {user.nom_utilisateur}</span>
                    </div>
                  </div>
                </div>
                <div className="flex items-center gap-1">
                  <Button variant="ghost" size="sm" onClick={() => basculerStatut(user)}>
                    {user.statut === 'actif' ? <Power className="w-4 h-4 text-emerald-500" /> : <Ban className="w-4 h-4 text-slate-400" />}
                  </Button>
                  <Button variant="ghost" size="sm" onClick={() => { setFormData(user); setEditionMode(true); setFormOuvert(true); }}><Pencil className="w-4 h-4" /></Button>
                  <Button variant="ghost" size="sm" className="text-red-500" onClick={() => supprimerUtilisateur(user.id)}><Trash className="w-4 h-4" /></Button>
                </div>
              </CardContent>
            </Card>
          ))
        )}
      </div>
    </div>
  );
}