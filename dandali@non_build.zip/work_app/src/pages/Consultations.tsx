import React, { useState, useEffect, useMemo } from "react";
import { db } from "@/db";
import { interactions } from "../data/interactionData";
import { medicationsSeed } from "../data/medicationData";
import {
  Bed,
  Plus,
  Search,
  Trash,
  X,
  Stethoscope,
  FileText,
  FlaskConical,
  ChevronRight,
  CheckCircle2,
  UserPlus,
  Activity,
  Thermometer,
  Brain,
  Eye,
  Ear,
  Wind,
  Heart,
  Droplets,
  Printer,
  Pill,
  AlertTriangle,
  Info,
} from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { useAuth } from "@/hooks/useAuth";
import OrdonnancePreview from "@/components/OrdonnancePreview";

interface ConsultationField {
  id: string;
  label: string;
  icon: any;
  fields: {
    key: string;
    label: string;
    type: "text" | "select";
    options?: string[];
  }[];
}

const CONSULTATION_FIELDS: ConsultationField[] = [
  {
    id: "signes_vitaux",
    label: "A. Signes vitaux",
    icon: Activity,
    fields: [
      { key: "temperature", label: "Température (°C)", type: "text" },
      { key: "tension", label: "Tension artérielle (mmHg)", type: "text" },
      { key: "pouls", label: "Pouls (bpm)", type: "text" },
      { key: "frequence_respiratoire", label: "FR (/min)", type: "text" },
      { key: "saturation_o2", label: "Sat O2 (%)", type: "text" },
      { key: "poids", label: "Poids (kg)", type: "text" },
      { key: "taille", label: "Taille (cm)", type: "text" },
      { key: "glycemie", label: "Glycémie (g/L)", type: "text" },
    ],
  },
  {
    id: "examen_general",
    label: "B. Examen général",
    icon: Thermometer,
    fields: [
      {
        key: "etat_general",
        label: "État général",
        type: "select",
        options: ["Bon", "Moyen", "Altéré", "Grave"],
      },
      {
        key: "conscience",
        label: "Conscience",
        type: "select",
        options: ["Claire", "Obnubilée", "Confusion", "Coma"],
      },
      {
        key: "hydratation",
        label: "Hydratation",
        type: "select",
        options: ["Normale", "Déshydratation légère", "Déshydratation sévère"],
      },
      {
        key: "nutrition",
        label: "Nutrition",
        type: "select",
        options: ["Normale", "Maigreur", "Obésité", "Cachexie"],
      },
      {
        key: "douleur",
        label: "Douleur EVA",
        type: "select",
        options: ["0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "10"],
      },
      {
        key: "coloration_peau",
        label: "Coloration peau",
        type: "select",
        options: ["Normale", "Pâle", "Ictérique", "Cyanosée"],
      },
    ],
  },
  {
    id: "tete",
    label: "1. Tête",
    icon: Brain,
    fields: [
      {
        key: "tete_crane",
        label: "Crâne",
        type: "select",
        options: ["Normal", "Déformation", "Traumatisme"],
      },
      {
        key: "tete_cuir_chevelu",
        label: "Cuir chevelu",
        type: "select",
        options: ["Normal", "Lésions", "Alopécie"],
      },
    ],
  },
  {
    id: "yeux",
    label: "2. Yeux",
    icon: Eye,
    fields: [
      {
        key: "yeux_conjonctive",
        label: "Conjonctive",
        type: "select",
        options: ["Normale", "Pâle", "Ictérique"],
      },
      {
        key: "yeux_pupilles",
        label: "Pupilles",
        type: "select",
        options: ["Normales", "Anisocorie", "Mydriase", "Miosis"],
      },
      {
        key: "yeux_oculaire",
        label: "Mouvements oculaires",
        type: "select",
        options: ["Normaux", "Anormaux"],
      },
    ],
  },
  {
    id: "oreilles",
    label: "3. Oreilles",
    icon: Ear,
    fields: [
      {
        key: "oreilles_tympan",
        label: "Tympan",
        type: "select",
        options: ["Normal", "Perforation", "Inflammation"],
      },
      {
        key: "oreilles_conduit",
        label: "Conduit auditif",
        type: "select",
        options: ["Normal", "Bouchon cérumen", "Inflammation"],
      },
    ],
  },
  {
    id: "nez",
    label: "4. Nez",
    icon: Wind,
    fields: [
      {
        key: "nez_muqueuse",
        label: "Muqueuse",
        type: "select",
        options: ["Normale", "Hyperhémique", "Atrophique"],
      },
      {
        key: "nez_septum",
        label: "Septum",
        type: "select",
        options: ["Normal", "Dévié"],
      },
    ],
  },
  {
    id: "bouche",
    label: "5. Bouche",
    icon: Heart,
    fields: [
      {
        key: "bouche_dents",
        label: "Dents",
        type: "select",
        options: ["Bon état", "Carie", "Édentation"],
      },
      {
        key: "bouche_gencives",
        label: "Gencives",
        type: "select",
        options: ["Normales", "Inflammation", "Saignement"],
      },
      {
        key: "bouche_langue",
        label: "Langue",
        type: "select",
        options: ["Normale", "Fissurée", "Papillée"],
      },
    ],
  },
  {
    id: "gorge",
    label: "6. Gorge",
    icon: Brain,
    fields: [
      {
        key: "gorge_amygdales",
        label: "Amygdales",
        type: "select",
        options: ["Normales", "Hypertrophie", "Inflammation"],
      },
      {
        key: "gorge_pharynx",
        label: "Pharynx",
        type: "select",
        options: ["Normal", "Hyperhémique"],
      },
    ],
  },
  {
    id: "cou",
    label: "7. Cou",
    icon: Brain,
    fields: [
      {
        key: "cou_thyroide",
        label: "Thyroïde",
        type: "select",
        options: ["Normale", "Augmentation volume", "Nodules"],
      },
      {
        key: "cou_ganglions",
        label: "Ganglions",
        type: "select",
        options: ["Non palpables", "Palpables", "Adénopathies"],
      },
    ],
  },
  {
    id: "respiratoire",
    label: "8. Système respiratoire",
    icon: Wind,
    fields: [
      {
        key: "resp_toux",
        label: "Toux",
        type: "select",
        options: ["Non", "Sèche", "Grasse", "Hémoptysie"],
      },
      {
        key: "resp_dyspnee",
        label: "Dyspnée",
        type: "select",
        options: ["Non", "Légère", "Modérée", "Sévère"],
      },
      {
        key: "resp_auscultation",
        label: "Auscultation",
        type: "select",
        options: ["Normale", "Sibilants", "Crépitants", "Matité"],
      },
    ],
  },
  {
    id: "cardiovasculaire",
    label: "9. Système cardiovasculaire",
    icon: Heart,
    fields: [
      {
        key: "cardio_coeur",
        label: "Bruits du coeur",
        type: "select",
        options: ["Normaux", "Souffle", "B3"],
      },
      {
        key: "cardio_oedemes",
        label: "Œdèmes",
        type: "select",
        options: ["Non", "Pieds", "Généralisés"],
      },
    ],
  },
  {
    id: "abdomen",
    label: "10. Abdomen",
    icon: Activity,
    fields: [
      {
        key: "abdomen_souplesse",
        label: "Souplesse",
        type: "select",
        options: ["Souple", "Contracté", "Météorique"],
      },
      {
        key: "abdomen_douleur",
        label: "Douleur",
        type: "select",
        options: ["Non", "Diffuse", "Localisée"],
      },
      {
        key: "abdomen_visceromegalie",
        label: "Viscéromégalie",
        type: "select",
        options: ["Non", "Hépatomégalie", "Splénomégalie"],
      },
    ],
  },
  {
    id: "digestif",
    label: "11. Système digestif",
    icon: Droplets,
    fields: [
      {
        key: "digest_transit",
        label: "Transit",
        type: "select",
        options: ["Normal", "Constipation", "Diarrhée"],
      },
      {
        key: "digest_appetit",
        label: "Appétit",
        type: "select",
        options: ["Bon", "Diminué", "Anorexie"],
      },
    ],
  },
  {
    id: "psychologique",
    label: "12. Examen psychologique",
    icon: Brain,
    fields: [
      {
        key: "psy_humeur",
        label: "Humeur",
        type: "select",
        options: ["Normale", "Triste", "Anxieuse", "Irritable", "Euphorique"],
      },
      {
        key: "psy_comportement",
        label: "Comportement",
        type: "select",
        options: ["Normal", "Agressif", "Retiré", "Confus", "Désinhibé"],
      },
      {
        key: "psy_orientation",
        label: "Orientation espace/temps",
        type: "select",
        options: [
          "Bonne",
          "Temps perturbé",
          "Lieu perturbé",
          "Personne perturbée",
          "Désorienté",
        ],
      },
      {
        key: "psy_sommeil",
        label: "Sommeil",
        type: "select",
        options: ["Normal", "Insomnie", "Hypersomnie", "Cauchemars"],
      },
      {
        key: "psy_appetit",
        label: "Appétit psychologique",
        type: "select",
        options: ["Normal", "Anorexie", "Hyperphagie"],
      },
    ],
  },
  {
    id: "genital",
    label: "13. Système génital",
    icon: Heart,
    fields: [
      {
        key: "genital_regles",
        label: "Cycles menstruels",
        type: "select",
        options: ["N/A", "Réguliers", "Irréguliers", "Aménorrhée"],
      },
      {
        key: "genital_leucorrhees",
        label: "Leucorrhées",
        type: "select",
        options: ["N/A", "Non", "Oui"],
      },
    ],
  },
  {
    id: "nerveux",
    label: "14. Système nerveux",
    icon: Brain,
    fields: [
      {
        key: "nerveux_tremblements",
        label: "Tremblements",
        type: "select",
        options: ["Non", "Oui"],
      },
      {
        key: "nerveux_reflexes",
        label: "Réflexes",
        type: "select",
        options: ["Normaux", "Diminués", "Exagérés"],
      },
    ],
  },
  {
    id: "musculosquelettique",
    label: "15. Système musculo-squelettique",
    icon: Activity,
    fields: [
      {
        key: "musc_raideur",
        label: "Raideur matinale",
        type: "select",
        options: ["Non", "Oui"],
      },
      {
        key: "musc_deformations",
        label: "Déformations articulaires",
        type: "select",
        options: ["Non", "Oui"],
      },
    ],
  },
  {
    id: "peau",
    label: "16. Peau",
    icon: Eye,
    fields: [
      {
        key: "peau_etat",
        label: "État",
        type: "select",
        options: ["Normale", "Sèche", "Humide"],
      },
      {
        key: "peau_lesions",
        label: "Lésions",
        type: "select",
        options: ["Non", "Rash", "Ulcères", "Escarres"],
      },
    ],
  },
  {
    id: "membres",
    label: "17. Membres",
    icon: Activity,
    fields: [
      {
        key: "membres_superieurs",
        label: "Membres supérieurs",
        type: "select",
        options: ["Normaux", "Œdèmes", "Paralysie"],
      },
      {
        key: "membres_inferieurs",
        label: "Membres inférieurs",
        type: "select",
        options: ["Normaux", "Œdèmes", "Varices", "Ulcères"],
      },
    ],
  },
];

const DEFAULT_EXAMS = [
  "Hémogramme",
  "Glycémie",
  "Paludisme",
  "Selles",
  "Urine",
];

export default function Consultations() {
  const { canEdit, user } = useAuth() as any;
  const [consultations, setConsultations] = useState<any[]>([]);
  const [patients, setPatients] = useState<any[]>([]);
  const [view, setView] = useState<
    "consultations" | "newPatient" | "newConsultation"
  >("consultations");
  const [searchTerm, setSearchTerm] = useState("");
  const [loading, setLoading] = useState(true);
  const [form, setForm] = useState<Record<string, any>>({});
  const [patientForm, setPatientForm] = useState({
    numero_patient: "",
    nom_complet: "",
    age: "",
    sexe: "M",
    telephone: "",
    allergies: "",
  });
  const [selectedConsultation, setSelectedConsultation] = useState<any>(null);
  const [examResults, setExamResults] = useState<any[]>([]);
  const [availableExams, setAvailableExams] = useState<string[]>(DEFAULT_EXAMS);
  const [isExamsExpanded, setIsExamsExpanded] = useState(false);
  const [newExamInput, setNewExamInput] = useState("");
  const [activeSection, setActiveSection] = useState<string | null>(null);

  // --- Prescription Builder States Integrated into Consultations ---
  const [prescribeOrdonnance, setPrescribeOrdonnance] = useState(false);
  const [prescribedMedications, setPrescribedMedications] = useState<any[]>([]);
  const [showBaseMedicamentsModal, setShowBaseMedicamentsModal] =
    useState(false);
  const [baseSearchQuery, setBaseSearchQuery] = useState("");
  const [dbBaseMedicaments, setDbBaseMedicaments] = useState<any[]>([]);
  const [registeredMedications, setRegisteredMedications] = useState<any[]>([]);
  const [medSuggestions, setMedSuggestions] = useState<any[]>([]);
  const [showMedSuggestions, setShowMedSuggestions] = useState(false);
  const [ordonnancePreviewData, setOrdonnancePreviewData] = useState<
    any | null
  >(null);

  // Proactive Search states
  const [proactiveQueryA, setProactiveQueryA] = useState("");
  const [proactiveQueryB, setProactiveQueryB] = useState("");
  const [proactiveResult, setProactiveResult] = useState<any | null>(null);

  const [currentMed, setCurrentMed] = useState({
    brandName: "",
    dci: "",
    classTherapeutic: "",
    category: "",
    dosage: "",
    form: "Comprimé",
    quantity: 1,
    dosageInstructions: "",
    duration: "",
  });

  useEffect(() => {
    if (!showBaseMedicamentsModal) {
      setDbBaseMedicaments([]);
      return;
    }
    const searchVal = baseSearchQuery.trim().toLowerCase();
    if (!searchVal) {
      db.base_medicaments
        .limit(100)
        .toArray()
        .then((items) => {
          setDbBaseMedicaments(items);
        });
    } else {
      db.base_medicaments
        .filter(
          (bm) =>
            (bm.nom_medicament || "").toLowerCase().includes(searchVal) ||
            (bm.dci || "").toLowerCase().includes(searchVal) ||
            (bm.categorie || "").toLowerCase().includes(searchVal),
        )
        .limit(200)
        .toArray()
        .then((items) => {
          setDbBaseMedicaments(items);
        });
    }
  }, [showBaseMedicamentsModal, baseSearchQuery]);

  const getPatientById = (patientId: any) =>
    patients.find((p) => p.id === Number(patientId));

  const buildOrdonnancePreviewData = (sourceConsultation?: any) => {
    const consultation = sourceConsultation || form;
    const patient = getPatientById(consultation.patient_id);
    const meds = sourceConsultation
      ? safeParseMedications(
          sourceConsultation.ordonnance_medicaments_data ||
            sourceConsultation.ordonnance_data,
        )
      : prescribedMedications;

    return {
      patientNom:
        patient?.nom_complet || sourceConsultation?.patient_nom || "Patient",
      age: patient?.age
        ? Number(String(patient.age).replace(/[^0-9]/g, ""))
        : undefined,
      sexe: patient?.sexe === "F" ? "F" : "M",
      medecinNom: consultation.medecin || user?.username || "",
      date: new Date(
        sourceConsultation?.date_consultation || new Date(),
      ).toLocaleDateString("fr-FR"),
      diagnostic: consultation.diagnostic || "",
      conseils: consultation.conclusion || consultation.traitement || "",
      medicaments: meds.map((m: any) => ({
        brandName: m.brandName || m.nom_medicament || "",
        dci: m.dci || "",
        dosage: m.dosage || "",
        form: m.form || "",
        quantity: Number(m.quantity || 1),
        frequency: m.frequency || m.dosageInstructions || "",
        duration: m.duration || "",
      })),
      structure: {
        nom_clinique: "Clinique Médicale LAFIASSO",
        type_structure: "Structure sanitaire privée",
        adresse: "",
        telephone: "",
      },
    };
  };

  const safeParseMedications = (raw: any): any[] => {
    if (!raw) return [];
    if (Array.isArray(raw)) return raw;
    try {
      const parsed = JSON.parse(raw);
      return Array.isArray(parsed) ? parsed : [];
    } catch {
      return [];
    }
  };

  const detectedInteractions = useMemo(() => {
    if (prescribedMedications.length < 2) return [];
    const found: any[] = [];
    const seenPairs = new Set<string>();

    for (let i = 0; i < prescribedMedications.length; i++) {
      for (let j = i + 1; j < prescribedMedications.length; j++) {
        const medA = prescribedMedications[i];
        const medB = prescribedMedications[j];

        const dciA = (medA.dci || "").trim().toLowerCase();
        const brandA = (medA.brandName || "").trim().toLowerCase();
        const dciB = (medB.dci || "").trim().toLowerCase();
        const brandB = (medB.brandName || "").trim().toLowerCase();

        for (const inter of interactions) {
          const target1 = inter.drug1Dci.toLowerCase();
          const target2 = inter.drug2Dci.toLowerCase();

          const match1 =
            (dciA === target1 || brandA === target1) &&
            (dciB === target2 || brandB === target2);
          const match2 =
            (dciA === target2 || brandA === target2) &&
            (dciB === target1 || brandB === target1);

          if (match1 || match2) {
            const pairKey = [medA.medicationId, medB.medicationId]
              .sort()
              .join("-");
            if (!seenPairs.has(pairKey)) {
              seenPairs.add(pairKey);
              found.push({
                medA,
                medB,
                severity: inter.severity,
                description: inter.description,
                mechanism: inter.mechanism,
                recommendation: inter.recommendation,
              });
            }
          }
        }
      }
    }
    return found;
  }, [prescribedMedications]);

  // Handle proactive search check
  const handleProactiveCheck = () => {
    if (!proactiveQueryA || !proactiveQueryB) {
      setProactiveResult({
        status: "error",
        message: "Veuillez saisir les deux substances à analyser.",
      });
      return;
    }
    const qA = proactiveQueryA.trim().toLowerCase();
    const qB = proactiveQueryB.trim().toLowerCase();

    const matchInter = interactions.find((inter) => {
      const target1 = inter.drug1Dci.toLowerCase();
      const target2 = inter.drug2Dci.toLowerCase();
      return (
        (qA === target1 && qB === target2) || (qA === target2 && qB === target1)
      );
    });

    if (matchInter) {
      setProactiveResult({
        status: "danger",
        severity: matchInter.severity,
        description: matchInter.description,
        mechanism: matchInter.mechanism,
        recommendation: matchInter.recommendation,
        message: `⚠️ INTERACTION IDENTIFIÉE (${matchInter.severity.toUpperCase()}) : ${matchInter.description}`,
      });
    } else {
      setProactiveResult({
        status: "safe",
        message:
          "✅ Aucune interaction clinique majeure répertoriée entre ces deux substances dans la base de données hors ligne d'ANS/PDDI.",
      });
    }
  };

  const resetCurrentMed = () => {
    setCurrentMed({
      brandName: "",
      dci: "",
      classTherapeutic: "",
      category: "",
      dosage: "",
      form: "Comprimé",
      quantity: 1,
      dosageInstructions: "",
      duration: "",
    });
    setMedSuggestions([]);
    setShowMedSuggestions(false);
  };

  const normalizeMedSuggestion = (m: any) => ({
    brandName: m.nom_medicament || m.brandName || m.nom || "",
    dci: m.dci || m.dci_principale || "",
    classTherapeutic:
      m.classe_therapeutique || m.classTherapeutic || m.categorie || "",
    category: m.categorie || m.category || "",
    dosage: m.dosage || m.presentation || "",
    form: m.forme || m.form || "Comprimé",
  });

  const handleMedNameChange = async (val: string) => {
    setCurrentMed((prev) => ({ ...prev, brandName: val }));
    const q = val.trim().toLowerCase();
    if (q.length < 1) {
      setMedSuggestions([]);
      setShowMedSuggestions(false);
      return;
    }

    const localMatches = registeredMedications
      .filter(
        (m: any) =>
          (m.nom_medicament || m.brandName || m.nom || "")
            .toLowerCase()
            .includes(q) ||
          (m.dci || "").toLowerCase().includes(q) ||
          (m.categorie || m.classTherapeutic || "").toLowerCase().includes(q),
      )
      .slice(0, 25)
      .map(normalizeMedSuggestion);

    const seedMatches = medicationsSeed
      .filter(
        (m: any) =>
          (m.brandName || "").toLowerCase().includes(q) ||
          (m.dci || "").toLowerCase().includes(q) ||
          (m.classTherapeutic || "").toLowerCase().includes(q),
      )
      .slice(0, 25)
      .map(normalizeMedSuggestion);

    let dbMatches: any[] = [];
    try {
      const fromDb = await db.base_medicaments
        .filter(
          (bm: any) =>
            (bm.nom_medicament || "").toLowerCase().includes(q) ||
            (bm.dci || "").toLowerCase().includes(q) ||
            (bm.categorie || "").toLowerCase().includes(q),
        )
        .limit(25)
        .toArray();
      dbMatches = fromDb.map(normalizeMedSuggestion);
    } catch (err) {
      console.error("Erreur suggestion médicament:", err);
    }

    const seen = new Set<string>();
    const merged = [...localMatches, ...dbMatches, ...seedMatches]
      .filter((m: any) => {
        const key = `${(m.brandName || "").toLowerCase()}|${(m.dci || "").toLowerCase()}|${(m.dosage || "").toLowerCase()}`;
        if (!m.brandName || seen.has(key)) return false;
        seen.add(key);
        return true;
      })
      .slice(0, 12);

    setMedSuggestions(merged);
    setShowMedSuggestions(merged.length > 0);
  };

  const handleSelectMedSuggestion = (sug: any) => {
    setCurrentMed((prev) => ({
      ...prev,
      brandName: sug.brandName || "",
      dci: sug.dci || "",
      classTherapeutic: sug.classTherapeutic || "",
      category: sug.category || "specialite",
      dosage: sug.dosage || prev.dosage,
      form: sug.form || prev.form || "Comprimé",
    }));
    setShowMedSuggestions(false);
    setMedSuggestions([]);
    setPrescribeOrdonnance(true);
  };

  const addMedicationToPrescription = () => {
    const brandName = currentMed.brandName.trim();
    const dci = currentMed.dci.trim();
    if (!brandName && !dci) {
      toast.error(
        "Veuillez renseigner au moins le nom du médicament ou la DCI",
      );
      return;
    }
    setPrescribedMedications((prev) => [
      ...prev,
      {
        ...currentMed,
        medicationId: `${brandName || dci}-${Date.now()}`,
        brandName: brandName || dci,
        dci: dci || brandName,
        quantity: Number(currentMed.quantity) || 1,
      },
    ]);
    resetCurrentMed();
    setPrescribeOrdonnance(true);
  };

  const selectMedicineFromBase = (med: any) => {
    setCurrentMed((prev) => ({
      ...prev,
      brandName: med.nom_medicament || med.nom || med.brandName || "",
      dci: med.dci || med.dci_principale || "",
      classTherapeutic:
        med.classe_therapeutique || med.classTherapeutic || med.categorie || "",
      category: med.categorie || "",
      dosage: med.dosage || med.presentation || "",
      form: med.forme || med.form || "Comprimé",
    }));
    setShowBaseMedicamentsModal(false);
    setBaseSearchQuery("");
  };

  useEffect(() => {
    loadData();
  }, []);

  useEffect(() => {
    if (user && (view === "newConsultation" || !form.medecin)) {
      db.utilisateurs
        .where("nom_utilisateur")
        .equals(user.username || "")
        .first()
        .then((u) => {
          if (u) {
            const fullName = `${u.prenom || ""} ${u.nom || ""}`.trim();
            handleFormChange(
              "medecin",
              fullName || u.nom_utilisateur || user?.username || "",
            );
          } else {
            handleFormChange("medecin", user?.username || "");
          }
        })
        .catch(() => {
          handleFormChange("medecin", user?.username || "");
        });
    }
  }, [user, view]);

  async function loadData() {
    setLoading(true);
    try {
      const [cList, pList, labTypesList, labExamsList, baseMedsList] =
        await Promise.all([
          db.consultations.toArray(),
          db.patients_consultation.toArray(),
          db.typeExamensLaboratoire.toArray(),
          db.examensLaboratoire.toArray(),
          db.base_medicaments.toArray(),
        ]);
      setConsultations([...cList].reverse());
      setPatients([...pList]);
      setExamResults(labExamsList);
      setRegisteredMedications(baseMedsList);

      const activeLabTypeNames = labTypesList
        .filter((t) => t.actif !== false)
        .map((t) => t.nom);
      const uniqueExams = Array.from(
        new Set([...activeLabTypeNames, ...DEFAULT_EXAMS]),
      );
      setAvailableExams(uniqueExams);
    } catch (err) {
      console.error("Erreur chargement:", err);
      toast.error("Erreur de chargement");
    }
    setLoading(false);
  }

  const handleFormChange = (key: string, value: any) => {
    setForm((prev) => ({ ...prev, [key]: value }));
  };

  const toggleExam = (exam: string) => {
    const currentList = form.examens_complementaires || [];
    if (currentList.includes(exam)) {
      handleFormChange(
        "examens_complementaires",
        currentList.filter((e: string) => e !== exam),
      );
    } else {
      handleFormChange("examens_complementaires", [...currentList, exam]);
    }
  };

  const addCustomExam = () => {
    if (newExamInput.trim()) {
      if (!availableExams.includes(newExamInput.trim())) {
        setAvailableExams((prev) => [...prev, newExamInput.trim()]);
      }
      toggleExam(newExamInput.trim());
      setNewExamInput("");
    }
  };

  async function handleSavePatient(e: React.FormEvent) {
    e.preventDefault();
    if (!patientForm.nom_complet) {
      toast.error("Nom du patient requis");
      return;
    }
    try {
      const pId = await db.patients_consultation.add({
        numero_patient:
          patientForm.numero_patient ||
          `CON-${String(patients.length + 1).padStart(4, "0")}`,
        nom_complet: patientForm.nom_complet,
        age: patientForm.age,
        sexe: patientForm.sexe,
        telephone: patientForm.telephone,
        allergies: patientForm.allergies,
        created_at: new Date(),
      });
      toast.success("Patient ajouté à la liste des consultations");
      setForm((prev) => ({ ...prev, patient_id: String(pId) }));
      setView("newConsultation");
      setPatientForm({
        numero_patient: "",
        nom_complet: "",
        age: "",
        sexe: "M",
        telephone: "",
        allergies: "",
      });
      loadData();
    } catch (err) {
      toast.error("Erreur d'ajout du patient");
    }
  }

  const handleEditConsultation = (c: any) => {
    setForm({
      id: c.id,
      patient_id: String(c.patient_id),
      medecin: c.medecin,
      type_consultation: c.type_consultation || "générale",
      motif: c.motif,
      diagnostic: c.diagnostic || "",
      traitement: c.traitement || "",
      conclusion: c.conclusion || "",
      examens_complementaires_libres: c.examens_complementaires_libres || "",
      gravite: c.gravite || "non_urgente",
      _active_tab: "examen",

      // Vitaux
      temperature: c.temperature || "",
      tension: c.tension || "",
      pouls: c.pouls || "",
      frequence_respiratoire: c.frequence_respiratoire || "",
      saturation_o2: c.saturation_o2 || "",
      poids: c.poids || "",
      taille: c.taille || "",
      glycemie: c.glycemie || "",

      // Examen general
      etat_general: c.etat_general || "",
      conscience: c.conscience || "",
      hydratation: c.hydratation || "",
      nutrition: c.nutrition || "",
      douleur: c.douleur || "0",
      coloration_peau: c.coloration_peau || "",

      // Other system fields
      tete_crane: c.tete_crane || "",
      tete_cuir_chevelu: c.tete_cuir_chevelu || "",
      yeux_conjonctive: c.yeux_conjonctive || "",
      yeux_pupilles: c.yeux_pupilles || "",
      yeux_oculaire: c.yeux_oculaire || "",
      oreilles_tympan: c.oreilles_tympan || "",
      oreilles_conduit: c.oreilles_conduit || "",
      nez_muqueuse: c.nez_muqueuse || "",
      nez_septum: c.nez_septum || "",
      bouche_dents: c.bouche_dents || "",
      bouche_gencives: c.bouche_gencives || "",
      bouche_langue: c.bouche_langue || "",
      gorge_amygdales: c.gorge_amygdales || "",
      gorge_pharynx: c.gorge_pharynx || "",
      cou_thyroide: c.cou_thyroide || "",
      cou_ganglions: c.cou_ganglions || "",
      resp_toux: c.resp_toux || "",
      resp_dyspnee: c.resp_dyspnee || "",
      resp_auscultation: c.resp_auscultation || "",
      cardio_coeur: c.cardio_coeur || "",
      cardio_oedemes: c.cardio_oedemes || "",
      abdomen_souplesse: c.abdomen_souplesse || "",
      abdomen_douleur: c.abdomen_douleur || "",
      abdomen_visceromegalie: c.abdomen_visceromegalie || "",
      digest_transit: c.digest_transit || "",
      digest_appetit: c.digest_appetit || "",
      psy_humeur: c.psy_humeur || "",
      psy_comportement: c.psy_comportement || "",
      psy_orientation: c.psy_orientation || "",
      psy_sommeil: c.psy_sommeil || "",
      psy_appetit: c.psy_appetit || "",
      genital_regles: c.genital_regles || "",
      genital_leucorrhees: c.genital_leucorrhees || "",
      nerveux_tremblements: c.nerveux_tremblements || "",
      nerveux_reflexes: c.nerveux_reflexes || "",
      musc_raideur: c.musc_raideur || "",
      musc_deformations: c.musc_deformations || "",
      peau_etat: c.peau_etat || "",
      peau_lesions: c.peau_lesions || "",
      membres_superieurs: c.membres_superieurs || "",
      membres_inferieurs: c.membres_inferieurs || "",

      // Section obs
      signes_vitaux_obs: c.signes_vitaux_obs || "",
      examen_general_obs: c.examen_general_obs || "",
      tete_obs: c.tete_obs || "",
      yeux_obs: c.yeux_obs || "",
      oreilles_obs: c.oreilles_obs || "",
      nez_obs: c.nez_obs || "",
      bouche_obs: c.bouche_obs || "",
      gorge_obs: c.gorge_obs || "",
      cou_obs: c.cou_obs || "",
      respiratoire_obs: c.respiratoire_obs || "",
      cardiovasculaire_obs: c.cardiovasculaire_obs || "",
      abdomen_obs: c.abdomen_obs || "",
      digestif_obs: c.digestif_obs || "",
      psychologique_obs: c.psychologique_obs || "",
      genital_obs: c.genital_obs || "",
      nerveux_obs: c.nerveux_obs || "",
      musculosquelettique_obs: c.musculosquelettique_obs || "",
      peau_obs: c.peau_obs || "",
      membres_obs: c.membres_obs || "",

      examens_complementaires: examResults
        .filter((r) => r.consultation_id === c.id)
        .map((r) => r.type_analyse),
      rendez_vous_date: c.rendez_vous_date || "",
      rendez_vous_motif: c.rendez_vous_motif || "",
      rendez_vous_notes: c.rendez_vous_notes || "",
    });
    setSelectedConsultation(null);
    setView("newConsultation");
  };

  async function handleSaveConsultation(e: React.FormEvent) {
    e.preventDefault();
    if (!form.patient_id) {
      toast.error("Sélectionnez un patient");
      return;
    }

    try {
      const examensData: string[] = [];
      CONSULTATION_FIELDS.forEach((section) => {
        const fieldDetails: string[] = [];
        section.fields.forEach((f) => {
          const val = form[f.key];
          if (val && val !== "Non" && val !== "Normal" && val !== "--")
            fieldDetails.push(`${f.label}: ${val}`);
        });
        const obs = form[`${section.id}_obs`];
        if (obs) fieldDetails.push(`Obs: ${obs}`);
        if (fieldDetails.length > 0)
          examensData.push(`[${section.label}] ${fieldDetails.join(", ")}`);
      });

      const consObj: any = {
        patient_id: Number(form.patient_id),
        medecin: form.medecin,
        type_consultation: form.type_consultation || "générale",
        motif: form.motif,
        diagnostic: form.diagnostic || "",
        traitement: form.traitement || "",
        conclusion: form.conclusion || "",
        examen_clinique: examensData.join("\n"),
        examens_complementaires_libres:
          form.examens_complementaires_libres || "",
        gravite: form.gravite || "non_urgente",
        ordonnance_medicaments_data: prescribeOrdonnance
          ? JSON.stringify(prescribedMedications)
          : form.ordonnance_medicaments_data || "",
        ordonnance_integree:
          prescribeOrdonnance && prescribedMedications.length > 0,
        rendez_vous_date: form.rendez_vous_date || "",
        rendez_vous_motif: form.rendez_vous_motif || "",
        rendez_vous_notes: form.rendez_vous_notes || "",
      };

      // Also store raw fields to make it perfectly editable!
      CONSULTATION_FIELDS.forEach((section) => {
        section.fields.forEach((f) => {
          if (form[f.key] !== undefined) {
            consObj[f.key] = form[f.key];
          }
        });
        const obsKey = `${section.id}_obs`;
        if (form[obsKey] !== undefined) {
          consObj[obsKey] = form[obsKey];
        }
      });

      let finalConsId: number;

      if (form.id) {
        // Mode modification (update)
        finalConsId = Number(form.id);
        await db.consultations.update(finalConsId, consObj);

        // Update examensLaboratoire list (checklist test matches)
        const existingExams = examResults.filter(
          (r) => r.consultation_id === finalConsId,
        );
        const selectedExams = form.examens_complementaires || [];

        // Delete any existing exam request that was deselected
        for (const ex of existingExams) {
          if (!selectedExams.includes(ex.type_analyse)) {
            await db.examensLaboratoire.delete(ex.id);
          }
        }

        // Add newly selected exam requests
        const existingExamNames = existingExams.map((ex) => ex.type_analyse);
        for (const ex of selectedExams) {
          if (!existingExamNames.includes(ex)) {
            await db.examensLaboratoire.add({
              patient_id: Number(form.patient_id),
              consultation_id: finalConsId,
              type_analyse: ex,
              status: "demande",
              created_at: new Date(),
            });
          }
        }
        toast.success("Consultation mise à jour");
      } else {
        // Mode création (add)
        consObj.date_consultation = new Date();
        consObj.created_at = new Date();
        const consId = await db.consultations.add(consObj);
        finalConsId = consId;

        const selectedExams = form.examens_complementaires || [];
        for (const ex of selectedExams) {
          await db.examensLaboratoire.add({
            patient_id: Number(form.patient_id),
            consultation_id: consId,
            type_analyse: ex,
            status: "demande",
            created_at: new Date(),
          });
        }
        toast.success("Consultation enregistrée");
      }

      if (prescribeOrdonnance && prescribedMedications.length > 0) {
        const patient = patients.find((p) => p.id === Number(form.patient_id));
        const patientNom = patient ? patient.nom_complet : "Patient Inconnu";
        const medListStr = prescribedMedications
          .map(
            (m) =>
              `${m.brandName} ${m.dosage} (${m.form}) - Qté: ${m.quantity}`,
          )
          .join(", ");
        const combinedInstructions = prescribedMedications
          .map(
            (m) =>
              `${m.brandName}: ${m.dosageInstructions} pendant ${m.duration || "X jours"}`,
          )
          .join(". ");

        await db.ordonnances.add({
          patient_id: Number(form.patient_id),
          consultation_id: finalConsId,
          patient_nom: patientNom,
          médecin: form.medecin || "Dr. Traoré",
          medicaments: medListStr,
          medicaments_data: JSON.stringify(prescribedMedications),
          instructions: combinedInstructions,
          diagnostic: form.diagnostic || "",
          date_ordonnance: new Date(),
          created_at: new Date(),
        });
        await db.consultations.update(finalConsId, {
          ordonnance_medicaments_data: JSON.stringify(prescribedMedications),
          ordonnance_integree: true,
        });
        toast.success("Ordonnance de prescription générée automatiquement !");
      }

      if (form.rendez_vous_date) {
        const patient = patients.find((p) => p.id === Number(form.patient_id));
        await db.rendezVous.add({
          patient_id: Number(form.patient_id),
          consultation_id: finalConsId,
          patient_nom: patient?.nom_complet || "Patient",
          medecin: form.medecin || user?.username || "",
          date_rdv: form.rendez_vous_date,
          motif: form.rendez_vous_motif || form.conclusion || "Contrôle après consultation",
          notes: form.rendez_vous_notes || "",
          statut: "programme",
          created_at: new Date(),
        });
        toast.success("Rendez-vous enregistré dans la page Rendez-vous");
      }

      setPrescribeOrdonnance(false);
      setPrescribedMedications([]);
      setView("consultations");
      setForm({});
      loadData();
    } catch (err) {
      console.error("Save error:", err);
      toast.error("Erreur lors de l'enregistrement");
    }
  }

  const filteredConsultations = useMemo(() => {
    if (!searchTerm) return consultations;
    const term = searchTerm.toLowerCase();
    return consultations.filter((c) =>
      `${patients.find((p) => p.id === c.patient_id)?.nom_complet || ""} ${c.medecin} ${c.motif}`
        .toLowerCase()
        .includes(term),
    );
  }, [consultations, patients, searchTerm]);

  if (loading)
    return (
      <div className="flex items-center justify-center h-64 text-slate-500">
        Chargement...
      </div>
    );

  return (
    <div className="space-y-4">
      {view === "consultations" && (
        <div className="space-y-4">
          <div className="flex justify-between items-center">
            <div>
              <h2 className="text-xl font-bold">Consultations</h2>
              <p className="text-sm text-slate-500">
                {filteredConsultations.length} consultations
              </p>
            </div>
            {canEdit("consultations") && (
              <Button onClick={() => setView("newConsultation")}>
                <Plus className="w-4 h-4 mr-2" /> Nouvelle Consultation
              </Button>
            )}
          </div>

          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
            <Input
              placeholder="Rechercher une consultation..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-9"
            />
          </div>

          <Card>
            <CardContent className="p-0">
              <table className="w-full text-sm">
                <thead className="bg-slate-50">
                  <tr>
                    <th className="p-3 text-left">Date</th>
                    <th className="p-3 text-left">Patient</th>
                    <th className="p-3 text-left">Médecin</th>
                    <th className="p-3 text-left">Motif</th>
                    <th className="p-3 text-center">Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {filteredConsultations.map((c) => (
                    <tr key={c.id} className="border-t">
                      <td className="p-3">
                        {new Date(c.date_consultation).toLocaleDateString()}
                      </td>
                      <td className="p-3">
                        {
                          patients.find((p) => p.id === c.patient_id)
                            ?.nom_complet
                        }
                      </td>
                      <td className="p-3">{c.medecin}</td>
                      <td className="p-3">{c.motif}</td>
                      <td className="p-3 text-center flex items-center justify-center gap-1.5">
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => setSelectedConsultation(c)}
                          className="text-teal-600 hover:text-teal-800 hover:bg-teal-50"
                        >
                          Détails
                        </Button>
                        {canEdit("consultations") && (
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => handleEditConsultation(c)}
                            className="text-amber-600 hover:text-amber-800 hover:bg-amber-50"
                          >
                            Modifier
                          </Button>
                        )}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </CardContent>
          </Card>
        </div>
      )}

      {(view === "newConsultation" || view === "newPatient") && (
        <div className="max-w-3xl mx-auto space-y-4">
          <Button
            variant="ghost"
            onClick={() => setView("consultations")}
            className="mb-2"
          >
            <X className="w-4 h-4 mr-2" /> Fermer
          </Button>

          {view === "newPatient" && (
            <Card>
              <CardContent className="p-6">
                <h3 className="text-lg font-bold mb-4 text-slate-800 dark:text-white">
                  Création Nouveau Patient (Consultation)
                </h3>
                <form onSubmit={handleSavePatient} className="space-y-4">
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div className="space-y-1">
                      <Label>Nom Complet *</Label>
                      <Input
                        placeholder="Ex: Jean Dupont"
                        value={patientForm.nom_complet}
                        onChange={(e) =>
                          setPatientForm((p) => ({
                            ...p,
                            nom_complet: e.target.value,
                          }))
                        }
                        required
                      />
                    </div>
                    <div className="space-y-1">
                      <Label>Téléphone</Label>
                      <Input
                        placeholder="Ex: +223 76..."
                        value={patientForm.telephone}
                        onChange={(e) =>
                          setPatientForm((p) => ({
                            ...p,
                            telephone: e.target.value,
                          }))
                        }
                      />
                    </div>
                    <div className="space-y-1">
                      <Label>Âge</Label>
                      <Input
                        placeholder="Ex: 35 ans"
                        value={patientForm.age}
                        onChange={(e) =>
                          setPatientForm((p) => ({ ...p, age: e.target.value }))
                        }
                      />
                    </div>
                    <div className="space-y-1">
                      <Label>Sexe</Label>
                      <select
                        value={patientForm.sexe}
                        onChange={(e) =>
                          setPatientForm((p) => ({
                            ...p,
                            sexe: e.target.value,
                          }))
                        }
                        className="w-full h-10 rounded-md border border-input bg-transparent px-3 text-sm"
                      >
                        <option value="M">Masculin</option>
                        <option value="F">Féminin</option>
                      </select>
                    </div>
                    <div className="space-y-1 sm:col-span-2">
                      <Label>Allergies & Antécédents</Label>
                      <Textarea
                        placeholder="Allergies médicamenteuses, antécédents médicaux..."
                        value={patientForm.allergies}
                        onChange={(e) =>
                          setPatientForm((p) => ({
                            ...p,
                            allergies: e.target.value,
                          }))
                        }
                        rows={2}
                      />
                    </div>
                  </div>
                  <div className="flex justify-end gap-2 pt-2">
                    <Button
                      type="button"
                      variant="outline"
                      onClick={() => setView("newConsultation")}
                    >
                      Annuler
                    </Button>
                    <Button
                      type="submit"
                      className="bg-teal-600 hover:bg-teal-700 text-white"
                    >
                      Enregistrer le patient
                    </Button>
                  </div>
                </form>
              </CardContent>
            </Card>
          )}

          {view === "newConsultation" && (
            <Card>
              <CardContent className="p-6">
                <h3 className="text-lg font-bold mb-4 text-slate-800 dark:text-white flex items-center gap-2">
                  <Stethoscope className="text-teal-600 w-5 h-5" /> Saisie
                  Nouvelle Consultation
                </h3>
                <form onSubmit={handleSaveConsultation} className="space-y-5">
                  {/* Patient Selector */}
                  <div className="space-y-1">
                    <Label className="text-sm font-semibold">
                      Patient Consultant *
                    </Label>
                    <div className="flex gap-2">
                      <select
                        value={form.patient_id || ""}
                        onChange={(e) =>
                          handleFormChange("patient_id", e.target.value)
                        }
                        className="flex-1 h-10 rounded-md border border-input bg-transparent px-3 text-sm focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring"
                        required
                      >
                        <option value="">Sélectionner un patient...</option>
                        {patients.map((p) => (
                          <option key={p.id} value={p.id}>
                            {p.nom_complet} {p.age ? `(${p.age})` : ""} -{" "}
                            {p.telephone || "Pas de tel"}
                          </option>
                        ))}
                      </select>
                      <Button
                        type="button"
                        variant="outline"
                        onClick={() => setView("newPatient")}
                        title="Créer un nouveau patient"
                        className="bg-slate-50 hover:bg-slate-100"
                      >
                        <UserPlus className="w-4 h-4 mr-1 text-teal-600" />{" "}
                        Nouveau
                      </Button>
                    </div>
                  </div>

                  {/* Consultation Meta */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div className="space-y-1">
                      <Label>Médecin Consultant *</Label>
                      <Input
                        placeholder="Ex: Dr. Traoré"
                        value={form.medecin || ""}
                        onChange={(e) =>
                          handleFormChange("medecin", e.target.value)
                        }
                        required
                        disabled
                        className="bg-slate-100 cursor-not-allowed dark:bg-slate-800"
                      />
                    </div>
                    <div className="space-y-1">
                      <Label>Type de Consultation</Label>
                      <select
                        value={form.type_consultation || "générale"}
                        onChange={(e) =>
                          handleFormChange("type_consultation", e.target.value)
                        }
                        className="w-full h-10 rounded-md border border-input bg-transparent px-3 text-sm"
                      >
                        <option value="générale">Générale</option>
                        <option value="spécialisée">Spécialisée</option>
                        <option value="contrôle">Contrôle / Suivi</option>
                        <option value="urgence">Urgence</option>
                      </select>
                    </div>
                  </div>

                  {/* Reason for Visit */}
                  <div className="space-y-1">
                    <Label>Motif de consultation *</Label>
                    <Input
                      placeholder="Ex: Fièvre persistante depuis 3 jours, céphalées"
                      value={form.motif || ""}
                      onChange={(e) =>
                        handleFormChange("motif", e.target.value)
                      }
                      required
                    />
                  </div>

                  {/* Tabs Selector for Examen vs Diagnostic */}
                  <div className="flex gap-1 bg-slate-100 dark:bg-slate-800 p-1 rounded-lg w-fit">
                    {["examen", "diagnostic"].map((tab) => (
                      <button
                        key={tab}
                        type="button"
                        onClick={() => handleFormChange("_active_tab", tab)}
                        className={`px-4 py-2 rounded-md text-sm font-medium transition-colors ${
                          (form._active_tab || "examen") === tab
                            ? "bg-white dark:bg-slate-900 shadow-sm text-slate-950 dark:text-slate-100"
                            : "text-slate-600 dark:text-slate-400 hover:text-slate-900"
                        }`}
                      >
                        {tab === "examen"
                          ? "Examen Médical"
                          : "Diagnostic & Conduite"}
                      </button>
                    ))}
                  </div>

                  {/* Examen Médical Tab Content */}
                  {(form._active_tab || "examen") === "examen" && (
                    <div className="space-y-2">
                      {CONSULTATION_FIELDS.map((section) => {
                        const isExpanded = activeSection === section.id;
                        return (
                          <div
                            key={section.id}
                            className="border rounded-lg overflow-hidden border-slate-200 dark:border-slate-700"
                          >
                            <button
                              type="button"
                              className="w-full flex items-center gap-2 p-2.5 bg-slate-50 hover:bg-slate-100 dark:bg-slate-800 dark:hover:bg-slate-700 text-left text-sm font-medium transition-all"
                              onClick={() =>
                                setActiveSection(isExpanded ? null : section.id)
                              }
                            >
                              <section.icon className="w-4 h-4 text-teal-600 dark:text-teal-400" />
                              <span className="text-slate-800 dark:text-slate-200">
                                {section.label}
                              </span>
                              <ChevronRight
                                className={`w-4 h-4 ml-auto text-slate-400 transition-transform ${isExpanded ? "rotate-90" : ""}`}
                              />
                            </button>
                            {isExpanded && (
                              <div className="p-4 space-y-4 bg-white dark:bg-slate-900 border-t border-slate-100 dark:border-slate-800">
                                <div className="grid grid-cols-2 gap-3">
                                  {section.fields.map((f) => (
                                    <div key={f.key} className="space-y-1">
                                      <Label className="text-xs text-slate-500 dark:text-slate-400">
                                        {f.label}
                                      </Label>
                                      {f.type === "select" ? (
                                        <select
                                          value={form[f.key] || ""}
                                          onChange={(e) =>
                                            handleFormChange(
                                              f.key,
                                              e.target.value,
                                            )
                                          }
                                          className="w-full h-8 rounded border border-input bg-transparent px-2 text-xs focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring dark:bg-slate-800 dark:border-slate-700"
                                        >
                                          <option value="">--</option>
                                          {f.options?.map((opt) => (
                                            <option key={opt} value={opt}>
                                              {opt}
                                            </option>
                                          ))}
                                        </select>
                                      ) : (
                                        <Input
                                          placeholder="--"
                                          value={form[f.key] || ""}
                                          onChange={(e) =>
                                            handleFormChange(
                                              f.key,
                                              e.target.value,
                                            )
                                          }
                                          className="h-8 text-xs bg-white dark:bg-slate-800 dark:border-slate-700"
                                        />
                                      )}
                                    </div>
                                  ))}
                                </div>
                                <div className="space-y-1">
                                  <Label className="text-xs text-slate-500 dark:text-slate-400">
                                    Autres observations
                                  </Label>
                                  <Textarea
                                    placeholder="Observations..."
                                    value={form[`${section.id}_obs`] || ""}
                                    onChange={(e) =>
                                      handleFormChange(
                                        `${section.id}_obs`,
                                        e.target.value,
                                      )
                                    }
                                    rows={2}
                                    className="text-xs bg-white dark:bg-slate-800 dark:border-slate-700"
                                  />
                                </div>
                              </div>
                            )}
                          </div>
                        );
                      })}
                    </div>
                  )}

                  {/* Diagnostic & Conduite Tab Content */}
                  {(form._active_tab || "examen") === "diagnostic" && (
                    <div className="space-y-6">
                      {/* Labs Tests checklist */}
                      <div className="space-y-2 border rounded-lg p-4 bg-slate-50 dark:bg-slate-900 border-slate-100 dark:border-slate-800">
                        <div className="flex items-center justify-between">
                          <Label className="text-sm font-semibold flex items-center gap-1.5 text-slate-700 dark:text-slate-200">
                            <FlaskConical className="w-4 h-4 text-amber-600 dark:text-amber-400" />{" "}
                            Examens complémentaires demandés (Laboratoire)
                          </Label>
                          <Button
                            type="button"
                            variant="ghost"
                            size="sm"
                            onClick={() => setIsExamsExpanded(!isExamsExpanded)}
                            className="text-xs text-indigo-600 hover:text-indigo-800 dark:text-indigo-400 dark:hover:text-indigo-300"
                          >
                            {isExamsExpanded
                              ? "Masquer"
                              : "Afficher la liste des examens"}
                          </Button>
                        </div>

                        {isExamsExpanded && (
                          <div className="p-4 bg-white dark:bg-slate-800 rounded-lg border dark:border-slate-700 space-y-3">
                            <div className="flex flex-wrap gap-2.5">
                              {availableExams.map((ex) => {
                                const isChecked = (
                                  form.examens_complementaires || []
                                ).includes(ex);
                                return (
                                  <button
                                    type="button"
                                    key={ex}
                                    onClick={() => toggleExam(ex)}
                                    className={`px-3 py-1.5 rounded-full text-xs font-medium border transition-colors flex items-center gap-1.5 ${
                                      isChecked
                                        ? "bg-teal-100 border-teal-300 text-teal-800 dark:bg-teal-900/40 dark:border-teal-700 dark:text-teal-300"
                                        : "bg-white border-slate-200 text-slate-600 hover:bg-slate-50 dark:bg-slate-900 dark:border-slate-700 dark:text-slate-400"
                                    }`}
                                  >
                                    {isChecked && (
                                      <span className="w-1.5 h-1.5 rounded-full bg-teal-600 dark:bg-teal-400" />
                                    )}
                                    {ex}
                                  </button>
                                );
                              })}
                            </div>
                            <div className="flex gap-2 max-w-sm">
                              <Input
                                placeholder="Autre examen (Ex: NFS, Créatinine)"
                                value={newExamInput}
                                onChange={(e) =>
                                  setNewExamInput(e.target.value)
                                }
                                className="bg-white dark:bg-slate-900 h-9 text-xs border-slate-200"
                              />
                              <Button
                                type="button"
                                size="sm"
                                onClick={addCustomExam}
                                className="bg-indigo-600 hover:bg-indigo-700 text-white"
                              >
                                Ajouter
                              </Button>
                            </div>
                          </div>
                        )}
                      </div>

                      {/* Saisie libre d'examens complémentaires */}
                      <div className="space-y-1.5 p-4 border rounded-lg bg-teal-50/20 dark:bg-slate-900 border-teal-100 dark:border-slate-800">
                        <Label className="text-xs font-semibold text-teal-800 dark:text-teal-300 flex items-center gap-1.5">
                          <FileText className="w-4 h-4 text-teal-600 dark:text-teal-450" />
                          Examens complémentaires (Saisie libre - Échographie,
                          Radiographie, Scanner, ECG...)
                        </Label>
                        <Textarea
                          placeholder="Saisissez ici tout examen complémentaire requis (ex: Échographie abdomino-pelvienne, ECG à l'effort, Radiographie pulmonaire...)"
                          value={form.examens_complementaires_libres || ""}
                          onChange={(e) =>
                            handleFormChange(
                              "examens_complementaires_libres",
                              e.target.value,
                            )
                          }
                          rows={2}
                          className="bg-white dark:bg-slate-950 text-xs border-slate-200"
                        />
                      </div>

                      {/* Diagnostics & Treatment */}

                      {/* Ordonnance intégrée à la consultation */}
                      <div className="space-y-4 border rounded-xl p-4 bg-white dark:bg-slate-900 border-emerald-100 dark:border-slate-800">
                        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                          <div>
                            <Label className="text-sm font-bold text-emerald-800 dark:text-emerald-300 flex items-center gap-2">
                              <Pill className="w-4 h-4" /> Ordonnance à établir
                              en fin de consultation
                            </Label>
                            <p className="text-xs text-slate-500 mt-1">
                              Le médecin prescrit ici directement. L’ordonnance
                              sera enregistrée avec la consultation et restera
                              imprimable.
                            </p>
                          </div>
                          <label className="flex items-center gap-2 text-xs font-semibold text-slate-700 dark:text-slate-200">
                            <input
                              type="checkbox"
                              checked={prescribeOrdonnance}
                              onChange={(e) =>
                                setPrescribeOrdonnance(e.target.checked)
                              }
                            />
                            Générer une ordonnance
                          </label>
                        </div>

                        <div className="grid grid-cols-1 md:grid-cols-2 gap-3 p-3 rounded-lg bg-amber-50/60 dark:bg-amber-950/20 border border-amber-100 dark:border-amber-900/40">
                          <div className="md:col-span-2 flex items-center gap-2 text-xs font-bold text-amber-800 dark:text-amber-300">
                            <AlertTriangle className="w-4 h-4" /> Recherche
                            d’interaction avant prescription
                          </div>
                          <Input
                            placeholder="Substance / DCI 1 ex: Warfarine"
                            value={proactiveQueryA}
                            onChange={(e) => setProactiveQueryA(e.target.value)}
                            className="bg-white dark:bg-slate-950"
                          />
                          <Input
                            placeholder="Substance / DCI 2 ex: Aspirine"
                            value={proactiveQueryB}
                            onChange={(e) => setProactiveQueryB(e.target.value)}
                            className="bg-white dark:bg-slate-950"
                          />
                          <div className="md:col-span-2 flex flex-wrap items-center gap-2">
                            <Button
                              type="button"
                              size="sm"
                              variant="outline"
                              onClick={handleProactiveCheck}
                            >
                              Vérifier avant prescription
                            </Button>
                            {proactiveResult && (
                              <span
                                className={`text-xs font-semibold px-3 py-2 rounded border ${proactiveResult.status === "danger" ? "bg-red-50 text-red-800 border-red-200" : proactiveResult.status === "safe" ? "bg-emerald-50 text-emerald-800 border-emerald-200" : "bg-slate-50 text-slate-700 border-slate-200"}`}
                              >
                                {proactiveResult.message}
                              </span>
                            )}
                          </div>
                          {proactiveResult?.status === "danger" && (
                            <div className="md:col-span-2 text-xs bg-white dark:bg-slate-950 rounded border p-3 space-y-1">
                              <p>
                                <strong>Mécanisme :</strong>{" "}
                                {proactiveResult.mechanism || "Non précisé"}
                              </p>
                              <p>
                                <strong>Conduite :</strong>{" "}
                                {proactiveResult.recommendation ||
                                  "Surveillance clinique recommandée"}
                              </p>
                            </div>
                          )}
                        </div>

                        <div className="grid grid-cols-1 md:grid-cols-6 gap-2">
                          <div className="md:col-span-2 relative">
                            <Input
                              placeholder="Nom médicament"
                              value={currentMed.brandName}
                              onChange={(e) =>
                                handleMedNameChange(e.target.value)
                              }
                              onFocus={() => {
                                if (
                                  currentMed.brandName.trim() &&
                                  medSuggestions.length > 0
                                )
                                  setShowMedSuggestions(true);
                              }}
                              onBlur={() =>
                                setTimeout(
                                  () => setShowMedSuggestions(false),
                                  180,
                                )
                              }
                              className="bg-white dark:bg-slate-950"
                            />
                            {showMedSuggestions &&
                              medSuggestions.length > 0 && (
                                <div className="absolute left-0 right-0 top-full mt-1 z-50 max-h-64 overflow-y-auto rounded-md border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 shadow-xl divide-y divide-slate-100 dark:divide-slate-800">
                                  {medSuggestions.map((sug: any, i: number) => (
                                    <button
                                      key={`${sug.brandName}-${sug.dci}-${i}`}
                                      type="button"
                                      className="w-full text-left p-2.5 text-xs hover:bg-emerald-50 dark:hover:bg-emerald-950/40"
                                      onMouseDown={(e) => {
                                        e.preventDefault();
                                        handleSelectMedSuggestion(sug);
                                      }}
                                    >
                                      <div className="font-bold text-emerald-700 dark:text-emerald-300">
                                        {sug.brandName}{" "}
                                        {sug.dosage ? `— ${sug.dosage}` : ""}
                                      </div>
                                      <div className="text-[11px] text-slate-500 dark:text-slate-400">
                                        {sug.dci || "DCI non précisée"}{" "}
                                        {sug.form ? `• ${sug.form}` : ""}{" "}
                                        {sug.classTherapeutic
                                          ? `• ${sug.classTherapeutic}`
                                          : ""}
                                      </div>
                                    </button>
                                  ))}
                                </div>
                              )}
                          </div>
                          <div className="md:col-span-2">
                            <Input
                              placeholder="DCI"
                              value={currentMed.dci}
                              onChange={(e) =>
                                setCurrentMed((prev) => ({
                                  ...prev,
                                  dci: e.target.value,
                                }))
                              }
                              className="bg-white dark:bg-slate-950"
                            />
                          </div>
                          <Input
                            placeholder="Dosage"
                            value={currentMed.dosage}
                            onChange={(e) =>
                              setCurrentMed((prev) => ({
                                ...prev,
                                dosage: e.target.value,
                              }))
                            }
                            className="bg-white dark:bg-slate-950"
                          />
                          <Input
                            placeholder="Forme"
                            value={currentMed.form}
                            onChange={(e) =>
                              setCurrentMed((prev) => ({
                                ...prev,
                                form: e.target.value,
                              }))
                            }
                            className="bg-white dark:bg-slate-950"
                          />
                          <div className="md:col-span-3">
                            <Input
                              placeholder="Posologie ex: 1 cp matin et soir"
                              value={currentMed.dosageInstructions}
                              onChange={(e) =>
                                setCurrentMed((prev) => ({
                                  ...prev,
                                  dosageInstructions: e.target.value,
                                }))
                              }
                              className="bg-white dark:bg-slate-950"
                            />
                          </div>
                          <Input
                            placeholder="Durée"
                            value={currentMed.duration}
                            onChange={(e) =>
                              setCurrentMed((prev) => ({
                                ...prev,
                                duration: e.target.value,
                              }))
                            }
                            className="bg-white dark:bg-slate-950"
                          />
                          <Input
                            type="number"
                            min="1"
                            placeholder="Qté"
                            value={currentMed.quantity}
                            onChange={(e) =>
                              setCurrentMed((prev) => ({
                                ...prev,
                                quantity: Number(e.target.value) || 1,
                              }))
                            }
                            className="bg-white dark:bg-slate-950"
                          />
                          <div className="md:col-span-1 flex gap-2">
                            <Button
                              type="button"
                              size="sm"
                              variant="outline"
                              onClick={() => setShowBaseMedicamentsModal(true)}
                            >
                              Base
                            </Button>
                            <Button
                              type="button"
                              size="sm"
                              className="bg-emerald-600 hover:bg-emerald-700 text-white"
                              onClick={addMedicationToPrescription}
                            >
                              Ajouter
                            </Button>
                          </div>
                        </div>

                        {detectedInteractions.length > 0 && (
                          <div className="rounded-lg border border-red-200 bg-red-50 p-3 text-xs text-red-900 space-y-2">
                            <div className="font-bold flex items-center gap-2">
                              <AlertTriangle className="w-4 h-4" /> Interactions
                              détectées automatiquement dans l’ordonnance
                            </div>
                            {detectedInteractions.map((it, idx) => (
                              <div
                                key={idx}
                                className="bg-white border border-red-100 rounded p-2"
                              >
                                <strong>{it.medA.brandName}</strong> +{" "}
                                <strong>{it.medB.brandName}</strong> —{" "}
                                {it.severity}
                                <br />
                                {it.description}
                                <br />
                                <span className="font-semibold">
                                  Conduite :
                                </span>{" "}
                                {it.recommendation || "À surveiller"}
                              </div>
                            ))}
                          </div>
                        )}

                        <div className="space-y-2">
                          {prescribedMedications.length === 0 ? (
                            <p className="text-xs text-slate-400 italic">
                              Aucun médicament ajouté à l’ordonnance.
                            </p>
                          ) : (
                            prescribedMedications.map((m, idx) => (
                              <div
                                key={m.medicationId || idx}
                                className="flex items-center justify-between gap-3 rounded-lg border p-2 text-xs bg-slate-50 dark:bg-slate-950 dark:border-slate-800"
                              >
                                <div>
                                  <strong>{m.brandName}</strong>{" "}
                                  {m.dosage && <span>({m.dosage})</span>} —{" "}
                                  {m.form} — Qté {m.quantity}
                                  <br />
                                  <span className="text-slate-500">
                                    DCI: {m.dci || "N/A"} •{" "}
                                    {m.dosageInstructions ||
                                      "Posologie non précisée"}{" "}
                                    • {m.duration || "Durée non précisée"}
                                  </span>
                                </div>
                                <Button
                                  type="button"
                                  size="sm"
                                  variant="ghost"
                                  onClick={() =>
                                    setPrescribedMedications((prev) =>
                                      prev.filter((_, i) => i !== idx),
                                    )
                                  }
                                >
                                  <Trash className="w-4 h-4 text-red-500" />
                                </Button>
                              </div>
                            ))
                          )}
                          {prescribedMedications.length > 0 && (
                            <div className="flex justify-end pt-2">
                              <Button
                                type="button"
                                variant="outline"
                                size="sm"
                                onClick={() =>
                                  setOrdonnancePreviewData(
                                    buildOrdonnancePreviewData(),
                                  )
                                }
                              >
                                <Printer className="w-4 h-4 mr-2" />{" "}
                                Prévisualiser / Imprimer l’ordonnance
                              </Button>
                            </div>
                          )}
                        </div>
                      </div>

                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                        <div className="space-y-1">
                          <Label>
                            Hypothèse Diagnostic / Diagnostic retenu
                          </Label>
                          <Textarea
                            placeholder="Symptômes cliniques évocateurs de..."
                            value={form.diagnostic || ""}
                            onChange={(e) =>
                              handleFormChange("diagnostic", e.target.value)
                            }
                            rows={3}
                            className="bg-white dark:bg-slate-900"
                          />
                        </div>
                        <div className="space-y-1">
                          <Label>Traitement prescrit / Conduite à tenir</Label>
                          <Textarea
                            placeholder="Médicaments prescrits, posologie, conseils diététiques..."
                            value={form.traitement || ""}
                            onChange={(e) =>
                              handleFormChange("traitement", e.target.value)
                            }
                            rows={3}
                            className="bg-white dark:bg-slate-900"
                          />
                        </div>
                        <div className="space-y-1 sm:col-span-2">
                          <Label>Conclusions & Recommandations</Label>
                          <Input
                            placeholder="Ex: À revoir dans 48h si pas d'amélioration."
                            value={form.conclusion || ""}
                            onChange={(e) =>
                              handleFormChange("conclusion", e.target.value)
                            }
                            className="bg-white dark:bg-slate-900"
                          />
                        </div>
                      </div>
                    </div>
                  )}


                    <div className="rounded-xl border border-purple-100 bg-purple-50/50 p-4 space-y-3">
                      <div>
                        <h4 className="font-bold text-sm text-purple-800">Rendez-vous de contrôle</h4>
                        <p className="text-xs text-purple-700">Le médecin peut fixer ici le rendez-vous en fin de consultation. La page Rendez-vous l’affichera automatiquement.</p>
                      </div>
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                        <div className="space-y-1">
                          <Label>Date et heure du rendez-vous</Label>
                          <Input
                            type="datetime-local"
                            value={form.rendez_vous_date || ""}
                            onChange={(e) => handleFormChange("rendez_vous_date", e.target.value)}
                            className="bg-white"
                          />
                        </div>
                        <div className="space-y-1">
                          <Label>Motif du rendez-vous</Label>
                          <Input
                            placeholder="Contrôle, résultat, suivi traitement..."
                            value={form.rendez_vous_motif || ""}
                            onChange={(e) => handleFormChange("rendez_vous_motif", e.target.value)}
                            className="bg-white"
                          />
                        </div>
                        <div className="space-y-1 sm:col-span-2">
                          <Label>Notes pour le rendez-vous</Label>
                          <Textarea
                            rows={2}
                            placeholder="Consignes avant le rendez-vous..."
                            value={form.rendez_vous_notes || ""}
                            onChange={(e) => handleFormChange("rendez_vous_notes", e.target.value)}
                            className="bg-white"
                          />
                        </div>
                      </div>
                    </div>

                  {/* Save actions */}
                  <div className="flex justify-end gap-2 border-t pt-4">
                    <Button
                      type="button"
                      variant="outline"
                      onClick={() => setView("consultations")}
                    >
                      Annuler
                    </Button>
                    <Button
                      type="submit"
                      className="bg-teal-600 hover:bg-teal-700 text-white"
                    >
                      Enregistrer la Consultation
                    </Button>
                  </div>
                </form>
              </CardContent>
            </Card>
          )}
        </div>
      )}

      {showBaseMedicamentsModal && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-white dark:bg-slate-900 rounded-xl max-w-3xl w-full max-h-[85vh] flex flex-col shadow-2xl border border-slate-200 dark:border-slate-800">
            <div className="p-4 border-b flex items-center justify-between">
              <h3 className="font-bold text-slate-800 dark:text-white">
                Rechercher dans la base des médicaments
              </h3>
              <Button
                type="button"
                variant="ghost"
                size="sm"
                onClick={() => setShowBaseMedicamentsModal(false)}
              >
                <X className="w-5 h-5" />
              </Button>
            </div>
            <div className="p-4 space-y-3 overflow-y-auto">
              <Input
                autoFocus
                placeholder="Rechercher par nom, DCI ou catégorie..."
                value={baseSearchQuery}
                onChange={(e) => setBaseSearchQuery(e.target.value)}
              />
              <div className="grid grid-cols-1 gap-2">
                {dbBaseMedicaments.length === 0 ? (
                  <p className="text-sm text-slate-500 italic">
                    Aucun médicament trouvé.
                  </p>
                ) : (
                  dbBaseMedicaments.map((med: any) => (
                    <button
                      key={med.id}
                      type="button"
                      onClick={() => selectMedicineFromBase(med)}
                      className="text-left p-3 rounded-lg border hover:bg-teal-50 dark:hover:bg-slate-800 dark:border-slate-800"
                    >
                      <div className="font-bold text-sm text-slate-800 dark:text-white">
                        {med.nom_medicament || med.nom || med.brandName}
                      </div>
                      <div className="text-xs text-slate-500">
                        DCI: {med.dci || "N/A"} •{" "}
                        {med.categorie ||
                          med.classe_therapeutique ||
                          "Non classé"}
                      </div>
                    </button>
                  ))
                )}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Consultation Details modal */}
      {selectedConsultation && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-white dark:bg-slate-900 rounded-xl max-w-2xl w-full max-h-[85vh] flex flex-col shadow-2xl border border-slate-200 dark:border-slate-800 animate-in fade-in zoom-in-95 duration-150">
            <div className="p-5 border-b border-slate-100 dark:border-slate-800 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-lg bg-teal-50 dark:bg-teal-950 flex items-center justify-center text-teal-600 dark:text-teal-400">
                  <Stethoscope className="w-4 h-4" />
                </div>
                <h3 className="font-bold text-slate-800 dark:text-white text-base">
                  Fiche Clinique de Consultation
                </h3>
              </div>
              <Button
                variant="ghost"
                size="sm"
                onClick={() => setSelectedConsultation(null)}
                className="hover:bg-slate-100 dark:hover:bg-slate-800"
              >
                <X className="w-5 h-5" />
              </Button>
            </div>

            <div className="p-6 overflow-y-auto space-y-4 text-slate-700 dark:text-slate-300">
              <div className="grid grid-cols-2 gap-4 bg-slate-50 dark:bg-slate-900/40 p-4 rounded-lg text-xs">
                <div>
                  <p className="text-slate-400 font-medium text-[10px] uppercase">
                    Patient
                  </p>
                  <p className="font-bold text-slate-800 dark:text-slate-200">
                    {patients.find(
                      (p) => p.id === selectedConsultation.patient_id,
                    )?.nom_complet || "Inconnu"}
                  </p>
                </div>
                <div>
                  <p className="text-slate-400 font-medium text-[10px] uppercase">
                    Médecin Prescripteur
                  </p>
                  <p className="font-bold text-slate-800 dark:text-slate-200">
                    {selectedConsultation.medecin}
                  </p>
                </div>
                <div>
                  <p className="text-slate-400 font-medium text-[10px] uppercase">
                    Date de consultation
                  </p>
                  <p className="font-semibold text-slate-800 dark:text-slate-200">
                    {new Date(
                      selectedConsultation.date_consultation,
                    ).toLocaleString("fr-FR")}
                  </p>
                </div>
                <div>
                  <p className="text-slate-400 font-medium text-[10px] uppercase">
                    Type de consultation
                  </p>
                  <p className="font-semibold text-slate-800 dark:text-slate-205 capitalize">
                    {selectedConsultation.type_consultation || "Générale"} (
                    {selectedConsultation.gravite === "urgente"
                      ? "Prioritaire / Urgente"
                      : "Routine"}
                    )
                  </p>
                </div>
              </div>

              <div className="space-y-1">
                <h4 className="font-bold text-xs uppercase tracking-wider text-slate-400">
                  Motif de consultation
                </h4>
                <div className="text-xs bg-slate-50/50 dark:bg-slate-950 p-3 rounded border dark:border-slate-850 whitespace-pre-line text-slate-800 dark:text-slate-200">
                  {selectedConsultation.motif || "Aucun motif spécifié"}
                </div>
              </div>

              <div className="space-y-1">
                <h4 className="font-bold text-xs uppercase tracking-wider text-slate-400">
                  Observations / Examen Clinique
                </h4>
                <div className="text-xs bg-slate-50/50 dark:bg-slate-950 p-3 rounded border dark:border-slate-850 whitespace-pre-line text-slate-800 dark:text-slate-300">
                  {selectedConsultation.examen_clinique ||
                    "Aucune observation clinique saisie."}
                </div>
              </div>

              <div className="space-y-1">
                <h4 className="font-bold text-xs uppercase tracking-wider text-teal-600 dark:text-teal-400">
                  Examens complémentaires demandés
                </h4>
                <div className="bg-white dark:bg-slate-900 p-3.5 rounded-lg border dark:border-slate-800 space-y-3 shadow-inner">
                  <div>
                    <span className="text-[10px] font-bold text-slate-400 uppercase">
                      1. Analyses cochées (Laboratoire) :
                    </span>
                    <div className="space-y-2 mt-1.5">
                      {examResults.filter(
                        (r) => r.consultation_id === selectedConsultation.id,
                      ).length > 0 ? (
                        examResults
                          .filter(
                            (r) =>
                              r.consultation_id === selectedConsultation.id,
                          )
                          .map((r, idx) => (
                            <div
                              key={r.id || idx}
                              className="flex flex-col sm:flex-row sm:items-center justify-between p-2 rounded-lg border border-slate-100 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-900/30 gap-2"
                            >
                              <div className="flex items-center gap-2">
                                <span className="text-xs font-semibold text-slate-800 dark:text-slate-200">
                                  {r.type_analyse}
                                </span>
                                <Badge
                                  variant="outline"
                                  className={`text-[9px] ${r.status === "valide" ? "bg-emerald-50 text-emerald-800 border-emerald-200 dark:bg-emerald-950/40 dark:text-emerald-350 dark:border-emerald-800" : "bg-amber-50 text-amber-800 border-amber-200 dark:bg-amber-950/40 dark:text-amber-350 dark:border-amber-800"}`}
                                >
                                  {r.status === "valide"
                                    ? "Résultat disponible"
                                    : "En attente"}
                                </Badge>
                              </div>

                              <div className="flex items-center gap-2 ml-auto">
                                {r.status === "valide" && (
                                  <span className="text-xs font-medium text-slate-600 dark:text-slate-400 bg-white dark:bg-slate-950 px-2 py-1 rounded border dark:border-slate-850">
                                    {r.resultat}
                                  </span>
                                )}

                                <div className="flex items-center gap-1">
                                  <input
                                    type="text"
                                    placeholder="Saisir résultat..."
                                    defaultValue={r.resultat || ""}
                                    id={`details-res-input-${r.id}`}
                                    className="h-7 text-xs px-2 rounded border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-950 text-slate-850 dark:text-slate-100 w-32"
                                  />
                                  <Button
                                    size="sm"
                                    className="h-7 px-2 text-[10px] bg-teal-600 hover:bg-teal-700 text-white"
                                    onClick={async (e) => {
                                      e.preventDefault();
                                      const val = (
                                        document.getElementById(
                                          `details-res-input-${r.id}`,
                                        ) as HTMLInputElement
                                      )?.value;
                                      if (val !== undefined) {
                                        await db.examensLaboratoire.update(
                                          r.id,
                                          {
                                            resultat: val,
                                            status: "valide",
                                            updated_at: new Date(),
                                          },
                                        );
                                        toast.success("Résultat enregistré");
                                        loadData(); // Reload results
                                      }
                                    }}
                                  >
                                    Enregistrer
                                  </Button>
                                </div>
                              </div>
                            </div>
                          ))
                      ) : (
                        <span className="text-xs text-slate-400 block italic">
                          Aucun examen coché.
                        </span>
                      )}
                    </div>
                  </div>

                  <div className="pt-2 border-t border-slate-100 dark:border-slate-800">
                    <span className="text-[10px] font-bold text-slate-400 uppercase">
                      2. Saisie libre (Imagerie, radio, spécialités) :
                    </span>
                    <p className="text-xs mt-1 text-slate-700 dark:text-slate-300 font-medium bg-slate-50 dark:bg-slate-950 p-2.5 rounded whitespace-pre-line min-h-[40px]">
                      {selectedConsultation.examens_complementaires_libres ||
                        "Aucune saisie libre renseignée pour ces examens."}
                    </p>
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-1">
                <div className="space-y-1">
                  <h4 className="font-bold text-xs uppercase tracking-wider text-teal-600 dark:text-teal-400">
                    Diagnostic retenu
                  </h4>
                  <div className="text-xs bg-emerald-50/50 dark:bg-emerald-950/20 p-3 rounded border border-emerald-100 dark:border-emerald-900/50 text-slate-800 dark:text-slate-100 whitespace-pre-line font-medium">
                    {selectedConsultation.diagnostic || "Non spécifié"}
                  </div>
                </div>
                <div className="space-y-1">
                  <h4 className="font-bold text-xs uppercase tracking-wider text-teal-600 dark:text-teal-400">
                    Prescription / Conduite à tenir
                  </h4>
                  <div className="text-xs bg-teal-55/10 dark:bg-teal-950/20 p-3 rounded border border-teal-100 dark:border-teal-900/50 text-slate-800 dark:text-slate-200 whitespace-pre-line font-medium">
                    {selectedConsultation.traitement ||
                      "Conseils repos / pas de traitement requis"}
                  </div>
                </div>
              </div>

              {selectedConsultation.rendez_vous_date && (
                <div className="rounded-lg border border-purple-100 bg-purple-50/60 p-3 text-xs">
                  <h4 className="font-bold uppercase tracking-wider text-purple-700 mb-1">Rendez-vous donné</h4>
                  <p><strong>Date :</strong> {new Date(selectedConsultation.rendez_vous_date).toLocaleString("fr-FR")}</p>
                  <p><strong>Motif :</strong> {selectedConsultation.rendez_vous_motif || "Contrôle"}</p>
                  {selectedConsultation.rendez_vous_notes && <p><strong>Notes :</strong> {selectedConsultation.rendez_vous_notes}</p>}
                </div>
              )}

              {safeParseMedications(
                selectedConsultation.ordonnance_medicaments_data ||
                  selectedConsultation.ordonnance_data,
              ).length > 0 && (
                <div className="space-y-2">
                  <div className="flex items-center justify-between gap-2">
                    <h4 className="font-bold text-xs uppercase tracking-wider text-teal-600 dark:text-teal-400">
                      Ordonnance liée à cette consultation
                    </h4>
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() =>
                        setOrdonnancePreviewData(
                          buildOrdonnancePreviewData(selectedConsultation),
                        )
                      }
                    >
                      <Printer className="w-4 h-4 mr-2" /> Imprimer l’ordonnance
                    </Button>
                  </div>
                  <div className="rounded-lg border border-teal-100 dark:border-teal-900/50 bg-teal-50/40 dark:bg-teal-950/20 p-3 space-y-2 text-xs">
                    {safeParseMedications(
                      selectedConsultation.ordonnance_medicaments_data ||
                        selectedConsultation.ordonnance_data,
                    ).map((m: any, idx: number) => (
                      <div
                        key={idx}
                        className="border-b last:border-b-0 border-teal-100/70 pb-2 last:pb-0"
                      >
                        <strong>
                          {idx + 1}. {m.brandName || m.nom_medicament}
                        </strong>{" "}
                        {m.dosage && <span>({m.dosage})</span>}{" "}
                        {m.form && <span>— {m.form}</span>}
                        <br />
                        <span className="text-slate-600 dark:text-slate-300">
                          DCI: {m.dci || "N/A"} • Posologie:{" "}
                          {m.dosageInstructions ||
                            m.frequency ||
                            "Non précisée"}{" "}
                          • Durée: {m.duration || "Non précisée"} • Qté:{" "}
                          {m.quantity || 1}
                        </span>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {selectedConsultation.conclusion && (
                <div className="space-y-1">
                  <h4 className="font-bold text-xs uppercase tracking-wider text-slate-400 font-medium">
                    Recommandations additionnelles
                  </h4>
                  <div className="text-xs bg-slate-50 dark:bg-slate-950 p-2.5 rounded italic border border-dashed text-slate-600 dark:text-slate-450">
                    "{selectedConsultation.conclusion}"
                  </div>
                </div>
              )}
            </div>

            <div className="p-4 bg-slate-50 dark:bg-slate-900/60 border-t border-slate-100 dark:border-slate-800 flex justify-end gap-2">
              {canEdit("consultations") && (
                <Button
                  size="sm"
                  variant="outline"
                  className="border-amber-250 text-amber-800 hover:bg-amber-50"
                  onClick={() => handleEditConsultation(selectedConsultation)}
                >
                  Modifier cette fiche
                </Button>
              )}
              <Button
                size="sm"
                className="bg-teal-600 hover:bg-teal-700 text-white"
                onClick={() => setSelectedConsultation(null)}
              >
                Fermer
              </Button>
            </div>
          </div>
        </div>
      )}

      {ordonnancePreviewData && (
        <OrdonnancePreview
          {...ordonnancePreviewData}
          onClose={() => setOrdonnancePreviewData(null)}
        />
      )}
    </div>
  );
}
