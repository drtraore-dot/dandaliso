import React, { useState, useEffect } from 'react';
import { db } from '@/db';
import { Bed, Plus, Search, X, Building, Tag } from 'lucide-react';
import { toast } from 'react-hot-toast';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';

interface Chambre {
  id?: number;
  numero: string;
  type: 'Standard' | 'VIP' | 'Suite';
  etage: string;
  prix_journalier: number;
  equipements: string;
  statut: 'disponible' | 'occupee' | 'maintenance';
  created_at: Date;
}

export default function Chambres() {
  const [chambres, setChambres] = useState<Chambre[]>([]);
  const [search, setSearch] = useState("");
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [newChambre, setNewChambre] = useState<Omit<Chambre, 'id' | 'created_at' | 'statut'>>({
    numero: "",
    type: "Standard",
    etage: "",
    prix_journalier: 0,
    equipements: ""
  });

  useEffect(() => {
    fetchChambres();
  }, []);

  async function fetchChambres() {
    const data = await db.chambres.toArray();
    setChambres(data);
  }

  async function handleCreateChambre(e: React.FormEvent) {
    e.preventDefault();
    await db.chambres.add({
      ...newChambre,
      statut: 'disponible',
      created_at: new Date()
    });
    toast.success("Chambre créée");
    setIsModalOpen(false);
    fetchChambres();
  }

  const filteredChambres = chambres.filter(c => 
    c.numero.toLowerCase().includes(search.toLowerCase()) || 
    c.type.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div className="space-y-4">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-lg bg-orange-500 flex items-center justify-center">
            <Bed className="w-5 h-5 text-white" />
          </div>
          <div>
            <h2 className="text-lg font-semibold">Chambres</h2>
            <p className="text-sm text-slate-500">
              {chambres.length} chambre(s) - {chambres.filter(c => c.statut === "disponible").length} disponible(s)
            </p>
          </div>
        </div>
        <Button onClick={() => setIsModalOpen(true)} className="bg-teal-600 hover:bg-teal-700">
          <Plus className="w-4 h-4 mr-1" /> Nouvelle
        </Button>
      </div>

      <div className="relative">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
        <Input 
          placeholder="Rechercher..." 
          value={search} 
          onChange={(e) => setSearch(e.target.value)} 
          className="pl-10" 
        />
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
        {filteredChambres.map((c) => (
          <Card key={c.id} className={c.statut === "occupee" ? "border-red-200" : "border-emerald-200"}>
            <CardContent className="p-4">
              <div className="flex justify-between items-start">
                <div>
                  <p className="font-bold text-lg">{c.numero}</p>
                  <p className="text-sm text-slate-500">{c.type} - {c.etage}</p>
                  <p className="text-sm">{c.prix_journalier.toLocaleString()} FCFA/jour</p>
                  <p className="text-xs text-slate-400">{c.equipements}</p>
                </div>
                <Badge className={c.statut === "disponible" ? "bg-emerald-100 text-emerald-700" : c.statut === "occupee" ? "bg-red-100 text-red-700" : "bg-amber-100 text-amber-700"}>
                  {c.statut}
                </Badge>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {isModalOpen && (
        <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4">
          <div className="bg-white dark:bg-slate-800 rounded-lg shadow-xl max-w-md w-full">
            <div className="flex items-center justify-between p-4 border-b border-slate-200 dark:border-slate-700">
              <h3 className="text-lg font-semibold">Nouvelle Chambre</h3>
              <button onClick={() => setIsModalOpen(false)} className="p-1 hover:bg-slate-100 rounded">
                <X className="w-5 h-5" />
              </button>
            </div>
            <form onSubmit={handleCreateChambre} className="p-4 space-y-3">
              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1">
                  <Label>Numero</Label>
                  <Input value={newChambre.numero} onChange={e => setNewChambre({...newChambre, numero: e.target.value})} required />
                </div>
                <div className="space-y-1">
                  <Label>Type</Label>
                  <select value={newChambre.type} onChange={e => setNewChambre({...newChambre, type: e.target.value as any})} className="w-full h-10 rounded-md border border-input bg-transparent px-3 py-1 text-sm">
                    <option value="Standard">Standard</option>
                    <option value="VIP">VIP</option>
                    <option value="Suite">Suite</option>
                  </select>
                </div>
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1">
                  <Label>Etage</Label>
                  <Input value={newChambre.etage} onChange={e => setNewChambre({...newChambre, etage: e.target.value})} />
                </div>
                <div className="space-y-1">
                  <Label>Prix journalier</Label>
                  <Input type="number" value={newChambre.prix_journalier} onChange={e => setNewChambre({...newChambre, prix_journalier: Number(e.target.value)})} />
                </div>
              </div>
              <div className="space-y-1">
                <Label>Equipements</Label>
                <Input value={newChambre.equipements} onChange={e => setNewChambre({...newChambre, equipements: e.target.value})} />
              </div>
              <div className="flex justify-end gap-2">
                <Button type="button" variant="outline" onClick={() => setIsModalOpen(false)}>Annuler</Button>
                <Button type="submit" className="bg-teal-600 hover:bg-teal-700">Créer</Button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}