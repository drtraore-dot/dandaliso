import React, { useState, useEffect } from 'react';
import { db } from '@/db';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell } from 'recharts';
import { LayoutDashboard, TrendingUp, RefreshCw } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';

interface Recette {
  id: number;
  date: string;
  montant: number;
  libelle: string;
}

interface Depense {
  id: number;
  date: string;
  montant: number;
  type_depense: string;
}

interface Consultation {
  id: number;
  date_consultation: string;
}

const COLORS = ['#0d9488', '#06b6d4', '#8b5cf6', '#f59e0b', '#ef4444', '#10b981', '#6366f1', '#ec4899'];

export function detectCategory(recette: any): string {
  if (recette.categorie) {
    const c = String(recette.categorie);
    return c.charAt(0).toUpperCase() + c.slice(1);
  }
  const lib = (recette.libelle || "").toLowerCase();
  if (lib.includes("pharmacie") || lib.includes("médicament") || lib.includes("medicament") || lib.includes("vente")) {
    return "Pharmacie";
  }
  if (lib.includes("examen") || lib.includes("analyse") || lib.includes("labo") || lib.includes("laboratoire") || lib.includes("coagulation") || lib.includes("biochimie") || lib.includes("hemato") || lib.includes("sérologie") || lib.includes("parasito")) {
    return "Laboratoire";
  }
  if (lib.includes("consultation") || lib.includes("visite") || lib.includes("généraliste") || lib.includes("spécialiste")) {
    return "Consultation";
  }
  if (lib.includes("soin") || lib.includes("pansement") || lib.includes("injection") || lib.includes("perfusion") || lib.includes("soins")) {
    return "Soins Infirmiers";
  }
  if (lib.includes("hospitalisation") || lib.includes("chambre") || lib.includes("lit") || lib.includes("séjour")) {
    return "Hospitalisation";
  }
  return "Autre / Actes Divers";
}

export default function Rapports() {
  const [recettes, setRecettes] = useState<Recette[]>([]);
  const [depenses, setDepenses] = useState<Depense[]>([]);
  const [consultations, setConsultations] = useState<Consultation[]>([]);
  
  const [periode, setPeriode] = useState("jour");
  const [dateDebut, setDateDebut] = useState("");
  const [dateFin, setDateFin] = useState("");
  const [view, setView] = useState<"finance" | "activite">("finance");
  const [selectedCategory, setSelectedCategory] = useState("tous");

  useEffect(() => {
    const fetchData = async () => {
      const r = await db.table('recettes').toArray();
      const d = await db.table('depenses').toArray();
      const c = await db.table('consultations').toArray();
      setRecettes(r);
      setDepenses(d);
      setConsultations(c);
    };
    fetchData();
  }, []);

  const isWithinPeriod = (dateStr: string) => {
    const date = new Date(dateStr);
    if (dateDebut) {
      const start = new Date(dateDebut);
      start.setHours(0, 0, 0, 0);
      if (date < start) return false;
    }
    if (dateFin) {
      const end = new Date(dateFin);
      end.setHours(23, 59, 59);
      if (date > end) return false;
    }
    if (!dateDebut && !dateFin) {
      const now = new Date();
      if (periode === "jour") return date.toDateString() === now.toDateString();
      if (periode === "semaine") {
        const weekAgo = new Date(now);
        weekAgo.setDate(weekAgo.getDate() - 7);
        return date >= weekAgo;
      }
      if (periode === "mois") return date.getMonth() === now.getMonth() && date.getFullYear() === now.getFullYear();
      if (periode === "année") return date.getFullYear() === now.getFullYear();
    }
    return true;
  };

  const filteredRecettes = recettes.filter(r => {
    if (!isWithinPeriod(r.date)) return false;
    if (selectedCategory !== "tous" && detectCategory(r) !== selectedCategory) return false;
    return true;
  });
  const filteredDepenses = depenses.filter(d => isWithinPeriod(d.date));
  const filteredConsultations = consultations.filter(c => isWithinPeriod(c.date_consultation));

  const totalRecettes = filteredRecettes.reduce((acc, curr) => acc + curr.montant, 0);
  const totalDepenses = filteredDepenses.reduce((acc, curr) => acc + curr.montant, 0);

  const recettesData = Object.entries(filteredRecettes.reduce((acc: Record<string, number>, curr) => {
    const key = new Date(curr.date).toLocaleDateString("fr-FR", { day: "numeric", month: "short" });
    acc[key] = (acc[key] || 0) + curr.montant;
    return acc;
  }, {})).map(([name, value]) => ({ name, value }));

  const receiptsByCategoryData = Object.entries(
    recettes.filter(r => isWithinPeriod(r.date)).reduce((acc: Record<string, number>, curr) => {
      const cat = detectCategory(curr);
      acc[cat] = (acc[cat] || 0) + curr.montant;
      return acc;
    }, {})
  ).map(([name, value]) => ({ name, value }));

  const depensesData = Object.entries(filteredDepenses.reduce((acc: Record<string, number>, curr) => {
    const key = curr.type_depense || "Autre";
    acc[key] = (acc[key] || 0) + curr.montant;
    return acc;
  }, {})).map(([name, value]) => ({ name, value }));

  return (
    <div className="space-y-4">
      <div className="flex items-center gap-3">
        <div className="w-10 h-10 rounded-lg bg-indigo-500 flex items-center justify-center">
          <LayoutDashboard className="w-5 h-5 text-white" />
        </div>
        <div>
          <h2 className="text-lg font-semibold">Rapports & Statistiques</h2>
        </div>
      </div>

      <Card>
        <CardContent className="p-4">
          <div className="flex flex-wrap items-end gap-3">
            <div className="space-y-1">
              <Label className="text-xs text-slate-500">Période</Label>
              <select value={periode} onChange={(e) => setPeriode(e.target.value)} className="h-10 px-3 rounded-md border border-input bg-background text-sm">
                <option value="jour">Aujourd'hui</option>
                <option value="semaine">Semaine</option>
                <option value="mois">Mois</option>
                <option value="année">Année</option>
              </select>
            </div>
            <div className="space-y-1">
              <Label className="text-xs text-slate-500">Du</Label>
              <Input type="date" value={dateDebut} onChange={(e) => setDateDebut(e.target.value)} className="w-36" />
            </div>
            <div className="space-y-1">
              <Label className="text-xs text-slate-500">Au</Label>
              <Input type="date" value={dateFin} onChange={(e) => setDateFin(e.target.value)} className="w-36" />
            </div>

            <div className="space-y-1">
              <Label className="text-xs text-slate-500">Filtrer les recettes (Entrées)</Label>
              <select 
                value={selectedCategory} 
                onChange={(e) => setSelectedCategory(e.target.value)} 
                className="h-10 px-3 rounded-md border border-input bg-background text-sm font-medium text-emerald-700"
              >
                <option value="tous">Toutes les catégories d'entrée</option>
                <option value="Pharmacie">💊 Pharmacie (Ventes)</option>
                <option value="Consultation">🩺 Consultations</option>
                <option value="Laboratoire">🧪 Laboratoire & Examens</option>
                <option value="Soins Infirmiers">🩹 Soins Infirmiers</option>
                <option value="Hospitalisation">🛌 Hospitalisation</option>
                <option value="Autre / Actes Divers">📂 Autres actes divers</option>
              </select>
            </div>

            {(dateDebut || dateFin || selectedCategory !== "tous") && (
              <Button variant="ghost" size="sm" onClick={() => { setDateDebut(""); setDateFin(""); setSelectedCategory("tous"); }} className="text-xs h-9">
                <RefreshCw className="w-3 h-3 mr-2" /> Réinitialiser
              </Button>
            )}
          </div>
        </CardContent>
      </Card>

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        <Card><CardContent className="p-4"><p className="text-xs text-slate-500">Recettes {selectedCategory !== "tous" ? `(${selectedCategory})` : ""}</p><p className="text-lg font-bold text-emerald-600">{totalRecettes.toLocaleString()} FCFA</p></CardContent></Card>
        <Card><CardContent className="p-4"><p className="text-xs text-slate-500">Dépenses</p><p className="text-lg font-bold text-red-600">{totalDepenses.toLocaleString()} FCFA</p></CardContent></Card>
        <Card><CardContent className="p-4"><p className="text-xs text-slate-500">Bénéfice</p><p className="text-lg font-bold text-blue-600">{(totalRecettes - totalDepenses).toLocaleString()} FCFA</p></CardContent></Card>
        <Card><CardContent className="p-4"><p className="text-xs text-slate-500">Consultations</p><p className="text-lg font-bold text-teal-600">{filteredConsultations.length}</p></CardContent></Card>
      </div>

      <div className="flex gap-1 bg-slate-100 p-1 rounded-lg w-fit">
        <button onClick={() => setView("finance")} className={`px-4 py-2 rounded-md text-sm font-medium transition-colors ${view === "finance" ? "bg-white shadow-sm" : "text-slate-600"}`}>Finance</button>
        <button onClick={() => setView("activite")} className={`px-4 py-2 rounded-md text-sm font-medium transition-colors ${view === "activite" ? "bg-white shadow-sm" : "text-slate-600"}`}>Activité</button>
      </div>

      {view === "finance" && (
        <div className="space-y-4">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
            <Card className="lg:col-span-1">
              <CardHeader><CardTitle className="text-sm">Répartition des Recettes</CardTitle></CardHeader>
              <CardContent>
                {receiptsByCategoryData.length === 0 ? (
                  <p className="text-xs text-slate-400 text-center py-8">Aucune recette sur cette période</p>
                ) : (
                  <div className="space-y-3">
                    <ResponsiveContainer width="100%" height={160}>
                      <PieChart>
                        <Pie data={receiptsByCategoryData} dataKey="value" outerRadius={60} innerRadius={35}>
                          {receiptsByCategoryData.map((_, index) => <Cell key={index} fill={COLORS[index % COLORS.length]} />)}
                        </Pie>
                        <Tooltip formatter={(v) => `${Number(v).toLocaleString()} F`} />
                      </PieChart>
                    </ResponsiveContainer>
                    <div className="space-y-1.5 overflow-y-auto max-h-[140px] pr-1">
                      {receiptsByCategoryData.map((item, index) => (
                        <div key={item.name} className="flex justify-between items-center text-xs">
                          <span className="flex items-center gap-1.5 text-slate-650 font-medium">
                            <span className="w-2.5 h-2.5 rounded-full inline-block shrink-0" style={{ backgroundColor: COLORS[index % COLORS.length] }} />
                            {item.name}
                          </span>
                          <span className="font-bold text-slate-800">{item.value.toLocaleString()} F</span>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            <Card className="lg:col-span-1">
              <CardHeader><CardTitle className="text-sm">Séquence des Recettes</CardTitle></CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={260}>
                  <BarChart data={recettesData}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
                    <XAxis dataKey="name" stroke="#94a3b8" fontSize={10} />
                    <YAxis stroke="#94a3b8" fontSize={10} />
                    <Tooltip contentStyle={{ borderRadius: "8px" }} formatter={(v) => `${Number(v).toLocaleString()} F`} />
                    <Bar dataKey="value" fill="#0d9488" radius={[4, 4, 0, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>

            <Card className="lg:col-span-1">
              <CardHeader><CardTitle className="text-sm">Dépenses par catégorie</CardTitle></CardHeader>
              <CardContent>
                {depensesData.length === 0 ? (
                  <p className="text-xs text-slate-400 text-center py-8">Aucune dépense sur cette période</p>
                ) : (
                  <div className="space-y-2">
                    <ResponsiveContainer width="100%" height={160}>
                      <PieChart>
                        <Pie data={depensesData} dataKey="value" outerRadius={60}>
                          {depensesData.map((_, index) => <Cell key={index} fill={COLORS[(index + 4) % COLORS.length]} />)}
                        </Pie>
                        <Tooltip formatter={(v) => `${Number(v).toLocaleString()} F`} />
                      </PieChart>
                    </ResponsiveContainer>
                    <div className="space-y-1 text-xs">
                      {depensesData.map((item, index) => (
                        <div key={item.name} className="flex justify-between items-center">
                          <span className="flex items-center gap-1 text-slate-500">
                            <span className="w-2 h-2 rounded-full inline-block" style={{ backgroundColor: COLORS[(index + 4) % COLORS.length] }} />
                            {item.name}
                          </span>
                          <span className="font-bold">{item.value.toLocaleString()} F</span>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        </div>
      )}
    </div>
  );
}