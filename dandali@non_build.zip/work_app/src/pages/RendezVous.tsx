import React, { useState, useEffect } from 'react';
import { db } from '@/db';
import { Calendar, Search } from 'lucide-react';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { toast } from 'sonner';

interface RendezVous {
  id?: number;
  patient_id: number;
  date_rdv: Date;
  médecin: string;
  motif: string;
  statut: string;
  notes: string;
  created_at: Date;
}

interface Patient {
  id: number;
  nom_complet: string;
}

export const RendezVousPage: React.FC = () => {
  const [rendezVousList, setRendezVousList] = useState<RendezVous[]>([]);
  const [patients, setPatients] = useState<Patient[]>([]);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [searchTerm, setSearchTerm] = useState("");
  const [formData, setFormData] = useState({
    patient_id: "",
    date_rdv: new Date().toISOString().slice(0, 16),
    médecin: "",
    motif: "",
    statut: "planifie",
    notes: ""
  });

  const fetchData = async () => {
    const rdv = await db.rendezVous.toArray();
    const pts = await db.patients.toArray();
    setRendezVousList(rdv);
    setPatients(pts);
  };

  useEffect(() => {
    fetchData();
  }, []);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    await db.rendezVous.add({
      patient_id: Number(formData.patient_id),
      date_rdv: new Date(formData.date_rdv),
      médecin: formData.médecin,
      motif: formData.motif,
      statut: formData.statut,
      notes: formData.notes,
      created_at: new Date()
    });
    toast.success("Rendez-vous créé");
    setIsModalOpen(false);
    setFormData({
      patient_id: "",
      date_rdv: new Date().toISOString().slice(0, 16),
      médecin: "",
      motif: "",
      statut: "planifie",
      notes: ""
    });
    fetchData();
  };

  return (
    <div className="space-y-4">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-lg bg-sky-500 flex items-center justify-center">
            <Calendar className="w-5 h-5 text-white" />
          </div>
          <div>
            <h2 className="text-lg font-semibold">Rendez-vous</h2>
            <p className="text-sm text-slate-500">{rendezVousList.length} rendez-vous</p>
          </div>
        </div>
        <div className="text-xs bg-sky-50 text-sky-700 border border-sky-200 rounded-lg px-3 py-2">
          Les rendez-vous se créent en fin de consultation.
        </div>
      </div>

      <div className="relative">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
        <Input 
          placeholder="Rechercher..." 
          value={searchTerm} 
          onChange={(e) => setSearchTerm(e.target.value)} 
          className="pl-10" 
        />
      </div>

      <Card className="p-0">
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead className="bg-slate-50">
              <tr>
                <th className="text-left py-3 px-4 font-semibold">Date</th>
                <th className="text-left py-3 px-4 font-semibold">Patient</th>
                <th className="text-left py-3 px-4 font-semibold">Médecin</th>
                <th className="text-left py-3 px-4 font-semibold">Motif</th>
                <th className="text-left py-3 px-4 font-semibold">Statut</th>
              </tr>
            </thead>
            <tbody>
              {rendezVousList.map((rdv) => (
                <tr key={rdv.id} className="border-t hover:bg-slate-50">
                  <td className="py-3 px-4 text-xs">
                    {new Date(rdv.date_rdv).toLocaleDateString("fr-FR")} {new Date(rdv.date_rdv).toLocaleTimeString("fr-FR", { hour: "2-digit", minute: "2-digit" })}
                  </td>
                  <td className="py-3 px-4 font-medium">
                    {patients.find(p => p.id === rdv.patient_id)?.nom_complet || "N/A"}
                  </td>
                  <td className="py-3 px-4">{(rdv as any).medecin || rdv.médecin}</td>
                  <td className="py-3 px-4 text-xs">{rdv.motif}</td>
                  <td className="py-3 px-4">
                    <Badge variant="outline" className="text-xs">{rdv.statut}</Badge>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </Card>

      {isModalOpen && (
        <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4">
          <div className="bg-white dark:bg-slate-800 rounded-lg shadow-xl max-w-md w-full">
            <div className="flex items-center justify-between p-4 border-b border-slate-200 dark:border-slate-700">
              <h3 className="text-lg font-semibold">Nouveau Rendez-vous</h3>
              <button onClick={() => setIsModalOpen(false)} className="p-1 hover:bg-slate-100 rounded">
                <X className="w-5 h-5" />
              </button>
            </div>
            <form onSubmit={handleSubmit} className="p-4 space-y-3">
              <div className="space-y-1">
                <Label>Patient</Label>
                <select 
                  value={formData.patient_id} 
                  onChange={(e) => setFormData({...formData, patient_id: e.target.value})} 
                  className="w-full h-10 rounded-md border border-input bg-transparent px-3 py-1 text-sm" 
                  required
                >
                  <option value="">Choisir un patient</option>
                  {patients.map(p => <option key={p.id} value={p.id}>{p.nom_complet}</option>)}
                </select>
              </div>
              <div className="space-y-1">
                <Label>Date et heure</Label>
                <Input type="datetime-local" value={formData.date_rdv} onChange={(e) => setFormData({...formData, date_rdv: e.target.value})} required />
              </div>
              <div className="space-y-1">
                <Label>Médecin</Label>
                <Input value={formData.médecin} onChange={(e) => setFormData({...formData, médecin: e.target.value})} placeholder="Dr. ..." />
              </div>
              <div className="space-y-1">
                <Label>Motif</Label>
                <Input value={formData.motif} onChange={(e) => setFormData({...formData, motif: e.target.value})} placeholder="Motif du rendez-vous" />
              </div>
              <div className="flex justify-end gap-2 pt-2">
                <Button type="button" variant="outline" onClick={() => setIsModalOpen(false)}>Annuler</Button>
                <Button type="submit" className="bg-teal-600 hover:bg-teal-700">Enregistrer</Button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

export default RendezVousPage;