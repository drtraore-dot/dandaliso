import React, { useState, useEffect } from 'react';
import { db } from '@/db';
import { toast } from 'react-hot-toast';
import { 
  CreditCard, 
  Plus, 
  Search, 
  X, 
  Wallet 
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent } from '@/components/ui/card';

interface CategorieDepense {
  id: number;
  nom: string;
  actif: boolean;
}

interface Depense {
  id?: number;
  date: string | Date;
  type_depense: string;
  fournisseur: string;
  montant: number;
  description: string;
  categorie_id?: number;
}

export default function Depenses() {
  const [depenses, setDepenses] = useState<Depense[]>([]);
  const [categories, setCategories] = useState<CategorieDepense[]>([]);
  const [recherche, setRecherche] = useState("");
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [isCategoryModalOpen, setIsCategoryModalOpen] = useState(false);
  const [newCategoryName, setNewCategoryName] = useState("");

  const [nouvelleDepense, setNouvelleDepense] = useState<Depense>({
    date: new Date().toISOString().split('T')[0],
    type_depense: "",
    fournisseur: "",
    montant: 0,
    description: "",
    categorie_id: undefined
  });

  useEffect(() => {
    fetchData();
  }, []);

  async function fetchData() {
    const [depenseList, categorieList] = await Promise.all([
      db.depenses.toArray(),
      db.categoriesDepense.toArray()
    ]);
    setDepenses(depenseList);
    setCategories(categorieList);
  }

  async function handleAddCategory(e: React.FormEvent) {
    e.preventDefault();
    if (!newCategoryName.trim()) {
      toast.error("Veuillez saisir un nom");
      return;
    }
    try {
      await db.categoriesDepense.add({
        nom: newCategoryName.trim(),
        ordre: categories.length + 1,
        actif: true,
        created_at: new Date()
      });
      toast.success("Catégorie de dépenses ajoutée");
      setNewCategoryName("");
      fetchData();
    } catch (err) {
      toast.error("Erreur de création");
    }
  }

  async function handleAddDepense(e: React.FormEvent) {
    e.preventDefault();
    await db.depenses.add({
      ...nouvelleDepense,
      date: new Date(nouvelleDepense.date),
      categorie_id: nouvelleDepense.categorie_id ? Number(nouvelleDepense.categorie_id) : undefined,
      created_at: new Date()
    });
    toast.success("Dépense enregistrée");
    setIsModalOpen(false);
    fetchData();
  }

  const totalDepenses = depenses.reduce((acc, curr) => acc + curr.montant, 0);

  return (
    <div className="space-y-4">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-lg bg-red-500 flex items-center justify-center">
            <Wallet className="w-5 h-5 text-white" />
          </div>
          <div>
            <h2 className="text-lg font-semibold">Dépenses</h2>
            <p className="text-sm text-slate-500">
              {depenses.length} entrée(s) - Total: {totalDepenses.toLocaleString()} FCFA
            </p>
          </div>
        </div>
        <div className="flex gap-2">
          <Button onClick={() => setIsCategoryModalOpen(true)} variant="outline" className="border-teal-600 text-teal-600 hover:bg-teal-50">
            📁 Catégories
          </Button>
          <Button onClick={() => setIsModalOpen(true)} className="bg-teal-600 hover:bg-teal-700 text-white font-semibold">
            <Plus className="w-4 h-4 mr-1" /> Nouvelle Dépense
          </Button>
        </div>
      </div>

      <div className="relative">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
        <Input 
          placeholder="Rechercher..." 
          value={recherche} 
          onChange={(e) => setRecherche(e.target.value)} 
          className="pl-10"
        />
      </div>

      <Card>
        <CardContent className="p-0">
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead className="bg-slate-50">
                <tr>
                  <th className="text-left py-3 px-4 font-semibold">Date</th>
                  <th className="text-left py-3 px-4 font-semibold">Type</th>
                  <th className="text-left py-3 px-4 font-semibold">Fournisseur</th>
                  <th className="text-right py-3 px-4 font-semibold">Montant</th>
                  <th className="text-left py-3 px-4 font-semibold">Description</th>
                </tr>
              </thead>
              <tbody>
                {depenses.map((d) => (
                  <tr key={d.id} className="border-t hover:bg-slate-50">
                    <td className="py-3 px-4 text-xs">{new Date(d.date).toLocaleDateString("fr-FR")}</td>
                    <td className="py-3 px-4 font-medium">{d.type_depense}</td>
                    <td className="py-3 px-4 text-xs">{d.fournisseur}</td>
                    <td className="py-3 px-4 text-right font-semibold text-red-600">
                      {d.montant.toLocaleString()} FCFA
                    </td>
                    <td className="py-3 px-4 text-xs text-slate-500">{d.description}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>

      {isModalOpen && (
        <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4">
          <div className="bg-white dark:bg-slate-800 rounded-lg shadow-xl max-w-md w-full">
            <div className="flex items-center justify-between p-4 border-b border-slate-200 dark:border-slate-700">
              <h3 className="text-lg font-semibold">Nouvelle Dépense</h3>
              <button onClick={() => setIsModalOpen(false)} className="p-1 hover:bg-slate-100 rounded">
                <X className="w-5 h-5" />
              </button>
            </div>
            <form onSubmit={handleAddDepense} className="p-4 space-y-3">
              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1">
                  <Label>Catégorie</Label>
                  <select 
                    value={nouvelleDepense.categorie_id} 
                    onChange={(e) => setNouvelleDepense({...nouvelleDepense, categorie_id: Number(e.target.value)})}
                    className="w-full h-10 rounded-md border border-input bg-transparent px-3 py-1 text-sm"
                  >
                    <option value="">Choisir...</option>
                    {categories.filter(c => c.actif).map(c => (
                      <option key={c.id} value={c.id}>{c.nom}</option>
                    ))}
                  </select>
                </div>
                <div className="space-y-1">
                  <Label>Type dépense</Label>
                  <Input 
                    value={nouvelleDepense.type_depense} 
                    onChange={(e) => setNouvelleDepense({...nouvelleDepense, type_depense: e.target.value})} 
                    required 
                  />
                </div>
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1">
                  <Label>Montant</Label>
                  <Input 
                    type="number" 
                    value={nouvelleDepense.montant} 
                    onChange={(e) => setNouvelleDepense({...nouvelleDepense, montant: Number(e.target.value)})} 
                    required 
                  />
                </div>
                <div className="space-y-1">
                  <Label>Fournisseur</Label>
                  <Input 
                    value={nouvelleDepense.fournisseur} 
                    onChange={(e) => setNouvelleDepense({...nouvelleDepense, fournisseur: e.target.value})} 
                  />
                </div>
              </div>
              <div className="space-y-1">
                <Label>Description</Label>
                <Input 
                  value={nouvelleDepense.description} 
                  onChange={(e) => setNouvelleDepense({...nouvelleDepense, description: e.target.value})} 
                />
              </div>
              <div className="flex justify-end gap-2">
                <Button type="button" variant="outline" onClick={() => setIsModalOpen(false)}>Annuler</Button>
                <Button type="submit" className="bg-teal-600 hover:bg-teal-700">Enregistrer</Button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Category Management Modal */}
      {isCategoryModalOpen && (
        <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4">
          <div className="bg-white dark:bg-slate-800 rounded-lg shadow-xl max-w-md w-full">
            <div className="flex items-center justify-between p-4 border-b">
              <h3 className="text-lg font-semibold">Gérer les catégories de dépenses</h3>
              <button onClick={() => setIsCategoryModalOpen(false)} className="p-1 hover:bg-slate-100 rounded">
                <X className="w-5 h-5" />
              </button>
            </div>
            
            <div className="p-4 space-y-4">
              {/* Form to add a category */}
              <form onSubmit={handleAddCategory} className="flex gap-2">
                <div className="flex-1">
                  <Input 
                    placeholder="Nouvelle Catégorie (Ex: Loyer...)" 
                    value={newCategoryName} 
                    onChange={e => setNewCategoryName(e.target.value)} 
                    required 
                  />
                </div>
                <Button type="submit" className="bg-teal-600 hover:bg-teal-700 text-white">Ajouter</Button>
              </form>

              {/* List of existing categories */}
              <div className="space-y-1 max-h-[250px] overflow-y-auto">
                <p className="text-xs text-slate-400 font-semibold uppercase">Catégories existantes :</p>
                {categories.length === 0 ? (
                  <p className="text-sm text-slate-500 py-4 text-center">Aucune catégorie enregistrée</p>
                ) : (
                  categories.map(c => (
                    <div key={c.id} className="flex items-center justify-between p-2 rounded bg-slate-50 dark:bg-slate-900 border text-sm">
                      <span className="font-medium text-slate-700 dark:text-slate-300">{c.nom}</span>
                      <div className="flex items-center gap-1.5">
                        <span className="text-[10px] px-1.5 py-0.5 rounded bg-emerald-100 text-emerald-800">Actif</span>
                        <button
                          type="button"
                          onClick={async () => {
                            if (confirm("Supprimer cette catégorie ?")) {
                              await db.categoriesDepense.delete(c.id);
                              toast.success("Catégorie supprimée");
                              fetchData();
                            }
                          }}
                          className="text-[10px] text-red-600 hover:underline px-1"
                        >
                          Supprimer
                        </button>
                      </div>
                    </div>
                  ))
                )}
              </div>
            </div>

            <div className="flex justify-end p-4 border-t">
              <Button type="button" variant="outline" onClick={() => setIsCategoryModalOpen(false)}>Fermer</Button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}