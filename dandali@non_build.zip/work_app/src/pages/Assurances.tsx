import React, { useEffect, useMemo, useState } from 'react';
import { db } from '@/db';
import { ShieldCheck, Plus, Search, Printer, X } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { toast } from 'sonner';
import { getPrintSettings, renderPrintHeader, renderPrintFooter } from '@/lib/printSettings';

export default function Assurances() {
  const [assurances, setAssurances] = useState<any[]>([]);
  const [recettes, setRecettes] = useState<any[]>([]);
  const [search, setSearch] = useState('');
  const [mois, setMois] = useState(new Date().toISOString().slice(0, 7));
  const [showModal, setShowModal] = useState(false);
  const [form, setForm] = useState({ nom: '', telephone: '', adresse: '', contact: '', taux_prise_en_charge: 0 });

  const loadData = async () => {
    const [assurData, recData] = await Promise.all([
      db.assurances.toArray().catch(() => []),
      db.recettes.toArray().catch(() => [])
    ]);
    setAssurances(assurData.sort((a, b) => String(a.nom || '').localeCompare(String(b.nom || ''))));
    setRecettes(recData);
  };

  useEffect(() => { loadData(); }, []);

  const recettesMoisAssurees = useMemo(() => recettes.filter(r => {
    const d = String(r.date || r.created_at || '').slice(0, 7);
    return r.est_assure && d === mois;
  }), [recettes, mois]);

  const situation = useMemo(() => assurances.map(a => {
    const lignes = recettesMoisAssurees.filter(r => String(r.assurance_id) === String(a.id) || r.assurance_nom === a.nom);
    return {
      ...a,
      nombreTickets: lignes.length,
      montantTotal: lignes.reduce((sum, r) => sum + Number(r.montant_brut || r.montant || 0), 0),
      montantAssurance: lignes.reduce((sum, r) => sum + Number(r.montant_assurance || 0), 0),
      montantPatient: lignes.reduce((sum, r) => sum + Number(r.montant_patient || r.montant || 0), 0),
      lignes
    };
  }).filter(a => a.nom?.toLowerCase().includes(search.toLowerCase()) || a.lignes.some((r:any) => r.patient_nom?.toLowerCase().includes(search.toLowerCase()))), [assurances, recettesMoisAssurees, search]);

  const totalGeneral = situation.reduce((sum, a) => sum + a.montantTotal, 0);
  const totalAssurance = situation.reduce((sum, a) => sum + a.montantAssurance, 0);
  const totalPatient = situation.reduce((sum, a) => sum + a.montantPatient, 0);
  const totalTickets = situation.reduce((sum, a) => sum + a.nombreTickets, 0);

  const handleCreate = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.nom.trim()) { toast.error("Nom de l'assurance obligatoire"); return; }
    await db.assurances.add({ ...form, taux_prise_en_charge: Math.max(0, Math.min(100, Number(form.taux_prise_en_charge || 0))), statut: 'actif', created_at: new Date() });
    toast.success('Assurance créée');
    setForm({ nom: '', telephone: '', adresse: '', contact: '', taux_prise_en_charge: 0 });
    setShowModal(false);
    loadData();
  };

  const printSituation = async () => {
    const ps = await getPrintSettings();
    const rows = situation.map(a => `
      <tr><td><b>${a.nom || ''}</b><br><small>Taux: ${Number(a.taux_prise_en_charge || 0)}%</small></td><td class="center">${a.nombreTickets}</td><td class="right">${a.montantTotal.toLocaleString('fr-FR')} FCFA</td><td class="right">${a.montantAssurance.toLocaleString('fr-FR')} FCFA</td><td class="right">${a.montantPatient.toLocaleString('fr-FR')} FCFA</td></tr>
      ${a.lignes.map((r:any) => `<tr class="detail"><td colspan="5">${new Date(r.date || r.created_at).toLocaleDateString('fr-FR')} — ${r.patient_nom || ''} — ${r.libelle || ''} — Brut: ${Number(r.montant_brut || r.montant || 0).toLocaleString('fr-FR')} F — Assurance: ${Number(r.montant_assurance || 0).toLocaleString('fr-FR')} F — Patient: ${Number(r.montant_patient || r.montant || 0).toLocaleString('fr-FR')} F</td></tr>`).join('')}
    `).join('');
    const html = `<!doctype html><html><head><title>Situation assurances</title><style>
      @page { size:A4 portrait; margin:10mm; }
      body{font-family:Arial,sans-serif;font-size:11px;color:#111827}.print-logo-wrap{flex:0 0 auto}.print-logo{width:58px;height:58px;object-fit:contain;display:block}.print-header-main{flex:1}.print-header-block{display:flex;align-items:center;justify-content:center;gap:10px;border-bottom:1px solid #0f766e;padding-bottom:7px;margin-bottom:10px;text-align:center}.print-clinic-name{font-size:16px;font-weight:800;color:#0f766e;text-transform:uppercase}.print-clinic-sub,.print-custom-header{font-size:9px;color:#475569;line-height:1.25}.print-footer-block{border-top:1px solid #94a3b8;margin-top:12px;padding-top:6px;text-align:center;font-size:9px;color:#475569}table{width:100%;border-collapse:collapse}th,td{border:1px solid #cbd5e1;padding:6px}th{background:#f1f5f9}.right{text-align:right}.center{text-align:center}.total{font-weight:800;background:#ecfdf5}.detail td{font-size:9px;color:#475569;background:#fafafa;padding-left:18px}
    </style></head><body>${renderPrintHeader(ps, `Situation mensuelle assurances - ${mois}`)}<table><thead><tr><th>Assurance</th><th>Tickets</th><th>Total brut</th><th>Part assurance</th><th>Part patient</th></tr></thead><tbody>${rows || '<tr><td colspan="5" class="center">Aucune donnée</td></tr>'}<tr class="total"><td>Total général</td><td class="center">${totalTickets}</td><td class="right">${totalGeneral.toLocaleString('fr-FR')} FCFA</td><td class="right">${totalAssurance.toLocaleString('fr-FR')} FCFA</td><td class="right">${totalPatient.toLocaleString('fr-FR')} FCFA</td></tr></tbody></table>${renderPrintFooter(ps)}<script>window.onload=function(){window.print()}</script></body></html>`;
    const w = window.open('', '_blank', 'width=900,height=700');
    if (!w) { toast.error('Fenêtre d’impression bloquée'); return; }
    w.document.write(html); w.document.close();
  };

  return <div className="space-y-4">
    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
      <div className="flex items-center gap-3">
        <div className="w-10 h-10 rounded-lg bg-blue-600 flex items-center justify-center"><ShieldCheck className="w-5 h-5 text-white" /></div>
        <div><h2 className="text-lg font-semibold">Assurances</h2><p className="text-sm text-slate-500">Situation mensuelle des tickets assurés</p></div>
      </div>
      <div className="flex gap-2"><Button variant="outline" onClick={printSituation}><Printer className="w-4 h-4 mr-1" /> Imprimer</Button><Button onClick={() => setShowModal(true)} className="bg-teal-600 hover:bg-teal-700"><Plus className="w-4 h-4 mr-1" /> Nouvelle assurance</Button></div>
    </div>

    <div className="grid grid-cols-2 md:grid-cols-5 gap-3">
      <Card><CardContent className="p-3"><p className="text-[10px] uppercase text-slate-500 font-bold">Mois</p><Input type="month" value={mois} onChange={e => setMois(e.target.value)} className="mt-1" /></CardContent></Card>
      <Card><CardContent className="p-3"><p className="text-[10px] uppercase text-slate-500 font-bold">Tickets assurés</p><p className="text-xl font-bold">{totalTickets}</p></CardContent></Card>
      <Card><CardContent className="p-3"><p className="text-[10px] uppercase text-slate-500 font-bold">Total brut actes</p><p className="text-xl font-bold text-slate-700">{totalGeneral.toLocaleString('fr-FR')} F</p></CardContent></Card>
      <Card><CardContent className="p-3"><p className="text-[10px] uppercase text-slate-500 font-bold">À réclamer assurances</p><p className="text-xl font-bold text-blue-700">{totalAssurance.toLocaleString('fr-FR')} F</p></CardContent></Card>
      <Card><CardContent className="p-3"><p className="text-[10px] uppercase text-slate-500 font-bold">Payé par patients</p><p className="text-xl font-bold text-emerald-700">{totalPatient.toLocaleString('fr-FR')} F</p></CardContent></Card>
    </div>

    <div className="relative"><Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" /><Input placeholder="Rechercher assurance ou patient..." value={search} onChange={e => setSearch(e.target.value)} className="pl-10" /></div>

    <Card className="p-0 overflow-hidden"><div className="overflow-x-auto"><table className="w-full text-sm"><thead className="bg-slate-50"><tr><th className="text-left py-3 px-4">Assurance</th><th className="text-center py-3 px-4">Taux</th><th className="text-center py-3 px-4">Tickets</th><th className="text-right py-3 px-4">Total brut</th><th className="text-right py-3 px-4">Part assurance</th><th className="text-right py-3 px-4">Part patient</th><th className="text-left py-3 px-4">Détails tickets</th></tr></thead><tbody>{situation.length === 0 ? <tr><td colSpan={7} className="text-center py-8 text-slate-400">Aucune situation pour ce mois</td></tr> : situation.map(a => <tr key={a.id} className="border-t align-top"><td className="py-3 px-4 font-bold">{a.nom}<div className="text-[10px] text-slate-500 font-normal">{a.contact || a.telephone || ''}</div></td><td className="py-3 px-4 text-center font-bold text-blue-700">{Number(a.taux_prise_en_charge || 0)}%</td><td className="py-3 px-4 text-center">{a.nombreTickets}</td><td className="py-3 px-4 text-right font-bold">{a.montantTotal.toLocaleString('fr-FR')} FCFA</td><td className="py-3 px-4 text-right font-bold text-blue-700">{a.montantAssurance.toLocaleString('fr-FR')} FCFA</td><td className="py-3 px-4 text-right font-bold text-emerald-700">{a.montantPatient.toLocaleString('fr-FR')} FCFA</td><td className="py-3 px-4 text-xs text-slate-600">{a.lignes.length === 0 ? <span className="text-slate-400">Aucun ticket</span> : <div className="space-y-1 max-h-32 overflow-y-auto">{a.lignes.map((r:any) => <div key={r.id} className="border-b pb-1"><b>{r.patient_nom}</b> — {r.libelle} — Brut {Number(r.montant_brut || r.montant || 0).toLocaleString('fr-FR')} F — Assurance {Number(r.montant_assurance || 0).toLocaleString('fr-FR')} F — Patient {Number(r.montant_patient || r.montant || 0).toLocaleString('fr-FR')} F</div>)}</div>}</td></tr>)}</tbody></table></div></Card>

    {showModal && <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4"><div className="bg-white dark:bg-slate-800 rounded-lg shadow-xl max-w-md w-full"><div className="flex items-center justify-between p-4 border-b"><h3 className="font-bold">Nouvelle assurance</h3><button onClick={() => setShowModal(false)}><X className="w-5 h-5" /></button></div><form onSubmit={handleCreate} className="p-4 space-y-3"><div><Label>Nom de l'assurance *</Label><Input value={form.nom} onChange={e => setForm({...form, nom:e.target.value})} required /></div><div><Label>Contact / Responsable</Label><Input value={form.contact} onChange={e => setForm({...form, contact:e.target.value})} /></div><div><Label>Pourcentage de prise en charge (%)</Label><Input type="number" min={0} max={100} value={form.taux_prise_en_charge} onChange={e => setForm({...form, taux_prise_en_charge:Number(e.target.value) || 0})} /></div><div><Label>Téléphone</Label><Input value={form.telephone} onChange={e => setForm({...form, telephone:e.target.value})} /></div><div><Label>Adresse</Label><Input value={form.adresse} onChange={e => setForm({...form, adresse:e.target.value})} /></div><div className="flex justify-end gap-2 pt-2"><Button type="button" variant="outline" onClick={() => setShowModal(false)}>Annuler</Button><Button type="submit" className="bg-teal-600 hover:bg-teal-700">Créer</Button></div></form></div></div>}
  </div>;
}
