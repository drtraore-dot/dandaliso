import React, { useMemo, useState } from "react";
import { useLiveQuery } from "dexie-react-hooks";
import { db } from "@/db";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Users, Search } from "lucide-react";

const serviceLabels: Record<string, string> = {
  consultations: "Consultations",
  laboratoire: "Laboratoire",
  soins: "Soins infirmiers",
  caisse: "Caisse",
  hospitalisation: "Hospitalisation",
};

function toPatientRows(list: any[], service: string) {
  return (list || []).map((p: any) => ({
    ...p,
    service,
    serviceLabel: serviceLabels[service] || service,
    uniqueKey: `${service}-${p.id}`,
    createdAt: p.created_at ? new Date(p.created_at) : new Date(0),
  }));
}

export default function TousPatients() {
  const [search, setSearch] = useState("");
  const [serviceFilter, setServiceFilter] = useState("tous");
  const [dateSort, setDateSort] = useState<"desc" | "asc">("desc");

  const patientsConsultations = useLiveQuery(() => db.patients_consultation.toArray()) || [];
  const patientsLaboratoire = useLiveQuery(() => db.patients_laboratoire.toArray()) || [];
  const patientsSoins = useLiveQuery(() => db.patients_soins.toArray()) || [];
  const patientsCaisse = useLiveQuery(() => db.patients_caisse.toArray()) || [];
  const patientsHospitalisation = useLiveQuery(() => db.patients_hospitalisation.toArray()) || [];

  const rows = useMemo(() => {
    const all = [
      ...toPatientRows(patientsConsultations, "consultations"),
      ...toPatientRows(patientsLaboratoire, "laboratoire"),
      ...toPatientRows(patientsSoins, "soins"),
      ...toPatientRows(patientsCaisse, "caisse"),
      ...toPatientRows(patientsHospitalisation, "hospitalisation"),
    ];
    const term = search.trim().toLowerCase();
    return all
      .filter((p) => serviceFilter === "tous" || p.service === serviceFilter)
      .filter((p) => !term ||
        (p.nom_complet || "").toLowerCase().includes(term) ||
        (p.numero_patient || "").toLowerCase().includes(term) ||
        (p.telephone || "").toLowerCase().includes(term)
      )
      .sort((a, b) => dateSort === "desc"
        ? b.createdAt.getTime() - a.createdAt.getTime()
        : a.createdAt.getTime() - b.createdAt.getTime()
      );
  }, [patientsConsultations, patientsLaboratoire, patientsSoins, patientsCaisse, patientsHospitalisation, search, serviceFilter, dateSort]);

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between gap-4 flex-wrap">
        <div>
          <h1 className="text-2xl font-bold text-slate-900 dark:text-slate-100 flex items-center gap-2">
            <Users className="w-7 h-7" /> Tous les patients
          </h1>
          <p className="text-slate-600 dark:text-slate-300">Vue combinée des patients enregistrés par tous les services.</p>
        </div>
        <Badge variant="secondary" className="text-base px-4 py-2">{rows.length} patient(s)</Badge>
      </div>

      <Card>
        <CardHeader><CardTitle>Filtres</CardTitle></CardHeader>
        <CardContent className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="space-y-2">
            <Label>Recherche</Label>
            <div className="relative">
              <Search className="absolute left-3 top-3 w-4 h-4 text-slate-400" />
              <Input className="pl-9" value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Nom, N° patient, téléphone" />
            </div>
          </div>
          <div className="space-y-2">
            <Label>Service</Label>
            <select className="w-full h-10 rounded-md border border-input bg-background px-3" value={serviceFilter} onChange={(e) => setServiceFilter(e.target.value)}>
              <option value="tous">Tous les services</option>
              {Object.entries(serviceLabels).map(([value, label]) => <option key={value} value={value}>{label}</option>)}
            </select>
          </div>
          <div className="space-y-2">
            <Label>Tri par date</Label>
            <select className="w-full h-10 rounded-md border border-input bg-background px-3" value={dateSort} onChange={(e) => setDateSort(e.target.value as "desc" | "asc")}>
              <option value="desc">Plus récent en haut</option>
              <option value="asc">Plus ancien en haut</option>
            </select>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardContent className="p-0 overflow-x-auto">
          <table className="w-full text-sm">
            <thead className="bg-slate-100 dark:bg-slate-800">
              <tr>
                <th className="text-left p-3">Service</th>
                <th className="text-left p-3">N° patient</th>
                <th className="text-left p-3">Nom complet</th>
                <th className="text-left p-3">Âge</th>
                <th className="text-left p-3">Sexe</th>
                <th className="text-left p-3">Téléphone</th>
                <th className="text-left p-3">Date</th>
              </tr>
            </thead>
            <tbody>
              {rows.length === 0 ? (
                <tr><td colSpan={7} className="p-6 text-center text-slate-500">Aucun patient trouvé</td></tr>
              ) : rows.map((p) => (
                <tr key={p.uniqueKey} className="border-t hover:bg-slate-50 dark:hover:bg-slate-900">
                  <td className="p-3"><Badge variant="outline">{p.serviceLabel}</Badge></td>
                  <td className="p-3 font-mono">{p.numero_patient || "-"}</td>
                  <td className="p-3 font-semibold">{p.nom_complet || "-"}</td>
                  <td className="p-3">{p.age || "-"}</td>
                  <td className="p-3">{p.sexe || "-"}</td>
                  <td className="p-3">{p.telephone || "-"}</td>
                  <td className="p-3">{p.createdAt.getTime() > 0 ? p.createdAt.toLocaleDateString("fr-FR") : "-"}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </CardContent>
      </Card>
    </div>
  );
}
