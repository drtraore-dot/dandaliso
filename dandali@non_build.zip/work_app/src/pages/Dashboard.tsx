import React, { useState, useEffect } from 'react';
import { 
  Users, Stethoscope, Wallet, TrendingUp, Calendar, 
  Bed, FileText, Pill, AlertTriangle, Activity 
} from 'lucide-react';
import { 
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, 
  PieChart, Pie, Cell 
} from 'recharts';
import { db } from '@/db';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';

interface Stats {
  patients: number;
  consultations: number;
  recettes: number;
  depenses: number;
  benefice: number;
  rendezVous: number;
  hospitalisations: number;
  ordonnances: number;
  medicaments: number;
}

interface Alert {
  type: 'stock' | 'expiry' | 'info';
  message: string;
  severity: 'high' | 'medium' | 'low';
}

const COLORS = ['#0f766e', '#0d9488', '#14b8a6', '#5eead4'];

export default function Dashboard() {
  const [loading, setLoading] = useState(true);
  const [stats, setStats] = useState<Stats>({
    patients: 0, consultations: 0, recettes: 0, depenses: 0,
    benefice: 0, rendezVous: 0, hospitalisations: 0,
    ordonnances: 0, medicaments: 0
  });
  const [alerts, setAlerts] = useState<Alert[]>([]);
  const [chartData, setChartData] = useState<any[]>([]);
  const [consultationData, setConsultationData] = useState<any[]>([]);
  const [recentActivity, setRecentActivity] = useState<any[]>([]);

  useEffect(() => {
    const loadData = async () => {
      try {
        const [patientsData, consultationsData, recettesData, depensesData, rdvData, hospData, ordData, medsData, labData] = await Promise.all([
          db.patients.toArray().catch(() => []),
          db.consultations.toArray().catch(() => []),
          db.recettes.toArray().catch(() => []),
          db.depenses.toArray().catch(() => []),
          db.rendezVous.toArray().catch(() => []),
          db.hospitalisations.toArray().catch(() => []),
          db.ordonnances.toArray().catch(() => []),
          db.medicaments.toArray().catch(() => []),
          db.examensLaboratoire.toArray().catch(() => []),
        ]);

        const recettesTotal = recettesData.reduce((sum:any, r:any) => sum + Number(r.montant || 0), 0);
        const depensesTotal = depensesData.reduce((sum:any, d:any) => sum + Number(d.montant || d.montant_total || 0), 0);
        setStats({
          patients: patientsData.length,
          consultations: consultationsData.length,
          recettes: recettesTotal,
          depenses: depensesTotal,
          benefice: recettesTotal - depensesTotal,
          rendezVous: rdvData.length,
          hospitalisations: hospData.length,
          ordonnances: ordData.length,
          medicaments: medsData.length
        });

        const now = new Date();
        const months = Array.from({ length: 6 }).map((_, i) => {
          const d = new Date(now.getFullYear(), now.getMonth() - (5 - i), 1);
          const key = `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}`;
          return { key, mois: d.toLocaleDateString('fr-FR', { month: 'short' }) };
        });
        setChartData(months.map(m => ({
          mois: m.mois,
          recettes: recettesData.filter((r:any) => String(r.date || r.created_at || '').slice(0,7) === m.key).reduce((a:any,b:any)=>a+Number(b.montant||0),0),
          depenses: depensesData.filter((d:any) => String(d.date || d.created_at || '').slice(0,7) === m.key).reduce((a:any,b:any)=>a+Number(b.montant||b.montant_total||0),0),
        })));

        const typeCounts = consultationsData.reduce((acc:any, c:any) => {
          const k = c.type_consultation || 'générale';
          acc[k] = (acc[k] || 0) + 1;
          return acc;
        }, {});
        setConsultationData(Object.entries(typeCounts).map(([name, value]) => ({ name, value })));

        const activity = [
          ...consultationsData.map((c:any) => ({ label: `Consultation - ${c.motif || c.diagnostic || 'patient'}`, date: c.date_consultation || c.created_at })),
          ...labData.map((l:any) => ({ label: `Examen laboratoire - ${l.type_analyse || 'analyse'}`, date: l.date_examen || l.created_at })),
          ...recettesData.map((r:any) => ({ label: `Caisse - ${r.libelle || 'paiement'}`, date: r.date || r.created_at })),
        ].sort((a:any,b:any) => new Date(b.date || 0).getTime() - new Date(a.date || 0).getTime()).slice(0,8);
        setRecentActivity(activity);

        setAlerts([]);
      } catch (error) {
        console.error("Dashboard loadStats error:", error);
      } finally {
        setLoading(false);
      }
    };
    loadData();
  }, []);

  if (loading) {
    return (
      <div className="flex items-center justify-center h-screen text-slate-500">
        Chargement...
      </div>
    );
  }

  const statCards = [
    { label: "Patients", value: stats.patients, icon: Users, color: "bg-blue-100 text-blue-600" },
    { label: "Consultations", value: stats.consultations, icon: Stethoscope, color: "bg-teal-100 text-teal-600" },
    { label: "Recettes", value: `${stats.recettes.toLocaleString()} FCFA`, icon: Wallet, color: "bg-emerald-100 text-emerald-600" },
    { label: "Depenses", value: `${stats.depenses.toLocaleString()} FCFA`, icon: TrendingUp, color: "bg-red-100 text-red-600" },
    { label: "Benefice", value: `${stats.benefice.toLocaleString()} FCFA`, icon: Wallet, color: "bg-amber-100 text-amber-600" },
    { label: "Rendez-vous", value: stats.rendezVous, icon: Calendar, color: "bg-purple-100 text-purple-600" },
    { label: "Hospitalisations", value: stats.hospitalisations, icon: Bed, color: "bg-orange-100 text-orange-600" },
    { label: "Ordonnances", value: stats.ordonnances, icon: FileText, color: "bg-indigo-100 text-indigo-600" },
    { label: "Medicaments", value: stats.medicaments, icon: Pill, color: "bg-cyan-100 text-cyan-600" }
  ];

  return (
    <div className="space-y-4">
      <div className="flex items-center gap-3">
        <div className="w-10 h-10 rounded-lg bg-teal-600 flex items-center justify-center">
          <Stethoscope className="w-5 h-5 text-white" />
        </div>
        <div>
          <h2 className="text-xl font-bold text-slate-800 dark:text-white">Tableau de bord</h2>
          <p className="text-sm text-slate-500">Vue d'ensemble de l'activité</p>
        </div>
      </div>

      {alerts.length > 0 && (
        <div className="space-y-2">
          {alerts.map((alert, idx) => (
            <div key={idx} className={`flex items-center gap-2 p-3 rounded-lg text-sm ${alert.severity === 'high' ? 'bg-red-50 text-red-700 border border-red-200' : 'bg-blue-50 text-blue-700 border border-blue-200'}`}>
              <AlertTriangle className="w-4 h-4 flex-shrink-0" />
              {alert.message}
            </div>
          ))}
        </div>
      )}

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
        {statCards.map((stat) => (
          <Card key={stat.label}>
            <CardContent className="p-4">
              <div className="flex items-center gap-3">
                <div className={`w-10 h-10 rounded-lg flex items-center justify-center ${stat.color}`}>
                  <stat.icon className="w-5 h-5" />
                </div>
                <div>
                  <p className="text-xs text-slate-500">{stat.label}</p>
                  <p className="text-lg font-bold">{stat.value}</p>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-semibold flex items-center gap-2">
              <Wallet className="w-4 h-4 text-teal-600" />
              Recettes vs Depenses mensuelles (FCFA)
            </CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={250}>
              <BarChart data={chartData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
                <XAxis dataKey="mois" tick={{ fontSize: 12 }} />
                <YAxis tick={{ fontSize: 12 }} tickFormatter={(val) => `${(val / 1000).toFixed(0)}k`} />
                <Tooltip formatter={(val: number) => `${val.toLocaleString()} FCFA`} />
                <Legend />
                <Bar dataKey="recettes" fill="#0f766e" radius={[4, 4, 0, 0]} name="Recettes" />
                <Bar dataKey="depenses" fill="#ef4444" radius={[4, 4, 0, 0]} name="Depenses" />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-semibold flex items-center gap-2">
              <Stethoscope className="w-4 h-4 text-teal-600" />
              Repartition des consultations
            </CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={250}>
              <PieChart>
                <Pie data={consultationData} innerRadius={60} outerRadius={90} paddingAngle={5} dataKey="value">
                  {consultationData.map((_, idx) => (
                    <Cell key={`cell-${idx}`} fill={COLORS[idx % COLORS.length]} />
                  ))}
                </Pie>
                <Tooltip />
              </PieChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader className="pb-2">
          <CardTitle className="text-sm font-semibold">Activite recente</CardTitle>
        </CardHeader>
        <CardContent>
          {recentActivity.length === 0 ? (
            <p className="text-sm text-slate-400 text-center py-4">Aucune activite recente</p>
          ) : (
            <div className="space-y-2">
              {recentActivity.map((activity, idx) => (
                <div key={idx} className="flex items-center gap-3 p-2 rounded-lg hover:bg-slate-50 text-sm">
                  <div className="w-8 h-8 rounded-full flex items-center justify-center bg-teal-100 text-teal-600">
                    <Activity className="w-4 h-4" />
                  </div>
                  <div className="flex-1">
                    <p className="font-medium">{activity.label}</p>
                  </div>
                  <span className="text-xs text-slate-400">
                    {activity.date ? new Date(activity.date).toLocaleDateString("fr-FR") : ""}
                  </span>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}