import React, { useState, useMemo, useEffect } from 'react';
import { 
  Database, 
  Search, 
  X, 
  Pill, 
  FlaskConical, 
  Syringe, 
  ChevronDown, 
  ChevronUp, 
  Filter, 
  Box,
  UploadCloud,
  Trash2,
  Play,
  Check,
  Loader2,
  FileText,
  Download
} from 'lucide-react';
import { db } from '@/db';
import { useLiveQuery } from 'dexie-react-hooks';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import toast from 'react-hot-toast';

interface Medicament {
  id: number;
  brandName: string;
  dci: string;
  dosage: string;
  classTherapeutic: string;
  form: string;
  manufacturer?: string;
  category: 'specialite' | 'dci' | 'consommable';
  isCustom?: boolean;
  indication?: string;
  atcCode?: string;
  contraindication?: string;
  sideEffects?: string;
}

const CATEGORY_COLORS = {
  specialite: 'bg-blue-100 text-blue-700',
  dci: 'bg-purple-100 text-purple-700',
  consommable: 'bg-amber-100 text-amber-700',
};

const CATEGORY_LABELS = {
  specialite: 'Spécialité',
  dci: 'DCI',
  consommable: 'Consommable',
};

const INITIAL_MEDICATIONS: Medicament[] = [
  {
    id: 1001,
    brandName: "Viagra",
    dci: "Sildénafil",
    dosage: "50mg",
    classTherapeutic: "Cardiologie / Urologie / Vasodilatateur",
    form: "Comprimé pelliculé",
    manufacturer: "Pfizer",
    category: "specialite",
    indication: "Traitement des hommes présentant des troubles de l'érection (impuissance), à savoir l'incapacité d'obtenir ou de maintenir une érection du pénis suffisante pour une activité sexuelle satisfaisante.",
    atcCode: "G04BE03",
    contraindication: "Contre-indiqué chez les patients prenant des donneurs d'oxyde azotique ou des dérivés nitrés sous quelque forme que ce soit (risque d'hypotension majeure)."
  },
  {
    id: 1002,
    brandName: "Viagra",
    dci: "Sildénafil",
    dosage: "100mg",
    classTherapeutic: "Cardiologie / Urologie / Vasodilatateur",
    form: "Comprimé pelliculé",
    manufacturer: "Pfizer",
    category: "specialite",
    indication: "Traitement des hommes présentant des troubles de l'érection.",
    atcCode: "G04BE03",
    contraindication: "Contre-indiqué en association avec des donneurs d'oxyde azotique ou des dérivés nitrés sous quelque forme que ce soit."
  },
  {
    id: 1003,
    brandName: "Natispray",
    dci: "Trinitrine",
    dosage: "0.4mg/dose",
    classTherapeutic: "Cardiologie / Antiangoreux / Vasodilatateur",
    form: "Spray sublingual",
    manufacturer: "Biogaran",
    category: "specialite",
    indication: "Traitement curatif de la crise d'angine de poitrine (angor) et traitement préventif à très court terme (effort, stress).",
    atcCode: "C01DA02",
    contraindication: "Hypotension sévère, état de choc, infarctus du myocarde à la phase aiguë avec basse pression de remplissage. Ne pas associer au sildénafil ou autres inhibiteurs de la PDE5."
  },
  {
    id: 1004,
    brandName: "Nitrone",
    dci: "Trinitrine",
    dosage: "2.5mg",
    classTherapeutic: "Cardiologie / Antiangoreux / Vasodilatateur",
    form: "Comprimé pelliculé",
    manufacturer: "Sanofi",
    category: "specialite",
    indication: "Traitement préventif de l'angine de poitrine (angor).",
    atcCode: "C01DA02",
    contraindication: "Hypotension sévère, association avec les inhibiteurs de la PDE5 (sildénafil, etc.)."
  },
  {
    id: 1,
    brandName: "Doliprane",
    dci: "Paracétamol",
    dosage: "1000mg",
    classTherapeutic: "Antalgiques & Antipyrétiques",
    form: "Comprimé",
    manufacturer: "Sanofi Aventis",
    category: "specialite",
    indication: "Traitement symptomatique des douleurs d'intensité légère à modérée et/ou des états fébriles.",
    atcCode: "N02BE01",
    contraindication: "Hypersensibilité au paracétamol, insuffisance hépatocellulaire sévère."
  },
  {
    id: 2,
    brandName: "Clamoxyl",
    dci: "Amoxicilline",
    dosage: "500mg",
    classTherapeutic: "Antibiotiques & Antibactériens",
    form: "Gélule",
    manufacturer: "GlaxoSmithKline",
    category: "specialite",
    indication: "Infections bactériennes dues aux germes sensibles : otites aiguës, sinusites, pneumopathies, cystites.",
    atcCode: "J01CA04",
    contraindication: "Allergie aux bêtalactamines (pénicillines et céphalosporines)."
  },
  {
    id: 3,
    brandName: "Advil",
    dci: "Ibuprofène",
    dosage: "400mg",
    classTherapeutic: "Anti-inflammatoires (AINS)",
    form: "Comprimé pelliculé",
    manufacturer: "Pfizer",
    category: "specialite",
    indication: "Traitement de courte durée de la fièvre et/ou des douleurs (maux de tête, états grippaux, douleurs dentaires, courbatures).",
    atcCode: "M01AE01",
    contraindication: "Grossesse (à partir du 6ème mois), antécédents d'ulcère gastroduodénal en évolution, insuffisance cardiaque grave."
  },
  {
    id: 4,
    brandName: "Augmentin",
    dci: "Amoxicilline + Acide Clavulanique",
    dosage: "1g / 125mg",
    classTherapeutic: "Antibiotiques & Antibactériens",
    form: "Poudre pour suspension buvable",
    manufacturer: "GlaxoSmithKline",
    category: "specialite",
    indication: "Infections bactériennes de l'adulte et de l'enfant : otites aiguës, sinusites, surinfections bronchiques, infections urinaires.",
    atcCode: "J01CR02",
    contraindication: "Antécédent d'ictère ou d'atteinte hépatique liée à l'association amoxicilline/acide clavulanique."
  },
  {
    id: 5,
    brandName: "Flagyl",
    dci: "Métronidazole",
    dosage: "500mg",
    classTherapeutic: "Antiparasitaires & Anti-infectieux",
    form: "Comprimé",
    manufacturer: "Sanofi Aventis",
    category: "specialite",
    indication: "Traitement de certaines infections à germes anaérobies ou à parasites (amibiase, trichomonase urogénitale, lambliase).",
    atcCode: "J01XD01",
    contraindication: "Hypersensibilité aux dérivés imidazolés."
  },
  {
    id: 6,
    brandName: "Spasfon",
    dci: "Phloroglucinol",
    dosage: "80mg",
    classTherapeutic: "Antispasmodiques",
    form: "Comprimé enrobé",
    manufacturer: "Teva Santé",
    category: "specialite",
    indication: "Traitement des douleurs spasmodiques des voies digestives, des voies biliaires, de la vessie et des voies gynécologiques.",
    atcCode: "A03AX12",
    contraindication: "Hypersensibilité au phloroglucinol ou à l'un des excipients."
  },
  {
    id: 7,
    brandName: "Voltarène",
    dci: "Diclofénac de sodium",
    dosage: "75mg",
    classTherapeutic: "Anti-inflammatoires (AINS)",
    form: "Ampoule injectable IM",
    manufacturer: "Novartis",
    category: "specialite",
    indication: "Traitement d'attaque de courte durée des rhumatismes inflammatoires aigus, sciatiques, crises de coliques néphrétiques.",
    atcCode: "M01AB05",
    contraindication: "Insuffisance cardiaque congestive, cardiopathie ischémique, artériopathie périphérique."
  },
  {
    id: 8,
    brandName: "Rocéphine",
    dci: "Ceftriaxone",
    dosage: "1g",
    classTherapeutic: "Antibiotiques & Antibactériens",
    form: "Poudre et solvant injectable",
    manufacturer: "Roche",
    category: "specialite",
    indication: "Infections bactériennes sévères : méningites purulentes, septicémies, infections des voies urinaires ou respiratoires basses.",
    atcCode: "J01DD04",
    contraindication: "Nouveau-nés prématurés, nouveau-nés présentant une hyperbilirubinémie ou traités par le calcium intraveineux."
  },
  {
    id: 9,
    brandName: "Mopral",
    dci: "Oméprazole",
    dosage: "20mg",
    classTherapeutic: "Anti-acides & Anti-ulcéreux",
    form: "Gélules gastro-résistantes",
    manufacturer: "AstraZeneca",
    category: "specialite",
    indication: "Traitement de l'ulcère duodénal ou gastrique, reflux gastro-œsophagien (RGO), syndrome de Zollinger-Ellison.",
    atcCode: "A02BC01",
    contraindication: "Association d'oméprazole avec le nelfinavir (médicament antiviral)."
  },
  {
    id: 10,
    brandName: "Ventoline",
    dci: "Salbutamol",
    dosage: "100 mcg / dose",
    classTherapeutic: "Bronchodilatateurs & Antiasthmatiques",
    form: "Suspension pour inhalation",
    manufacturer: "GlaxoSmithKline",
    category: "specialite",
    indication: "Traitement symptomatique de la crise d'asthme ou de l'exacerbation de la bronchopneumopathie chronique obstructive (BPCO).",
    atcCode: "R03AC02",
    contraindication: "Hypersensibilité au salbutamol."
  },
  {
    id: 11,
    brandName: "Coartem",
    dci: "Artéméther + Luméfantrine",
    dosage: "20mg / 120mg",
    classTherapeutic: "Antipaludéens",
    form: "Comprimé",
    manufacturer: "Novartis",
    category: "specialite",
    indication: "Traitement des accès palustres simples à Plasmodium falciparum chez l'adulte, l'enfant et le nourrisson de plus de 5 kg.",
    atcCode: "P01BF01",
    contraindication: "Antécédents familiaux de mort subite ou d'allongement du segment QTc, troubles du rythme cardiaque grave."
  },
  {
    id: 12,
    brandName: "Lasilix",
    dci: "Furosémide",
    dosage: "40mg",
    classTherapeutic: "Diurétiques",
    form: "Comprimé",
    manufacturer: "Sanofi Aventis",
    category: "specialite",
    indication: "Hypertension artérielle, œdèmes d'origine cardiaque, rénale ou hépatique.",
    atcCode: "C03CA01",
    contraindication: "Insuffisance rénale anurique, encéphalopathie hépatique, déshydratation ou hypovolémie."
  },
  {
    id: 13,
    brandName: "Loxen",
    dci: "Nicardipine",
    dosage: "10mg / 10ml",
    classTherapeutic: "Antihypertenseurs",
    form: "Ampoule injectable",
    manufacturer: "Novartis",
    category: "specialite",
    indication: "Poussées hypertensives d'extrême urgence, hypertension en période péri-opératoire.",
    atcCode: "C08CA04",
    contraindication: "Sténose aortique sévère, choc cardiogénique, angor instable ou phase aiguë d'infarctus du myocarde."
  },
  {
    id: 14,
    brandName: "Gaviscon",
    dci: "Alginate de Sodium + Bicarbonate de Sodium",
    dosage: "500mg / 267mg",
    classTherapeutic: "Anti-acides & Anti-ulcéreux",
    form: "Suspension buvable",
    manufacturer: "Reckitt Benckiser",
    category: "specialite",
    indication: "Traitement symptomatique du reflux gastro-œsophagien (brûlures d'estomac, régurgitations acides).",
    atcCode: "A02BX13",
    contraindication: "Hypersensibilité aux principes actifs ou aux excipients."
  },
  {
    id: 15,
    brandName: "Seringue 5ml avec aiguille",
    dci: "Matériel d'injection stérile",
    dosage: "5ml - 21G",
    classTherapeutic: "Matériel de perfusion & Injection",
    form: "Dispositif médical unitaire",
    manufacturer: "Becton Dickinson",
    category: "consommable"
  },
  {
    id: 16,
    brandName: "Cathéter G22 - Bleu",
    dci: "Dispositif d'accès vasculaire périphérique",
    dosage: "G22",
    classTherapeutic: "Matériel de perfusion & Injection",
    form: "Dispositif médical unitaire",
    manufacturer: "B. Braun",
    category: "consommable"
  },
  {
    id: 17,
    brandName: "Ringer Lactate",
    dci: "Soluté d'électrolytes",
    dosage: "500ml",
    classTherapeutic: "Solutés d'hydratation & Perfusion",
    form: "Poche de perfusion souple",
    manufacturer: "Aguettant",
    category: "consommable",
    indication: "Rétablissement d'une volémie ou correction de pertes d'eau et de sels minéraux."
  },
  {
    id: 18,
    brandName: "Sérum Physiologique NaCl 0,9%",
    dci: "Chlorure de Sodium",
    dosage: "500ml",
    classTherapeutic: "Solutés d'hydratation & Perfusion",
    form: "Poche de perfusion souple",
    manufacturer: "Aguettant",
    category: "consommable",
    indication: "Réhydratation extracellulaire, solvant pour préparations injectables."
  },
  {
    id: 19,
    brandName: "Bétadine Dermique 10%",
    dci: "Povidone iodée",
    dosage: "125ml",
    classTherapeutic: "Antiseptiques & Désinfectants",
    form: "Solution cutanée",
    manufacturer: "Meda Pharma",
    category: "consommable",
    indication: "Antisepsie de la peau saine ou lésée (plaies chirurgicales ou traumatiques, brûlures superfcielle)."
  },
  {
    id: 20,
    brandName: "Compresses de gaze stériles",
    dci: "Compresse de coton hydrophile",
    dosage: "7.5 x 7.5 cm",
    classTherapeutic: "Pansements & Soins",
    form: "Sachet de 2 compresses",
    manufacturer: "Lohmann & Rauscher",
    category: "consommable"
  },
  // ---- MÉDICAMENTS EXTRAITS DE LA BASE DE DONNÉES PDF ----
  {
    id: 21,
    brandName: "ATryn",
    dci: "Antithrombine III",
    classTherapeutic: "Anticoagulants & Antithrombotiques",
    dosage: "1000 UI",
    form: "Poudre pour solution injectable",
    manufacturer: "N/A",
    category: "specialite",
    indication: "Prévention de la thrombo-embolie veineuse chez les patients congénitalement déficients en antithrombine."
  },
  {
    id: 22,
    brandName: "ATryn",
    dci: "Antithrombine III",
    classTherapeutic: "Anticoagulants & Antithrombotiques",
    dosage: "500 UI",
    form: "Poudre pour solution injectable",
    manufacturer: "N/A",
    category: "specialite",
    indication: "Prévention de la thrombo-embolie veineuse chez les patients congénitalement déficients."
  },
  {
    id: 23,
    brandName: "Abacavir",
    dci: "Abacavir",
    classTherapeutic: "Antirétroviraux (VIH)",
    dosage: "300mg",
    form: "Comprimé",
    manufacturer: "N/A",
    category: "specialite",
    indication: "Traitement de l’infection par le virus de l’immunodéficience humaine (VIH)."
  },
  {
    id: 24,
    brandName: "Abacavir",
    dci: "Abacavir",
    classTherapeutic: "Antirétroviraux (VIH)",
    dosage: "300mg",
    form: "Sirop",
    manufacturer: "N/A",
    category: "specialite",
    indication: "Traitement de l’infection par le virus de l’immunodéficience humaine (VIH)."
  },
  {
    id: 25,
    brandName: "Abacavir",
    dci: "Abacavir",
    classTherapeutic: "Antirétroviraux (VIH)",
    dosage: "600mg",
    form: "Comprimé",
    manufacturer: "N/A",
    category: "specialite",
    indication: "Traitement de l’infection par le virus de l’immunodéficience humaine."
  },
  {
    id: 26,
    brandName: "Abasaglar",
    dci: "Insuline glargine",
    classTherapeutic: "Insulines & Diabétologie",
    dosage: "100 UI/ml",
    form: "Injection IM/IV",
    manufacturer: "N/A",
    category: "specialite",
    indication: "Traitement du diabète sucré de l'adulte, de l'adolescent et de l'enfant à partir de 2 ans."
  },
  {
    id: 27,
    brandName: "Abasaglar",
    dci: "Insuline glargine",
    classTherapeutic: "Insulines & Diabétologie",
    dosage: "300 UI/ml",
    form: "Injection IM/IV",
    manufacturer: "N/A",
    category: "specialite",
    indication: "Traitement du diabète sucré de l'adulte et de l'adolescent."
  },
  {
    id: 28,
    brandName: "Abbocillin",
    dci: "Penicilline V",
    classTherapeutic: "Antibiotiques & Antibactériens",
    dosage: "1MUI",
    form: "Comprimé",
    manufacturer: "N/A",
    category: "specialite",
    indication: "Infections bactériennes dues aux germes sensibles."
  },
  {
    id: 29,
    brandName: "Abbocillin",
    dci: "Penicilline V",
    classTherapeutic: "Antibiotiques & Antibactériens",
    dosage: "1MUI",
    form: "Sirop",
    manufacturer: "N/A",
    category: "specialite",
    indication: "Infections bactériennes chez l'enfant dues aux germes sensibles."
  },
  {
    id: 30,
    brandName: "Abbocillin",
    dci: "Penicilline V",
    classTherapeutic: "Antibiotiques & Antibactériens",
    dosage: "250mg",
    form: "Comprimé",
    manufacturer: "N/A",
    category: "specialite",
    indication: "Traitement d'angines, otites, infections cutanées simples."
  },
  {
    id: 31,
    brandName: "Abbocillin",
    dci: "Penicilline V",
    classTherapeutic: "Antibiotiques & Antibactériens",
    dosage: "500mg",
    form: "Comprimé",
    manufacturer: "N/A",
    category: "specialite",
    indication: "Infections de l'adulte dues aux germes sensibles."
  },
  {
    id: 32,
    brandName: "Abboticine",
    dci: "Erythromycine",
    classTherapeutic: "Antibiotiques & Antibactériens",
    dosage: "250mg",
    form: "Comprimé",
    manufacturer: "N/A",
    category: "specialite",
    indication: "Alternative en cas d'allergie aux pénicillines (famille des macrolides)."
  },
  {
    id: 33,
    brandName: "Abboticine",
    dci: "Erythromycine",
    classTherapeutic: "Antibiotiques & Antibactériens",
    dosage: "250mg",
    form: "Gélule",
    manufacturer: "N/A",
    category: "specialite",
    indication: "Infections ORL, pulmonaires, cutanées ou génitales."
  },
  {
    id: 34,
    brandName: "Abboticine",
    dci: "Erythromycine",
    classTherapeutic: "Antibiotiques & Antibactériens",
    dosage: "250mg",
    form: "Injection IM/IV",
    manufacturer: "N/A",
    category: "specialite",
    indication: "Infections bactériennes sévères."
  },
  {
    id: 35,
    brandName: "Abboticine",
    dci: "Erythromycine",
    classTherapeutic: "Antibiotiques & Antibactériens",
    dosage: "500mg",
    form: "Comprimé",
    manufacturer: "N/A",
    category: "specialite",
    indication: "Infections de l'adulte dues aux germes sensibles."
  },
  {
    id: 36,
    brandName: "Abecma",
    dci: "Idécabtagène vicleucel",
    classTherapeutic: "Oncologie & Immunothérapie",
    dosage: "Dose personnalisée",
    form: "Injection IM/IV",
    manufacturer: "N/A",
    category: "specialite",
    indication: "Thérapie cellulaire génique (CAR-T) pour le traitement du myélome multiple."
  },
  {
    id: 37,
    brandName: "Abelcet",
    dci: "Amphotéricine B",
    classTherapeutic: "Antifongiques & Antimycosiques",
    dosage: "100mg",
    form: "Injection IM/IV",
    manufacturer: "N/A",
    category: "specialite",
    indication: "Infections fongiques invasives graves systémiques."
  },
  {
    id: 38,
    brandName: "Abelcet",
    dci: "Amphotéricine B",
    classTherapeutic: "Antifongiques & Antimycosiques",
    dosage: "50mg",
    form: "Injection IM/IV",
    manufacturer: "N/A",
    category: "specialite",
    indication: "Traitement symptomatique des mycoses profondes invasives."
  },
  {
    id: 39,
    brandName: "Abilify",
    dci: "Aripiprazole",
    classTherapeutic: "Neurologie & Psychiatrie",
    dosage: "10mg",
    form: "Comprimé",
    manufacturer: "N/A",
    category: "specialite",
    indication: "Traitement de la schizophrénie, épisodes maniaques du trouble bipolaire I."
  },
  {
    id: 40,
    brandName: "Abilify",
    dci: "Aripiprazole",
    classTherapeutic: "Neurologie & Psychiatrie",
    dosage: "10mg",
    form: "Sirop",
    manufacturer: "N/A",
    category: "specialite",
    indication: "Traitement de la schizophrénie et des troubles bipolaires chez l'adolescent."
  },
  {
    id: 41,
    brandName: "Abilify",
    dci: "Aripiprazole",
    classTherapeutic: "Neurologie & Psychiatrie",
    dosage: "15mg",
    form: "Comprimé",
    manufacturer: "N/A",
    category: "specialite",
    indication: "Posologie standard pour le trouble de la bipolarité."
  },
  {
    id: 42,
    brandName: "Abilify",
    dci: "Aripiprazole",
    classTherapeutic: "Neurologie & Psychiatrie",
    dosage: "30mg",
    form: "Comprimé",
    manufacturer: "N/A",
    category: "specialite",
    indication: "Posologie élevée de traitement de la schizophrénie."
  },
  {
    id: 43,
    brandName: "Abilify",
    dci: "Aripiprazole",
    classTherapeutic: "Neurologie & Psychiatrie",
    dosage: "5mg",
    form: "Comprimé",
    manufacturer: "N/A",
    category: "specialite",
    indication: "Dose initiale ou ajustements thérapeutiques."
  },
  {
    id: 44,
    brandName: "Abraxane",
    dci: "Abraxane (Paclitaxel albumine)",
    classTherapeutic: "Oncologie & Immunothérapie",
    dosage: "100mg",
    form: "Injection IM/IV",
    manufacturer: "N/A",
    category: "specialite",
    indication: "Traitement du cancer du sein métastatique ou de l'adénocarcinome du pancréas."
  },
  {
    id: 45,
    brandName: "Abreva",
    dci: "Docosanol",
    classTherapeutic: "Antiviraux & Dermatologie",
    dosage: "10%",
    form: "Comprimé",
    manufacturer: "N/A",
    category: "specialite",
    indication: "Traitement topique ou général du bouton herpétique labial."
  },
  {
    id: 46,
    brandName: "Abricycline",
    dci: "Tetracycline",
    classTherapeutic: "Antibiotiques & Antibactériens",
    dosage: "250mg",
    form: "Gélule",
    manufacturer: "N/A",
    category: "specialite",
    indication: "Infections bactériennes urinaires, respiratoires, ou cutanées d'origine sensible."
  },
  {
    id: 47,
    brandName: "Abricycline",
    dci: "Tetracycline",
    classTherapeutic: "Antibiotiques & Antibactériens",
    dosage: "500mg",
    form: "Gélule",
    manufacturer: "N/A",
    category: "specialite",
    indication: "Traitement intensifié d'infections à bactéries sensibles."
  },
  {
    id: 48,
    brandName: "Abseamed",
    dci: "Érythropoïétine (EPO)",
    classTherapeutic: "Hématologie & Facteurs de croissance",
    dosage: "1000 UI",
    form: "Injection IM/IV",
    manufacturer: "N/A",
    category: "specialite",
    indication: "Traitement de l'anémie symptomatique associée à l'insuffisance rénale ou suite à chimiothérapie."
  },
  {
    id: 49,
    brandName: "Abseamed",
    dci: "Érythropoïétine (EPO)",
    classTherapeutic: "Hématologie & Facteurs de croissance",
    dosage: "2000 UI",
    form: "Injection IM/IV",
    manufacturer: "N/A",
    category: "specialite",
    indication: "Traitement de l'anémie rénale ou post-chimiothérapie."
  },
  {
    id: 50,
    brandName: "Abseamed",
    dci: "Érythropoïétine (EPO)",
    classTherapeutic: "Hématologie & Facteurs de croissance",
    dosage: "4000 UI",
    form: "Injection IM/IV",
    manufacturer: "N/A",
    category: "specialite",
    indication: "Correction d'anémies chroniques sévères."
  },
  {
    id: 51,
    brandName: "Acarbose",
    dci: "Acarbose",
    classTherapeutic: "Insulines & Diabétologie",
    dosage: "50mg",
    form: "Comprimé",
    manufacturer: "N/A",
    category: "specialite",
    indication: "Adjuvant au régime adapté pour le diabète de type 2."
  },
  {
    id: 52,
    brandName: "Acarbose",
    dci: "Acarbose",
    classTherapeutic: "Insulines & Diabétologie",
    dosage: "100mg",
    form: "Comprimé",
    manufacturer: "N/A",
    category: "specialite",
    indication: "Diabète non insulinodépendant par inhibition des oses intestinaux."
  },
  {
    id: 53,
    brandName: "Accofil",
    dci: "Filgrastim",
    classTherapeutic: "Hématologie & Facteurs de croissance",
    dosage: "30MU/0.5ml",
    form: "Injection IM/IV",
    manufacturer: "N/A",
    category: "specialite",
    indication: "Stimulation de la moelle osseuse pour accroître les globules blancs."
  },
  {
    id: 54,
    brandName: "Accofil",
    dci: "Filgrastim",
    classTherapeutic: "Hématologie & Facteurs de croissance",
    dosage: "48MU/0.5ml",
    form: "Injection IM/IV",
    manufacturer: "N/A",
    category: "specialite",
    indication: "Traitement des neutropénies secondaires à la chimiothérapie cytotoxique."
  },
  {
    id: 55,
    brandName: "Aciclovir",
    dci: "Aciclovir",
    classTherapeutic: "Antiviraux & Dermatologie",
    dosage: "5%",
    form: "Comprimé",
    manufacturer: "N/A",
    category: "specialite",
    indication: "Traitement de l'herpès simplex récurrent ou zona aigu."
  },
  {
    id: 56,
    brandName: "Acide aminocaproïque",
    dci: "Acide aminocaproïque",
    classTherapeutic: "Hémostatiques & Antifibrinolytiques",
    dosage: "500mg",
    form: "Sirop",
    manufacturer: "N/A",
    category: "specialite",
    indication: "Inhibiteur de la fibrinolyse pour pallier aux syndromes hémorragiques."
  },
  {
    id: 57,
    brandName: "Acide borique",
    dci: "Acide borique",
    classTherapeutic: "Antiseptiques & Gynécologie",
    dosage: "500mg",
    form: "Comprimé",
    manufacturer: "N/A",
    category: "specialite",
    indication: "Propriétés antiseptiques légères locales pour herpès ou mycoses récurrentes."
  },
  {
    id: 58,
    brandName: "Acide folique",
    dci: "Acide folique",
    classTherapeutic: "Vitamines & Suppléments",
    dosage: "5mg",
    form: "Comprimé",
    manufacturer: "N/A",
    category: "specialite",
    indication: "Supplémentation en cas de carence, prévention des anomalies fœtales."
  },
  {
    id: 59,
    brandName: "Acide tranexamique",
    dci: "Acide tranexamique",
    classTherapeutic: "Hémostatiques & Antifibrinolytiques",
    dosage: "500mg",
    form: "Comprimé",
    manufacturer: "N/A",
    category: "specialite",
    indication: "Traitement de crises hémorragiques dues à un accroissement fibrinolytique."
  }
];

const GENERATOR_DCIS = [
  { name: "Paracétamol", class: "Antalgiques & Antipyrétiques", category: "specialite" as const },
  { name: "Amoxicilline", class: "Antibiotiques & Antibactériens", category: "specialite" as const },
  { name: "Ibuprofène", class: "Anti-inflammatoires (AINS)", category: "specialite" as const },
  { name: "Ceftriaxone", class: "Antibiotiques & Antibactériens", category: "specialite" as const },
  { name: "Métformine", class: "Insulines & Diabétologie", category: "specialite" as const },
  { name: "Amlodipine", class: "Cardiologie & Hypertension", category: "specialite" as const },
  { name: "Oméprazole", class: "Gastro-entérologie", category: "specialite" as const },
  { name: "Atorvastatine", class: "Cardiologie & Hypertension", category: "specialite" as const },
  { name: "Ciprofloxacine", class: "Antibiotiques & Antibactériens", category: "specialite" as const },
  { name: "Artemether + Lumefantrine", class: "Antipaludéens (Paludisme)", category: "specialite" as const },
  { name: "Salbutamol", class: "Pneumologie & Asthme", category: "specialite" as const },
  { name: "Phloroglucinol", class: "Antispasmodiques", category: "specialite" as const },
  { name: "Diazépam", class: "Neurologie & Psychiatrie", category: "specialite" as const },
  { name: "Sulfate de Fer + Acide folique", class: "Hématologie & Anémie", category: "specialite" as const },
  { name: "Cétirizine", class: "Allergologie & Antihistaminiques", category: "specialite" as const },
  { name: "Spironolactone", class: "Cardiologie & Hypertension", category: "specialite" as const },
  { name: "Prednisolone", class: "Corticoïdes (Anti-inflammatoires)", category: "specialite" as const },
  { name: "Azithromycine", class: "Antibiotiques & Antibactériens", category: "specialite" as const },
  { name: "Gliclazide", class: "Insulines & Diabétologie", category: "specialite" as const },
  { name: "Diclofénac", class: "Anti-inflammatoires (AINS)", category: "specialite" as const },
  { name: "Fluconazole", class: "Antifongiques & Antimycosiques", category: "specialite" as const },
  { name: "Tramadol", class: "Antalgiques & Antipyrétiques", category: "specialite" as const },
  { name: "Metoclopramide", class: "Gastro-entérologie", category: "specialite" as const },
  { name: "Furosémide", class: "Cardiologie & Hypertension", category: "specialite" as const },
  { name: "Losartan", class: "Cardiologie & Hypertension", category: "specialite" as const },
  { name: "Gentamicine", class: "Antibiotiques & Antibactériens", category: "specialite" as const }
];

import { medicationsSeed } from '../data/medicationData';
import { dciData } from '../data/dciData';
import { specialtiesData } from '../data/specialtiesData';
import { consumablesData } from '../data/consumablesData';

function generateStandardDatabase() {
  const list: any[] = [];
  
  // 1. Add medicationsSeed (1,007 real drug formulations)
  medicationsSeed.forEach((m, idx) => {
    list.push({
      nom_medicament: m.brandName || m.dci,
      dci: m.dci,
      dosage: m.dosage || "N/A",
      categorie: m.classTherapeutic || "Général",
      forme: m.form || "Comprimé",
      fournisseur: m.manufacturer || "N/A",
      quantite: Math.floor((idx * 7) % 350) + 50,
      quantite_min: 20,
      prix_achat: Math.floor((idx * 13) % 4500) + 150,
      prix_vente: Math.floor((idx * 13) % 4500) + 300,
      emplacement: `Rayon ${String.fromCharCode(65 + (idx % 26))}-${(idx % 10) + 1}`,
      created_at: new Date().toISOString()
    });
  });

  // 2. Expand specialtiesData (5,294 real drug brands)
  let specIdx = 0;
  specialtiesData.forEach((spec) => {
    spec.specialties.forEach((brand) => {
      list.push({
        nom_medicament: brand.brandName || spec.dci,
        dci: spec.dci,
        dosage: spec.dosage || "N/A",
        categorie: spec.classTherapeutic || "Général",
        forme: spec.form || "Comprimé",
        fournisseur: brand.manufacturer || "N/A",
        quantite: Math.floor((specIdx * 7) % 350) + 50,
        quantite_min: 20,
        prix_achat: Math.floor((specIdx * 13) % 4500) + 150,
        prix_vente: Math.floor((specIdx * 13) % 4500) + 300,
        emplacement: `Rayon ${String.fromCharCode(65 + (specIdx % 26))}-${(specIdx % 10) + 1}`,
        created_at: new Date().toISOString()
      });
      specIdx++;
    });
  });

  // 3. Add dciData (1,514 real items)
  dciData.forEach((m, idx) => {
    list.push({
      nom_medicament: m.brandName || m.dci,
      dci: m.dci,
      dosage: m.dosage || "N/A",
      categorie: m.classTherapeutic || "Général",
      forme: m.form || "Comprimé",
      fournisseur: m.manufacturer || "N/A",
      quantite: Math.floor((idx * 9) % 300) + 50,
      quantite_min: 20,
      prix_achat: Math.floor((idx * 11) % 4000) + 200,
      prix_vente: Math.floor((idx * 11) % 4000) + 400,
      emplacement: `Rayon ${String.fromCharCode(65 + ((idx + 5) % 26))}-${((idx + 3) % 10) + 1}`,
      created_at: new Date().toISOString()
    });
  });

  // 4. Add consumablesData (325 real items)
  consumablesData.forEach((m, idx) => {
    list.push({
      nom_medicament: m.brandName,
      dci: m.dci,
      dosage: m.dosage || "N/A",
      categorie: m.classTherapeutic || "Consommables & Matériels",
      forme: m.form || "Unité",
      fournisseur: m.manufacturer || "N/A",
      quantite: Math.floor((idx * 12) % 400) + 100,
      quantite_min: 30,
      prix_achat: Math.floor((idx * 15) % 3000) + 50,
      prix_vente: Math.floor((idx * 15) % 3000) + 100,
      emplacement: `Rayon M-${(idx % 15) + 1}`,
      created_at: new Date().toISOString()
    });
  });

  return list;
}

export default function BaseMedicaments() {
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedClass, setSelectedClass] = useState("");
  const [expandedId, setExpandedId] = useState<number | null>(null);
  
  // High-performance Mass Seeding States
  const [isGenerating, setIsGenerating] = useState(false);
  const [generationProgress, setGenerationProgress] = useState(0);
  const [isUploading, setIsUploading] = useState(false);
  const [uploadError, setUploadError] = useState("");

  // Pagination states to prevent DOM from freezing with 7,800 items
  const [currentPage, setCurrentPage] = useState(1);
  const itemsPerPage = 30;

  // Real-time integration of pharmacy-registered medications
  const dbMeds = useLiveQuery(() => db.base_medicaments.toArray()) || [];

  const medications = useMemo(() => {
    const customMeds: Medicament[] = dbMeds.map((m: any, idx: number) => ({
      id: m.id ? m.id + 1000 : 10000 + idx,
      brandName: m.nom_medicament || "",
      dci: m.dci || m.nom_medicament || "",
      dosage: m.dosage || "",
      classTherapeutic: m.categorie || "Pharmacie Générale",
      form: m.forme || m.form || "Comprimé",
      manufacturer: m.fournisseur || "N/A",
      category: (m.categorie?.toLowerCase().includes("matériel") || m.categorie?.toLowerCase().includes("consommable")) ? "consommable" : "specialite",
      isCustom: true,
      indication: m.indication || `Médicament d'aide à la prescription de la base nationale reference.`
    }));
    return [...INITIAL_MEDICATIONS, ...customMeds];
  }, [dbMeds]);
  
  const classesTherapeutiques = useMemo(() => {
    const list = Array.from(new Set(medications.map(m => m.classTherapeutic)));
    return list.sort();
  }, [medications]);

  const groupedClasses = useMemo(() => {
    const map: Record<string, string[]> = {};
    classesTherapeutiques.forEach((c) => {
      const firstLetter = c.charAt(0).toUpperCase();
      if (!map[firstLetter]) map[firstLetter] = [];
      map[firstLetter].push(c);
    });
    return map;
  }, [classesTherapeutiques]);

  const filteredMeds = useMemo(() => {
    let result = medications;
    
    if (selectedClass) {
      result = result.filter(m => m.classTherapeutic === selectedClass);
    }
    
    if (searchTerm.trim().length >= 1) {
      const term = searchTerm.toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "");
      result = result.filter(m => 
        `${m.brandName || ""} ${m.dci || ""} ${m.dosage || ""} ${m.classTherapeutic || ""} ${m.form || ""} ${m.manufacturer || ""}`
          .toLowerCase()
          .normalize("NFD")
          .replace(/[\u0300-\u036f]/g, "")
          .includes(term)
      );
    }
    
    return result;
  }, [medications, searchTerm, selectedClass]);

  // Reset pagination on search filter modifications
  useEffect(() => {
    setCurrentPage(1);
  }, [searchTerm, selectedClass]);

  const paginatedMeds = useMemo(() => {
    const start = (currentPage - 1) * itemsPerPage;
    return filteredMeds.slice(start, start + itemsPerPage);
  }, [filteredMeds, currentPage]);

  const totalPages = Math.ceil(filteredMeds.length / itemsPerPage);

  const classCounts = useMemo(() => {
    const counts: Record<string, number> = {};
    medications.forEach(m => {
      counts[m.classTherapeutic] = (counts[m.classTherapeutic] || 0) + 1;
    });
    return counts;
  }, [medications]);

  const stats = {
    total: medications.length,
    specialites: medications.filter(m => m.category === "specialite").length,
    dci: medications.filter(m => m.category === "dci").length,
    consommables: medications.filter(m => m.category === "consommable").length,
    classes: classesTherapeutiques.length
  };

  // Mass Loading Handlers
  const handleMassGenerate = async () => {
    setIsGenerating(true);
    setGenerationProgress(5);
    try {
      const preList = generateStandardDatabase();
      setGenerationProgress(25);
      
      // Clear existings to prevent multiple repetitive loads on subsequent clicks
      await db.base_medicaments.clear();
      setGenerationProgress(35);

      const chunkSize = 1500;
      for (let i = 0; i < preList.length; i += chunkSize) {
        const chunk = preList.slice(i, i + chunkSize);
        await db.base_medicaments.bulkAdd(chunk);
        setGenerationProgress(Math.min(95, Math.floor(35 + (i / preList.length) * 60)));
      }
      
      setGenerationProgress(100);
      toast.success("7 895 médicaments chargés et initialisés avec succès dans la base clinique !");
    } catch (error: any) {
      console.error(error);
      toast.error("Erreur de chargement en bloc : " + (error.message || error));
    } finally {
      setTimeout(() => {
        setIsGenerating(false);
        setGenerationProgress(0);
      }, 500);
    }
  };

  const handleClearDatabase = async () => {
    if (window.confirm("IMPORTANT: Êtes-vous sûr de vouloir vider TOUS les médicaments de la base de données? Cette opération est irréversible.")) {
      try {
        await db.base_medicaments.clear();
        toast.success("Base de données de médicaments réinitialisée.");
      } catch (err: any) {
        toast.error("Erreur lors de la réinitialisation : " + err.message);
      }
    }
  };

  const handleFileUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    setIsUploading(true);
    setUploadError("");

    const reader = new FileReader();
    reader.onload = async (e) => {
      try {
        const text = e.target?.result as string;
        if (!text) throw new Error("Impossible d'accéder au fichier");

        const lines = text.split(/\r?\n/).filter(line => line.trim().length > 0);
        if (lines.length < 2) {
          throw new Error("Format invalide : Le fichier doit contenir des colonnes et au moins une ligne de données.");
        }

        let delimiter = ",";
        const headerLine = lines[0];
        if (headerLine.includes(";")) delimiter = ";";
        else if (headerLine.includes("\t")) delimiter = "\t";

        const headers = headerLine.split(delimiter).map(h => 
          h.trim().toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "")
        );

        const idxNom = headers.findIndex(h => h.includes("nom") || h.includes("brand") || h.includes("produit") || h.includes("medicament") || h.includes("article"));
        const idxDci = headers.findIndex(h => h.includes("dci") || h.includes("molecule") || h.includes("substance") || h.includes("chimique"));
        const idxDosage = headers.findIndex(h => h.includes("dosage") || h.includes("dose") || h.includes("concentration") || h.includes("puissance"));
        const idxForme = headers.findIndex(h => h.includes("forme") || h.includes("form") || h.includes("presentation") || h.includes("boite"));
        const idxClasse = headers.findIndex(h => h.includes("classe") || h.includes("type") || h.includes("categorie") || h.includes("therapeutic") || h.includes("famille"));
        const idxLabo = headers.findIndex(h => h.includes("lab") || h.includes("fabricant") || h.includes("fournisseur") || h.includes("manufact"));
        const idxPrixVente = headers.findIndex(h => h.includes("vente") || h.includes("prix") || h.includes("tarif"));

        if (idxNom === -1) {
          throw new Error("Entête manquante : Assurez-vous d'avoir au moins une colonne nommée 'Nom' ou 'Médicament' dans l'entête.");
        }

        const itemsToInsert = [];
        for (let i = 1; i < lines.length; i++) {
          const rowText = lines[i].trim();
          if (!rowText) continue;

          let cols: string[] = [];
          if (rowText.includes('"')) {
            const regex = new RegExp(`\\s*${delimiter}\\s*(?=(?:[^"]*"[^"]*")*[^"]*$)`);
            cols = rowText.split(regex).map(c => c.replace(/^"|"$/g, "").trim());
          } else {
            cols = rowText.split(delimiter).map(c => c.trim());
          }

          if (cols.length === 0 || !cols[idxNom]) continue;

          const nom = cols[idxNom];
          const dci = idxDci !== -1 ? cols[idxDci] : nom;
          const dosage = idxDosage !== -1 ? cols[idxDosage] : "N/A";
          const forme = idxForme !== -1 ? cols[idxForme] : "Comprimé";
          const classe = idxClasse !== -1 ? cols[idxClasse] : "Pharmacie Générale";
          const lab = idxLabo !== -1 ? cols[idxLabo] : "N/A";
          const prix = idxPrixVente !== -1 ? parseFloat(cols[idxPrixVente].replace(/[^0-9.]/g, "")) || 500 : 500;

          itemsToInsert.push({
            nom_medicament: nom,
            dci: dci,
            dosage: dosage,
            categorie: classe,
            forme: forme,
            fournisseur: lab,
            quantite: 150,
            quantite_min: 20,
            prix_achat: Math.floor(prix * 0.75),
            prix_vente: prix,
            emplacement: "Emplacement Importé",
            created_at: new Date().toISOString()
          });
        }

        if (itemsToInsert.length === 0) {
          throw new Error("Aucun article valide trouvé. Vérifiez le format de votre fichier.");
        }

        const size = 1500;
        for (let i = 0; i < itemsToInsert.length; i += size) {
          await db.base_medicaments.bulkAdd(itemsToInsert.slice(i, i + size));
        }

        toast.success(`${itemsToInsert.length} médicaments importés avec succès depuis le fichier !`);
      } catch (err: any) {
        console.error(err);
        setUploadError(err.message || "Erreur lors du traitement du fichier");
        toast.error("Importation en échec");
      } finally {
        setIsUploading(false);
        event.target.value = "";
      }
    };
    reader.readAsText(file);
  };

  return (
    <div className="space-y-6 max-w-6xl">
      <div className="flex items-center justify-between flex-wrap gap-3">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-lg bg-teal-600 flex items-center justify-center">
            <Database className="w-5 h-5 text-white" />
          </div>
          <div>
            <h2 className="text-xl font-bold text-slate-800 dark:text-white">Base de données médicamenteuse</h2>
            <p className="text-sm text-slate-500">
              {stats.total} médicaments - {stats.classes} classes thérapeutiques
            </p>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-2 sm:grid-cols-5 gap-3">
        {[
          { label: "Total", val: stats.total, icon: Database, color: "bg-teal-100 text-teal-600" },
          { label: "Spécialités", val: stats.specialites, icon: Pill, color: "bg-blue-100 text-blue-600" },
          { label: "DCI", val: stats.dci, icon: FlaskConical, color: "bg-purple-100 text-purple-600" },
          { label: "Consommables", val: stats.consommables, icon: Syringe, color: "bg-amber-100 text-amber-600" },
          { label: "Classes", val: stats.classes, icon: Box, color: "bg-emerald-100 text-emerald-600" }
        ].map((item, idx) => (
          <Card key={idx} className="p-3">
            <div className="flex items-center gap-2">
              <div className={`w-8 h-8 rounded-lg ${item.color} flex items-center justify-center`}>
                <item.icon className="w-4 h-4" />
              </div>
              <div>
                <p className="text-xs text-slate-500">{item.label}</p>
                <p className="text-lg font-bold">{item.val}</p>
              </div>
            </div>
          </Card>
        ))}
      </div>

      {/* Modern Mass Loader & Custom File Importer Panel */}
      <Card className="border border-slate-250 bg-white dark:bg-slate-900 shadow-sm p-5 space-y-4 rounded-xl">
        <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
          <div className="space-y-1">
            <h3 className="text-base font-bold text-slate-850 dark:text-white flex items-center gap-2">
              <UploadCloud className="w-5 h-5 text-teal-600" />
              Alimentation en Masse de la Pharmacie & Clinique (7 800+ Articles)
            </h3>
            <p className="text-xs text-slate-600 dark:text-slate-400 leading-relaxed max-w-2xl">
              Votre clinique gère plus de 7 800 produits ? Chargez instantanément la base nationale standard complète (7 830 médicaments prédéfinis), ou importez votre propre fichier CSV/Text exporté depuis votre tableau de médicaments.
            </p>
          </div>
          <div className="flex flex-wrap gap-2 shrink-0">
            <Button
              onClick={handleMassGenerate}
              disabled={isGenerating || isUploading}
              className="bg-teal-600 hover:bg-teal-700 text-white text-xs px-3.5 h-9"
              id="btn-mass-generate"
            >
              {isGenerating ? (
                <>
                  <Loader2 className="w-3.5 h-3.5 mr-1.5 animate-spin" />
                  Génération {generationProgress}%
                </>
              ) : (
                <>
                  <Play className="w-3.5 h-3.5 mr-1.5" />
                  Charger 7 830 produits
                </>
              )}
            </Button>

            <div className="relative">
              <input
                type="file"
                accept=".csv, .tsv, .txt"
                onChange={handleFileUpload}
                disabled={isGenerating || isUploading}
                className="absolute inset-0 w-full h-full opacity-0 cursor-pointer disabled:cursor-not-allowed"
                id="mass-csv-uploader"
              />
              <Button
                variant="outline"
                disabled={isGenerating || isUploading}
                className="text-xs px-3.5 h-9 border-slate-300 hover:bg-slate-50 dark:hover:bg-slate-800"
                id="btn-csv-upload"
              >
                {isUploading ? (
                  <>
                    <Loader2 className="w-3.5 h-3.5 mr-1.5 animate-spin" />
                    Lecture...
                  </>
                ) : (
                  <>
                    <UploadCloud className="w-3.5 h-3.5 mr-1.5 text-teal-600" />
                    Importer CSV / Fichier
                  </>
                )}
              </Button>
            </div>

            <Button
              variant="destructive"
              onClick={handleClearDatabase}
              disabled={isGenerating || isUploading || stats.total === 0}
              className="text-xs px-3 h-9"
              title="Vider la base de données"
              id="btn-clear-db"
            >
              <Trash2 className="w-3.5 h-3.5 mr-1.5" />
              Réinitialiser
            </Button>
          </div>
        </div>

        {uploadError && (
          <p className="text-xs font-semibold text-red-650 bg-red-50 dark:bg-red-950/20 p-2.5 rounded border border-red-100 dark:border-red-900/30">
            {uploadError}
          </p>
        )}
        
        {isGenerating && (
          <div className="w-full bg-slate-100 dark:bg-slate-800 rounded-full h-1.5 mt-2 overflow-hidden">
            <div 
              className="bg-teal-600 h-1.5 rounded-full transition-all duration-300" 
              style={{ width: `${generationProgress}%` }}
            />
          </div>
        )}
      </Card>

      <div className="relative">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
        <Input 
          placeholder="Rechercher (DCI, nom commercial, classe...)" 
          value={searchTerm} 
          onChange={(e) => { setSearchTerm(e.target.value); setSelectedClass(""); }} 
          className="pl-9 bg-white dark:bg-slate-950" 
          id="input-meds-search"
        />
        {(searchTerm || selectedClass) && (
          <Button 
            variant="ghost" 
            size="sm" 
            className="absolute right-2 top-1/2 -translate-y-1/2" 
            onClick={() => { setSearchTerm(""); setSelectedClass(""); }}
          >
            <X className="w-4 h-4" />
          </Button>
        )}
      </div>

      <div className="grid lg:grid-cols-4 gap-4">
        <div className="lg:col-span-1">
          <Card className="max-h-[calc(100vh-320px)] overflow-y-auto">
            <div className="pb-2 sticky top-0 bg-white dark:bg-slate-900 z-10 p-4 border-b">
              <div className="text-sm flex items-center gap-2 font-semibold text-slate-800 dark:text-slate-100">
                <Filter className="w-4 h-4 text-teal-600" />
                Classes thérapeutiques
              </div>
              {selectedClass && (
                <Button variant="ghost" size="sm" className="text-xs mt-1 h-8" onClick={() => setSelectedClass("")}>
                  <X className="w-3 h-3 mr-1" /> Effacer le filtre
                </Button>
              )}
            </div>
            <div className="space-y-2 pt-2 px-4 pb-4">
              {Object.entries(groupedClasses).map(([letter, items]) => (
                <div key={letter}>
                  <p className="text-xs font-bold text-slate-400 uppercase mb-1">{letter}</p>
                  <div className="space-y-1">
                    {items.map(className => (
                      <button 
                        key={className}
                        onClick={() => { setSelectedClass(className); setSearchTerm(""); }}
                        className={`w-full text-left px-2 py-1.5 rounded text-xs transition-colors flex items-center justify-between ${selectedClass === className ? "bg-teal-50 text-teal-700 dark:bg-teal-900/30 dark:text-teal-300 font-medium" : "hover:bg-slate-50 dark:hover:bg-slate-800 text-slate-600 dark:text-slate-400"}`}
                      >
                        <span className="truncate pr-1">{className}</span>
                        <Badge variant="outline" className="text-[10px] shrink-0">{classCounts[className] || 0}</Badge>
                      </button>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          </Card>
        </div>

        <div className="lg:col-span-3">
          {(selectedClass || searchTerm) && (
            <div className="mb-3 flex items-center gap-2 flex-wrap">
              {selectedClass && <Badge className="bg-teal-100 text-teal-700 dark:bg-teal-900/30 dark:text-teal-300">{selectedClass}</Badge>}
              {searchTerm && <Badge className="bg-slate-100 text-slate-700 dark:bg-slate-800 dark:text-slate-300">{searchTerm}</Badge>}
              <span className="text-xs text-slate-500 font-medium">{filteredMeds.length} médicament(s) trouvé(s)</span>
            </div>
          )}

          <div className="space-y-2">
            {paginatedMeds.map((med) => (
              <Card key={med.id} className="overflow-hidden border border-slate-150 shadow-sm hover:border-slate-350 dark:hover:border-slate-700 transition-all rounded-lg">
                <button 
                  className="w-full p-3.5 flex items-center justify-between text-left hover:bg-slate-50 dark:hover:bg-slate-800/40 transition-colors"
                  onClick={() => setExpandedId(expandedId === med.id ? null : med.id)}
                >
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 flex-wrap">
                      <span className="font-semibold text-sm text-slate-850 dark:text-slate-100">{med.brandName}</span>
                      <Badge className={`text-[10px] uppercase font-bold tracking-wide ${CATEGORY_COLORS[med.category]}`}>{CATEGORY_LABELS[med.category]}</Badge>
                      {med.isCustom && <Badge variant="outline" className="text-[10px] border-teal-200 text-teal-600 bg-teal-50/50">Base Locale</Badge>}
                    </div>
                    <p className="text-xs text-teal-600 font-medium mt-1">{med.dci} - {med.dosage}</p>
                    <p className="text-[11px] text-slate-500 mt-0.5">{med.classTherapeutic} | {med.form}{med.manufacturer ? ` | ${med.manufacturer}` : ""}</p>
                  </div>
                  {expandedId === med.id ? <ChevronUp className="w-4 h-4 text-slate-400" /> : <ChevronDown className="w-4 h-4 text-slate-400" />}
                </button>
                
                {expandedId === med.id && (
                  <div className="px-4 pb-3.5 border-t bg-slate-50/50 dark:bg-slate-900/40 space-y-2.5 pt-3 animate-fade-in">
                    {med.indication && (
                      <div>
                        <p className="text-xs font-semibold text-slate-550">Indications / Remarque</p>
                        <p className="text-xs text-slate-700 dark:text-slate-300 mt-1 leading-relaxed">{med.indication}</p>
                      </div>
                    )}
                    <div className="grid grid-cols-2 gap-2 text-xs border-t pt-2.5">
                      {med.atcCode && <p><span className="text-slate-400">ATC:</span> <span className="font-mono text-slate-700 dark:text-slate-300">{med.atcCode}</span></p>}
                      {med.manufacturer && <p><span className="text-slate-400">Fabricant:</span> <span className="text-slate-700 dark:text-slate-300 font-medium">{med.manufacturer}</span></p>}
                    </div>
                  </div>
                )}
              </Card>
            ))}

            {filteredMeds.length === 0 && (
              <div className="text-center py-12 bg-slate-50 dark:bg-slate-900 rounded-xl border border-dashed border-slate-200">
                <Pill className="w-8 h-8 text-slate-400 mx-auto mb-2" />
                <p className="text-sm font-semibold text-slate-700 dark:text-slate-300">Aucun produit ne correspond à ces critères</p>
                <p className="text-xs text-slate-400 mt-1">Générez la base de 7 830 produits ou ajustez votre recherche.</p>
              </div>
            )}
          </div>

          {/* High-Performance Pagination Controls */}
          {totalPages > 1 && (
            <div className="flex items-center justify-between pt-5 mt-4 border-t border-slate-100 dark:border-slate-800">
              <Button
                variant="outline"
                size="sm"
                onClick={() => setCurrentPage(prev => Math.max(prev - 1, 1))}
                disabled={currentPage === 1}
                className="h-8.5 text-xs border-slate-300"
              >
                Précédent
              </Button>
              <span className="text-xs text-slate-500 font-semibold">
                Page {currentPage} sur {totalPages} ({filteredMeds.length} produits)
              </span>
              <Button
                variant="outline"
                size="sm"
                onClick={() => setCurrentPage(prev => Math.min(prev + 1, totalPages))}
                disabled={currentPage === totalPages}
                className="h-8.5 text-xs border-slate-300"
              >
                Suivant
              </Button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}