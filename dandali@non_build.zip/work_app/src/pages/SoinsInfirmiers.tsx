import React, { useState, useEffect } from 'react';
import { db } from '@/db';
import { 
  Bed, 
  Plus, 
  Search, 
  Trash, 
  X, 
  Stethoscope, 
  User, 
  Calendar, 
  Edit, 
  CheckCircle2, 
  AlertCircle 
} from 'lucide-react';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { toast } from 'sonner';
import { useAuth } from '@/contexts/AuthContext';

interface Soin {
  id?: number;
  patient_id: string;
  type_soin: string;
  infirmier: string;
  soin_detail: string;
  date_soin: string;
  statut: string;
  observations: string;
}

interface TypeSoin {
  id?: number;
  nom: string;
  description?: string;
}

interface Patient {
  id?: number;
  nom_complet: string;
  numero_patient: string;
  age: number;
  sexe: string;
  telephone: string;
}

export default function SoinsInfirmiers() {
  const [activeTab, setActiveTab] = useState<'list' | 'newPatient' | 'newSoin' | 'typeForm'>('list');
  const [soins, setSoins] = useState<Soin[]>([]);
  const [patients, setPatients] = useState<Patient[]>([]);
  const [typesSoin, setTypesSoin] = useState<TypeSoin[]>([]);
  
  const [search, setSearch] = useState("");
  const [currentTab, setCurrentTab] = useState<'soins' | 'types'>('soins');
  
  const [newPatient, setNewPatient] = useState({ numero_patient: "", nom_complet: "", age: "", sexe: "M", telephone: "" });
  const [newSoin, setNewSoin] = useState<Soin>({ patient_id: "", type_soin: "", infirmier: "", soin_detail: "", date_soin: "", statut: "planifie", observations: "" });
  const [editingType, setEditingType] = useState<TypeSoin>({ id: null, nom: "", description: "" });

  const { canEdit } = useAuth();

  useEffect(() => {
    loadData();
  }, []);

  const handleCreatePatient = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newPatient.nom_complet.trim()) {
      toast.error("Le nom complet est obligatoire");
      return;
    }
    const patientData = {
      numero_patient: newPatient.numero_patient || `SOI-${String(patients.length + 1).padStart(4, "0")}`,
      nom_complet: newPatient.nom_complet,
      age: Number(newPatient.age) || 0,
      sexe: newPatient.sexe,
      telephone: newPatient.telephone,
      created_at: new Date()
    };
    await db.patients_soins.add(patientData);
    toast.success("Patient ajouté avec succès !");
    setNewPatient({ numero_patient: "", nom_complet: "", age: "", sexe: "M", telephone: "" });
    loadData();
    setActiveTab("list");
  };

  const handleCreateSoin = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newSoin.patient_id) {
      toast.error("Veuillez sélectionner un patient");
      return;
    }
    if (!newSoin.type_soin) {
      toast.error("Veuillez sélectionner un type de soin");
      return;
    }
    const soinData = {
      ...newSoin,
      date_soin: newSoin.date_soin || new Date().toISOString().slice(0, 16),
      created_at: new Date()
    };
    await db.soinsInfirmiers.add(soinData);
    toast.success("Soin infirmier enregistré avec succès !");
    setNewSoin({ patient_id: "", type_soin: "", infirmier: "", soin_detail: "", date_soin: "", statut: "planifie", observations: "" });
    loadData();
    setActiveTab("list");
  };

  const handleSaveTypeSoin = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingType.nom.trim()) {
      toast.error("Le nom du type est requis");
      return;
    }
    if (editingType.id) {
      await db.typesSoinsInfirmiers.update(editingType.id, {
        nom: editingType.nom,
        description: editingType.description,
        actif: true
      });
      toast.success("Type de soin mis à jour");
    } else {
      await db.typesSoinsInfirmiers.add({
        nom: editingType.nom,
        description: editingType.description,
        actif: true,
        created_at: new Date()
      });
      toast.success("Type de soin créé");
    }
    setEditingType({ id: null, nom: "", description: "" });
    loadData();
    setActiveTab("list");
  };

  const deleteSoin = async (id: number) => {
    if (window.confirm("Supprimer ce soin ?")) {
      await db.soinsInfirmiers.delete(id);
      toast.success("Soin supprimé");
      loadData();
    }
  };

  const updateSoinStatus = async (id: number, status: string) => {
    await db.soinsInfirmiers.update(id, { statut: status });
    toast.success(`Statut mis à jour`);
    loadData();
  };

  async function loadData() {
    const [s, p] = await Promise.all([
      db.soinsInfirmiers.toArray(),
      db.patients_soins.toArray()
    ]);
    
    let t = await db.typesSoinsInfirmiers.toArray();
    if (t.length === 0) {
      const defaultTypes = [
        { nom: "Pansement chirurgical", description: "Nettoyage, désinfection et réfection de pansements", actif: true, created_at: new Date() },
        { nom: "Injection IM/IV", description: "Administration de médicaments injectables par voie intramusculaire ou intraveineuse", actif: true, created_at: new Date() },
        { nom: "Perfusion", description: "Pose, réglage de débit et surveillance de perfusions vasculaires", actif: true, created_at: new Date() },
        { nom: "Prise de constantes", description: "Mesure de la tension, température, pouls et oxygénation", actif: true, created_at: new Date() },
        { nom: "Aérosolthérapie / Nébulisation", description: "Administration de bronchodilatateurs en inhalations", actif: true, created_at: new Date() },
        { nom: "Prélèvement sanguin", description: "Prise de sang pour examens de laboratoire", actif: true, created_at: new Date() }
      ];
      for (const item of defaultTypes) {
        await db.typesSoinsInfirmiers.add(item);
      }
      t = await db.typesSoinsInfirmiers.toArray();
    }
    
    setSoins(s);
    setPatients(p);
    setTypesSoin(t);
  }

  async function deleteTypeSoin(id: number) {
    if (window.confirm("Supprimer ce type de soin ?")) {
      await db.typesSoinsInfirmiers.delete(id);
      toast.success("Supprimé");
      loadData();
    }
  }

  const filteredSoins = soins.filter(s => {
    const patientObj = patients.find(p => p.id === Number(s.patient_id));
    return !search || (patientObj?.nom_complet || "").toLowerCase().includes(search.toLowerCase());
  });

  if (activeTab === "newPatient") {
    return (
      <div className="space-y-4 max-w-2xl">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <Bed className="w-6 h-6 text-green-600" />
            <h2 className="text-xl font-bold text-slate-800 dark:text-white">Nouveau Patient - Soins Infirmiers</h2>
          </div>
          <Button variant="ghost" size="sm" onClick={() => setActiveTab("list")}>
            <X className="w-4 h-4" />
          </Button>
        </div>
        <Card>
          <CardContent className="p-4">
            <form onSubmit={handleCreatePatient} className="space-y-3">
              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1">
                  <Label>N° Patient (Généré si vide)</Label>
                  <Input value={newPatient.numero_patient} onChange={e => setNewPatient({...newPatient, numero_patient: e.target.value})} placeholder="Ex: SOI-0001" />
                </div>
                <div className="space-y-1">
                  <Label>Nom complet *</Label>
                  <Input value={newPatient.nom_complet} onChange={e => setNewPatient({...newPatient, nom_complet: e.target.value})} placeholder="Ex: Souleymane Diallo" required />
                </div>
              </div>
              <div className="grid grid-cols-3 gap-3">
                <div className="space-y-1">
                  <Label>Age</Label>
                  <Input type="number" value={newPatient.age} onChange={e => setNewPatient({...newPatient, age: e.target.value})} placeholder="Ex: 40" />
                </div>
                <div className="space-y-1">
                  <Label>Sexe</Label>
                  <select value={newPatient.sexe} onChange={e => setNewPatient({...newPatient, sexe: e.target.value})} className="w-full h-9 rounded-md border border-input bg-transparent px-3 py-1 text-sm">
                    <option value="M">M</option>
                    <option value="F">F</option>
                  </select>
                </div>
                <div className="space-y-1">
                  <Label>Tel</Label>
                  <Input value={newPatient.telephone} onChange={e => setNewPatient({...newPatient, telephone: e.target.value})} placeholder="Ex: 77123456" />
                </div>
              </div>
              <div className="flex justify-end gap-2">
                <Button type="button" variant="outline" onClick={() => setActiveTab("list")}>Annuler</Button>
                {canEdit("soins") && <Button type="submit" className="bg-green-600 hover:bg-green-700 text-white">Créer</Button>}
              </div>
            </form>
          </CardContent>
        </Card>
      </div>
    );
  }

  if (activeTab === "newSoin") {
    return (
      <div className="space-y-4 max-w-2xl">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <Plus className="w-6 h-6 text-green-600" />
            <h2 className="text-xl font-bold text-slate-800 dark:text-white">Créer un acte de soin infirmier</h2>
          </div>
          <Button variant="ghost" size="sm" onClick={() => setActiveTab("list")}>
            <X className="w-4 h-4" />
          </Button>
        </div>
        <Card>
          <CardContent className="p-4">
            <form onSubmit={handleCreateSoin} className="space-y-3">
              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1">
                  <Label>Patient *</Label>
                  <select 
                    value={newSoin.patient_id} 
                    onChange={e => setNewSoin({...newSoin, patient_id: e.target.value})} 
                    className="w-full h-10 rounded-md border border-input bg-transparent px-3 py-1 text-sm dark:bg-slate-900"
                    required
                  >
                    <option value="">Sélectionner un patient...</option>
                    {patients.map(p => (
                      <option key={p.id} value={p.id}>{p.nom_complet} ({p.numero_patient})</option>
                    ))}
                  </select>
                </div>
                <div className="space-y-1">
                  <Label>Type de soin *</Label>
                  <select 
                    value={newSoin.type_soin} 
                    onChange={e => setNewSoin({...newSoin, type_soin: e.target.value})} 
                    className="w-full h-10 rounded-md border border-input bg-transparent px-3 py-1 text-sm dark:bg-slate-900"
                    required
                  >
                    <option value="">Sélectionner l'acte...</option>
                    {typesSoin.map(t => (
                      <option key={t.id} value={t.nom}>{t.nom}</option>
                    ))}
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1">
                  <Label>Détail de l'intervention / Posologie</Label>
                  <Input value={newSoin.soin_detail} onChange={e => setNewSoin({...newSoin, soin_detail: e.target.value})} placeholder="Ex: 1 ampoule IM ou pansement de brûlure" />
                </div>
                <div className="space-y-1">
                  <Label>Date d'administration</Label>
                  <Input type="datetime-local" value={newSoin.date_soin} onChange={e => setNewSoin({...newSoin, date_soin: e.target.value})} />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1">
                  <Label>Infirmier(e) praticien(ne)</Label>
                  <Input value={newSoin.infirmier} onChange={e => setNewSoin({...newSoin, infirmier: e.target.value})} placeholder="Ex: Aminata Keita" />
                </div>
                <div className="space-y-1">
                  <Label>Statut initial</Label>
                  <select value={newSoin.statut} onChange={e => setNewSoin({...newSoin, statut: e.target.value})} className="w-full h-10 rounded-md border border-input bg-transparent px-3 py-1 text-sm dark:bg-slate-900">
                    <option value="planifie">Planifié</option>
                    <option value="en_cours">En cours</option>
                    <option value="realise">Réalisé</option>
                    <option value="annule">Annulé</option>
                  </select>
                </div>
              </div>

              <div className="space-y-1">
                <Label>Notes d'observations cliniques</Label>
                <Textarea value={newSoin.observations} onChange={e => setNewSoin({...newSoin, observations: e.target.value})} placeholder="Prise de constantes, comportement ou tolérance du patient..." />
              </div>

              <div className="flex justify-end gap-2 pt-2">
                <Button type="button" variant="outline" onClick={() => setActiveTab("list")}>Annuler</Button>
                <Button type="submit" className="bg-green-600 hover:bg-green-700 text-white">Enregistrer le Soin</Button>
              </div>
            </form>
          </CardContent>
        </Card>
      </div>
    );
  }

  if (activeTab === "typeForm") {
    return (
      <div className="space-y-4 max-w-xl">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <Stethoscope className="w-6 h-6 text-green-600" />
            <h2 className="text-xl font-bold text-slate-800 dark:text-white">{editingType.id ? "Modifier le Type de Soin" : "Créer un Type de Soin"}</h2>
          </div>
          <Button variant="ghost" size="sm" onClick={() => setActiveTab("list")}>
            <X className="w-4 h-4" />
          </Button>
        </div>
        <Card>
          <CardContent className="p-4">
            <form onSubmit={handleSaveTypeSoin} className="space-y-3">
              <div className="space-y-1">
                <Label>Désignation de l'acte *</Label>
                <Input value={editingType.nom} onChange={e => setEditingType({...editingType, nom: e.target.value})} placeholder="Ex: Lavage vésical" required />
              </div>
              <div className="space-y-1">
                <Label>Description / Protocoles</Label>
                <Textarea value={editingType.description || ""} onChange={e => setEditingType({...editingType, description: e.target.value})} placeholder="Détails du protocole infirmier..." />
              </div>
              <div className="flex justify-end gap-2 pt-2">
                <Button type="button" variant="outline" onClick={() => setActiveTab("list")}>Annuler</Button>
                <Button type="submit" className="bg-green-600 hover:bg-green-700 text-white">Sauvegarder</Button>
              </div>
            </form>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between flex-wrap gap-3">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-lg bg-green-500 flex items-center justify-center">
            <Stethoscope className="w-5 h-5 text-white" />
          </div>
          <div>
            <h2 className="text-lg font-semibold text-slate-800 dark:text-white">Soins Infirmiers</h2>
            <p className="text-sm text-slate-500">{soins.length} soin(s) | {patients.length} patient(s)</p>
          </div>
        </div>
        <div className="flex gap-2">
          {canEdit("soins") && (
            <>
              <Button variant="outline" onClick={() => setActiveTab("newPatient")} className="border-green-200 text-green-700 hover:bg-green-50">
                <User className="w-4 h-4 mr-1" /> Nouveau Patient
              </Button>
              <Button variant="outline" onClick={() => {setEditingType({id: null, nom: ""}); setActiveTab("typeForm")}} className="border-green-200 text-green-700 hover:bg-green-50">
                <Stethoscope className="w-4 h-4 mr-1" /> Actes de Soin
              </Button>
              <Button onClick={() => {
                const nowStr = new Date().toISOString().slice(0, 16);
                setNewSoin({ patient_id: "", type_soin: "", infirmier: "", soin_detail: "", date_soin: nowStr, statut: "planifie", observations: "" });
                setActiveTab("newSoin");
              }} className="bg-green-600 hover:bg-green-700 text-white">
                <Plus className="w-4 h-4 mr-1" /> Enregistrer Soin
              </Button>
            </>
          )}
        </div>
      </div>

      <div className="flex border-b border-slate-200 dark:border-slate-800">
        <button
          onClick={() => setCurrentTab('soins')}
          className={`px-4 py-2 text-sm font-medium border-b-2 transition-colors ${currentTab === 'soins' ? 'border-green-500 text-green-600' : 'border-transparent text-slate-500 hover:text-slate-700'}`}
        >
          Soin Des Patients ({filteredSoins.length})
        </button>
        <button
          onClick={() => setCurrentTab('types')}
          className={`px-4 py-2 text-sm font-medium border-b-2 transition-colors ${currentTab === 'types' ? 'border-green-500 text-green-600' : 'border-transparent text-slate-500 hover:text-slate-700'}`}
        >
          Actes de Soins Configurés ({typesSoin.length})
        </button>
      </div>

      {currentTab === 'soins' ? (
        <div className="space-y-4">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
            <Input 
              placeholder="Rechercher par nom de patient ou statut..." 
              value={search} 
              onChange={(e) => setSearch(e.target.value)} 
              className="pl-10"
            />
          </div>

          <div className="grid gap-3">
            {filteredSoins.length === 0 ? (
              <div className="text-center py-12 text-slate-400 border border-dashed rounded-xl dark:border-slate-800">
                <Stethoscope className="w-12 h-12 mx-auto mb-2 opacity-50" />
                <p className="text-sm">Aucun soin infirmier enregistré ou trouvé</p>
              </div>
            ) : (
              filteredSoins.map((soin) => {
                const patient = patients.find(p => p.id === Number(soin.patient_id));
                return (
                  <Card key={soin.id} className="p-4">
                    <div className="flex items-start justify-between flex-wrap gap-2">
                      <div className="space-y-1">
                        <div className="flex items-center gap-2 flex-wrap">
                          <span className="font-bold text-slate-800 dark:text-white">{patient?.nom_complet || "Patient Inconnu"}</span>
                          <span className="text-xs text-slate-400">({patient?.numero_patient})</span>
                          <div className={`px-2 py-0.5 rounded text-[10px] font-semibold uppercase ${
                            soin.statut === 'realise' ? "bg-green-100 text-green-800 dark:bg-green-900/20 dark:text-green-400" :
                            soin.statut === 'en_cours' ? "bg-amber-100 text-amber-800 dark:bg-amber-900/20 dark:text-amber-400 animate-pulse" :
                            soin.statut === 'annule' ? "bg-red-100 text-red-800 dark:bg-red-900/20 dark:text-red-400" :
                            "bg-slate-100 text-slate-800 dark:bg-slate-800 dark:text-slate-400"
                          }`}>
                            {soin.statut === 'realise' ? 'Réalisé' :
                             soin.statut === 'en_cours' ? 'En cours' :
                             soin.statut === 'annule' ? 'Annulé' : 'Planifié'}
                          </div>
                        </div>
                        <p className="text-sm text-green-700 dark:text-green-400 font-semibold">{soin.type_soin} {soin.soin_detail ? `- ${soin.soin_detail}` : ""}</p>
                        <p className="text-xs text-slate-500">
                          <strong>Date:</strong> {soin.date_soin ? new Date(soin.date_soin).toLocaleString('fr-FR') : "Non définie"} 
                          {soin.infirmier && ` | Infirmier(e): ${soin.infirmier}`}
                        </p>
                        {soin.observations && (
                          <div className="p-2 bg-slate-50 dark:bg-slate-900 rounded text-xs text-slate-600 dark:text-slate-400 mt-2 border-l-2 border-green-500">
                            <strong>Observations:</strong> {soin.observations}
                          </div>
                        )}
                      </div>

                      <div className="flex gap-1">
                        {soin.statut !== 'realise' && soin.statut !== 'annule' && (
                          <>
                            <Button size="sm" variant="outline" className="text-green-600 border-green-200 hover:bg-green-50" onClick={() => updateSoinStatus(soin.id!, 'realise')}>
                              <CheckCircle2 className="w-3.5 h-3.5 mr-1" /> Réalisé
                            </Button>
                            {soin.statut !== 'en_cours' && (
                              <Button size="sm" variant="outline" className="text-amber-600 border-amber-200 hover:bg-amber-50" onClick={() => updateSoinStatus(soin.id!, 'en_cours')}>
                                <Calendar className="w-3.5 h-3.5 mr-1" /> Commencer
                              </Button>
                            )}
                          </>
                        )}
                        <Button size="sm" variant="ghost" className="text-red-600 hover:text-red-700" onClick={() => deleteSoin(soin.id!)}>
                          <Trash className="w-3.5 h-3.5" />
                        </Button>
                      </div>
                    </div>
                  </Card>
                );
              })
            )}
          </div>
        </div>
      ) : (
        <div className="grid md:grid-cols-2 gap-4">
          <div className="space-y-3">
            <h3 className="font-semibold text-sm text-slate-700 dark:text-slate-300">Actes infirmiers de soin pré-configurés</h3>
            <div className="space-y-2">
              {typesSoin.map(t => (
                <Card key={t.id} className="p-3">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="font-bold text-sm text-slate-800 dark:text-white">{t.nom}</p>
                      <p className="text-xs text-slate-500">{t.description || "Aucune description enregistrée"}</p>
                    </div>
                    <div className="flex gap-1">
                      <Button size="sm" variant="ghost" onClick={() => { setEditingType({ id: t.id, nom: t.nom, description: t.description }); setActiveTab("typeForm"); }}>
                        <Edit className="w-3.5 h-3.5" />
                      </Button>
                      <Button size="sm" variant="ghost" className="text-red-600 hover:text-red-700" onClick={() => deleteTypeSoin(t.id!)}>
                        <Trash className="w-3.5 h-3.5" />
                      </Button>
                    </div>
                  </div>
                </Card>
              ))}
            </div>
          </div>

          <div className="p-4 bg-teal-50/50 dark:bg-teal-900/10 rounded-xl space-y-3 border border-teal-100 dark:border-teal-900/30 flex flex-col justify-center">
            <h4 className="font-bold text-teal-850 dark:text-teal-400 flex items-center gap-2">
              <AlertCircle className="w-5 h-5 text-teal-600" />
              Plateforme infirmière Koule Djakan
            </h4>
            <p className="text-xs text-teal-800 dark:text-teal-400 leading-relaxed">
              Ce module centralise la saisie des soins administrés au quotidien par l'équipe soignante infirmière sur prescription médicale (perfusions, sutures, pansements, constantes de suivi), avec couplage automatique à l'historique global de l'hospitalisation ou du dossier clinique patient.
            </p>
          </div>
        </div>
      )}
    </div>
  );
}