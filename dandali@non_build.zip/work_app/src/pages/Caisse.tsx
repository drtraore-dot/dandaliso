import React, { useState, useEffect } from 'react';
import { db } from '@/db';
import { 
  Wallet, 
  Plus, 
  Search, 
  CreditCard, 
  FileText, 
  X, 
  UserPlus, 
  TrendingUp, 
  TrendingDown, 
  AlertCircle 
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { toast } from 'sonner';
import { getPrintSettings, renderPrintHeader, renderPrintFooter } from '@/lib/printSettings';

interface CaisseProps {
  // Add specific prop interfaces if needed
}

export const Caisse: React.FC<CaisseProps> = () => {
  const [recettes, setRecettes] = useState<any[]>([]);
  const [credits, setCredits] = useState<any[]>([]);
  const [patients, setPatients] = useState<any[]>([]);
  const [actes, setActes] = useState<any[]>([]);
  const [prescripteurs, setPrescripteurs] = useState<any[]>([]);
  const [prestataires, setPrestataires] = useState<any[]>([]);
  const [assurances, setAssurances] = useState<any[]>([]);
  const [categoriesActes, setCategoriesActes] = useState<any[]>([]);
  const [expandedCategorieId, setExpandedCategorieId] = useState<string | number>('');
  const [view, setView] = useState<'recettes' | 'credits'>('recettes');
  const [searchTerm, setSearchTerm] = useState("");
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [showNewPatient, setShowNewPatient] = useState(false);
  const [selectedTicket, setSelectedTicket] = useState<any | null>(null);
  const [isTicketViewOpen, setIsTicketViewOpen] = useState(false);
  const [ticketActes, setTicketActes] = useState<any[]>([]);

  const [form, setForm] = useState({
    id: 0,
    patient_id: "",
    acte_id: "",
    quantite: 1,
    montant: 0,
    mode_paiement: "especes",
    date: new Date().toISOString(),
    isCredit: false,
    montant_avance: 0,
    reference_paiement: "",
    est_assure: false,
    assurance_id: "",
    assurance_nom: "",
    prescripteur_id: "",
    prestataire_id: ""
  });

  const [newPatient, setNewPatient] = useState({ nom_complet: "", age: "", sexe: "M", telephone: "" });

  const loadData = async () => {
    try {
      const [recData, credData, patData, actData, prescData, prestData, assurData, catData, catPrestData] = await Promise.all([
        db.recettes.toArray(),
        db.creditsPatients.toArray(),
        db.patients_caisse.toArray(),
        db.prestations.toArray(),
        db.prescripteurs.toArray(),
        db.prestataires.toArray(),
        db.assurances.toArray().catch(() => []),
        db.categories.toArray().catch(() => []),
        db.categoriesPrestation.toArray().catch(() => [])
      ]);

      setRecettes(recData.reverse());
      setCredits(credData.reverse());
      setPatients(patData);

      // Liste vide par défaut : les vrais actes, catégories et prix doivent être créés dans Gestion des Actes.
      setActes(actData);

      setPrescripteurs(prescData);
      setPrestataires(prestData);
      setAssurances(assurData);
      setCategoriesActes([...(catPrestData || []), ...(catData || [])]);
    } catch (err) {
      console.error("Erreur de chargement de la caisse", err);
    }
  };

  useEffect(() => {
    loadData();
  }, []);

  // Calculations
  const totalJour = recettes
    .filter(r => new Date(r.date).toDateString() === new Date().toDateString())
    .reduce((acc, curr) => acc + curr.montant, 0);

  const totalCreditsEnCours = credits
    .filter(c => c.statut === "en_cours")
    .reduce((acc, curr) => acc + curr.montant_restant, 0);

  const selectedActe = actes.find(a => a.id === Number(form.acte_id));
  const assuranceSelectionnee = assurances.find(a => String(a.id) === String(form.assurance_id));
  const tauxPriseEnCharge = form.est_assure ? Math.max(0, Math.min(100, Number(assuranceSelectionnee?.taux_prise_en_charge || 0))) : 0;
  const montantBrutTicket = ticketActes.reduce((sum, item) => sum + Number(item.total || 0), 0);
  const montantAssurance = Math.round(montantBrutTicket * tauxPriseEnCharge / 100);
  const montantPatient = Math.max(0, montantBrutTicket - montantAssurance);
  const montantCalcule = montantBrutTicket;
  const acteAvecRistourne = ticketActes.some(a => Number(a.montant_ristourne || 0) > 0);
  const acteAvecRemuneration = ticketActes.some(a => Number(a.taux_remuneration || 0) > 0);

  const addActeToTicket = (acte: any) => {
    const qte = Math.max(1, Number(form.quantite) || 1);
    setTicketActes(prev => {
      const existing = prev.find(i => String(i.id) === String(acte.id));
      if (existing) {
        return prev.map(i => String(i.id) === String(acte.id)
          ? { ...i, quantite: Number(i.quantite || 1) + qte, total: (Number(i.quantite || 1) + qte) * Number(i.prix || 0) }
          : i
        );
      }
      return [...prev, {
        id: acte.id,
        nom: acte.nom,
        prix: Number(acte.prix || 0),
        quantite: qte,
        total: Number(acte.prix || 0) * qte,
        montant_ristourne: Number(acte.montant_ristourne || 0),
        taux_remuneration: Number(acte.taux_remuneration || 0)
      }];
    });
    setForm(prev => ({ ...prev, acte_id: String(acte.id), montant: Number(acte.prix || 0) }));
  };

  const updateTicketActeQty = (acteId: any, quantite: number) => {
    const qte = Math.max(1, Number(quantite) || 1);
    setTicketActes(prev => prev.map(i => String(i.id) === String(acteId) ? { ...i, quantite: qte, total: qte * Number(i.prix || 0) } : i));
  };

  const removeTicketActe = (acteId: any) => {
    setTicketActes(prev => prev.filter(i => String(i.id) !== String(acteId)));
  };

  const getCategorieNom = (categorieId: any) => {
    const cat = categoriesActes.find(c => String(c.id) === String(categorieId));
    return cat?.nom || (categorieId === 1 ? 'Consultations' : categorieId === 2 ? 'Laboratoire' : categorieId === 3 ? 'Imagerie' : categorieId === 4 ? 'Soins infirmiers' : 'Autres actes');
  };

  const actesGroupes = actes.reduce((acc: Record<string, any[]>, acte) => {
    const key = String(acte.categorie_id || acte.categorie || 'autres');
    if (!acc[key]) acc[key] = [];
    acc[key].push(acte);
    return acc;
  }, {});

  const printTicket = async (ticket: any) => {
    const printSettings = await getPrintSettings();
    const html = `<!doctype html><html><head><title>Ticket caisse</title><style>
      @page { size: A5 portrait; margin: 8mm; }
      body { font-family: Arial, sans-serif; font-size: 11px; line-height: 1.25; color:#111827; }
      .ticket { max-width: 390px; margin: 0 auto; border: 1px dashed #94a3b8; padding: 12px; }
      .print-logo-wrap { flex:0 0 auto; }
            .print-logo { width:52px; height:52px; object-fit:contain; display:block; }
            .print-header-main { flex:1; }
            .print-header-block { display:flex; align-items:center; justify-content:center; gap:8px; border-bottom: 1px solid #0f766e; padding-bottom: 6px; margin-bottom: 8px; text-align:center; }
      .print-clinic-name { font-size: 15px; font-weight: 800; color:#0f766e; text-transform:uppercase; }
      .print-clinic-sub, .print-custom-header { font-size: 9px; color:#475569; line-height:1.25; }
      .print-footer-block { border-top: 1px solid #94a3b8; margin-top: 12px; padding-top: 6px; text-align:center; font-size:9px; color:#475569; }
      .center { text-align:center; } .title { font-size:16px; font-weight:800; }
      .muted { color:#64748b; font-size:10px; } .row{display:flex; justify-content:space-between; gap:8px; margin:5px 0;}
      .sep{border-top:1px dashed #94a3b8; margin:10px 0;} .total{font-size:14px; font-weight:800;}
      table{width:100%;border-collapse:collapse;font-size:10px;margin-top:4px} th,td{border-bottom:1px solid #e2e8f0;padding:4px 2px} th{text-align:left;background:#f8fafc}.right{text-align:right}.center{text-align:center}
      @media print { button { display:none; } }
    </style></head><body><div class="ticket">
      ${renderPrintHeader(printSettings, 'Ticket de caisse')}
      <div class="sep"></div>
      <div class="row"><span>Reçu N°</span><b>#${String(ticket.id || '').padStart(6,'0')}</b></div>
      <div class="row"><span>Date</span><b>${new Date(ticket.date || ticket.created_at).toLocaleString('fr-FR')}</b></div>
      <div class="row"><span>Patient</span><b>${ticket.patient_nom || ''}</b></div>
      <div class="row"><span>Assuré</span><b>${ticket.est_assure ? 'Oui' : 'Non'}</b></div>
      ${ticket.est_assure ? `<div class="row"><span>Assurance</span><b>${ticket.assurance_nom || ''}</b></div>` : ''}
      ${ticket.prescripteur_nom ? `<div class="row"><span>Prescripteur</span><b>${ticket.prescripteur_nom}</b></div>` : ''}
      ${ticket.prestataire_nom ? `<div class="row"><span>Prestataire</span><b>${ticket.prestataire_nom}</b></div>` : ''}
      <div class="sep"></div>
      <table><thead><tr><th>Acte</th><th class="center">Qté</th><th class="right">PU</th><th class="right">Total</th></tr></thead><tbody>
        ${ticket.actes && ticket.actes.length ? ticket.actes.map((a:any) => `<tr><td>${a.nom || ''}</td><td class="center">${a.quantite || 1}</td><td class="right">${Number(a.prix || 0).toLocaleString()} F</td><td class="right"><b>${Number(a.total || 0).toLocaleString()} F</b></td></tr>`).join('') : `<tr><td>${ticket.libelle || 'Acte médical'}</td><td class="center">${ticket.quantite || 1}</td><td class="right">${Number(ticket.prix_unitaire || ticket.montant || 0).toLocaleString()} F</td><td class="right"><b>${Number(ticket.montant || 0).toLocaleString()} F</b></td></tr>`}
      </tbody></table>
      <div class="sep"></div>
      <div class="row"><span>Total brut</span><b>${Number(ticket.montant_brut || ticket.montant || 0).toLocaleString()} FCFA</b></div>
      ${ticket.est_assure ? `<div class="row"><span>Part assurance (${Number(ticket.taux_prise_en_charge || 0)}%)</span><b>${Number(ticket.montant_assurance || 0).toLocaleString()} FCFA</b></div>` : ''}
      <div class="row total"><span>À payer patient</span><span>${Number(ticket.montant_patient || ticket.montant || 0).toLocaleString()} FCFA</span></div>
      <div class="row muted"><span>Mode</span><span>${(ticket.mode_paiement || '').toUpperCase()}</span></div>
      ${renderPrintFooter(printSettings)}
    </div><script>window.onload=function(){window.print();}</script></body></html>`;
    const w = window.open('', '_blank', 'width=520,height=700');
    if (!w) { toast.error('Fenêtre d’impression bloquée'); return; }
    w.document.write(html); w.document.close();
  };

  const handleOpenTicket = (ticket: any) => {
    const patient = patients.find(p => p.id === ticket.patient_id);
    const prescripteur = prescripteurs.find(p => p.id === ticket.prescripteur_id);
    const prestataire = prestataires.find(p => p.id === ticket.prestataire_id);
    const prestation = actes.find(a => a.id === ticket.prestation_id);
    const assurance = assurances.find(a => a.id === ticket.assurance_id);

    setSelectedTicket({
      ...ticket,
      libelle: ticket.libelle || prestation?.nom || (ticket.actes || []).map((a:any) => a.nom).join(', '),
      prix_unitaire: prestation?.prix || ticket.prix_unitaire || ticket.montant,
      patient_nom: patient?.nom_complet || ticket.patient_nom,
      prescripteur_nom: prescripteur ? `Dr. ${prescripteur.prenom} ${prescripteur.nom}` : "",
      assurance_nom: assurance?.nom || ticket.assurance_nom || "",
      prestataire_nom: prestataire ? `${prestataire.prenom} ${prestataire.nom}` : ""
    });
    setIsTicketViewOpen(true);
  };

  const createPatient = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newPatient.nom_complet) {
      toast.error("Le nom du patient est obligatoire");
      return;
    }
    try {
      const pId = await db.patients_caisse.add({ 
        ...newPatient, 
        numero_patient: `CAI-${String(patients.length + 1).padStart(4, "0")}`,
        created_at: new Date()
      });
      toast.success("Patient ajouté à la liste caisse");
      setForm(prev => ({ ...prev, patient_id: String(pId) }));
      setShowNewPatient(false);
      setNewPatient({ nom_complet: "", age: "", sexe: "M", telephone: "" });
      loadData();
    } catch (err) {
      toast.error("Erreur de création du patient");
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!form.patient_id) {
      toast.error("Veuillez sélectionner un patient");
      return;
    }

    const qty = Number(form.quantite) || 1;
    const finalMontant = montantPatient;

    if (ticketActes.length === 0) {
      toast.error("Veuillez ajouter au moins un acte sur le ticket");
      return;
    }

    if (montantBrutTicket <= 0) {
      toast.error("Le montant total doit être supérieur à 0");
      return;
    }

    if (form.est_assure && !form.assurance_id) {
      toast.error("Veuillez sélectionner l'assurance");
      return;
    }
    if (acteAvecRistourne && !form.prescripteur_id) {
      toast.error("Veuillez sélectionner le prescripteur pour la ristourne");
      return;
    }
    if (acteAvecRemuneration && !form.prestataire_id) {
      toast.error("Veuillez sélectionner le prestataire à rémunérer");
      return;
    }

    const patient = patients.find(p => p.id === Number(form.patient_id));
    const patientNom = patient ? patient.nom_complet : "Patient Inconnu";
    const libelleActe = ticketActes.length === 1 ? ticketActes[0].nom : `${ticketActes.length} actes médicaux`;
    const assuranceNom = form.est_assure ? (assuranceSelectionnee?.nom || form.assurance_nom || '') : '';

    try {
      const recId = await db.recettes.add({
        patient_id: Number(form.patient_id),
        patient_nom: patientNom,
        prestation_id: ticketActes.length === 1 ? Number(ticketActes[0].id) : null,
        libelle: libelleActe,
        actes: ticketActes,
        montant_brut: montantBrutTicket,
        montant: finalMontant,
        montant_patient: montantPatient,
        montant_assurance: montantAssurance,
        taux_prise_en_charge: tauxPriseEnCharge,
        mode_paiement: form.mode_paiement,
        est_assure: form.est_assure,
        assurance_id: form.est_assure ? Number(form.assurance_id) : null,
        assurance_nom: assuranceNom,
        prescripteur_id: acteAvecRistourne ? Number(form.prescripteur_id) : null,
        prescripteur_nom: acteAvecRistourne ? (prescripteurs.find(p => p.id === Number(form.prescripteur_id)) ? `Dr. ${prescripteurs.find(p => p.id === Number(form.prescripteur_id))?.prenom || ''} ${prescripteurs.find(p => p.id === Number(form.prescripteur_id))?.nom || ''}`.trim() : '') : '',
        montant_ristourne: acteAvecRistourne ? ticketActes.reduce((sum, a) => sum + Number(a.montant_ristourne || 0) * Number(a.quantite || 1), 0) : 0,
        prestataire_id: acteAvecRemuneration ? Number(form.prestataire_id) : null,
        prestataire_nom: acteAvecRemuneration ? (prestataires.find(p => p.id === Number(form.prestataire_id)) ? `${prestataires.find(p => p.id === Number(form.prestataire_id))?.prenom || ''} ${prestataires.find(p => p.id === Number(form.prestataire_id))?.nom || ''}`.trim() : '') : '',
        montant_remuneration: acteAvecRemuneration ? ticketActes.reduce((sum, a) => sum + Math.round(Number(a.total || 0) * Number(a.taux_remuneration || 0) / 100), 0) : 0,
        date: new Date().toISOString(),
        created_at: new Date()
      });

      if (acteAvecRistourne) {
        for (const acte of ticketActes.filter(a => Number(a.montant_ristourne || 0) > 0)) {
          await db.ristournes.add({
            prescripteur_id: Number(form.prescripteur_id),
            prestation_id: Number(acte.id),
            recette_id: recId,
            montant: Number(acte.montant_ristourne || 0) * Number(acte.quantite || 1),
            mois: new Date().toISOString().slice(0, 7),
            statut_paiement: 'non_paye',
            created_at: new Date()
          });
        }
      }

      if (acteAvecRemuneration) {
        for (const acte of ticketActes.filter(a => Number(a.taux_remuneration || 0) > 0)) {
          await db.remunerations.add({
            prestataire_id: Number(form.prestataire_id),
            prestation_id: Number(acte.id),
            recette_id: recId,
            montant: Math.round(Number(acte.total || 0) * Number(acte.taux_remuneration || 0) / 100),
            mois: new Date().toISOString().slice(0, 7),
            statut_paiement: 'non_paye',
            created_at: new Date()
          });
        }
      }

      if (form.isCredit) {
        const avance = Number(form.montant_avance) || 0;
        const restant = finalMontant - avance;
        
        await db.creditsPatients.add({
          patient_id: Number(form.patient_id),
          patient_nom: patientNom,
          recette_id: recId,
          montant_total: finalMontant,
          montant_brut: montantBrutTicket,
          montant_assurance: montantAssurance,
          montant_avance: avance,
          montant_restant: restant,
          statut: restant <= 0 ? "paye" : "en_cours",
          date_credit: new Date().toISOString(),
          created_at: new Date()
        });
      }

      toast.success("Transaction enregistrée");
      setIsModalOpen(false);
      
      setTicketActes([]);
      setForm({
        id: 0,
        patient_id: "",
        acte_id: "",
        quantite: 1,
        montant: 0,
        mode_paiement: "especes",
        date: new Date().toISOString(),
        isCredit: false,
        montant_avance: 0,
        reference_paiement: "",
        est_assure: false,
        assurance_id: "",
        assurance_nom: "",
        prescripteur_id: "",
        prestataire_id: ""
      });

      loadData();
    } catch (err) {
      console.error(err);
      toast.error("Erreur de sauvegarde");
    }
  };

  return (
    <div className="space-y-4">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-lg bg-emerald-500 flex items-center justify-center">
            <Wallet className="w-5 h-5 text-white" />
          </div>
          <div>
            <h2 className="text-lg font-semibold">Caisse</h2>
            <p className="text-sm text-slate-500">
              {recettes.length} entrée(s) - Aujourd'hui: {totalJour.toLocaleString()} FCFA
            </p>
          </div>
        </div>
        <Button onClick={() => setIsModalOpen(true)} className="bg-teal-600 hover:bg-teal-700">
          <Plus className="w-4 h-4 mr-1" /> Nouvelle entrée
        </Button>
      </div>

      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        {/* Stats Cards */}
        <Card>
          <CardContent className="p-3">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-lg bg-emerald-100 text-emerald-600 flex items-center justify-center">
                <TrendingUp className="w-4 h-4" />
              </div>
              <div className="min-w-0">
                <p className="text-[10px] text-slate-500 uppercase font-semibold">Aujourd'hui</p>
                <p className="text-sm font-bold truncate">{totalJour.toLocaleString()} F</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-3">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-lg bg-blue-100 text-blue-600 flex items-center justify-center">
                <FileText className="w-4 h-4" />
              </div>
              <div className="min-w-0">
                <p className="text-[10px] text-slate-500 uppercase font-semibold">Total Entrées</p>
                <p className="text-sm font-bold truncate">{recettes.length} Recettes</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-3">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-lg bg-orange-100 text-orange-600 flex items-center justify-center">
                <AlertCircle className="w-4 h-4" />
              </div>
              <div className="min-w-0">
                <p className="text-[10px] text-slate-500 uppercase font-semibold">Crédits Actifs</p>
                <p className="text-sm font-bold truncate">{totalCreditsEnCours.toLocaleString()} F</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-3">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-lg bg-teal-100 text-teal-600 flex items-center justify-center">
                <CreditCard className="w-4 h-4" />
              </div>
              <div className="min-w-0">
                <p className="text-[10px] text-slate-500 uppercase font-semibold">Taux Recouvr.</p>
                <p className="text-sm font-bold truncate">
                  {recettes.length > 0 
                    ? Math.round(100 - (totalCreditsEnCours / (recettes.reduce((a, b) => a + b.montant, 0) || 1) * 100)) 
                    : 100}%
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="flex gap-1 bg-slate-100 dark:bg-slate-800 p-1 rounded-lg w-fit">
        <button 
          onClick={() => { setView("recettes"); setSearchTerm(""); }}
          className={`flex items-center gap-1.5 px-4 py-2 rounded-md text-xs font-semibold transition-colors ${view === "recettes" ? "bg-white shadow-sm text-slate-900" : "text-slate-600"}`}
        >
          <Wallet className="w-3.5 h-3.5" /> Recettes
        </button>
        <button 
          onClick={() => { setView("credits"); setSearchTerm(""); }}
          className={`flex items-center gap-1.5 px-4 py-2 rounded-md text-xs font-semibold transition-colors ${view === "credits" ? "bg-white shadow-sm text-slate-900" : "text-slate-600"}`}
        >
          <CreditCard className="w-3.5 h-3.5" /> Crédits ({credits.filter(c => c.statut === "en_cours").length})
        </button>
      </div>

      {view === "recettes" ? (
        <div className="space-y-3">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
            <Input 
              placeholder="Rechercher par patient ou par libellé..." 
              value={searchTerm} 
              onChange={(e) => setSearchTerm(e.target.value)} 
              className="pl-10" 
            />
          </div>
          
          <Card className="p-0 overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead className="bg-slate-50 border-b">
                  <tr>
                    <th className="text-left py-3 px-4 font-semibold">Date / Heure</th>
                    <th className="text-left py-3 px-4 font-semibold">Patient</th>
                    <th className="text-left py-3 px-4 font-semibold">Prestation / Acte</th>
                    <th className="text-right py-3 px-4 font-semibold">Montant</th>
                    <th className="text-left py-3 px-4 font-semibold">Mode</th>
                    <th className="text-center py-3 px-4 font-semibold">Facture</th>
                  </tr>
                </thead>
                <tbody>
                  {recettes.filter(r => 
                    r.patient_nom?.toLowerCase().includes(searchTerm.toLowerCase()) ||
                    r.libelle?.toLowerCase().includes(searchTerm.toLowerCase())
                  ).length === 0 ? (
                    <tr>
                      <td colSpan={6} className="text-center py-8 text-slate-400">Aucune recette trouvée</td>
                    </tr>
                  ) : (
                    recettes.filter(r => 
                      r.patient_nom?.toLowerCase().includes(searchTerm.toLowerCase()) ||
                      r.libelle?.toLowerCase().includes(searchTerm.toLowerCase())
                    ).map(r => (
                      <tr key={r.id} className="border-b hover:bg-slate-50 transition-colors">
                        <td className="py-2.5 px-4 text-xs text-slate-500">
                          {new Date(r.date || r.created_at).toLocaleString('fr-FR')}
                        </td>
                        <td className="py-2.5 px-4 font-medium">{r.patient_nom}</td>
                        <td className="py-2.5 px-4 text-slate-700">{r.libelle}</td>
                        <td className="py-2.5 px-4 text-right font-bold text-emerald-600">
                          {r.montant.toLocaleString('fr-FR')} FCFA
                        </td>
                        <td className="py-2.5 px-4">
                          <span className="inline-block px-1.5 py-0.5 rounded text-[10px] bg-slate-100 text-slate-700 capitalize">
                            {r.mode_paiement?.replace('_', ' ')}
                          </span>
                        </td>
                        <td className="py-2.5 px-4 text-center">
                          <Button 
                            variant="ghost" 
                            size="sm" 
                            onClick={() => handleOpenTicket(r)}
                            title="Visualiser le reçu"
                            className="text-indigo-600 hover:text-indigo-800"
                          >
                            <FileText className="w-4 h-4" />
                          </Button>
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          </Card>
        </div>
      ) : (
        <div className="space-y-3">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
            <Input 
              placeholder="Rechercher crédit par patient..." 
              value={searchTerm} 
              onChange={(e) => setSearchTerm(e.target.value)} 
              className="pl-10" 
            />
          </div>

          <Card className="p-0 overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead className="bg-slate-50 border-b">
                  <tr>
                    <th className="text-left py-3 px-4 font-semibold">Date du crédit</th>
                    <th className="text-left py-3 px-4 font-semibold">Patient</th>
                    <th className="text-right py-3 px-4 font-semibold">Total Dû</th>
                    <th className="text-right py-3 px-4 font-semibold">Avance versée</th>
                    <th className="text-right py-3 px-4 font-semibold">Montant restant</th>
                    <th className="text-left py-3 px-4 font-semibold">Statut</th>
                    <th className="text-center py-3 px-4 font-semibold">Action</th>
                  </tr>
                </thead>
                <tbody>
                  {credits.filter(c => 
                    c.patient_nom?.toLowerCase().includes(searchTerm.toLowerCase())
                  ).length === 0 ? (
                    <tr>
                      <td colSpan={7} className="text-center py-8 text-slate-400">Aucun historique de crédit actif</td>
                    </tr>
                  ) : (
                    credits.filter(c => 
                      c.patient_nom?.toLowerCase().includes(searchTerm.toLowerCase())
                    ).map(c => (
                      <tr key={c.id} className="border-b hover:bg-slate-50 transition-colors">
                        <td className="py-2.5 px-4 text-xs text-slate-500">
                          {new Date(c.date_credit || c.created_at).toLocaleDateString('fr-FR')}
                        </td>
                        <td className="py-2.5 px-4 font-semibold">{c.patient_nom}</td>
                        <td className="py-2.5 px-4 text-right font-medium">
                          {c.montant_total?.toLocaleString()} F
                        </td>
                        <td className="py-2.5 px-4 text-right text-slate-500">
                          {c.montant_avance?.toLocaleString()} F
                        </td>
                        <td className="py-2.5 px-4 text-right font-bold text-red-600">
                          {c.montant_restant?.toLocaleString()} F
                        </td>
                        <td className="py-2.5 px-4">
                          <span className={`inline-block px-1.5 py-0.5 rounded text-[10px] font-medium ${c.statut === 'paye' ? 'bg-emerald-100 text-emerald-800' : 'bg-red-100 text-red-800'}`}>
                            {c.statut === 'paye' ? 'Réglé' : 'Non payé'}
                          </span>
                        </td>
                        <td className="py-2.5 px-4 text-center">
                          {c.statut !== 'paye' ? (
                            <Button
                              size="sm"
                              className="bg-amber-600 hover:bg-amber-700 text-white text-[10px] h-7 px-2.5"
                              onClick={async () => {
                                if (confirm("Confirmer le règlement intégral de ce crédit ?")) {
                                  try {
                                    await db.creditsPatients.update(c.id, {
                                      montant_avance: c.montant_total,
                                      montant_restant: 0,
                                      statut: "paye"
                                    });
                                    toast.success("Crédit soldé avec succès");
                                    loadData();
                                  } catch (err) {
                                    toast.error("Erreur technique");
                                  }
                                }
                              }}
                            >
                              Solder crédit
                            </Button>
                          ) : (
                            <span className="text-[11px] text-slate-400">Aucun</span>
                          )}
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          </Card>
        </div>
      )}

      {/* 1. Modal overlay for registering a new sale */}
      {isModalOpen && (
        <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4">
          <div className="bg-white dark:bg-slate-800 rounded-lg shadow-xl max-w-2xl w-full max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between p-4 border-b">
              <h3 className="text-base font-bold text-slate-800 dark:text-white">Créer une transaction financière</h3>
              <button onClick={() => { setIsModalOpen(false); setShowNewPatient(false); }} className="p-1 hover:bg-slate-100 rounded">
                <X className="w-5 h-5" />
              </button>
            </div>

            {showNewPatient ? (
              <form onSubmit={createPatient} className="p-4 space-y-3">
                <div className="border-l-2 border-teal-500 pl-2 bg-slate-50 p-2 text-xs text-slate-600">
                  Ajout rapide d'un patient à la caisse
                </div>
                <div className="space-y-1">
                  <Label>Nom Complet *</Label>
                  <Input 
                    placeholder="Jean-Luc Camara" 
                    value={newPatient.nom_complet}
                    onChange={e => setNewPatient({ ...newPatient, nom_complet: e.target.value })}
                    required
                  />
                </div>
                <div className="space-y-1">
                  <Label>Téléphone</Label>
                  <Input 
                    placeholder="Ex: +223 75456575" 
                    value={newPatient.telephone}
                    onChange={e => setNewPatient({ ...newPatient, telephone: e.target.value })}
                  />
                </div>
                <div className="grid grid-cols-2 gap-2">
                  <div className="space-y-1">
                    <Label>Âge</Label>
                    <Input 
                      placeholder="Ex: 12 ans" 
                      value={newPatient.age}
                      onChange={e => setNewPatient({ ...newPatient, age: e.target.value })}
                    />
                  </div>
                  <div className="space-y-1">
                    <Label>Sexe</Label>
                    <select
                      value={newPatient.sexe}
                      onChange={e => setNewPatient({ ...newPatient, sexe: e.target.value })}
                      className="w-full h-10 border rounded px-3 text-xs"
                    >
                      <option value="M">Homme</option>
                      <option value="F">Femme</option>
                    </select>
                  </div>
                </div>
                <div className="flex justify-end gap-2 pt-2">
                  <Button type="button" variant="outline" size="sm" onClick={() => setShowNewPatient(false)}>Annuler</Button>
                  <Button type="submit" size="sm" className="bg-teal-600 text-white hover:bg-teal-700">Créer le patient</Button>
                </div>
              </form>
            ) : (
              <form onSubmit={handleSubmit} className="p-4 space-y-3">
                <div className="space-y-1">
                  <div className="flex justify-between items-center">
                    <Label>Patient bénéficiaire *</Label>
                    <button 
                      type="button" 
                      onClick={() => setShowNewPatient(true)}
                      className="text-[10px] text-teal-600 hover:underline font-semibold"
                    >
                      + Nouveau patient
                    </button>
                  </div>
                  <select
                    value={form.patient_id}
                    onChange={e => setForm({ ...form, patient_id: e.target.value })}
                    className="w-full h-10 rounded border bg-transparent px-3 text-sm"
                    required
                  >
                    <option value="">Sélectionner le patient...</option>
                    {patients.map(p => (
                      <option key={p.id} value={String(p.id)}>{p.nom_complet}</option>
                    ))}
                  </select>
                </div>

                <div className="grid grid-cols-2 gap-2">
                  <div className="space-y-1 col-span-2">
                    <Label>Prestation / Acte par catégorie *</Label>
                    <div className="rounded border bg-slate-50 p-2 space-y-2 max-h-56 overflow-y-auto">
                      {Object.keys(actesGroupes).length === 0 && (
                        <div className="text-xs text-slate-500 p-3 bg-white rounded border">Aucun acte enregistré. Ajoutez vos vraies catégories, actes et prix dans Gestion des Actes.</div>
                      )}
                      {Object.entries(actesGroupes).map(([catId, list]) => (
                        <div key={catId} className="border rounded bg-white overflow-hidden">
                          <button
                            type="button"
                            onClick={() => setExpandedCategorieId(expandedCategorieId === catId ? '' : catId)}
                            className="w-full px-3 py-2 text-left text-xs font-bold text-slate-700 bg-slate-100 hover:bg-slate-200 flex justify-between"
                          >
                            <span>{getCategorieNom(catId)}</span>
                            <span>{expandedCategorieId === catId ? '−' : '+'}</span>
                          </button>
                          {expandedCategorieId === catId && (
                            <div className="p-2 grid grid-cols-1 gap-1">
                              {list.map((a:any) => (
                                <button
                                  key={a.id}
                                  type="button"
                                  onClick={() => addActeToTicket(a)}
                                  className={`text-left px-2 py-1.5 rounded text-xs border ${ticketActes.some(i => String(i.id) === String(a.id)) ? 'bg-teal-50 border-teal-400 text-teal-800 font-bold' : 'bg-white hover:bg-slate-50'}`}
                                >
                                  {a.nom} <span className="text-slate-500">({Number(a.prix || 0).toLocaleString()} F)</span>
                                </button>
                              ))}
                            </div>
                          )}
                        </div>
                      ))}
                    </div>
                    {!form.acte_id && <p className="text-[10px] text-red-500">Choisissez un acte dans une catégorie.</p>}
                  </div>
                  <div className="space-y-1">
                    <Label>Quantité</Label>
                    <Input
                      type="number"
                      min={1}
                      value={form.quantite}
                      onChange={e => setForm({ ...form, quantite: Number(e.target.value) || 1 })}
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-2">
                  <div className="space-y-1">
                    <Label>Total brut</Label>
                    <Input type="number" value={montantBrutTicket} disabled className="bg-slate-100 font-bold text-indigo-700" />
                  </div>
                  <div className="space-y-1">
                    <Label>Part assurance</Label>
                    <Input type="number" value={montantAssurance} disabled className="bg-blue-50 font-bold text-blue-700" />
                  </div>
                  <div className="space-y-1">
                    <Label>À payer par patient</Label>
                    <Input type="number" value={montantPatient} disabled className="bg-emerald-50 font-bold text-emerald-700" />
                  </div>
                </div>

                <div className="space-y-1">
                  <Label>Mode de paiement</Label>
                  <select
                    value={form.mode_paiement}
                    onChange={e => setForm({ ...form, mode_paiement: e.target.value })}
                    className="w-full h-10 rounded border bg-transparent px-3 text-sm"
                  >
                    <option value="especes">Espèces</option>
                    <option value="orange_money">Orange Money</option>
                    <option value="moov_money">Moov Money</option>
                    <option value="carte_bancaire">Carte Bancaire</option>
                    <option value="assurance">Prise en charge Assurance</option>
                  </select>
                </div>

                <div className="bg-blue-50 dark:bg-slate-700 p-2.5 rounded border border-blue-100 space-y-2">
                  <div className="flex items-center gap-2">
                    <input
                      type="checkbox"
                      id="est_assure"
                      checked={form.est_assure}
                      onChange={e => setForm({ ...form, est_assure: e.target.checked, assurance_id: e.target.checked ? form.assurance_id : "" })}
                      className="rounded text-blue-600"
                    />
                    <Label htmlFor="est_assure" className="text-xs cursor-pointer font-bold text-blue-700 dark:text-blue-200">Patient assuré</Label>
                  </div>
                  {form.est_assure && (
                    <div className="space-y-1">
                      <Label className="text-[10px]">Nom de l'assurance *</Label>
                      <select
                        value={form.assurance_id}
                        onChange={e => setForm({ ...form, assurance_id: e.target.value })}
                        className="w-full h-9 rounded border bg-white dark:bg-slate-800 px-3 text-xs"
                        required={form.est_assure}
                      >
                        <option value="">Sélectionner une assurance...</option>
                        {assurances.filter(a => a.statut !== 'inactif').map(a => <option key={a.id} value={String(a.id)}>{a.nom} — {Number(a.taux_prise_en_charge || 0)}%</option>)}
                      </select>
                      {form.assurance_id && <p className="text-[10px] text-blue-700 dark:text-blue-200">Prise en charge : {tauxPriseEnCharge}% — Assurance: {montantAssurance.toLocaleString()} F — Patient: {montantPatient.toLocaleString()} F</p>}
                      {assurances.length === 0 && <p className="text-[10px] text-red-500">Créez d'abord les assurances dans la page Assurances.</p>}
                    </div>
                  )}
                </div>

                {(acteAvecRistourne || acteAvecRemuneration) && (
                  <div className="bg-amber-50 dark:bg-slate-700 p-2.5 rounded border border-amber-100 space-y-2">
                    {acteAvecRistourne && (
                      <div className="space-y-1">
                        <Label className="text-[10px]">Prescripteur / Ristourne *</Label>
                        <select
                          value={form.prescripteur_id}
                          onChange={e => setForm({ ...form, prescripteur_id: e.target.value })}
                          className="w-full h-9 rounded border bg-white dark:bg-slate-800 px-3 text-xs"
                        >
                          <option value="">Sélectionner le prescripteur...</option>
                          {prescripteurs.filter(p => p.statut !== 'inactif').map(p => <option key={p.id} value={String(p.id)}>Dr. {p.prenom} {p.nom}</option>)}
                        </select>
                        <p className="text-[10px] text-slate-500">Ristourne prévue : {Number((selectedActe?.montant_ristourne || 0) * form.quantite).toLocaleString()} FCFA</p>
                      </div>
                    )}
                    {acteAvecRemuneration && (
                      <div className="space-y-1">
                        <Label className="text-[10px]">Prestataire / Rémunération *</Label>
                        <select
                          value={form.prestataire_id}
                          onChange={e => setForm({ ...form, prestataire_id: e.target.value })}
                          className="w-full h-9 rounded border bg-white dark:bg-slate-800 px-3 text-xs"
                        >
                          <option value="">Sélectionner le prestataire...</option>
                          {prestataires.filter(p => p.statut !== 'inactif').map(p => <option key={p.id} value={String(p.id)}>{p.prenom} {p.nom}</option>)}
                        </select>
                        <p className="text-[10px] text-slate-500">Rémunération prévue : {Math.round(montantCalcule * Number(selectedActe?.taux_remuneration || 0) / 100).toLocaleString()} FCFA</p>
                      </div>
                    )}
                  </div>
                )}

                {/* Credit checkbox */}
                <div className="bg-slate-50 p-2.5 rounded border border-slate-200 space-y-2 mt-2">
                  <div className="flex items-center gap-2">
                    <input 
                      type="checkbox" 
                      id="isCredit"
                      checked={form.isCredit}
                      onChange={e => setForm({ ...form, isCredit: e.target.checked })}
                      className="rounded text-teal-600 focus:ring-teal-500"
                    />
                    <Label htmlFor="isCredit" className="text-xs cursor-pointer text-amber-700 font-bold">
                      Enregistrer comme crédit / Impayé
                    </Label>
                  </div>

                  {form.isCredit && (
                    <div className="space-y-1 pt-1.5 border-t">
                      <Label className="text-[10px]">Acompte / Avance reçue (FCFA)</Label>
                      <Input 
                        type="number" 
                        min={0}
                        placeholder="0"
                        value={form.montant_avance}
                        onChange={e => setForm({ ...form, montant_avance: Number(e.target.value) || 0 })}
                        className="bg-white h-8 text-xs"
                      />
                    </div>
                  )}
                </div>

                <div className="flex justify-end gap-2 pt-3 border-t">
                  <Button type="button" variant="outline" onClick={() => setIsModalOpen(false)}>Annuler</Button>
                  <Button type="submit" className="bg-emerald-600 text-white hover:bg-emerald-700">
                    Valider le Paiement
                  </Button>
                </div>
              </form>
            )}
          </div>
        </div>
      )}

      {/* 2. Receipt Pop-up Viewer */}
      {isTicketViewOpen && selectedTicket && (
        <div className="fixed inset-0 bg-black/60 z-50 flex items-center justify-center p-4">
          <div className="bg-white dark:bg-slate-900 rounded-lg shadow-2xl max-w-sm w-full p-6 space-y-4 font-mono text-xs border border-indigo-100">
            <div className="text-center border-b pb-4 space-y-1">
              <h4 className="font-bold text-base tracking-wider text-slate-800">CLINIQUE DJAKAN</h4>
              <p className="text-[10px] text-slate-500">Service de Caisse & Facturation</p>
              <p className="text-[9px] text-slate-400">Tel: +223 76 00 00 00 / Bamako</p>
            </div>

            <div className="space-y-1 text-[11px]">
              <p><span className="text-slate-500">REÇU N°:</span> #{selectedTicket.id?.toString().padStart(6, '0')}</p>
              <p><span className="text-slate-500">DATE:</span> {new Date(selectedTicket.date || selectedTicket.created_at).toLocaleString()}</p>
              <p><span className="text-slate-500">PATIENT:</span> <strong className="text-slate-800 uppercase">{selectedTicket.patient_nom}</strong></p>
            </div>

            <div className="space-y-1 text-[10px] bg-slate-50 p-2 rounded border">
              <p><span className="text-slate-500">ASSURÉ:</span> <strong>{selectedTicket.est_assure ? 'OUI' : 'NON'}</strong></p>
              {selectedTicket.est_assure && <p><span className="text-slate-500">ASSURANCE:</span> <strong>{selectedTicket.assurance_nom}</strong></p>}
              {selectedTicket.prescripteur_nom && <p><span className="text-slate-500">PRESCRIPTEUR:</span> <strong>{selectedTicket.prescripteur_nom}</strong></p>}
              {selectedTicket.prestataire_nom && <p><span className="text-slate-500">PRESTATAIRE:</span> <strong>{selectedTicket.prestataire_nom}</strong></p>}
            </div>

            <div className="border-t border-b py-3 space-y-2">
              <div className="flex justify-between font-bold">
                <span>DÉSIGNATION</span>
                <span>TOTAL</span>
              </div>
              {(selectedTicket.actes && selectedTicket.actes.length > 0) ? selectedTicket.actes.map((a:any) => (
                <div key={a.id} className="flex justify-between text-slate-700 gap-2">
                  <span className="truncate max-w-[200px]">{a.nom} x {a.quantite}</span>
                  <span>{Number(a.total || 0).toLocaleString()} F</span>
                </div>
              )) : (
                <div className="flex justify-between text-slate-700">
                  <span className="truncate max-w-[200px]">{selectedTicket.libelle || "Acte Médical"}</span>
                  <span>{selectedTicket.montant?.toLocaleString()} F</span>
                </div>
              )}
            </div>

            <div className="space-y-4">
              <div className="space-y-1 text-[11px]">
                <div className="flex justify-between"><span>Total brut</span><b>{Number(selectedTicket.montant_brut || selectedTicket.montant || 0).toLocaleString()} FCFA</b></div>
                {selectedTicket.est_assure && <div className="flex justify-between text-blue-700"><span>Part assurance ({Number(selectedTicket.taux_prise_en_charge || 0)}%)</span><b>{Number(selectedTicket.montant_assurance || 0).toLocaleString()} FCFA</b></div>}
                <div className="flex justify-between items-center text-sm font-bold border-l-4 border-teal-500 pl-2 pt-1">
                  <span>À PAYER PATIENT</span>
                  <span className="text-teal-700">{Number(selectedTicket.montant_patient || selectedTicket.montant || 0).toLocaleString()} FCFA</span>
                </div>
              </div>

              <div className="text-[9px] text-slate-400 border-t pt-3 flex justify-between">
                <span>Mode: {selectedTicket.mode_paiement?.toUpperCase()}</span>
                <span>Opérateur: Guichet Caisse</span>
              </div>
            </div>

            <div className="flex justify-end gap-1.5 pt-2">
              <Button 
                variant="outline" 
                size="sm" 
                onClick={() => setIsTicketViewOpen(false)}
                className="h-8 text-[11px]"
              >
                Fermer
              </Button>
              <Button 
                variant="default" 
                size="sm" 
                onClick={() => printTicket(selectedTicket)}
                className="bg-slate-800 text-white h-8 text-[11px]"
              >
                Imprimer Ticket
              </Button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default Caisse;