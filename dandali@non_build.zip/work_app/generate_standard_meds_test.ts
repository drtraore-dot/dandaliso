import { medicationsSeed } from './src/data/medicationData';
import { dciData } from './src/data/dciData';
import { specialtiesData } from './src/data/specialtiesData';
import { consumablesData } from './src/data/consumablesData';

function generateStandardDatabase() {
  const list: any[] = [];
  
  // 1. Add medicationsSeed
  medicationsSeed.forEach((m, idx) => {
    list.push({
      nom_medicament: m.brandName || m.dci,
      dci: m.dci,
      dosage: m.dosage || "N/A",
      categorie: m.classTherapeutic || "Général",
      forme: m.form || "Comprimé",
      fournisseur: m.manufacturer || "N/A",
      quantite: Math.floor((idx * 7) % 350) + 50,
      quantite_min: 20,
      prix_achat: Math.floor((idx * 13) % 4500) + 150,
      prix_vente: Math.floor((idx * 13) % 4500) + 300,
      emplacement: `Rayon ${String.fromCharCode(65 + (idx % 26))}-${(idx % 10) + 1}`,
      created_at: new Date().toISOString()
    });
  });

  // 2. Expand specialtiesData
  let specIdx = 0;
  specialtiesData.forEach((spec) => {
    spec.specialties.forEach((brand) => {
      list.push({
        nom_medicament: brand.brandName || spec.dci,
        dci: spec.dci,
        dosage: spec.dosage || "N/A",
        categorie: spec.classTherapeutic || "Général",
        forme: spec.form || "Comprimé",
        fournisseur: brand.manufacturer || "N/A",
        quantite: Math.floor((specIdx * 7) % 350) + 50,
        quantite_min: 20,
        prix_achat: Math.floor((specIdx * 13) % 4500) + 150,
        prix_vente: Math.floor((specIdx * 13) % 4500) + 300,
        emplacement: `Rayon ${String.fromCharCode(65 + (specIdx % 26))}-${(specIdx % 10) + 1}`,
        created_at: new Date().toISOString()
      });
      specIdx++;
    });
  });

  // 3. Add dciData
  dciData.forEach((m, idx) => {
    list.push({
      nom_medicament: m.brandName || m.dci,
      dci: m.dci,
      dosage: m.dosage || "N/A",
      categorie: m.classTherapeutic || "Général",
      forme: m.form || "Comprimé",
      fournisseur: m.manufacturer || "N/A",
      quantite: Math.floor((idx * 9) % 300) + 50,
      quantite_min: 20,
      prix_achat: Math.floor((idx * 11) % 4000) + 200,
      prix_vente: Math.floor((idx * 11) % 4000) + 400,
      emplacement: `Rayon ${String.fromCharCode(65 + ((idx + 5) % 26))}-${((idx + 3) % 10) + 1}`,
      created_at: new Date().toISOString()
    });
  });

  // 4. Add consumablesData
  consumablesData.forEach((m, idx) => {
    list.push({
      nom_medicament: m.brandName,
      dci: m.dci,
      dosage: m.dosage || "N/A",
      categorie: m.classTherapeutic || "Consommables & Matériels",
      forme: m.form || "Unité",
      fournisseur: m.manufacturer || "N/A",
      quantite: Math.floor((idx * 12) % 400) + 100,
      quantite_min: 30,
      prix_achat: Math.floor((idx * 15) % 3000) + 50,
      prix_vente: Math.floor((idx * 15) % 3000) + 100,
      emplacement: `Rayon M-${(idx % 15) + 1}`,
      created_at: new Date().toISOString()
    });
  });

  return list;
}

const list = generateStandardDatabase();
console.log('Total generated medications database list:', list.length);
console.log('First generated element:', list[0]);
console.log('Random generated element (index 5000):', list[5000]);
