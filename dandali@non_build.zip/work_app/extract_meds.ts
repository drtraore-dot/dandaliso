import AdmZip from 'adm-zip';
import path from 'path';
import fs from 'fs';

try {
  const zip = new AdmZip(path.resolve('base_offline.zip'));
  
  // Ensure target folder exists
  const targetDir = path.resolve('src/data');
  if (!fs.existsSync(targetDir)) {
    fs.mkdirSync(targetDir, { recursive: true });
  }
  
  const filesToExtract = [
    { src: 'app/src/data/consumablesData.ts', dest: 'src/data/consumablesData.ts' },
    { src: 'app/src/data/dciData.ts', dest: 'src/data/dciData.ts' },
    { src: 'app/src/data/medicationData.ts', dest: 'src/data/medicationData.ts' },
    { src: 'app/src/data/specialtiesData.ts', dest: 'src/data/specialtiesData.ts' }
  ];
  
  for (const item of filesToExtract) {
    const entry = zip.getEntry(item.src);
    if (entry) {
      const content = entry.getData().toString('utf8');
      fs.writeFileSync(path.resolve(item.dest), content);
      console.log(`Successfully extracted and saved: ${item.dest} (${content.length} characters)`);
    } else {
      console.warn(`Could not find entry ${item.src} in the zip`);
    }
  }
} catch (e) {
  console.error('Error extracting data:', e);
}
