const fs = require('fs');
const path = require('path');
const { pathToFileURL } = require('url');
const { app, BrowserWindow, ipcMain, clipboard, dialog } = require('electron');
const license = require('./license.cjs');

// Evite certaines pages blanches liées au GPU sur quelques PC Windows anciens.
app.commandLine.appendSwitch('disable-gpu');
app.commandLine.appendSwitch('disable-gpu-compositing');

let mainWindow;

function findIndexHtml() {
  const candidates = [
    path.join(app.getAppPath(), 'dist', 'index.html'),
    path.join(app.getAppPath(), 'index.html'),
    path.join(process.resourcesPath || '', 'app', 'dist', 'index.html'),
    path.join(process.resourcesPath || '', 'app', 'index.html'),
    path.join(__dirname, '..', 'dist', 'index.html'),
    path.join(__dirname, '..', 'index.html')
  ];

  for (const file of candidates) {
    try {
      if (file && fs.existsSync(file)) return file;
    } catch (_) {}
  }

  return candidates[0];
}

function createWindow() {
  mainWindow = new BrowserWindow({
    width: 1280,
    height: 820,
    minWidth: 1024,
    minHeight: 700,
    title: 'DANDALI@NET',
    backgroundColor: '#f8fafc',
    autoHideMenuBar: true,
    show: false,
    webPreferences: {
      preload: path.join(__dirname, 'preload.cjs'),
      nodeIntegration: false,
      contextIsolation: true,
      sandbox: false,
      webSecurity: false
    }
  });

  mainWindow.once('ready-to-show', () => {
    mainWindow.show();
  });

  mainWindow.webContents.on('did-fail-load', (_event, errorCode, errorDescription, validatedURL) => {
    dialog.showErrorBox('Erreur de chargement DANDALI@NET', `Code: ${errorCode}\n${errorDescription}\n${validatedURL}`);
  });

  mainWindow.webContents.on('render-process-gone', (_event, details) => {
    dialog.showErrorBox('Erreur DANDALI@NET', `Le processus d'affichage a quitté : ${details.reason}`);
  });

  // En cas de page blanche, cette ligne permet de voir l'erreur exacte avec :
  // set DANDALI_DEBUG=1 puis lancer le .exe depuis PowerShell.
  if (process.env.DANDALI_DEBUG === '1') {
    mainWindow.webContents.openDevTools({ mode: 'detach' });
  }

  if (!app.isPackaged && process.env.NODE_ENV === 'development') {
    mainWindow.loadURL('http://localhost:3000');
  } else {
    const indexPath = findIndexHtml();
    mainWindow.loadURL(pathToFileURL(indexPath).toString());
  }
}

ipcMain.handle('license:getStatus', () => license.getLicenseStatus(app));
ipcMain.handle('license:activate', (_event, licenseKey) => license.activate(app, licenseKey));

ipcMain.handle('print:saveHtmlAsPdf', async (_event, html) => {
  const pdfWindow = new BrowserWindow({
    show: false,
    webPreferences: { sandbox: false, contextIsolation: true }
  });
  try {
    await pdfWindow.loadURL('data:text/html;charset=utf-8,' + encodeURIComponent(String(html || '')));
    const pdfData = await pdfWindow.webContents.printToPDF({
      printBackground: true,
      pageSize: 'A4',
      margins: { marginType: 'default' }
    });
    const result = await dialog.showSaveDialog(mainWindow, {
      title: 'Enregistrer en PDF',
      defaultPath: `document-${new Date().toISOString().slice(0,10)}.pdf`,
      filters: [{ name: 'PDF', extensions: ['pdf'] }]
    });
    if (!result.canceled && result.filePath) {
      fs.writeFileSync(result.filePath, pdfData);
      return { ok: true, path: result.filePath };
    }
    return { ok: false, canceled: true };
  } finally {
    if (!pdfWindow.isDestroyed()) pdfWindow.close();
  }
});

ipcMain.handle('license:copyMachineCode', (_event, machineCode) => {
  clipboard.writeText(String(machineCode || ''));
  return { ok: true };
});

app.whenReady().then(createWindow);

app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') app.quit();
});

app.on('activate', () => {
  if (BrowserWindow.getAllWindows().length === 0) createWindow();
});
