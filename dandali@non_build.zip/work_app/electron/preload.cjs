const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('DANDALI_LICENSE', {
  getStatus: () => ipcRenderer.invoke('license:getStatus'),
  activate: (licenseKey) => ipcRenderer.invoke('license:activate', licenseKey),
  copyMachineCode: (machineCode) => ipcRenderer.invoke('license:copyMachineCode', machineCode)
});


contextBridge.exposeInMainWorld('DANDALI_PRINT', {
  saveHtmlAsPdf: (html) => ipcRenderer.invoke('print:saveHtmlAsPdf', html)
});
