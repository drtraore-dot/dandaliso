import fs from 'fs';
import https from 'https';
import path from 'path';

const url = 'https://raw.githubusercontent.com/drtraore-dot/base8medica/main/Kimi_Agent_Base%20M%C3%A9dicamenteuse%20Offline.zip';
const dest = path.resolve('base_offline.zip');

console.log('Downloading Zip from GitHub...');
const file = fs.createWriteStream(dest);
https.get(url, (response) => {
  response.pipe(file);
  file.on('finish', () => {
    file.close();
    console.log('Download finished.');
  });
}).on('error', (err) => {
  fs.unlink(dest, () => {});
  console.error('Error downloading:', err);
});
