import AdmZip from 'adm-zip';
import path from 'path';

try {
  const zip = new AdmZip(path.resolve('base_offline.zip'));
  const zipEntries = zip.getEntries();
  
  console.log('Zip file contains ' + zipEntries.length + ' entries:');
  for (const entry of zipEntries) {
    console.log(`- ${entry.entryName} (${entry.header.size} bytes)`);
  }
} catch (e) {
  console.error('Error reading zip:', e);
}
