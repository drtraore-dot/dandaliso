const { spawn } = require('child_process');

const isWin = process.platform === 'win32';

function run(command, args = [], options = {}) {
  const child = spawn(command, args, {
    stdio: 'inherit',
    shell: isWin,
    windowsHide: false,
    ...options,
  });

  child.on('error', (error) => {
    console.error(`Erreur lancement ${command}:`, error.message);
  });

  return child;
}

// 1) Lance le serveur Vite sur le port 3000
const vite = run(isWin ? 'npm.cmd' : 'npm', ['run', 'dev:web']);

// 2) Attend que Vite démarre, puis lance Electron
setTimeout(() => {
  const env = { ...process.env, NODE_ENV: 'development' };
  run(isWin ? 'npx.cmd' : 'npx', ['electron', '.'], { env });
}, 6000);

process.on('SIGINT', () => {
  try { vite.kill('SIGINT'); } catch (_) {}
  process.exit(0);
});
