const crypto = require('crypto');

// IMPORTANT : gardez exactement le même secret que dans electron/license.cjs
const LICENSE_SECRET = 'DANDALI-NET-CHANGEZ-CE-SECRET-AVANT-COMPILATION-2026';

function makeLicenseKey(machineCode) {
  const cleanCode = String(machineCode || '').trim().toUpperCase();
  const digest = crypto
    .createHmac('sha256', LICENSE_SECRET)
    .update(cleanCode)
    .digest('hex')
    .toUpperCase();

  return [digest.slice(0, 5), digest.slice(5, 10), digest.slice(10, 15), digest.slice(15, 20), digest.slice(20, 25)].join('-');
}

const machineCode = process.argv.slice(2).join(' ').trim();

if (!machineCode) {
  console.log('Usage : node scripts/generate-license.cjs DN-XXXX-XXXX-XXXX-XXXX-XXXX');
  process.exit(1);
}

console.log(makeLicenseKey(machineCode));
